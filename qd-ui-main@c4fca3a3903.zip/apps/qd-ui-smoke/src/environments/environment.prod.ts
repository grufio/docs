export const environment = {
  production: true
};

export const appEnvironment = {
  production: true,
  BACKEND_SERVICE_API: '',
  CONFIGURATION_PATH: ''
};
