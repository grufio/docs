export const environment = {
  production: false
};

export const appEnvironment = {
  production: true,
  BACKEND_SERVICE_API: '',
  CONFIGURATION_PATH: ''
};
