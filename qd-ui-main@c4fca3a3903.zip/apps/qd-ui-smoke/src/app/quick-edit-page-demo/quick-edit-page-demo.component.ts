import { Component } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { QdFormControl, QdPageConfig, QdSectionConfig } from '../../../../../libs/qd-ui/src';
import { QdQuickEditConfig } from '../../../../../libs/qd-ui/src/lib/quick-edit/model/quick-edit-config';

type MyColumnsDefinition = 'rubrik' | 'size' | 'data' | 'active';

@Component({
  selector: 'quick-edit-demo',
  templateUrl: 'quick-edit-page-demo.component.html',
  styleUrls: ['quick-edit-page-demo.component.scss']
})
export class QuickEditPageDemoComponent {
  pageConfig: QdPageConfig = {
    pageType: 'inspect',
    title: {
      i18n: 'Quick Edit'
    },
    pageTypeConfig: {
      submit: {
        handler: () => console.log('My Handler')
      },
      cancel: {
        handler: () => console.log('My Handler')
      }
    }
  };

  config: QdQuickEditConfig<MyColumnsDefinition> = {
    columns: [
      {
        name: 'rubrik',
        type: 'text',
        i18n: 'Rubrik',
        isEditable: () => true
      },
      {
        name: 'data',
        type: 'text',
        i18n: 'Positionen',
        isEditable: () => true
      },
      {
        name: 'size',
        type: 'integer',
        i18n: 'Nummer',
        isHidden: true,
        isEditable: () => true
      },
      {
        name: 'active',
        type: 'integer',
        i18n: 'Status',
        isEditable: (row, column) => true
      }
    ],
    secondaryActions: [
      { label: { i18n: 'Save' }, handler: rowData => console.log('Save handler', rowData) },
      {
        label: { i18n: 'Delete' },
        handler: rowData => console.log('Delete handler', rowData)
      }
    ],
    emptyStateView: {
      i18n: 'Es sind noch keine Inhalte verfügbar.'
    }
  };

  form = new FormGroup({
    data: new FormArray([
      new FormGroup({
        rubrik: new QdFormControl('Schienenverkehr'),
        data: new QdFormControl(12),
        size: new QdFormControl(31),
        active: new QdFormControl(1)
      }),
      new FormGroup({
        rubrik: new QdFormControl('Flugfracht'),
        data: new QdFormControl(999),
        size: new QdFormControl(2005),
        active: new QdFormControl(1)
      }),
      new FormGroup({
        rubrik: new QdFormControl('LKW'),
        data: new QdFormControl(999),
        size: new QdFormControl(2005),
        active: new QdFormControl(0)
      })
    ])
  });

  sectionConfig: QdSectionConfig = {
    actions: [
      {
        type: 'addNew'
      }
    ]
  };

  submit(data: any): void {
    console.log('Received submitted form data: ', data);
    // For optimistic locking
    // this.data = data.rows;
  }
}
