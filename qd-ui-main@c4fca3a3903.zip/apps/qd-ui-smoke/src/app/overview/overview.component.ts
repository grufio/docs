import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { QD_TABLE_DATA_RESOLVER_TOKEN, QdSectionConfig, QdTableConfig } from '../../../../../libs/qd-ui/src';
import { QdPageConfig } from '../../../../../libs/qd-ui/src/lib/page/model/page-config.interface';
import { Constellation, TableConstellationResolver } from '../app-home.component';

@Component({
  selector: 'qd-ui-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss'],
  providers: [
    {
      provide: QD_TABLE_DATA_RESOLVER_TOKEN,
      useClass: TableConstellationResolver
    }
  ]
})
export class OverviewComponent {
  pageConfig: QdPageConfig = {
    pageType: 'overview',
    title: {
      i18n: 'Aktuelle Vorgänge'
    },
    pageTypeConfig: {
      customActions: [
        {
          label: {
            i18n: 'Vorgang erstellen'
          },
          handler: () => this.router.navigateByUrl('/create')
        },
        {
          label: {
            i18n: 'Vorgang anschauen'
          },
          handler: () => this.router.navigateByUrl('/inspect')
        },
        {
          label: {
            i18n: 'home'
          },
          handler: () => this.router.navigateByUrl('/')
        }
      ]
    }
  };

  sectionConfig: QdSectionConfig = {
    title: {
      i18n: 'Section Title'
    }
  };

  tableConfig: QdTableConfig<Constellation> = {
    columns: [
      {
        column: 'abbr',
        type: 'text'
      }
    ],
    pagination: {
      pageSizes: [10, 20, 50],
      pageSizeDefault: 10
    },
    whichColumnFillsWidth: 'main'
  };

  constructor(private router: Router) {}
}
