import { HttpClient, HttpClientModule } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { APP_ENVIRONMENT, QdDialogService, QdSectionModule, QdUiModule } from '../../../../libs/qd-ui/src';

import { CdkStepperModule } from '@angular/cdk/stepper';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { QdContextService } from '../../../../libs/qd-ui/src/lib/page/shared/services/context.service';
import { appEnvironment } from '../environments/environment';
import { AppHomeComponent } from './app-home.component';
import { AppComponent } from './app.component';
import { ContextDialogComponent } from './ContextDialog/context-dialog.component';
import { CustomComponent } from './custom/custom.component';
import { OverviewComponent } from './overview/overview.component';
import { CreateComponent } from './page-types/create.component';
import { InspectComponent } from './page-types/inspect.component';
import { QuickEditDemoComponent } from './quick-edit-demo/quick-edit-demo.component';
import { QuickEditPageDemoComponent } from './quick-edit-page-demo/quick-edit-page-demo.component';
import { QuickEditWithDataComponent } from './quick-edit-with-data/quick-edit-with-data.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

function initializeContexts(contextService: QdContextService, dialog: QdDialogService) {
  contextService.initContexts([
    {
      id: 'typeOfTraffic',
      label: { i18n: 'Verkehrsart' },
      type: 'single',
      options: [
        {
          value: 'rail',
          label: { i18n: 'Schiene' }
        },
        {
          value: 'air',
          label: { i18n: 'Luft' }
        }
      ]
    },
    {
      id: 'customsOffice',
      label: { i18n: 'Zollstelle' },
      type: 'multi',
      options: [
        {
          value: '1234',
          label: { i18n: 'Basel' }
        },
        {
          value: '5678',
          label: { i18n: 'Weil am Rhein' }
        }
      ]
    },
    {
      id: 'Custom',
      label: { i18n: 'Custom Test' },
      type: 'custom',
      open: () => dialog.open(ContextDialogComponent, {})
    }
  ]);
}

@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    AppHomeComponent,
    InspectComponent,
    OverviewComponent,
    CustomComponent,
    QuickEditDemoComponent,
    QuickEditPageDemoComponent,
    QuickEditWithDataComponent,
    CustomComponent,
    ContextDialogComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    CdkStepperModule,
    QdSectionModule,
    QdUiModule.forRoot(appEnvironment),
    StoreModule.forRoot({}),
    StoreDevtoolsModule.instrument({
      name: 'QdUiSmokeTest'
    }),
    RouterModule.forRoot([
      {
        path: '',
        component: AppHomeComponent,
        data: { hasPortal: true, isInternal: true, isHome: true }
      },
      {
        path: 'create',
        component: CreateComponent,
        data: {
          hasPortal: true,
          isInternal: true,
          previousHref: routeComponent => routeComponent.navigateToHome()
        }
      },
      {
        path: 'inspect/:id/:ref',
        component: InspectComponent,
        data: {
          hasPortal: true,
          isInternal: true,
          previousHref: routeComponent => routeComponent.navigateToHome()
        }
      },
      {
        path: 'overview',
        component: OverviewComponent
      },
      {
        path: 'custom',
        component: CustomComponent
      },
      {
        path: 'quick-edit',
        component: QuickEditDemoComponent
      },
      {
        path: 'quick-edit-page',
        component: QuickEditPageDemoComponent
      },
      {
        path: 'quick-edit-with-data',
        component: QuickEditWithDataComponent
      }
    ]),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [
    {
      provide: APP_ENVIRONMENT,
      useValue: appEnvironment
    },
    {
      provide: APP_INITIALIZER,
      useFactory: (contextService: QdContextService, dialogService: QdDialogService) => () =>
        initializeContexts(contextService, dialogService),
      multi: true,
      deps: [QdContextService, QdDialogService]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
