import { Component } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormGroup, ValidationErrors, Validators } from '@angular/forms';

import { delay, map, Observable, of } from 'rxjs';
import {
  QD_PAGE_STEP_RESOLVER_TOKEN,
  QdFormControl,
  QdFormGroup,
  QdGridConfig,
  QdPageStepConfig,
  QdPageStepperConfig,
  QdPageStepResolver,
  QdSectionConfig,
  QdValidators
} from '../../../../../libs/qd-ui/src';
import { QdFormInputConfiguration } from '../../../../../libs/qd-ui/src/lib/forms/model/forms.interface';
import { QdPageConfig } from '../../../../../libs/qd-ui/src/lib/page/model/page-config.interface';

export interface SamplePageObject {
  name: string;
  value: number;
  createdAt: string;
  city: string;
  updates: { label: string; value: string }[];
}

const PAGE_CONFIG: QdPageConfig<SamplePageObject> = {
  title: {
    i18n: 'PageType: Create with MultiStep (Wizard)'
  },
  pageType: 'create',
  pageTypeConfig: {
    submit: {
      handler: params => console.log(params)
    },
    cancel: {
      handler: params => console.log(params)
    },
    customActions: [
      {
        label: {
          i18n: 'Action 1'
        },
        handler: () => console.log('Action 1')
      },
      {
        label: {
          i18n: 'Action 2'
        },
        handler: () => console.log('Action 2')
      }
    ]
  },
  customActionsLabel: {
    i18n: 'Meine Aktionen'
  }
};

const STEP_ONE_CONFIG = {
  label: { i18n: 'i18n.qd.stepper.step.one' },
  isEditable: true,
  isOptional: false
};

const STEP_TWO_CONFIG = {
  label: { i18n: 'i18n.qd.stepper.step.two' },
  isEditable: true,
  isOptional: false
};

const SECTION_CONFIG = {
  title: {
    i18n: 'i18n.qd.exampleSection.title'
  }
};

function asyncValidator(): AsyncValidatorFn {
  return (control: AbstractControl): Observable<ValidationErrors | null> => {
    if (!control.value) {
      // If control is empty, return null (no errors)
      return of(null);
    }

    return of(['Peter', 'Max'].some(a => a === control.value)).pipe(
      delay(1000),
      map((result: boolean) => (result ? { usernameAlreadyExists: true } : null))
    );
  };
}

const GRID_CONFIG = { columns: 6, columnsMax: 4 };

class PageStepResolver implements QdPageStepResolver {
  resolve(index: number): Observable<void> {
    console.log(index);
    return of();
  }
}

@Component({
  selector: 'qd-ui-page-create',
  templateUrl: './create.component.html',
  providers: [
    {
      provide: QD_PAGE_STEP_RESOLVER_TOKEN,
      useClass: PageStepResolver
    }
  ]
})
export class CreateComponent {
  pageConfig = PAGE_CONFIG as QdPageConfig<SamplePageObject>;
  stepOneConfig = STEP_ONE_CONFIG as QdPageStepConfig;
  stepTwoConfig = STEP_TWO_CONFIG as QdPageStepConfig;
  sectionConfig = SECTION_CONFIG as QdSectionConfig;
  gridConfig = GRID_CONFIG as QdGridConfig;

  personalInfos = new QdFormGroup({
    firstName: new QdFormControl('Hans', [QdValidators.required()]),
    lastName: new QdFormControl('Peter', [QdValidators.minLength(3)])
  });

  contactInfoForm = new FormGroup({
    email: new QdFormControl('example@example.com', [QdValidators.required(), QdValidators.email()]),
    phone: new QdFormControl('1234567890', [
      QdValidators.required(),
      QdValidators.minLength(10),
      QdValidators.pattern(/^\d+$/)
    ]),
    address: new QdFormControl('Spitalgasse 1, 3011 Bern', [QdValidators.required()])
  });

  firstNameConfig: QdFormInputConfiguration = { label: { i18n: 'First name' } };
  lastNameConfig: QdFormInputConfiguration = { label: { i18n: 'Last name' } };
  ageConfig: QdFormInputConfiguration = { label: { i18n: 'Minimum age: 18' } };

  emailConfig: QdFormInputConfiguration = { label: { i18n: 'Email address' } };
  phoneConfig: QdFormInputConfiguration = { label: { i18n: 'Phone number' } };
  addressConfig: QdFormInputConfiguration = { label: { i18n: 'Address' } };

  myStepperConfig: QdPageStepperConfig = {
    next: {
      i18n: 'Next',
      handler: () => console.log('My Custom Handler')
    },
    submit: { i18n: 'Complete' },
    cancel: { i18n: 'Cancel' },
    previous: {
      i18n: 'Previous',
      handler: () => console.log('My Custom Previous Handler')
    }
  };

  myFirstFormGroup = this.createFormGroup();

  mySecondFormGroup = new FormGroup({
    firstName: new QdFormControl(''),
    lastName: new QdFormControl(),
    age: new QdFormControl()
  });

  myThirdFormGroup = this.createFormGroup();

  createFormGroup() {
    return new FormGroup({
      firstName: new QdFormControl('', [Validators.required]),
      lastName: new QdFormControl(),
      age: new QdFormControl()
    });
  }

  myFirstStepConfig: QdPageStepConfig = {
    label: { i18n: 'One' },
    isEditable: true,
    isOptional: false
  };
  mySecondStepConfig: QdPageStepConfig = { label: { i18n: 'Two' } };
  myThirdStepConfig: QdPageStepConfig = { label: { i18n: 'Three' } };
  myFourthStepConfig: QdPageStepConfig = { label: { i18n: 'Four' }, isOptional: false };

  complete(): void {
    console.log('I come from Step 1. You call me by clicking on Save or Next!');
  }

  navigateToHome() {
    return '';
  }
}
