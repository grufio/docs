import { Component, Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BehaviorSubject, map, Observable, timer } from 'rxjs';
import {
  QD_PAGE_OBJECT_RESOLVER_TOKEN,
  QdFormControl,
  QdPageObjectResolver,
  QdPageObjectResolverConfig,
  QdPageTabConfig,
  QdPageTabsConfig,
  QdSectionConfig,
  QdValidators
} from '../../../../../libs/qd-ui/src';
import {
  QdFormCheckboxesConfiguration,
  QdFormDatepickerConfiguration,
  QdFormDropdownConfiguration,
  QdFormInputConfiguration,
  QdFormMultiInputConfiguration,
  QdFormPinCodeConfiguration,
  QdFormRadioButtonsConfiguration,
  QdFormSwitchesConfiguration,
  QdFormTextAreaConfiguration,
  QdRichtextConfig
} from '../../../../../libs/qd-ui/src/lib/forms/model/forms.interface';
import { QdPageConfig } from '../../../../../libs/qd-ui/src/lib/page/model/page-config.interface';
import { SamplePageObject } from '../../../../../shared/sample-page-object-resolver';

@Injectable()
export class InspectPageObjectResolver implements QdPageObjectResolver<SamplePageObject> {
  config: QdPageObjectResolverConfig = {
    triggerOn: 'queryParamsChange'
  };

  resolve(): Observable<any> {
    return timer(1000);
  }
}

@Component({
  selector: 'qd-ui-page-inspect',
  templateUrl: './inspect.component.html',
  providers: [
    {
      provide: QD_PAGE_OBJECT_RESOLVER_TOKEN,
      useClass: InspectPageObjectResolver
    }
  ]
})
export class InspectComponent {
  showSubmitButton$: BehaviorSubject<boolean> = new BehaviorSubject(false);

  pageConfig$: Observable<QdPageConfig<SamplePageObject>> = this.showSubmitButton$.pipe(
    map(showSubmitButton => ({
      title: {
        i18n: 'Pagetype - inspect'
      },
      pageType: 'inspect',
      pageTypeConfig: {
        operationMode: 'view',
        submit: {
          label: { i18n: 'submit' },
          handler: formValues => console.log('My Submit handler with form value:', formValues),
          isHidden: !showSubmitButton
        },
        customActions: [
          {
            label: {
              i18n: 'Action 1'
            },
            handler: () => console.log('My Action 1 Handler')
          },
          {
            label: {
              i18n: 'Edit'
            },
            handler: () => console.log('My Edit Handler')
          }
        ],
        delete: {
          handler: formValues => console.log('My delete handler with form value:', formValues)
        },
        edit: {
          handler: formValues => console.log('My Edit handler with form value:', formValues)
        },
        archive: {
          handler: () => console.log('My archive handler with form value:')
        },
        cancel: {
          handler: formValues => console.log('My cancel handler with form value:', formValues)
        }
      },
      headerFacets: [
        {
          name: 'name',
          label: { i18n: 'Name' },
          options: { type: 'value' }
        }
      ]
    }))
  );

  complete(): void {
    console.log('I come from Step 1. You call me by clicking on Save or Next!');
  }

  myFirstFormGroup = this.createFormGroup();

  TABS_CONFIG: QdPageTabsConfig = {
    submitButton: { i18n: 'Abschicken' }
  };

  TAB_ONE_CONFIG: QdPageTabConfig = {
    label: { i18n: 'i18n.qd.stepper.step.one' }
  };

  SECTION_CONFIG: QdSectionConfig = {
    title: {
      i18n: 'i18n.qd.exampleSection.title'
    }
  };

  firstNameConfig: QdFormInputConfiguration = { label: { i18n: 'First name' }, readonly: true };
  lastNameConfig: QdFormInputConfiguration = { label: { i18n: 'Last name' } };

  // tagsConfig: QdFormMultiInputConfiguration = {
  //   label: { i18n: 'Schlagwörter' },
  //   options: [
  //     { i18n: 'i18n.qd.options.apple', value: 'AP', disabled: true },
  //     { i18n: 'i18n.qd.options.lemon', value: 'LM' },
  //     { i18n: 'i18n.qd.options.lime', value: 'LI' },
  //     { i18n: 'i18n.qd.options.yellowWatermelon', value: 'YW' },
  //     { i18n: 'i18n.qd.options.pomegranate', value: 'PG' },
  //     { i18n: 'i18n.qd.options.orange', value: 'OR' },
  //     { i18n: 'i18n.qd.options.strawberry', value: 'SB' }
  //   ]
  // };

  get tagsConfig(): QdFormMultiInputConfiguration {
    return {
      label: { i18n: 'Schlagwörter' },
      options: [
        { i18n: 'i18n.qd.options.apple', value: 'AP', disabled: true },
        { i18n: 'i18n.qd.options.lemon', value: 'LM' },
        { i18n: 'i18n.qd.options.lime', value: 'LI' },
        { i18n: 'i18n.qd.options.yellowWatermelon', value: 'YW' },
        { i18n: 'i18n.qd.options.pomegranate', value: 'PG' },
        { i18n: 'i18n.qd.options.orange', value: 'OR' },
        { i18n: 'i18n.qd.options.strawberry', value: 'SB' }
      ]
    };
  }
  datepickerConfig: QdFormDatepickerConfiguration = { label: { i18n: 'Age' } };
  dropdownConfig: QdFormDropdownConfiguration = {
    label: { i18n: 'Gender ' },
    options: [
      { i18n: 'male', value: 'M' },
      { i18n: 'female', value: 'F' },
      { i18n: 'diverse', value: 'D' }
    ]
  };
  descriptionConfig: QdFormTextAreaConfiguration = {
    label: { i18n: 'Description' }
  };
  checkboxesConfig: QdFormCheckboxesConfiguration = {
    label: { i18n: 'Checkboxes' },
    options: [{ i18n: 'i18n.rule.output', value: 'ABC' }]
  };

  radioButtonsConfig: QdFormRadioButtonsConfiguration = {
    label: { i18n: 'Radio Buttons' },
    options: [
      { i18n: 'i18n.rule.output', value: 'ABC' },
      { i18n: 'i18n.rule.output', value: 'def' }
    ]
  };

  switchesConfig: QdFormSwitchesConfiguration = {
    label: { i18n: 'Switches' },
    options: [{ i18n: 'Aktiv', value: 'true' }]
  };

  pincodeConfig: QdFormPinCodeConfiguration = {
    label: { i18n: 'PIN Code' }
  };

  richtextConfig: QdRichtextConfig = {
    label: { i18n: 'Richtext' }
  };

  constructor(private router: Router) {}

  goToId123RefXyz() {
    this.router.navigate(['/inspect', '123', 'xyz']);
  }

  goToId456RefXyz() {
    this.router.navigate(['/inspect', '456', 'xyz']);
  }

  goToId123RefAbcWithQuery() {
    this.router.navigate(['/inspect', '123', 'abc'], { queryParams: { filter: 'active' } });
  }

  goToId123RefDefWithInactiveQuery() {
    this.router.navigate(['/inspect', '123', 'def'], { queryParams: { filter: 'inactive' } });
  }

  goToId123RefDefWithActiveQuery() {
    this.router.navigate(['/inspect', '123', 'def'], { queryParams: { filter: 'active' } });
  }

  goToId123RefXyzWithActiveQuery() {
    this.router.navigate(['/inspect', '123', 'xyz'], { queryParams: { filter: 'active' } });
  }

  goToId456RefXyzWithInactiveQuery() {
    this.router.navigate(['/inspect', '456', 'xyz'], { queryParams: { filter: 'inactive' } });
  }

  goToId789RefXyzWithOptionalParams() {
    this.router.navigate(['/inspect', '789', 'xyz'], { queryParams: { optional: 'test' } });
  }

  patchValue(): void {
    this.showSubmitButton$.next(!this.showSubmitButton$.value);
  }

  private createFormGroup() {
    return new FormGroup({
      firstName: new QdFormControl(''),
      lastName: new QdFormControl('', [Validators.required]),
      tags: new QdFormControl(['LM']),
      age: new QdFormControl(new Date(), QdValidators.date()),
      gender: new FormControl('M'),
      description: new FormControl('Some description'),
      checkboxes: new FormControl(['ABC']),
      radiobuttons: new FormControl('ABC'),
      switches: new FormControl('true'),
      pinCode: new FormControl()
    });
  }
}
