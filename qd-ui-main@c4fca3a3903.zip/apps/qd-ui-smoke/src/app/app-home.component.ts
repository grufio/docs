import { Component, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { delay, Observable, of } from 'rxjs';

import {
  QD_TABLE_DATA_RESOLVER_TOKEN,
  QdFilterConfigData,
  QdNotificationsService,
  QdSortDirection,
  QdTableConfig,
  QdTableDataResolver,
  QdTableResolvedData
} from '../../../../libs/qd-ui/src';
import { QdPageConfig } from '../../../../libs/qd-ui/src/lib/page/model/page-config.interface';
import { QD_PAGE_OBJECT_RESOLVER_TOKEN } from '../../../../libs/qd-ui/src/lib/page/model/page-object-resolver';
import { QdSearchOptions } from '../../../../libs/qd-ui/src/lib/search/model/search-options.interface';
import { QdSectionConfig } from '../../../../libs/qd-ui/src/lib/section/model/section-config.interface';
import { SamplePageObject, SamplePageObjectResolver } from '../../../../shared/sample-page-object-resolver';
import { database, searchData, sortData } from './helpers/app-home.helpers.and.data';

export type Constellation = 'abbr' | 'name' | 'genitive' | 'en';

@Injectable()
export class TableConstellationResolver implements QdTableDataResolver<Constellation> {
  constructor(private notificationService: QdNotificationsService) {}

  resolve({ page, size, sort, filter, search, context }): Observable<QdTableResolvedData<Constellation>> {
    this.notificationService.add('', {
      type: 'success',
      i18n: 'Performs a resolver call',
      lifeTime: 2,
      showAsSnackbar: true
    });

    let data = database;
    let totalElements = data.length;

    if (filter?.categories[0]) {
      data = data.filter(constellation => constellation.name === 'Aquarius');
      totalElements = data.length;
    }

    if (search) {
      data = searchData(data, search.phrase);
    }

    totalElements = data.length;

    if (sort) data = sortData(data, sort);

    const startIndex = page * size;
    const endIndex = startIndex + size;
    data = data.slice(startIndex, endIndex);

    return of({
      data,
      page,
      size,
      totalElements
    } as any).pipe(delay(Math.floor(Math.random() * (700 - 500 + 1) + 500)));
  }
}

@Component({
  selector: 'qd-ui-app-home',
  templateUrl: './app-home.component.html',
  providers: [
    {
      provide: QD_TABLE_DATA_RESOLVER_TOKEN,
      useClass: TableConstellationResolver
    },
    {
      provide: QD_PAGE_OBJECT_RESOLVER_TOKEN,
      useClass: SamplePageObjectResolver
    }
  ]
})
export class AppHomeComponent {
  pageConfig: QdPageConfig<SamplePageObject> = {
    title: {
      i18n: 'Custom Page'
    },
    headerFacets: [
      {
        name: 'name',
        label: {
          i18n: 'Name'
        },
        options: {
          type: 'value'
        }
      },
      {
        name: 'city',
        label: {
          i18n: 'Stadt'
        },
        options: {
          type: 'singleSelect',
          action: {
            label: { i18n: 'Ändern' },
            handler: () => alert('Stadt ändern')
          }
        }
      },
      {
        name: 'updates',
        label: {
          i18n: 'Name'
        },
        options: {
          type: 'multiSelect',
          action: {
            label: { i18n: 'Ändern' },
            handler: () => alert('Stadt ändern')
          }
        }
      },
      {
        name: 'name',
        label: {
          i18n: 'Name'
        },
        options: {
          type: 'status',
          state: {
            Peter: 'success'
          }
        }
      },
      {
        name: 'name',
        label: {
          i18n: 'Name'
        },
        options: {
          type: 'value'
        }
      },
      {
        name: 'name',
        label: {
          i18n: 'Name'
        },
        options: {
          type: 'value'
        }
      },
      {
        name: 'createdAt',
        label: {
          i18n: 'Erstellt am'
        },
        options: {
          type: 'date',
          showIcon: true
        }
      },
      {
        name: 'priority',
        label: {
          i18n: 'Wichtigkeit'
        },
        options: {
          type: 'criticality'
        }
      },
      {
        name: 'furtherLinks',
        label: {
          i18n: 'Weitere Ressourcen'
        },
        options: {
          type: 'references'
        }
      },
      {
        name: 'progress',
        label: {
          i18n: 'Fortschritt'
        },
        options: {
          type: 'progress'
        }
      }
    ],
    pageType: 'custom',
    pageTypeConfig: {}
  };

  sectionConfig: QdSectionConfig = {
    title: {
      i18n: 'Paste in "aquarius" to see how this works'
    },
    action: {
      i18n: 'Create',
      icon: 'plus'
    }
  };

  tableConfig: QdTableConfig<Constellation> = {
    columns: [
      {
        column: 'abbr',
        type: 'text',
        sort: {
          direction: QdSortDirection.ASC
        }
      },
      {
        column: 'name',
        type: 'text',
        sort: {}
      },
      {
        column: 'genitive',
        type: 'text'
      },
      {
        column: 'en',
        type: 'text'
      }
    ],
    pagination: {
      pageSizes: [3, 5],
      pageSizeDefault: 3
    },
    whichColumnFillsWidth: 'main',
    uid: 'STAR-CONSTELLATIONS'
  };

  searchConfig: QdSearchOptions = {};

  filterConfig: QdFilterConfigData = {
    categories: [
      {
        type: 'boolean',
        category: 'controlObject',
        i18n: 'i18n.qd.exampleFilterData.category.isAquarius',
        items: [{ item: 'aquarius', active: true }]
      }
    ]
  };

  constructor(private router: Router) {}

  createNew() {
    this.router.navigateByUrl('/create');
  }
}
