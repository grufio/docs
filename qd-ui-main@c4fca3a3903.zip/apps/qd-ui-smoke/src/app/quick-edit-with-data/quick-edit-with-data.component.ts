import { Component } from '@angular/core';
import { AbstractControl, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { QdQuickEditConfig, QdQuickEditData } from '../../../../../libs/qd-ui/src';

type MyColumnsDefinition = 'rubrik' | 'size' | 'data' | 'active' | 'active2';

export function activeOrInactiveValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const isValid = control.value == 'active' || control.value == 'inactive';
    return isValid ? null : { notOneOrTwo: true };
  };
}

@Component({
  selector: 'qd-ui-quick-edit-with-data',
  templateUrl: './quick-edit-with-data.component.html',
  styleUrl: './quick-edit-with-data.component.scss'
})
export class QuickEditWithDataComponent {
  config: QdQuickEditConfig<MyColumnsDefinition> = {
    columns: [
      {
        name: 'rubrik',
        type: 'text',
        i18n: 'Rubrik',
        isEditable: (row, column) => true
      },
      {
        name: 'active',
        type: 'enum',
        i18n: 'Status',
        isEditable: (row, column) => true,
        validators: [activeOrInactiveValidator()],
        options: [
          {
            i18n: 'aktiv',
            value: 'active'
          },
          {
            i18n: 'inaktiv',
            value: 'inactive'
          }
        ],
        placeholder: { i18n: 'TEST' },
        filter: true
      },
      {
        name: 'active2',
        type: 'enum',
        i18n: 'Status',
        isEditable: (row, column) => true,
        validators: [activeOrInactiveValidator()],
        options: [
          {
            i18n: 'aktiv',
            value: 'active'
          },
          {
            i18n: 'inaktiv',
            value: 'inactive'
          }
        ],
        placeholder: { i18n: 'TEST' },
        filter: true
      },

      {
        name: 'data',
        type: 'text',
        i18n: 'Positionen',
        isEditable: (row, column) => row['active'] == 1,
        validators: [Validators.max(1000)]
      },
      {
        name: 'size',
        type: 'integer',
        i18n: 'Nummer',
        isEditable: (row, column) => row[column] === 31 || row[column] === null,
        validators: [Validators.required]
      }
    ],
    secondaryActions: [
      { label: { i18n: 'Save' }, handler: rowData => console.log('Save handler', rowData) },
      {
        label: { i18n: 'Delete' },
        handler: rowData => console.log('Delete handler', rowData)
      }
    ],
    canAdd: true
  };

  data: QdQuickEditData<MyColumnsDefinition> = [
    {
      rubrik: 'Schienenverkehr',
      data: 12,
      size: 31,
      active: 'active',
      active2: 'active'
    },
    {
      rubrik: 'Flugfracht',
      data: 999,
      size: 2005,
      active: 'active',
      active2: 'active'
    },
    {
      rubrik: 'LKW',
      data: 999,
      size: 2005,
      active: 'inactive',
      active2: 'active'
    },
    {
      rubrik: 'Space X',
      data: 999,
      size: 2005,
      active: 'active',
      active2: 'active'
    },
    {
      rubrik: 'Schiff',
      data: 999,
      size: 31,
      active: null,
      active2: 'active'
    }
  ];

  submit(data: any): void {}

  log(data: any): void {
    console.log(data);
  }
}
