import { ComponentFixture, TestBed } from '@angular/core/testing';
import { QuickEditWithDataComponent } from './quick-edit-with-data.component';

describe('QuickEditWithDataComponent', () => {
  let component: QuickEditWithDataComponent;
  let fixture: ComponentFixture<QuickEditWithDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuickEditWithDataComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(QuickEditWithDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
