import { Component } from '@angular/core';
import { AbstractControl, FormArray, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { QdFormControl, QdValidators } from '../../../../../libs/qd-ui/src';
import { QdQuickEditConfig } from '../../../../../libs/qd-ui/src/lib/quick-edit/model/quick-edit-config';
import { QdQuickEditData } from '../../../../../libs/qd-ui/src/lib/quick-edit/model/quick-edit-data';

type MyColumnsDefinition = 'rubrik' | 'size' | 'data' | 'active' | 'active2';

export function activeOrInactiveValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const isValid = control.value == 'active' || control.value == 'inactive';
    return isValid ? null : { notOneOrTwo: true };
  };
}

@Component({
  selector: 'quick-edit-demo',
  templateUrl: 'quick-edit-demo.component.html',
  styleUrls: ['quick-edit-demo.component.scss']
})
export class QuickEditDemoComponent {
  config: QdQuickEditConfig<MyColumnsDefinition> = {
    columns: [
      {
        name: 'rubrik',
        type: 'text',
        i18n: 'Rubrik',
        isEditable: (row, column) => true
      },
      {
        name: 'active',
        type: 'enum',
        i18n: 'Status',
        isEditable: (row, column) => true,
        validators: [activeOrInactiveValidator()],
        options: [
          {
            i18n: 'aktiv',
            value: 'active'
          },
          {
            i18n: 'inaktiv',
            value: 'inactive'
          }
        ],
        placeholder: { i18n: 'TEST' },
        filter: true
      },
      {
        name: 'active2',
        type: 'enum',
        i18n: 'Status',
        isEditable: (row, column) => true,
        validators: [activeOrInactiveValidator()],
        options: [
          {
            i18n: 'aktiv',
            value: 'active'
          },
          {
            i18n: 'inaktiv',
            value: 'inactive'
          }
        ],
        placeholder: { i18n: 'TEST' },
        filter: true
      },

      {
        name: 'data',
        type: 'text',
        i18n: 'Positionen',
        isEditable: (row, column) => row['active'] == 1,
        validators: [Validators.max(1000)]
      },
      {
        name: 'size',
        type: 'integer',
        i18n: 'Nummer',
        isEditable: (row, column) => row[column] === 31 || row[column] === null,
        validators: [Validators.required]
      }
    ],
    secondaryActions: [
      { label: { i18n: 'Save' }, handler: rowData => console.log('Save handler', rowData) },
      {
        label: { i18n: 'Delete' },
        handler: rowData => console.log('Delete handler', rowData)
      }
    ],
    canAdd: true
  };

  form = new FormGroup({
    control: new FormArray(
      [
        new FormGroup({
          rubrik: new QdFormControl('Schienenverkehr', [QdValidators.minLength(5)]),
          data: new QdFormControl(12),
          size: new QdFormControl(31),
          active: new QdFormControl('active'),
          active2: new QdFormControl('active')
        }),
        new FormGroup({
          rubrik: new QdFormControl('Flugfracht', [Validators.minLength(10)]),
          data: new QdFormControl(12),
          size: new QdFormControl(31),
          active: new QdFormControl('active'),
          active2: new QdFormControl('active')
        })
      ],
      [Validators.minLength(3)]
    )
  });

  data: QdQuickEditData<MyColumnsDefinition> = [
    {
      rubrik: 'Schienenverkehr',
      data: 12,
      size: 31,
      active: 'active',
      active2: 'active'
    },
    {
      rubrik: 'Flugfracht',
      data: 999,
      size: 2005,
      active: 'active',
      active2: 'active'
    },
    {
      rubrik: 'LKW',
      data: 999,
      size: 2005,
      active: 'inactive',
      active2: 'active'
    },
    {
      rubrik: 'Space X',
      data: 999,
      size: 2005,
      active: 'active',
      active2: 'active'
    },
    {
      rubrik: 'Schiff',
      data: 999,
      size: 31,
      active: null,
      active2: 'active'
    }
  ];

  submit(data: any): void {
    // For optimistic locking
    this.data = data.rows;
  }

  log(any: any): void {
    console.log(any);
  }

  addControl(): void {
    this.form.controls.control.insert(
      0,
      new FormGroup({
        rubrik: new QdFormControl('', [Validators.minLength(10)]),
        data: new QdFormControl(null),
        size: new QdFormControl(null),
        active: new QdFormControl('active'),
        active2: new QdFormControl('active')
      })
    );
  }
}
