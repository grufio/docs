import { DialogRef } from '@angular/cdk/dialog';
import { Component } from '@angular/core';
import { QdPageSelectedContext } from '../../../../../libs/qd-ui/src/lib/page/model/page-config.interface';
import { QdContextService } from '../../../../../libs/qd-ui/src/lib/page/shared/services/context.service';

@Component({
  selector: 'qd-ui-context-dialog',
  templateUrl: './context-dialog.component.html',
  styleUrls: ['./context-dialog.component.scss']
})
export class ContextDialogComponent {
  constructor(private dialogRef: DialogRef, private contextService: QdContextService) {}

  confirm(): void {
    const selection: QdPageSelectedContext = {
      value: 'TEST',
      label: {
        i18n: 'something'
      }
    };
    this.contextService.setValue('Custom', selection);
    this.dialogRef.close();
  }
}
