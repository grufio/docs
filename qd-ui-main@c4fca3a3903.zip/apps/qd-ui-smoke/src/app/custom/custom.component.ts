import { Component } from '@angular/core';
import { QdPageConfig } from '../../../../../libs/qd-ui/src/lib/page/model/page-config.interface';

@Component({
  selector: 'qd-ui-custom',
  templateUrl: './custom.component.html',
  styleUrls: ['./custom.component.scss']
})
export class CustomComponent {
  config: QdPageConfig = {
    title: {
      i18n: 'Benutzerdefiniert'
    },
    pageType: 'custom',
    pageTypeConfig: {
      customActions: [
        {
          label: {
            i18n: 'Bearbeiten'
          },
          handler: () => console.log('Vorgang schließen')
        }
      ]
    }
  };
}
