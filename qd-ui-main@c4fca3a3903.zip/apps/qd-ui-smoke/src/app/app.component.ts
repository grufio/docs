import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { QdShellConfig } from '../../../../libs/qd-ui/src';
import {
  QdContextSelection,
  QdContextService
} from '../../../../libs/qd-ui/src/lib/page/shared/services/context.service';

@Component({
  selector: 'qd-ui-root',
  templateUrl: './app.component.html',
  providers: [TranslateService]
})
export class AppComponent implements OnInit {
  constructor(private translate: TranslateService, private contextService: QdContextService) {
    translate.setDefaultLang('de');

    const cookie = this.readCookie<QdContextSelection[]>('my_contexts');

    cookie?.forEach(entry => {
      this.contextService.setValue(entry.contextId, entry.value);
    });

    this.contextService.values$.subscribe(values => this.bakeCookie('my_contexts', values));
  }

  ngOnInit(): void {
    this.translate.use('de');
  }

  config: QdShellConfig = {
    title: 'Smoke Test Application',
    isInternal: true,
    headerWidget: {
      isDisabled: true
    }
  };

  private bakeCookie(name: string, value: unknown) {
    document.cookie = [name, '=', JSON.stringify(value), '; path=/;'].join('');
  }

  private readCookie<T>(name): T {
    var result = document.cookie.match(new RegExp(name + '=([^;]+)'));
    result && (result = JSON.parse(result[1]));
    return result as T;
  }
}
