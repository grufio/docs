import { QdTableStateSort } from '../../../../../libs/qd-ui/src/lib/table/model/table-store.interface';
import { QdSortDirection } from '../../../../../libs/qd-ui/src';

export interface ConstellationEntry {
  abbr: string;
  name: string;
  genitive: string;
  en: string;
}

export const database: ConstellationEntry[] = [
  {
    abbr: 'And',
    name: 'Andromeda',
    genitive: 'Andromedae',
    en: 'Andromeda (mythological character)'
  },
  {
    abbr: 'Ant',
    name: 'Antlia',
    genitive: 'Antliae',
    en: 'Air Pump'
  },
  {
    abbr: 'Aps',
    name: 'Apus',
    genitive: 'Apodis',
    en: 'Bird-of-paradise'
  },
  {
    abbr: 'Aqr',
    name: 'Aquarius',
    genitive: 'Aquarii',
    en: 'Water-bearer'
  },
  {
    abbr: 'Aql',
    name: 'Aquila',
    genitive: 'Aquilae',
    en: 'Eagle'
  },
  {
    abbr: 'Ara',
    name: 'Ara',
    genitive: 'Arae',
    en: 'Altar'
  },
  {
    abbr: 'Ari',
    name: 'Aries',
    genitive: 'Arietis',
    en: 'Ram'
  },
  {
    abbr: 'Aur',
    name: 'Auriga',
    genitive: 'Aurigae',
    en: 'Charioteer'
  },
  {
    abbr: 'Boo',
    name: 'Boötes',
    genitive: 'Boötis',
    en: 'Herdsman'
  },
  {
    abbr: 'Cae',
    name: 'Caelum',
    genitive: 'Caeli',
    en: 'Chisel'
  },
  {
    abbr: 'Cam',
    name: 'Camelopardalis',
    genitive: 'Camelopardalis',
    en: 'Giraffe'
  },
  {
    abbr: 'Cnc',
    name: 'Cancer',
    genitive: 'Cancri',
    en: 'Crab'
  },
  {
    abbr: 'CVn',
    name: 'Canes Venatici',
    genitive: 'Canum Venaticorum',
    en: 'Hunting Dogs'
  },
  {
    abbr: 'CMA',
    name: 'Canis Major',
    genitive: 'Canis Majoris',
    en: 'Great Dog'
  },
  {
    abbr: 'CMi',
    name: 'Canis Minor',
    genitive: 'Canis Minoris',
    en: 'Lesser Dog'
  },
  {
    abbr: 'Cap',
    name: 'Capricornus',
    genitive: 'Capricorni',
    en: 'Sea-goat'
  },
  {
    abbr: 'Car',
    name: 'Carina',
    genitive: 'Carinae',
    en: 'Keel'
  },
  {
    abbr: 'Cas',
    name: 'Cassiopeia',
    genitive: 'Cassiopeiae',
    en: 'Cassiopeia (mythological queen)'
  },
  {
    abbr: 'Cen',
    name: 'Centaurus',
    genitive: 'Centauri',
    en: 'Centaur'
  },
  {
    abbr: 'Cep',
    name: 'Cepheus',
    genitive: 'Cephei',
    en: 'Cepheus (mythological king)'
  },
  {
    abbr: 'Cet',
    name: 'Cetus',
    genitive: 'Ceti',
    en: 'Sea Monster'
  },
  {
    abbr: 'Cha',
    name: 'Chamaeleon',
    genitive: 'Chamaeleontis',
    en: 'Chameleon'
  },
  {
    abbr: 'Cir',
    name: 'Circinus',
    genitive: 'Circini',
    en: 'Compasses'
  },
  {
    abbr: 'Col',
    name: 'Columba',
    genitive: 'Columbae',
    en: 'Dove'
  },
  {
    abbr: 'Com',
    name: 'Coma Berenices',
    genitive: 'Comae Berenices',
    en: "Berenice's Hair"
  },
  {
    abbr: 'CrA',
    name: 'Corona Australis',
    genitive: 'Coronae Australis',
    en: 'Southern Crown'
  },
  {
    abbr: 'CrB',
    name: 'Corona Borealis',
    genitive: 'Coronae Borealis',
    en: 'Northern Crown'
  },
  {
    abbr: 'Crt',
    name: 'Crater',
    genitive: 'Crateris',
    en: 'Cup'
  },
  {
    abbr: 'Cru',
    name: 'Crux',
    genitive: 'Crucis',
    en: 'Southern Cross'
  },
  {
    abbr: 'Cyg',
    name: 'Cygnus',
    genitive: 'Cygni',
    en: 'Swan'
  },
  {
    abbr: 'Del',
    name: 'Delphinus',
    genitive: 'Delphini',
    en: 'Dolphin'
  },
  {
    abbr: 'Dor',
    name: 'Dorado',
    genitive: 'Doradus',
    en: 'Dolphinfish'
  },
  {
    abbr: 'Dra',
    name: 'Draco',
    genitive: 'Draconis',
    en: 'Dragon'
  },
  {
    abbr: 'Equ',
    name: 'Equuleus',
    genitive: 'Equulei',
    en: 'Little Horse'
  },
  {
    abbr: 'Eri',
    name: 'Eridanus',
    genitive: 'Eridani',
    en: 'River'
  },
  {
    abbr: 'For',
    name: 'Fornax',
    genitive: 'Fornacis',
    en: 'Furnace'
  },
  {
    abbr: 'Gem',
    name: 'Gemini',
    genitive: 'Geminorum',
    en: 'Twins'
  },
  {
    abbr: 'Gru',
    name: 'Grus',
    genitive: 'Gruis',
    en: 'Crane'
  },
  {
    abbr: 'Her',
    name: 'Hercules',
    genitive: 'Herculis',
    en: 'Hercules (mythological hero)'
  },
  {
    abbr: 'Hor',
    name: 'Horologium',
    genitive: 'Horologii',
    en: 'Clock'
  },
  {
    abbr: 'Hya',
    name: 'Hydra',
    genitive: 'Hydrae',
    en: 'Water Snake'
  },
  {
    abbr: 'Hyi',
    name: 'Hydrus',
    genitive: 'Hydri',
    en: 'Male Water Snake'
  },
  {
    abbr: 'Ind',
    name: 'Indus',
    genitive: 'Indi',
    en: 'Indian'
  },
  {
    abbr: 'Lac',
    name: 'Lacerta',
    genitive: 'Lacertae',
    en: 'Lizard'
  },
  {
    abbr: 'Leo',
    name: 'Leo',
    genitive: 'Leonis',
    en: 'Lion'
  },
  {
    abbr: 'LMi',
    name: 'Leo Minor',
    genitive: 'Leonis Minoris',
    en: 'Lesser Lion'
  },
  {
    abbr: 'Lep',
    name: 'Lepus',
    genitive: 'Leporis',
    en: 'Hare'
  },
  {
    abbr: 'Lib',
    name: 'Libra',
    genitive: 'Librae',
    en: 'Scales'
  },
  {
    abbr: 'Lup',
    name: 'Lupus',
    genitive: 'Lupi',
    en: 'Wolf'
  },
  {
    abbr: 'Lyn',
    name: 'Lynx',
    genitive: 'Lyncis',
    en: 'Lynx'
  },
  {
    abbr: 'Lyr',
    name: 'Lyra',
    genitive: 'Lyrae',
    en: 'Lyre'
  },
  {
    abbr: 'Men',
    name: 'Mensa',
    genitive: 'Mensae',
    en: 'Table Mountain'
  },
  {
    abbr: 'Mic',
    name: 'Microscopium',
    genitive: 'Microscopii',
    en: 'Microscope'
  },
  {
    abbr: 'Mon',
    name: 'Monoceros',
    genitive: 'Monocerotis',
    en: 'Unicorn'
  },
  {
    abbr: 'Mus',
    name: 'Musca',
    genitive: 'Muscae',
    en: 'Fly'
  },
  {
    abbr: 'Nor',
    name: 'Norma',
    genitive: 'Normae',
    en: 'Square'
  },
  {
    abbr: 'Oct',
    name: 'Octans',
    genitive: 'Octantis',
    en: 'Octant'
  },
  {
    abbr: 'Oph',
    name: 'Ophiuchus',
    genitive: 'Ophiuchi',
    en: 'Serpent-bearer'
  },
  {
    abbr: 'Ori',
    name: 'Orion',
    genitive: 'Orionis',
    en: 'Orion (mythological hunter)'
  },
  {
    abbr: 'Pav',
    name: 'Pavo',
    genitive: 'Pavonis',
    en: 'Peacock'
  },
  {
    abbr: 'Peg',
    name: 'Pegasus',
    genitive: 'Pegasi',
    en: 'Winged Horse'
  },
  {
    abbr: 'Per',
    name: 'Perseus',
    genitive: 'Persei',
    en: 'Perseus (mythological hero)'
  },
  {
    abbr: 'Phe',
    name: 'Phoenix',
    genitive: 'Phoenicis',
    en: 'Phoenix'
  },
  {
    abbr: 'Pic',
    name: 'Pictor',
    genitive: 'Pictoris',
    en: "Painter's Easel"
  },
  {
    abbr: 'Psc',
    name: 'Pisces',
    genitive: 'Piscium',
    en: 'Fishes'
  },
  {
    abbr: 'PsA',
    name: 'Piscis Austrinus',
    genitive: 'Piscis Austrini',
    en: 'Southern Fish'
  },
  {
    abbr: 'Pup',
    name: 'Puppis',
    genitive: 'Puppis',
    en: 'Stern'
  },
  {
    abbr: 'Pyx',
    name: 'Pyxis',
    genitive: 'Pyxidis',
    en: 'Compass'
  },
  {
    abbr: 'Ret',
    name: 'Reticulum',
    genitive: 'Reticuli',
    en: 'Reticle'
  },
  {
    abbr: 'Sge',
    name: 'Sagitta',
    genitive: 'Sagittae',
    en: 'Arrow'
  },
  {
    abbr: 'Sgr',
    name: 'Sagittarius',
    genitive: 'Sagittarii',
    en: 'Archer'
  },
  {
    abbr: 'Sco',
    name: 'Scorpius',
    genitive: 'Scorpii',
    en: 'Scorpion'
  },
  {
    abbr: 'Scl',
    name: 'Sculptor',
    genitive: 'Sculptoris',
    en: 'Sculptor'
  },
  {
    abbr: 'Sct',
    name: 'Scutum',
    genitive: 'Scuti',
    en: 'Shield'
  },
  {
    abbr: 'Ser',
    name: 'Serpens',
    genitive: 'Serpentis',
    en: 'Serpent'
  },
  {
    abbr: 'Sex',
    name: 'Sextans',
    genitive: 'Sextantis',
    en: 'Sextant'
  },
  {
    abbr: 'Tau',
    name: 'Taurus',
    genitive: 'Tauri',
    en: 'Bull'
  },
  {
    abbr: 'Tel',
    name: 'Telescopium',
    genitive: 'Telescopii',
    en: 'Telescope'
  },
  {
    abbr: 'Tri',
    name: 'Triangulum',
    genitive: 'Trianguli',
    en: 'Triangle'
  },
  {
    abbr: 'TrA',
    name: 'Triangulum Australe',
    genitive: 'Trianguli Australis',
    en: 'Southern Triangle'
  },
  {
    abbr: 'Tuc',
    name: 'Tucana',
    genitive: 'Tucanae',
    en: 'Toucan'
  },
  {
    abbr: 'UMa',
    name: 'Ursa Major',
    genitive: 'Ursae Majoris',
    en: 'Great Bear'
  },
  {
    abbr: 'UMi',
    name: 'Ursa Minor',
    genitive: 'Ursae Minoris',
    en: 'Little Bear'
  },
  {
    abbr: 'Vel',
    name: 'Vela',
    genitive: 'Velorum',
    en: 'Sails'
  },
  {
    abbr: 'Vir',
    name: 'Virgo',
    genitive: 'Virginis',
    en: 'Virgin'
  },
  {
    abbr: 'Vol',
    name: 'Volans',
    genitive: 'Volantis',
    en: 'Flying Fish'
  },
  {
    abbr: 'Vul',
    name: 'Vulpecula',
    genitive: 'Vulpeculae',
    en: 'Little Fox'
  }
];

export function sortData(data: any[], sortingCriteria: QdTableStateSort<string>[]): any[] {
  return [...data].sort((a, b) => {
    for (const criterion of sortingCriteria) {
      const { column, direction } = criterion;
      if (direction === QdSortDirection.ASC) {
        const result = compareAscending(a, b, column);
        if (result !== 0) {
          return result;
        }
      } else if (direction === QdSortDirection.DESC) {
        const result = compareDescending(a, b, column);
        if (result !== 0) {
          return result;
        }
      }
    }
    return 0;
  });
}

export function compareAscending(a: any, b: any, column: string): number {
  if (a[column] < b[column]) {
    return -1;
  }
  if (a[column] > b[column]) {
    return 1;
  }
  return 0;
}

export function compareDescending(a: any, b: any, column: string): number {
  if (a[column] > b[column]) {
    return -1;
  }
  if (a[column] < b[column]) {
    return 1;
  }
  return 0;
}

export function searchData(data: any[], term: string) {
  return data.filter(entry => JSON.stringify(Object.values(entry)).toLowerCase().includes(term.toLowerCase()));
}
