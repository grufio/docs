# Testing Guidelines

> This framework serves as the foundation for many applications – automated testing is therefore essential to ensure quality and stability.

---

## What and Why

We follow a **test-driven approach** to ensure high quality and long-term maintainability.

**Core principles**:

- Every contribution must include both **component tests** and **unit tests**
- These two types of tests **complement each other** – they do **not replace** one another:
  - **Component tests** validate whether a feature works as expected
  - **Unit tests** validate logic in isolation (e.g., components, services, pipes)

**Component Tests**:

We focus on writing **automated tests for acceptance criteria (ACs)** whenever possible.  
**Do not test the internal implementation**, only the expected behavior.

If you contribute to this project, make sure your code adheres to these testing principles.

---

## Testing Process for Contributors

If you're planning to submit a pull request:

- Consider early **what should be tested and how**
  - For features: write a **component test**, ideally covering the acceptance criteria
  - For bug fixes: include a test that **reproduces the issue**
- Use existing tests as examples or templates
- Keep your tests **clear, focused, and easy to understand**

We review all contributions with a strong focus on test quality.  
If you're unsure how to test something, feel free to reach out – we're happy to support you!

---

## Component Tests

Component tests verify whether a component behaves correctly from a user's perspective:

**What to Test**:

- **API**: Inputs, outputs, and other component interfaces
- **User interactions**: Clicks, keyboard input, focus behavior
- **Styling**: Visual output (e.g., using screenshot testing)

**Execution**:

To run component tests in a Docker environment (for consistent browser versions like in Jenkins):

```bash
# Set up Docker alias (add this to ~/.bashrc)
alias dc="docker run --volume \$(pwd):/workdir/ --workdir /workdir/ --network='host' repo.bit.admin.ch:8444/bit/cypress:13.7.2-node-18.19"

# Move to project
cd path/to/qd-ui/

# Run all component tests
dc npm run comp-test

# Run a single component test
dc npm run comp-test -- --spec libs/qd-ui/src/lib/page/page.component.cy.ts
```

**Managing Docker Containers**:

Note: Pressing Ctrl + C won’t stop the Docker container during component test runs – you’ll need to kill it manually.

```bash
# 1. List running containers
docker ps

# 2. Copy the container ID from the output

# 3. Kill the container manually
docker kill <container-id>
```

---

## Unit Tests

Unit tests validate **logic in isolation**.

**Use them for**:

- **Components**, **Services**, **Pipes**, etc.
- Isolate logic using mocks (`ngMocks`) or mock providers

**Structure**:

- `Arrange – Act – Assert`

**Best Practices**:

- Avoid direct interaction with the **DOM** if possible
- Only test Angular lifecycles if really necessary
- Keep test structures **flat and simple** _(e.g., no more than 2 nested `describe` blocks)_
- Test interactions with dependencies using `toHaveBeenCalled...` rather than testing the dependencies themselves
- Ensure full coverage of all branches and logic paths → **Branch Coverage**
