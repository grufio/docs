# Commit Message Guidelines

> Clear and consistent commit messages are essential for project collaboration, readability, and automation. In **Quadrel UI**, they are a critical part of the **CI/CD workflow**, including changelog generation and versioning.

---

## Why It Matters

- Improves Git history readability
- Powers changelogs and blog updates
- Essential for CI/CD release type detection
- Enables automated versioning

---

## Rules to Follow

**One Commit per Change**:

- Each change must be represented by **one commit**
- Tests, mocks, documentation, and schematics for that change must be included in the **same commit**
- Fixes must be **squashed together**

**Line Length**:

- No line in the commit message may be **longer than 100 characters**

---

## Allowed Commit Types

| Type     | Purpose                                                             |
| -------- | ------------------------------------------------------------------- |
| feat     | A new feature                                                       |
| fix      | A bug fix                                                           |
| refactor | A code change that neither fixes a bug nor adds a feature           |
| test     | Changes to tests or test configuration                              |
| docs     | Documentation changes only                                          |
| format   | Code formatting only (no logic changes)                             |
| chore    | Maintenance tasks (e.g. updates, CI configs, release scripts, etc.) |

---

## Example

```
feat: DAZUIC-6645 - Add model design for qd-forms
```
