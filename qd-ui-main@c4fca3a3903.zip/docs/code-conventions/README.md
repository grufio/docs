# Coding Conventions

> The following **coding conventions** must be followed when developing in the **Quadrel framework**.

---

## Observable Suffix

Observable properties must be **suffixed with `$`**:

```typescript
const myObservable$ = of('HELLO WORLD');
```

---

## Private Prefix

- **Private members** must be prefixed with **`_`**, but **private methods** should **not** have a prefix.

```typescript
private _state: MyState;
private initState(): void { }
```

---

## Public Properties

Public properties **do not** require an explicit access modifier.  
Since the **default modifier in TypeScript is `public`**, omitting it improves readability.

```typescript
class Modifiers {
  private initState(): void {}
  doSomething(): void {}
}
```

---

## Member Sequence

To improve **code structure** in long classes, members should be ordered as follows:

```typescript
class MyComponent {
    Inputs
    Outputs
    ViewChild, etc.
    HostBindings

    public members
    private members

    getter
    setter

    constructor

    Lifecycle Hooks

    public methods
    private methods
}
```

---

## Selectors

- **Component selectors** and **directive selectors** should be written in **kebab-case**:

```typescript
qd - button;
```

---

## Inputs/Outputs

- **Input and Output properties** should be written in **camelCase**:

```typescript
@Input("buttonInput") buttonInput: something;
```

---

## `undefined` and `null` Handling

- `null` and `undefined` should be **used sparingly** and handled **as early as possible**.
- Code should only deal with `null` or `undefined` values **where they actually occur**.

❌ **Don't:** Using `undefined` in the type

```typescript
type CoffeeResponse = Latte | Americano | undefined;

class CoffeeService {
  getLatte(): CoffeeResponse { ... };
}
```

✅ **Do:** Handling `undefined` at the function level

```typescript
type CoffeeResponse = Latte | Americano;

class CoffeeService {
  getLatte(): CoffeeResponse | undefined { ... };
}
```

---

## Using `null` and `undefined` in Objects

- `null` should be used when a variable **intentionally has no value**.
- `undefined` should **never be explicitly assigned**; it represents **uninitialized values**.

✅ **Do:** Use optional parameters instead of `undefined`

```ts
interface CoffeeOrder {
  sugarCubes: number;
  milk?: Whole | LowFat | HalfHalf;
}
```

**Source:** [Google TypeScript Guide](https://google.github.io/styleguide/tsguide.html#undefined-and-null)

---

## Getter/Setter Best Practices

❌ **Don't:** Getter with side effects
_Getters should not modify state and must always return a consistent result._

```ts
class Car {
  private _fuelLevel: number;

  constructor(fuelLevel: number) {
    this._fuelLevel = fuelLevel;
  }

  // This getter modifies the state each time it is accessed
  get fuelLevel() {
    this._fuelLevel -= 1; // Changes value on every call
    return this._fuelLevel;
  }
}
```

✅ **Do:** Pure getter without side effects

```ts
class Car {
  private _fuelLevel: number;

  constructor(fuelLevel: number) {
    this._fuelLevel = fuelLevel;
  }

  // This getter does not modify state
  get fuelLevel() {
    return this._fuelLevel;
  }
}
```

---

## When to Use Getters/Setters

- **Use getters and setters only when they contain logic.**
- If no logic is required, **use a public property instead.**

❌ **Don't:** Unnecessary getter/setter

```ts
class Bar {
  private barInternal = '';

  // No additional logic; property should just be public
  get bar() {
    return this.barInternal;
  }

  set bar(value: string) {
    this.barInternal = value;
  }
}
```

✅ **Do:** Use a public property

```ts
class Foo {
  // No logic, so it's just a public property
  foo = '';
}
```

Or, **if logic is needed, use a proper getter/setter**:

```ts
class Bar {
  private _wrappedBar = '';

  // Getter with logic: returns 'bar' if _wrappedBar is empty
  get bar() {
    return this._wrappedBar || 'bar';
  }

  // Setter with logic: trims whitespace before storing
  set bar(wrapped: string) {
    this._wrappedBar = wrapped.trim();
  }
}
```
