# API Style Guide - Connectors

> **Connector Directives** simplify **loosely coupled communication** between components within the framework. They enable synchronization of states, configurations, and user interactions through defined inputs, contributing to **modularity** and **reusability**.

**Note:** Connector directives should be **specific to one function and target**.  
Avoid redundancy in configurations or inputs to improve maintainability.

---

## Naming Convention

❌ **Don't:** Vague naming

```typescript
selector: 'qd-table[connector]';
```

✅ **Do:** Precise, context-specific naming
**Format:**

```typescript
// <Prefix><Function><Target>
selector: 'qd-table[qdConnectToSearch]';
```

---

## Binding

❌ **Don't:** Selector without a clear binding source

```typescript
selector: '[qdTableConnectToSearch]';
```

✅ **Do:** Selector that defines the source clearly (when possible)

```typescript
selector: 'qd-table[qdConnectToSearch]';
```
