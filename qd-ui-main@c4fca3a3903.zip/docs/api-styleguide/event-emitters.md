# API Style Guide - Event Emitters

> Event Emitters are used to **communicate state changes** to the outside. This allows application UI components to be **informed about the current state** of Quadrel components and react accordingly.

## Difference from Service Binding and Action Handlers

- **Service Binding:** Provides **services or data sources** that are used within a Quadrel component.
- **Action Handlers:** Directly **react to user interactions** inside a component and execute specific actions.

---

## Examples

```typescript
@Output() valueChanged = new EventEmitter<string>();
@Output() optionSelected = new EventEmitter<string>();
@Output() optionsFilterChanged = new EventEmitter<string>();
@Output() rowsSelected = new EventEmitter<QdTableSelectedRows<T>>();
```

---

## Naming Convention

❌ **Don't:** Poor naming

```typescript
@Output() selectedRowsOutput = new EventEmitter<QdTableSelectedRows<T>>();
```

✅ **Do:** Follow a structured naming scheme

```typescript
// <Object or Context in Singular/Plural> <Past Tense Action>
@Output() rowsSelected = new EventEmitter<QdTableSelectedRows<T>>();
```

---

## Parameters

❌ **Don't:** Do not omit state information

```typescript
@Output() valueChanged = new EventEmitter();
```

✅ **Do:** Always pass the relevant state

```typescript
@Output() valueChanged = new EventEmitter<string>();
```

---

## Actions

❌ **Don't:** Do not use Event Emitters for actions like button clicks

```typescript
@Output() menuButtonActionClicked = new EventEmitter<void>();
```

✅ **Do:** Use handlers in the configuration for user actions

```typescript
const menuButtonActionsConfig: QdMenuButtonConfig = {
  actions: [
    {
      handler: () => this.handleAddNew()
    }
  ]
};
```
