# API Style Guide - Naming Conventions

> A clear and consistent naming strategy helps keep a Quadrel-based application **understandable** and **maintainable**.

## Components

```typescript
// Schema: Qd<Name>Component
// Selector: qd-<name>
@Component({
  selector: 'qd-table',
  ...
})
export class QdTableComponent {}
```

---

## Services

```typescript
// Schema: Qd<Name>Service
@Injectable()
export class QdTableDataService {}
```

---

## Directives

```typescript
// Schema: Qd<Name>Directive
// Selector: [qd<Name>]
@Directive({
  selector: '[qdHighlight]'
})
export class QdHighlightDirective {}
```

---

## Pipes

```typescript
// Schema: Qd<Name>Pipe
// Selector: qd<Name>
@Pipe({
  name: 'qdDate'
})
export class QdDatePipe {}
```

---

## Interfaces

```typescript
// Schema: Qd<Name><Topic>
export interface QdTableConfig {
  columns: QdTableConfigColumn[];
}
```

---

## Enums

```typescript
// Schema: Qd<Name>Enum
export enum QdTableStateEnum {
  Loading = 'loading',
  Success = 'success',
  Error = 'error'
}
```
