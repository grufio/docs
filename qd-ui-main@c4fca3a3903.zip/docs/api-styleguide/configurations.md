# API Style Guide - Configurations

> **Configurations are the central control element of the API.** They allow components' behavior, appearance, and interactions to be configured flexibly and reused efficiently.

**Note:** A central configuration input is usually used to define the entire configuration of a component. Additional inputs should only be used in exceptional cases to ensure consistency and maintainability.

---

## Example Configuration Object

```typescript
const config: NamespaceComponentConfig = {
  title: { i18n: 'i18n.namespace.component.title' },
  actions: [
    { label: { i18n: 'i18n.namespace.component.action.save' }, handler: () => this.handleSave() },
    { label: { i18n: 'i18n.namespace.component.action.cancel' }, handler: () => this.handleCancel() }
  ],
  elements: [
    { name: 'title', type: 'text', i18n: 'i18n.namespace.component.element.title' },
    { name: 'status', type: 'boolean', i18n: 'i18n.namespace.component.element.status' },
    { name: 'amount', type: 'number', i18n: 'i18n.namespace.component.element.amount' }
  ],
  options: [
    { value: 'import', label: { i18n: 'i18n.namespace.component.option.import' } },
    { value: 'export', label: { i18n: 'i18n.namespace.component.option.export' }, isActive: true },
    { value: 'transit', label: { i18n: 'i18n.namespace.component.option.transit' }, isDisabled: true }
  ],
  pagination: { size: 10, sizes: [10, 20, 50] },
  isEditable: true
};
```

---

## Structure Example

❌ **Don't:** Unnecessary nesting.

```typescript
const config = {
  component: {
    meta: {
      title: { i18n: 'i18n.namespace.component.title' }
    },
    layout: {
      pagination: { size: 10 }
    }
  }
};
```

✅ **Do:** Keep a flat structure for better readability.

```typescript
const config = {
  title: { i18n: 'i18n.namespace.component.title' },
  pagination: { size: 10, sizes: [10, 20, 50] }
};
```

---

## Internationalization

❌ **Don't:** Store text directly in the configuration.

```typescript
title: 'Component Title';
```

✅ **Do:** Use i18n for internationalization.

```typescript
title: {
  i18n: 'i18n.namespace.component.title';
}
```

---

## Clarity

❌ **Don't:** Use unclear parameter names.

```typescript
payload: {
  data: [];
}
```

✅ **Do:** Use clear and descriptive parameters.

```typescript
payload: {
  userProfiles: [];
}
```

---

## Redundancy

❌ **Don't:** Use redundant naming in nested objects.

```typescript
user: {
  userName: 'admin';
}
```

✅ **Do:** Keep property names simple without redundancy.

```typescript
user: {
  name: 'admin';
}
```

---

## States

❌ **Don't:** Boolean values without a prefix.

```typescript
editable: true;
```

✅ **Do:** Prefix boolean values with `is`, `has`, or `can`.

```typescript
isEditable: true;
```

---

## Consistency

❌ **Don't:** Use different keys for the same functionality.

```typescript
type: 'success';
level: 'success';
status: 'success';
```

✅ **Do:** Use consistent keys across functionalities.

```typescript
state: 'success';
```

---

## Defaults

❌ **Don't:** Manually define default settings.

```typescript
pagination: { sizeDefault: 25, sizes: [25, 50, 100], ... }
```

✅ **Do:** Set meaningful defaults that can be overridden.

```typescript
pagination: { ... }
```
