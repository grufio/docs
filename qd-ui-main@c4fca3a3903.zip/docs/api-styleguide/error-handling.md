# API Style Guide - Error Handling & Logging

> A **clear naming scheme** and **proper use of console methods** help developers debug efficiently, improve maintainability, and ensure **consistent error handling** across the framework.

## Which Methods Should Be Used?

## `console.warn()`

**When?**  
For **warnings** that indicate incorrect usage of Quadrel components or potential issues.  
**Example:** An optional parameter is missing, but functionality is not affected.

```typescript
console.warn('QD-UI | QdTable - No translations available.');
```

---

## `console.error()`

**When?**  
For **critical errors** that block application execution.  
**Example:** Missing configuration or essential data.

```typescript
console.error('QD-UI | QdMenuButton - Please provide a valid config.');
```

---

## `throw new Error()`

**When?**  
For **fatal errors** that **cannot be resolved automatically** and require immediate attention.  
**Example:** Unknown error sources that need investigation.

```typescript
throw new Error('QD-UI | QdComponent - Unexpected error occurred.');
```

---

## Naming Conventions

❌ **Don't:** Unclear context, making debugging harder

```typescript
console.error('Error occurred.');
```

✅ **Do:** Use a structured naming convention

```typescript
// <Product/Library> | <Component/Pattern> - <Message>, Error (if applicable)
console.error('QD-UI | QdMenuButton - Please provide a valid config.');
console.warn('QD-UI | QdTable - No translations available.');
```
