# API Style Guide - Service Binding

> Through **Angular Dependency Injection**, applications provide **services or data sources** required for a component's functionality. This **decouples** components from direct implementation, ensuring **flexibility** and **scalability**.

## Difference from Event Emitters and Action Handlers

- **Event Emitters:** Used to **communicate state changes** or results between components.
- **Action Handlers:** React **directly to user interactions** within a component and trigger specific actions.

---

## Complete Example

```typescript
interface QdTableDataResolver {
  resolve(params: QdTableResolverParams): Observable<any>;
}

const QD_TABLE_DATA_RESOLVER_TOKEN = new InjectionToken<QdTableDataResolver>('QD_TABLE_DATA_RESOLVER_TOKEN');
```

---

## Naming Convention

❌ **Don't:** Poor naming

```typescript
const TOKEN = new InjectionToken('Token'); // Unclear purpose
const DataResolverToken = new InjectionToken('Token'); // Inconsistent naming
const QD_TABLE_TOKEN = new InjectionToken('Token'); // Not specific enough
```

✅ **Do:** Follow a structured naming scheme

```typescript
// <Prefix>_<Module/Component>_<Description>_TOKEN
const QD_FORM_OPTIONS_RESOLVER_TOKEN = new InjectionToken<QdFormOptionsResolver>('QD_FORM_OPTIONS_RESOLVER_TOKEN');
```

---

## Typing

❌ **Don't:** Missing or incorrect type definitions

```typescript
const QD_FORM_OPTIONS_RESOLVER_TOKEN = new InjectionToken('QD_FORM_OPTIONS_RESOLVER_TOKEN');
const QD_FORM_OPTIONS_RESOLVER_TOKEN = new InjectionToken<any>('QD_FORM_OPTIONS_RESOLVER_TOKEN');
const QD_FORM_OPTIONS_RESOLVER_TOKEN = new InjectionToken<string>('QD_FORM_OPTIONS_RESOLVER_TOKEN');
```

✅ **Do:** Use clear and consistent typing

```typescript
export const QD_FORM_OPTIONS_RESOLVER_TOKEN = new InjectionToken<QdFormOptionsResolver>(
  'QD_FORM_OPTIONS_RESOLVER_TOKEN'
);
```

---

## Interfaces

❌ **Don't:** Untyped, overloaded, and unclear interfaces

```typescript
interface TableResolver {
  resolve(params: any): any;
  log(): void; // Unnecessary for the service
}
```

✅ **Do:** Keep interfaces minimal, clear, and typed

```typescript
interface QdTableDataResolver {
  resolve(params: QdTableResolverParams): Observable;
}
```
