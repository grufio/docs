# API Style Guide - Action Handlers

> Action Handlers are functions that directly respond to **specific user actions**. They are mainly used when behavior is **directly linked to user interactions**, such as clicking a button or triggering an action from an inline menu. They are part of the **configuration object**.

## Difference from Service Binding and Event Emitters

- **Service Binding:** Used to provide services or data sources that are utilized within a Quadrel component.
- **Event Emitters:** Communicate **state changes** or results between components.

---

## Example Action Configuration

```typescript
const config: NamespaceComponentConfig = {
  actions: [
    {
      type: 'save',
      handler: (item: Item) => this.handleSave(item)
    },
    {
      type: 'delete',
      handler: (id: number) => this.handleDelete(id)
    }
  ]
};
```

---

## Parameterization

❌ **Don't:** Avoid poorly parameterized handlers, when full parameterization is possible

```typescript
handler: (index: number) => void
```

✅ **Do:** Use handlers that accept parameters

```typescript
handler: (data: { rowData: QdTableDataRow<T>, index: number }) => void
```

---

## Side Effects for Handlers

❌ **Don't:** Avoid direct component access to maintain API abstraction

```typescript
@Component({ ... })
export class QdExampleComponent {

  // Only accessible via direct component reference
  showNotification() {
    ...
  }
}
```

✅ **Do:** Use return values to trigger side effects

```typescript
// Function returning a value for triggering side effects
handler?: () => QdActionResult;

// Enables the side effect
showNotification?: boolean;

// Emitting 'true' triggers a notification
type QdActionResult = Observable<boolean>;
```
