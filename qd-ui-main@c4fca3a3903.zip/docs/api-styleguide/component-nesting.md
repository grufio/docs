# API Style Guide - Component Nesting

> Quadrel enforces **restricted content projection** to ensure **consistent design, maintainability, and optimized performance**. Clear restrictions prevent bugs and simplify updates. Only **Quadrel-supported components** should be used to avoid layout and integration issues.

## Exit Points for Custom Content

There are **defined exit points** where custom content can be embedded. However, using them comes with risks:

- **Undefined behavior and styling bugs**
- **Non-compliance with UX standards** (lack of validation and support)
- **Unexpected side effects** on surrounding components
- **Compatibility issues** with future updates
- **Broken responsiveness** on different screen sizes

**Important:** Using these exit points means leaving the **Quadrel ecosystem**. Use them with caution and careful consideration.

## Additional Note

All **Quadrel components** can be used **standalone** and outside the **Quadrel Layout System (QLS)** (e.g., in a **dialog** or a **custom component**).

---

## Selects

❌ **Don't:** Uncontrolled Content Projection

```html
<qd-dialog>
  ...
  <ng-content></ng-content>
</qd-dialog>
```

✅ **Do:** Correct: Targeted Content Projection with "select"

```html
<qd-dialog>
  ...
  <ng-content select="qd-dialog-action"></ng-content>
</qd-dialog>
```
