import type { Config } from 'jest';

const config: Config = {
  displayName: 'qd-ui',
  preset: 'jest-preset-angular',
  setupFilesAfterEnv: ['<rootDir>/src/test-setup.ts'],
  maxWorkers: 4,
  globals: {},
  transform: {
    '^.+\\.(ts|mjs|js|html)$': [
      'jest-preset-angular',
      {
        tsconfig: '<rootDir>tsconfig.spec.json',
        stringifyContentPathRegex: '\\.(html|svg)$'
      }
    ]
  },
  testPathIgnorePatterns: ['/e2e/'],
  moduleNameMapper: {
    uuid: require.resolve('uuid')
  },
  transformIgnorePatterns: ['node_modules/(?!.*.mjs$)', '/node_modules/?!@angular'],
  collectCoverage: true,
  coverageDirectory: '<rootDir>/sonar',
  coveragePathIgnorePatterns: [
    '/node_modules/',
    '__mocks__',
    '__stubs__',
    '__expects__',
    'qd-ui/e2e/',
    'jest.config',
    'module.ts',
    'cy.ts'
  ],
  coverageThreshold: {
    global: {
      statements: 93,
      branches: 86,
      functions: 91,
      lines: 94
    }
  },
  testResultsProcessor: 'jest-sonar-reporter',
  snapshotFormat: {
    escapeString: true,
    printBasicPrototype: true
  },
  snapshotSerializers: [
    'jest-preset-angular/build/serializers/html-comment',
    'jest-preset-angular/build/serializers/ng-snapshot',
    '../../tools/snapshotSerializer.js'
  ]
};

export default config;
