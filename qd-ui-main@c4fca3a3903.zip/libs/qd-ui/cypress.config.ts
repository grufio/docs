import { initPlugin } from '@frsource/cypress-plugin-visual-regression-diff/dist/plugins';
import { nxComponentTestingPreset } from '@nx/angular/plugins/component-testing';
import { defineConfig } from 'cypress';

const preset = nxComponentTestingPreset(__filename);
preset.devServer.options.projectConfig.buildOptions.styles = ['./libs/qd-ui/src/assets/styles/index.scss'];

export default defineConfig({
  component: {
    ...preset,
    indexHtmlFile: './cypress/support/component-index.html',
    viewportWidth: 1000,
    viewportHeight: 720,
    setupNodeEvents(on, config) {
      initPlugin(on, config);
      on('before:browser:launch', (browser, launchOptions) => {
        if (browser.name === 'electron') {
          launchOptions.preferences['width'] = 1920;
          launchOptions.preferences['height'] = 990;
        }
        return launchOptions;
      });
    },
    env: {
      pluginVisualRegressionMaxDiffThreshold: 0.001
    }
  }
});
