import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class QdStoryBookApiBaseUrlInterceptor implements HttpInterceptor {
  private baseUrl = '{TICKET_NAME}';

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.match('^http') || !this.isTicketNameReplaced()) return next.handle(req);

    const apiReq = req.clone({ url: `${this.baseUrl}/${req.url}` });

    return next.handle(apiReq);
  }

  isTicketNameReplaced(): boolean {
    return !this.baseUrl.includes('TICKET_NAME');
  }
}
