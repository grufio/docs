import { Component } from '@angular/core';

@Component({
  selector: 'qd-container-action-footer',
  template: '<ng-content></ng-content>'
})
export class QdMockContainerActionFooterComponent {}
