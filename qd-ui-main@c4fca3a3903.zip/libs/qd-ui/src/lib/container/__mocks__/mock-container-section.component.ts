// @ts-strict-ignore
import { Component, Input } from '@angular/core';
import { QdContainerType } from '../model/container-type';

@Component({
  selector: 'qd-container-section',
  template: 'containerType: {{containerType}} <ng-content></ng-content>'
})
export class QdMockContainerSectionComponent {
  @Input() containerType: QdContainerType;
}
