// @ts-strict-ignore
import { Component, Input } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { QdContainerType } from '../model/container-type';

@Component({
  selector: 'qd-container-create-content',
  template: 'containerType {{containerType}}'
})
export class QdMockContainerCreateContentComponent {
  @Input() formGroup: UntypedFormGroup;
  @Input() containerType: QdContainerType;
}
