import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QdMockContainerActionFooterComponent } from './mock-action-footer.component';
import { QdMockContainerComponent } from './mock-container.component';
import { QdMockContainerCreateContentComponent } from './mock-container-create-content.component';
import { QdMockContainerCreateDefaultComponent } from './mock-container-create-default.component';
import { QdMockContainerSectionComponent } from './mock-container-section.component';
import {
  QdMockContainerToolbarActionComponent,
  QdMockContainerToolbarActionSearchDirective
} from './mock-container-toolbar-action.component';
import { QdMockContainerToolbarComponent } from './mock-container-toolbar.component';
import { QdMockContainerToolbarFilterComponent } from './mock-container-toolbar-filter.component';
import { QdMockContainerToolbarTitleComponent } from './mock-container-toolbar-title.component';
import { QdMockCreateDeleteAlertComponent } from './mock-create-delete-alert.component';
import {
  QdMockFormGroupComponent,
  QdMockFormGroupHeaderActionComponent,
  QdMockFormGroupHeaderComponent
} from './mock-form-group.component';

export {
  QdMockContainerActionFooterComponent,
  QdMockContainerComponent,
  QdMockContainerCreateContentComponent,
  QdMockContainerCreateDefaultComponent,
  QdMockContainerSectionComponent,
  QdMockContainerToolbarActionComponent,
  QdMockContainerToolbarActionSearchDirective,
  QdMockContainerToolbarComponent,
  QdMockContainerToolbarFilterComponent,
  QdMockContainerToolbarTitleComponent,
  QdMockCreateDeleteAlertComponent,
  QdMockFormGroupComponent,
  QdMockFormGroupHeaderActionComponent,
  QdMockFormGroupHeaderComponent
};

@NgModule({
  imports: [CommonModule],
  declarations: [
    QdMockContainerActionFooterComponent,
    QdMockContainerComponent,
    QdMockContainerCreateContentComponent,
    QdMockContainerCreateDefaultComponent,
    QdMockContainerSectionComponent,
    QdMockContainerToolbarActionComponent,
    QdMockContainerToolbarActionSearchDirective,
    QdMockContainerToolbarComponent,
    QdMockContainerToolbarFilterComponent,
    QdMockContainerToolbarTitleComponent,
    QdMockCreateDeleteAlertComponent,
    QdMockFormGroupComponent,
    QdMockFormGroupHeaderActionComponent,
    QdMockFormGroupHeaderComponent
  ],
  exports: [
    QdMockContainerActionFooterComponent,
    QdMockContainerComponent,
    QdMockContainerCreateContentComponent,
    QdMockContainerCreateDefaultComponent,
    QdMockContainerSectionComponent,
    QdMockContainerToolbarActionComponent,
    QdMockContainerToolbarActionSearchDirective,
    QdMockContainerToolbarComponent,
    QdMockContainerToolbarFilterComponent,
    QdMockContainerToolbarTitleComponent,
    QdMockCreateDeleteAlertComponent,
    QdMockFormGroupComponent,
    QdMockFormGroupHeaderActionComponent,
    QdMockFormGroupHeaderComponent
  ]
})
export class QdMockContainerModule {}
