import { Component, EventEmitter, Input, Output } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';

type ContainerType = 'form' | 'info' | 'table' | 'panel' | 'fullwidth';

@Component({
  selector: 'qd-container',
  template:
    'showCreate: {{showCreate | json}}, defaultCreateState: {{defaultCreateState | json}}, containerType: {{containerType}}, collapsable: {{collapsable | json}}, editDisabled: {{editDisabled | json}}, isCollapsed: {{isCollapsed}}<ng-content></ng-content>'
})
export class QdMockContainerComponent {
  @Input() showCreate = false;
  @Input() defaultCreateState = false;
  @Input() containerType: ContainerType = 'form';
  @Input() collapsable = false;
  @Input() editDisabled = false;
  @Input() isCollapsed = false;
  @Input() formGroup: UntypedFormGroup = new UntypedFormGroup({});

  @Output() createChange = new EventEmitter<boolean>();
}
