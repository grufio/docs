import { Component } from '@angular/core';

@Component({
  selector: 'qd-create-delete-alert',
  template: ''
})
export class QdMockCreateDeleteAlertComponent {
  cancel() {
    return;
  }

  confirm() {
    return;
  }
}
