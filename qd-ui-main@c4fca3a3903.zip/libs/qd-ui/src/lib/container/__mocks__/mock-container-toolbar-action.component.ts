// @ts-strict-ignore
import { Component, Directive, EventEmitter, Input, Output } from '@angular/core';
import { QdContainerToolbarActionOptions } from '../model/toolbar.interface';

@Directive({
  selector: '[qdContainerToolbarActionSearch]'
})
export class QdMockContainerToolbarActionSearchDirective {}

@Component({
  selector: 'qd-container-toolbar-action',
  template: 'configData: {{configData | json}}'
})
export class QdMockContainerToolbarActionComponent {
  @Input() configData: QdContainerToolbarActionOptions;

  @Output() action = new EventEmitter();
  @Output() searchQueryStringOutput = new EventEmitter();
  @Output() searchPostBodyOutput = new EventEmitter();

  public startSearch() {
    return;
  }
}
