// @ts-strict-ignore
import { Component, Input } from '@angular/core';
import { QdContainerType } from '../model/container-type';

@Component({
  selector: 'qd-container-create-default',
  template: 'containerType {{containerType}}'
})
export class QdMockContainerCreateDefaultComponent {
  @Input() containerType: QdContainerType;
}
