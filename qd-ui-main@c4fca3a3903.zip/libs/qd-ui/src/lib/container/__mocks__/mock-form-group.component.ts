import { Component } from '@angular/core';

@Component({
  selector: 'qd-form-group-header-action',
  template: '<ng-content></ng-content>'
})
export class QdMockFormGroupHeaderActionComponent {}

@Component({
  selector: 'qd-form-group-header',
  template: '<ng-content></ng-content>'
})
export class QdMockFormGroupHeaderComponent {}

@Component({
  selector: 'qd-form-group',
  template: '<ng-content></ng-content>'
})
export class QdMockFormGroupComponent {
  get hasHeader() {
    return true;
  }
}
