import { Component } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'qd-container-toolbar',
  template: '<ng-content></ng-content>'
})
export class QdMockContainerToolbarComponent {
  collapsedChangeSubject = new Subject<boolean>();
  collapsedChange$ = this.collapsedChangeSubject.asObservable();
}
