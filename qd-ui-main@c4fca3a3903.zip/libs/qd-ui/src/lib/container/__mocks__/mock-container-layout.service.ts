import { Injectable } from '@angular/core';

@Injectable()
export class QdMockContainerLayoutService {
  updateContent = jest.fn();
}
