import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { QdToolbarActionType } from '../model/toolbar.interface';

@Injectable()
export class QdMockContainerActionService {
  private _action$ = new Subject<QdToolbarActionType>();
  action$ = this._action$.asObservable();

  emitAction = jest.fn(type => this._action$.next(type));
}
