import { Component } from '@angular/core';

@Component({
  selector: 'qd-container-toolbar-title',
  template: '<ng-content></ng-content>'
})
export class QdMockContainerToolbarTitleComponent {}
