import { Component } from '@angular/core';

@Component({
  selector: 'qd-container-toolbar-filter',
  template: '<ng-content></ng-content>'
})
export class QdMockContainerToolbarFilterComponent {}
