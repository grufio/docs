import { Injectable } from '@angular/core';
import { asyncScheduler, ReplaySubject } from 'rxjs';
import { observeOn } from 'rxjs/operators';

export interface QdContainerContent {
  'horizontal-pairs': boolean;
  'vertical-pairs': boolean;
  'status-pairs': boolean;
  'content-grid': boolean;
  'button-stack': boolean;
  exception: boolean;
}

export const defaultContainerContent: QdContainerContent = {
  'horizontal-pairs': false,
  'vertical-pairs': false,
  'status-pairs': false,
  'content-grid': false,
  'button-stack': false,
  exception: false
};

@Injectable()
export class QdContainerLayoutService {
  private _contentContent = defaultContainerContent;

  private readonly _contentSubject = new ReplaySubject<QdContainerContent>();
  content$ = this._contentSubject.asObservable().pipe(observeOn(asyncScheduler));

  constructor() {
    this._emitContent();
  }

  updateContent(update: Partial<QdContainerContent> = {}): void {
    this._contentContent = { ...this._contentContent, ...update };
    this._emitContent();
  }

  private _emitContent(): void {
    this._contentSubject.next(this._contentContent);
  }
}
