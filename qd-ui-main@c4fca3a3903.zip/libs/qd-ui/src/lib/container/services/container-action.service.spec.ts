import { TestBed } from '@angular/core/testing';

import { QdContainerActionService } from './container-action.service';

describe(`${QdContainerActionService.name} |`, () => {
  let service: QdContainerActionService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdContainerActionService]
    });
    service = TestBed.inject(QdContainerActionService);
  });

  test('"emitAction" triggers the action$ observable.', done => {
    service.action$.subscribe(() => done());

    service.emitAction();
  });
});
