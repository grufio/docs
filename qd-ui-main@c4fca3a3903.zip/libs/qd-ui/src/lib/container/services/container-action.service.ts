// @ts-strict-ignore
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { QdToolbarActionType } from '../model/toolbar.interface';

@Injectable()
export class QdContainerActionService {
  private _action$ = new Subject<QdToolbarActionType>();

  get action$(): Observable<QdToolbarActionType> {
    return this._action$.asObservable();
  }

  emitAction(type?: QdToolbarActionType): void {
    this._action$.next(type);
  }
}
