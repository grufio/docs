// @ts-strict-ignore
import { TestBed } from '@angular/core/testing';
import { QdContainerLayoutService } from './container-layout.service';
import { QdContainerActionService } from './container-action.service';

describe(`${QdContainerActionService.name} |`, () => {
  let service: QdContainerLayoutService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdContainerLayoutService]
    });
    service = TestBed.inject(QdContainerLayoutService);
  });

  test('it should be created', () => {
    expect(service).toBeTruthy();
  });
});
