/**
 * Defines the type of container.
 *
 * * @default 'form'
 */
export type QdContainerType = 'form' | 'info' | 'table' | 'panel' | 'fullwidth';

/**
 * Indicates whether the container has a legacy layout. Controlled by the old Master Layout and the Layout System.
 */
export type QdLegacyLayout = { hasLegacyLayout: boolean };
