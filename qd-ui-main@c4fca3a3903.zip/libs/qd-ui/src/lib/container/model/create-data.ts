import { Observable } from 'rxjs';

export interface QdContainerCreateDeleteAlertData {
  alertTitle: string | Observable<string>;
  warningText: string | Observable<string>;
  confirmText: string | Observable<string>;
  cancelText: string | Observable<string>;
}

export interface QdContainerContainerCreateData extends QdContainerCreateDeleteAlertData {
  createText: string | Observable<string>;
  deleteText: string | Observable<string>;
}

export interface QdContainerCreateDeleteAlertDataObservable {
  alertTitle: Observable<string>;
  warningText: Observable<string>;
  confirmText: Observable<string>;
  cancelText: Observable<string>;
}

export interface QdContainerCreateDataObservable extends QdContainerCreateDeleteAlertDataObservable {
  createText: Observable<string>;
  deleteText: Observable<string>;
}

export enum QdContainerCreateDeleteAlertResult {
  Confirm,
  Cancel
}
