import { QdSearchOptions } from '../../search/model/search-options.interface';

export interface QdContainerToolbarActionOptions {
  /**
   * @description Configures the action for toolbar
   */
  action?: QdToolbarActionOptions;

  /**
   * @description Enables the search bar.
   */
  search?: boolean;

  /**
   * @description Configuration object for the search bar.
   */
  searchOptions?: QdSearchOptions;
}

export interface QdToolbarActionOptions {
  /**
   * @description The icon to be shown. Can be left empty if no icon is needed. For a list of available icons see {@link https://quadrel.ezv.admin.ch/?path=/story/components-icon--icons-set}.
   */
  icon?: string;

  /**
   * @description Here you can define an action type that will be passed to the action output callback.
   * For defined types like "addNew" the default icon and i18n will be set automatically.
   */
  type?: QdToolbarActionType;

  /**
   * @description Translation key.
   */
  i18n?: string;

  /**
   * @description Determines whether this action is hidden or will be shown.
   */
  isHidden?: boolean;
}

/**
 * Type for toolbar actions that can be defined in the config.
 * It will be given as a parameter to the action click events.
 * For defined types like "addNew" the default icon and i18n will be set automatically.
 */
export type QdToolbarActionType = 'addNew' | string;
