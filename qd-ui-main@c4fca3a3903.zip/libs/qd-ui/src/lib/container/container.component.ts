// @ts-strict-ignore
import {
  AfterContentInit,
  AfterViewInit,
  Component,
  ContentChild,
  ContentChildren,
  ElementRef,
  forwardRef,
  HostBinding,
  Inject,
  Input,
  OnDestroy,
  OnInit,
  Optional,
  QueryList,
  Renderer2,
  ViewEncapsulation
} from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';

import { QdContainerActionService } from './services/container-action.service';
import { QdContainerContent, QdContainerLayoutService } from './services/container-layout.service';
import { QdContainerSectionComponent } from './section/container-section.component';
import { QdContainerToolbarComponent } from './toolbar/container-toolbar.component';
import { QdContainerType, QdLegacyLayout } from './model/container-type';
import { QdNotificationsComponent } from '../notifications/notifications/notifications.component';
import { QdTableComponent } from '../table/table.component';
import { QdTreeComponent } from '../tree/tree.component';

/**
 * This **QdContainer** is a content container for all interactive content, e.g. form fields, tables, etc.
 *
 * The Container can be used inside the Shell or inside the legacy Master Layout. Layout differences: In the Shell, the containerType `form` is displayed with a flexible width. In the Master Layout, it has a fixed width.
 *
 * * @see child component: **QdContainerToolbar**.
 *
 * **Usage:**
 *
 * @example
 * <qd-container>
 *   <qd-container-toolbar>
 *     <qd-container-toolbar-title>Title</qd-container-toolbar-title>
 *     <qd-container-toolbar-action>Action</qd-container-toolbar-action>
 *     <qd-container-toolbar-filter>
 *       <qd-filter [filterData]="config"></qd-filter>
 *     </qd-container-toolbar-filter>
 *   </qd-container-toolbar>
 *   Content
 * </qd-container>
 */
@Component({
  selector: 'qd-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [QdContainerLayoutService, QdContainerActionService],
  host: { class: 'qd-container' }
})
export class QdContainerComponent implements OnInit, AfterViewInit, AfterContentInit, OnDestroy {
  /**
   * Defines the type of container.
   *
   * `containerType="form"`
   * * If you use the containerType form you get a fixed width container.
   * * It contains a qdColumns="4" directive directly in the container
   *
   * `containerType="fullwidth"`
   * * Fullwidth Container is a 100% width container.
   *
   * `containerType="table"`
   * * Table Container is a 100% width container.
   * * It should only use table component as content.
   */
  @Input() containerType: QdContainerType = 'form';

  /**
   * The container will be collapsable when set to true. Works in all container types.
   */
  @Input() collapsable = false;

  /**
   * The FormGroup is used to indicate the valid state of the container.
   */
  @Input() formGroup: UntypedFormGroup = new UntypedFormGroup({});

  @HostBinding('class.qd-container-editDisabled')
  /**
   * Defines whether you can interact with the contents of the container.
   */
  @Input()
  editDisabled = false;

  @HostBinding('class.has-legacy-layout') get hasMasterLayout(): boolean {
    if (this._rwdLayout) return this._rwdLayout.hasLegacyLayout;

    return this._legacyMasterLayout?.hasLegacyLayout || this._legacyLayoutSystem?.hasLegacyLayout;
  }

  @ContentChild(forwardRef(() => QdContainerToolbarComponent))
  toolbarRef: QdContainerToolbarComponent;
  @ContentChild(forwardRef(() => QdTableComponent))
  qdTableRef: QdTableComponent<any>;
  @ContentChild(forwardRef(() => QdTreeComponent))
  qdTreeRef: QdTreeComponent<any>;

  @ContentChild(QdNotificationsComponent) notificationsRef: any;

  @ContentChildren(forwardRef(() => QdContainerSectionComponent))
  childSections: QueryList<QdContainerSectionComponent>;

  @HostBinding('class.qd-container-has-qd-table')
  get hasQdTable(): boolean {
    return !!this.qdTableRef;
  }

  @HostBinding('class.qd-container-has-qd-tree')
  get hasQdTree(): boolean {
    return !!this.qdTreeRef;
  }

  @HostBinding('class.qd-container-has-notifications')
  get hasNotifications(): boolean {
    return !!this.notificationsRef;
  }

  hasChildSections = false;
  private _content: QdContainerContent;
  private _sub = new Subscription();

  constructor(
    private _renderer: Renderer2,
    private _elementRef: ElementRef<HTMLElement>,
    private containerLayoutService: QdContainerLayoutService,
    @Optional() @Inject('rwdLayout') private _rwdLayout: QdLegacyLayout,
    @Optional() @Inject('legacyMasterLayout') private _legacyMasterLayout: QdLegacyLayout,
    @Optional() @Inject('legacyLayoutSystem') private _legacyLayoutSystem: QdLegacyLayout
  ) {}

  ngOnInit(): void {
    this._renderer.addClass(this._elementRef.nativeElement, `qd-container-type-${this.containerType}`);

    this._sub.add(
      this.containerLayoutService.content$.subscribe(content => {
        this._content = content;
        this._updateContent();
      })
    );
  }

  ngAfterViewInit(): void {
    this.logMissingHeader();
  }

  private logMissingHeader(): void {
    if (!this.toolbarRef) {
      console.error('QD-UI | QdContainerComponent - Please use the container always with a toolbar!');
    }
  }

  ngOnDestroy(): void {
    this._sub.unsubscribe();
  }

  ngAfterContentInit(): void {
    if (this.childSections.length > 0) {
      this.hasChildSections = true;
      this.childSections.forEach(s => {
        s.setContainerType(this.containerType);
      });
    }
  }

  addControls(childFormGroup: UntypedFormGroup): void {
    if (childFormGroup) {
      for (const [name, control] of Object.entries(childFormGroup.controls)) {
        this.formGroup.addControl(name, control);
      }
    }
  }

  removeControls(childFormGroup: UntypedFormGroup): void {
    if (childFormGroup) {
      for (const [name] of Object.entries(childFormGroup.controls)) {
        this.formGroup.removeControl(name);
      }

      // TODO: restore to initial value
      childFormGroup.markAsPristine();
    }
  }

  private _hasContent(name: string): boolean {
    return this._content ? !!this._content[name] : false;
  }

  private _updateContent(): void {
    Object.keys(this._content || {}).forEach(name => {
      if (this._hasContent(name)) {
        this._renderer.addClass(this._elementRef.nativeElement, `qd-container-has-${name}`);
      }
    });

    if (
      this._hasContent('horizontal-pairs') ||
      this._hasContent('vertical-pairs') ||
      this._hasContent('status-pairs')
    ) {
      this._renderer.addClass(this._elementRef.nativeElement, 'qd-container-has-pair-list');
    }
  }
}
