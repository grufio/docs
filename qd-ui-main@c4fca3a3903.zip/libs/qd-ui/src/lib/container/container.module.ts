import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

import { QdButtonModule } from '../button/button.module';
import { QdGridModule } from '../grid/grid.module';
import { QdIconModule } from '../icon/icon.module';
import { QdSearchModule } from '../search/search.module';

import { QdContainerComponent } from './container.component';
import { QdContainerSectionComponent } from './section/container-section.component';
import { QdContainerSectionHeaderComponent } from './section/header/container-section-header.component';
import { QdContainerSectionInfoComponent } from './section/info/container-section-info.component';
import { QdContainerToolbarActionComponent } from './toolbar/action/container-toolbar-action.component';
import {
  QdContainerToolbarActionOptions,
  QdToolbarActionOptions,
  QdToolbarActionType
} from './model/toolbar.interface';
import { QdContainerToolbarComponent } from './toolbar/container-toolbar.component';
import { QdContainerToolbarFilterComponent } from './toolbar/filter/container-toolbar-filter.component';
import { QdContainerToolbarTitleComponent } from './toolbar/title/container-toolbar-title.component';

export {
  QdContainerComponent,
  QdContainerSectionComponent,
  QdContainerSectionHeaderComponent,
  QdContainerSectionInfoComponent,
  QdContainerToolbarActionComponent,
  QdContainerToolbarActionOptions,
  QdToolbarActionOptions,
  QdToolbarActionType,
  QdContainerToolbarComponent,
  QdContainerToolbarFilterComponent,
  QdContainerToolbarTitleComponent
};

@NgModule({
  imports: [CommonModule, FormsModule, TranslateModule, QdButtonModule, QdGridModule, QdIconModule, QdSearchModule],
  declarations: [
    QdContainerComponent,
    QdContainerSectionComponent,
    QdContainerSectionHeaderComponent,
    QdContainerSectionInfoComponent,
    QdContainerToolbarActionComponent,
    QdContainerToolbarComponent,
    QdContainerToolbarFilterComponent,
    QdContainerToolbarTitleComponent
  ],
  exports: [
    QdContainerComponent,
    QdContainerSectionComponent,
    QdContainerSectionHeaderComponent,
    QdContainerSectionInfoComponent,
    QdContainerToolbarActionComponent,
    QdContainerToolbarComponent,
    QdContainerToolbarFilterComponent,
    QdContainerToolbarTitleComponent
  ]
})
export class QdContainerModule {}
