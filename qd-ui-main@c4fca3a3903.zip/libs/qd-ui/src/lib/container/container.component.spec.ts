// @ts-strict-ignore
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdMockGridModule } from '../grid/__mocks__/mock-grid.module';
import { QdMockContainerActionService } from './__mocks__/mock-container-action.service';
import { QdMockContainerLayoutService } from './__mocks__/mock-container-layout.service';
import { QdMockContainerSectionComponent } from './__mocks__/mock-container-section.component';
import { QdMockContainerToolbarComponent } from './__mocks__/mock-container-toolbar.component';
import { QdMockContainerToolbarTitleComponent } from './__mocks__/mock-container-toolbar-title.component';
import { QdMockTableComponent } from '../table/__mocks__/mock-table.module';
import { QdMockTreeComponent } from '../table/__mocks__/mock-tree.component';
import { QdContainerComponent } from './container.component';

jest.mock('./toolbar/container-toolbar.component', () => ({
  QdContainerToolbarComponent: require('./__mocks__/mock-container-toolbar.component').QdMockContainerToolbarComponent
}));

jest.mock('../table/table.component', () => ({
  QdTableComponent: require('../table/__mocks__/mock-table.component').QdMockTableComponent
}));

jest.mock('../tree/tree.component', () => ({
  QdTreeComponent: require('../table/__mocks__/mock-tree.component').QdMockTreeComponent
}));

@Component({
  selector: 'test-header-content',
  template: `
    <qd-container>
      <qd-container-toolbar>
        <qd-container-toolbar-title>Container Title</qd-container-toolbar-title>
      </qd-container-toolbar>
      Container Content
    </qd-container>
  `
})
class TestHeaderContentComponent {}

@Component({
  selector: 'test-toolbar-content',
  template: `
    <qd-container>
      <qd-container-toolbar>
        <qd-container-toolbar-title>Container Title</qd-container-toolbar-title>
      </qd-container-toolbar>
      Container Content
    </qd-container>
  `
})
class TestToolbarContentComponent {}

@Component({
  selector: 'test-without-header-or-toolbar',
  template: ` <qd-container> Container Content </qd-container> `
})
class TestWithoutHeaderOrToolbarComponent {}

@Component({
  selector: 'test-with-table',
  template: `
    <qd-container>
      <qd-container-toolbar>
        <qd-container-toolbar-title>Container Title</qd-container-toolbar-title>
      </qd-container-toolbar>
      <qd-table></qd-table>
    </qd-container>
  `
})
class TestWithTableComponent {}

@Component({
  selector: 'test-with-tree',
  template: `
    <qd-container>
      <qd-container-toolbar>
        <qd-container-toolbar-title>Container Title</qd-container-toolbar-title>
      </qd-container-toolbar>
      <qd-tree></qd-tree>
    </qd-container>
  `
})
class TestWithTreeComponent {}

describe('QdContainerComponent', () => {
  let consoleError: jest.SpyInstance;

  beforeEach(() => {
    consoleError = jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestHeaderContentComponent,
        TestToolbarContentComponent,
        TestWithoutHeaderOrToolbarComponent,
        TestWithTableComponent,
        TestWithTreeComponent,
        QdContainerComponent,
        QdMockContainerToolbarComponent,
        QdMockContainerToolbarTitleComponent,
        QdMockContainerSectionComponent,
        QdMockTableComponent,
        QdMockTreeComponent
      ],
      providers: [QdMockContainerLayoutService, QdMockContainerActionService],
      imports: [QdMockGridModule]
    }).compileComponents();
  }));

  describe('With Header and Content', () => {
    let component: TestHeaderContentComponent;
    let fixture: ComponentFixture<TestHeaderContentComponent>;

    beforeEach(() => {
      fixture = TestBed.createComponent(TestHeaderContentComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the component was rendered with Header and Content', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('no error is logged', () => {
      expect(consoleError).not.toHaveBeenCalled();
    });
  });

  describe('With Toolbar and Content', () => {
    let component: TestToolbarContentComponent;
    let fixture: ComponentFixture<TestToolbarContentComponent>;

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarContentComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the component was rendered with Toolbar and Content', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('no error is logged', () => {
      expect(consoleError).not.toHaveBeenCalled();
    });
  });

  describe('Without Header or Toolbar', () => {
    let component: TestWithoutHeaderOrToolbarComponent;
    let fixture: ComponentFixture<TestWithoutHeaderOrToolbarComponent>;

    beforeEach(() => {
      fixture = TestBed.createComponent(TestWithoutHeaderOrToolbarComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('an error is logged without Header or Toolbar', () => {
      expect(consoleError).toHaveBeenCalledWith(
        'QD-UI | QdContainerComponent - Please use the container always with a toolbar!'
      );
    });
  });

  describe('With QdTable', () => {
    let component: TestWithTableComponent;
    let fixture: ComponentFixture<TestWithTableComponent>;

    beforeEach(() => {
      fixture = TestBed.createComponent(TestWithTableComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('component is rendered with class qd-container-has-qd-table', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('With QdTree', () => {
    let component: TestWithTreeComponent;
    let fixture: ComponentFixture<TestWithTreeComponent>;

    beforeEach(() => {
      fixture = TestBed.createComponent(TestWithTreeComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('component is rendered with class qd-container-has-qd-tree', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });
});
