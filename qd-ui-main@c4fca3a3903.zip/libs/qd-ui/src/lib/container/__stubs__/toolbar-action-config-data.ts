// @ts-strict-ignore
import { QdContainerToolbarActionOptions } from '../model/toolbar.interface';

export const fullyDisabledToolbarActionConfigData: QdContainerToolbarActionOptions = {
  search: true,
  searchOptions: {
    preSelect: {
      disabled: false,
      optionsList: [
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.import', value: 'import' },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.export', value: 'export', active: true },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.transit', value: 'transit', disabled: true }
      ],
      globalSearch: {
        i18n: 'i18n.qd.search.global',
        disabled: false
      }
    },
    emptyAfterSearch: false
  }
};

export const preSelectDisabledToolbarActionConfigData: QdContainerToolbarActionOptions = {
  search: true,
  searchOptions: {
    preSelect: {
      disabled: true,
      optionsList: [
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.import', value: 'import' },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.export', value: 'export', active: true },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.transit', value: 'transit', disabled: true }
      ],
      globalSearch: {
        i18n: 'i18n.qd.search.global',
        disabled: false
      }
    },
    emptyAfterSearch: false
  }
};

export const toolbarActionConfigData: QdContainerToolbarActionOptions = {
  search: true,
  searchOptions: {
    preSelect: {
      disabled: false,
      optionsList: [
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.import', value: 'import' },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.export', value: 'export', active: true },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.transit', value: 'transit', disabled: true }
      ],
      globalSearch: {
        i18n: 'i18n.qd.search.global',
        disabled: false
      }
    },
    emptyAfterSearch: false
  }
};

export const addNewActionToolbarActionConfigData: QdContainerToolbarActionOptions = {
  action: {
    type: 'addNew'
  },
  search: true,
  searchOptions: {
    preSelect: {
      disabled: false,
      optionsList: [
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.import', value: 'import' },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.export', value: 'export', active: true },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.transit', value: 'transit', disabled: true }
      ],
      globalSearch: {
        i18n: 'i18n.qd.search.global',
        disabled: false
      }
    },
    emptyAfterSearch: false
  }
};

export const addNewActionWithoutIconToolbarActionConfigData: QdContainerToolbarActionOptions = {
  action: {
    type: 'addNew',
    icon: null
  },
  search: true,
  searchOptions: {
    preSelect: {
      disabled: false,
      optionsList: [
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.import', value: 'import' },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.export', value: 'export', active: true },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.transit', value: 'transit', disabled: true }
      ],
      globalSearch: {
        i18n: 'i18n.qd.search.global',
        disabled: false
      }
    },
    emptyAfterSearch: false
  }
};

export const customActionToolbarActionConfigData: QdContainerToolbarActionOptions = {
  action: {
    i18n: 'i18n.qd.container.toolbar.edit',
    type: 'edit',
    icon: 'pencil'
  },
  search: true,
  searchOptions: {
    preSelect: {
      disabled: false,
      optionsList: [
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.import', value: 'import' },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.export', value: 'export', active: true },
        { i18n: 'i18n.qd.exampleFormField.goodsDeclaration.transit', value: 'transit', disabled: true }
      ],
      globalSearch: {
        i18n: 'i18n.qd.search.global',
        disabled: false
      }
    },
    emptyAfterSearch: false
  }
};
