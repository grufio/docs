// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdContainerSectionComponent } from './container-section.component';
import { QdGridModule } from '../../grid/grid.module';

describe(`${QdContainerSectionComponent.name} |`, () => {
  let component: QdContainerSectionComponent;
  let fixture: ComponentFixture<QdContainerSectionComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [QdGridModule],
      declarations: [QdContainerSectionComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdContainerSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('it should create', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
