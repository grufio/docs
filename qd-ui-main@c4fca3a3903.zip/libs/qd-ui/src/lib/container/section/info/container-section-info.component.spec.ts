// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdContainerSectionInfoComponent } from './container-section-info.component';

describe(`${QdContainerSectionInfoComponent.name} |`, () => {
  let component: QdContainerSectionInfoComponent;
  let fixture: ComponentFixture<QdContainerSectionInfoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QdContainerSectionInfoComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdContainerSectionInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('it should create', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
