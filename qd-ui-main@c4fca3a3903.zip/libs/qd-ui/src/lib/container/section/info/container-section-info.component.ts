import { Component } from '@angular/core';

/**
 * The **QdContainerSectionInfo** was intended to have an optional text area on the right side. Belongs to `containerType="info"`.
 */
@Component({
  selector: 'qd-container-section-info',
  templateUrl: './container-section-info.component.html'
})
export class QdContainerSectionInfoComponent {}
