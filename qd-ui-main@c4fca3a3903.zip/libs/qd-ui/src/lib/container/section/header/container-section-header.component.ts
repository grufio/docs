import { Component, ViewEncapsulation } from '@angular/core';

/**
 * With **QdContainerSectionHeader** a related header can be created within the **QdContainerSection**.
 *
 * * @see parent component: **QdContainerSection**.
 */
@Component({
  selector: 'qd-container-section-header',
  templateUrl: './container-section-header.component.html',
  styleUrls: ['./container-section-header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class QdContainerSectionHeaderComponent {}
