// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdContainerSectionHeaderComponent } from './container-section-header.component';

describe(`${QdContainerSectionHeaderComponent.name} |`, () => {
  let component: QdContainerSectionHeaderComponent;
  let fixture: ComponentFixture<QdContainerSectionHeaderComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QdContainerSectionHeaderComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdContainerSectionHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('it should create', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
