// @ts-strict-ignore
import { Component, ElementRef, Input, OnInit, Renderer2 } from '@angular/core';
import { QdContainerType } from '../model/container-type';

/**
 * With **QdContainerSection** a **QdContainer** can be divided into several sections.
 *
 * * @see parent component: **QdContainer**.
 */
@Component({
  selector: 'qd-container-section',
  templateUrl: './container-section.component.html',
  styleUrls: ['./container-section.component.scss']
})
export class QdContainerSectionComponent implements OnInit {
  /**
   * Defines the type of container.
   */
  @Input() containerType: QdContainerType;

  constructor(private _renderer: Renderer2, private _elementRef: ElementRef<HTMLElement>) {}

  ngOnInit(): void {
    this.updateContainerTypeClass();
  }

  updateContainerTypeClass(): void {
    this._renderer.addClass(this._elementRef.nativeElement, `qd-container-section-type-${this.containerType}`);
  }

  setContainerType(containerType: QdContainerType): void {
    this.containerType = containerType;
    this.updateContainerTypeClass();
  }
}
