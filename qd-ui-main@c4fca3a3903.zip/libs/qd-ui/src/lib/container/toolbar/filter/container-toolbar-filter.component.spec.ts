// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { QdContainerToolbarFilterComponent } from './container-toolbar-filter.component';
import { Component } from '@angular/core';

@Component({
  template: ` <qd-container-toolbar-filter> Toolbar Filter </qd-container-toolbar-filter> `
})
class TestFilterComponent {}

describe(`${QdContainerToolbarFilterComponent.name} |`, () => {
  let component: TestFilterComponent;
  let fixture: ComponentFixture<TestFilterComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [TestFilterComponent, QdContainerToolbarFilterComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('the filter is rendered properly.', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
