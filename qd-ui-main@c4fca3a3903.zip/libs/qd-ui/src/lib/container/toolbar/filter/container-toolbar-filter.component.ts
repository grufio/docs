import { Component, ViewEncapsulation } from '@angular/core';

/**
 * The **QdContainerToolbarFilter** is a structure element in which a filter can be positioned.
 *
 * * @see child component: **QdFilter**.
 * * @see parent component: **QdContainerToolbar**.
 */
@Component({
  selector: 'qd-container-toolbar-filter',
  templateUrl: './container-toolbar-filter.component.html',
  styleUrls: ['./container-toolbar-filter.component.scss'],
  host: { class: 'qd-container-toolbar-filter' },
  encapsulation: ViewEncapsulation.None
})
export class QdContainerToolbarFilterComponent {}
