// @ts-strict-ignore
import { Component } from '@angular/core';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { QdContainerToolbarComponent } from './container-toolbar.component';
import { twoCategoriesConfigData } from '../../filter/__stubs__/filter-config-data';
import {
  QdMockContainerToolbarActionComponent,
  QdMockContainerToolbarFilterComponent,
  QdMockContainerToolbarTitleComponent
} from '../__mocks__/mock-container.module';
import { QdMockFilterComponent } from '../../filter/__mocks__/mock-filter';
import { By } from '@angular/platform-browser';
import { QdMockIconModule } from '../../icon/__mocks__/mock-icon.module';

@Component({
  template: `
    <qd-container-toolbar>
      <qd-container-toolbar-title>Title</qd-container-toolbar-title>
      <qd-container-toolbar-action>Action</qd-container-toolbar-action>
      <qd-container-toolbar-filter>
        <qd-filter [filterData]="filterData"></qd-filter>
      </qd-container-toolbar-filter>
    </qd-container-toolbar>
  `
})
class TestComponent {
  filterData = twoCategoriesConfigData;
}

describe(`${QdContainerToolbarComponent.name} |`, () => {
  let component;
  let fixture;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [QdMockIconModule],
      declarations: [
        TestComponent,
        QdContainerToolbarComponent,
        QdMockContainerToolbarTitleComponent,
        QdMockContainerToolbarActionComponent,
        QdMockContainerToolbarFilterComponent,
        QdMockFilterComponent
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Default Toolbar', () => {
    test('matches the snapshot.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('Toolbar in Collapsable Container', () => {
    let toolbar;

    beforeEach(() => {
      toolbar = fixture.debugElement.query(By.directive(QdContainerToolbarComponent)).componentInstance;
      toolbar.collapsable = true;
      fixture.detectChanges();
    });

    test('matches the snapshot.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('collapse is toggled correctly.', () => {
      const collapsedChangeFn = jest.fn();
      toolbar.collapsedChange$.subscribe(collapsedChangeFn);

      const toolbarTitleContainer = fixture.debugElement.query(By.css('.toolbar-title-container')).nativeElement;
      toolbarTitleContainer.click();
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
      expect(collapsedChangeFn).toHaveBeenCalledWith(true);
    });
  });
});
