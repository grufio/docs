// @ts-strict-ignore
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Optional,
  Output,
  SimpleChanges,
  ViewEncapsulation
} from '@angular/core';
import { QdSearchPostBodyData } from '../../../search/model/search-post-body';
import { QdSearchService } from '../../../search/services/search.service';
import { QdContainerToolbarActionOptions, QdToolbarActionOptions } from '../../model/toolbar.interface';
import { QdContainerActionService } from '../../services/container-action.service';

/**
 * The **QdContainerToolbarAction** is a structure element in which a search component  <br />
 * or an action button can be included via Input Properties.
 *
 * * @see parent component: **QdContainerToolbar**.
 */
@Component({
  selector: 'qd-container-toolbar-action',
  templateUrl: './container-toolbar-action.component.html',
  styleUrls: ['./container-toolbar-action.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: { class: 'qd-container-toolbar-action' },
  providers: [QdSearchService]
})
export class QdContainerToolbarActionComponent implements OnInit, OnChanges {
  private searchQueryString: string;
  private searchPostBody: QdSearchPostBodyData;
  private addNewActionDefaultToolbarActionOptions: QdToolbarActionOptions = {
    icon: 'plus',
    i18n: 'i18n.qd.container.toolbar.addNew'
  };

  /**
   * Configuration of this component
   */
  @Input() configData: QdContainerToolbarActionOptions;

  /**
   * Emits event on click/tap on action button.
   */
  @Output() actionOutput = new EventEmitter();

  /**
   * Emits event on click/tap of the search. Return value is the query string of the search.
   */
  @Output() searchQueryStringOutput = new EventEmitter<string>();

  /**
   * Emits event on click/tap of the search. Return value is the result object of the search
   */
  @Output() searchPostBodyOutput = new EventEmitter<QdSearchPostBodyData>();

  get searchEnabled(): boolean {
    return this.configData?.search;
  }

  get hasAction(): boolean {
    return this.configData?.action != null && !this.configData?.action?.isHidden;
  }

  constructor(
    private readonly searchService: QdSearchService,
    @Optional() private readonly containerActionService: QdContainerActionService
  ) {}

  private updateConfig(): void {
    if (this.configData?.action?.type === 'addNew') {
      this.configData.action = {
        ...this.addNewActionDefaultToolbarActionOptions,
        ...this.configData.action
      };
    }
  }

  ngOnInit(): void {
    if (!this.containerActionService) {
      console.warn(
        'QD-UI | QdContainer - Please wrap the component "QdContainerToolbarActionComponent" with a "QdContainer"!'
      );
    }

    this.updateConfig();

    this.searchService.searchQueryString$.subscribe(searchQueryString => {
      this.searchQueryString = searchQueryString;
    });

    this.searchService.searchPostBody$.subscribe(searchPostBody => {
      this.searchPostBody = searchPostBody;

      this.startSearch();
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['configData'] && !changes['configData'].isFirstChange()) {
      this.updateConfig();
    }
  }

  startSearch(): void {
    this.searchQueryStringOutput.emit(this.searchQueryString);
    this.searchPostBodyOutput.emit(this.searchPostBody);
  }

  clickAction(): void {
    const actionType = this.configData.action.type;

    this.actionOutput.emit(actionType);
    if (this.containerActionService) this.containerActionService.emitAction(actionType);
  }
}
