// @ts-strict-ignore
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

import { By } from '@angular/platform-browser';
import { QdMockButtonComponent } from '../../../button/__mocks__/mock-button.component';
import { QdMockInputComponent } from '../../../forms/__mocks__/mock-input.component';
import { QdMockIconComponent } from '../../../icon/__mocks__/mock-icon.component';
import { QdMockSearchComponent } from '../../../search/__mocks__/mock-search.component';
import { QdMockContainerActionService } from '../../__mocks__/mock-container-action.service';
import {
  addNewActionToolbarActionConfigData,
  addNewActionWithoutIconToolbarActionConfigData,
  customActionToolbarActionConfigData,
  fullyDisabledToolbarActionConfigData,
  preSelectDisabledToolbarActionConfigData,
  toolbarActionConfigData
} from '../../__stubs__/toolbar-action-config-data';
import { QdContainerToolbarActionOptions } from '../../container.module';
import { QdContainerActionService } from '../../services/container-action.service';
import { QdContainerToolbarActionComponent } from './container-toolbar-action.component';

@Component({
  template: ` <qd-container-toolbar-action> Toolbar Action Area</qd-container-toolbar-action> `
})
class TestToolbarActionNoConfigComponent {}

@Component({
  template: `
    <qd-container-toolbar-action [configData]="toolbarActionConfigData">
      Toolbar Action Area
    </qd-container-toolbar-action>
  `
})
class TestToolbarActionFullDisabledComponent {
  toolbarActionConfigData = fullyDisabledToolbarActionConfigData;
}

@Component({
  template: `
    <qd-container-toolbar-action [configData]="toolbarActionConfigData">
      Toolbar Action Area
    </qd-container-toolbar-action>
  `
})
class TestToolbarActionPreSelectDisabledComponent {
  toolbarActionConfigData = preSelectDisabledToolbarActionConfigData;
}

@Component({
  template: `
    <qd-container-toolbar-action [configData]="toolbarActionConfigData">
      Toolbar Action Area
    </qd-container-toolbar-action>
  `
})
class TestToolbarActionFullConfigComponent {
  toolbarActionConfigData = toolbarActionConfigData;
}

@Component({
  template: `
    <qd-container-toolbar-action [configData]="toolbarActionConfigData" (actionOutput)="action($event)">
      Toolbar Action Area
    </qd-container-toolbar-action>
  `
})
class TestToolbarActionAddNewActionComponent {
  toolbarActionConfigData = addNewActionToolbarActionConfigData;
  action = jest.fn();
}

@Component({
  template: `
    <qd-container-toolbar-action [configData]="toolbarActionConfigData">
      Toolbar Action Area
    </qd-container-toolbar-action>
  `
})
class TestToolbarActionAddNewActionWithoutIconComponent {
  toolbarActionConfigData = addNewActionWithoutIconToolbarActionConfigData;
}

@Component({
  template: `
    <qd-container-toolbar-action [configData]="toolbarActionConfigData">
      Toolbar Action Area
    </qd-container-toolbar-action>
  `
})
class TestToolbarActionAddNewActionHiddenComponent {
  toolbarActionConfigData: QdContainerToolbarActionOptions = {
    ...addNewActionWithoutIconToolbarActionConfigData,
    action: {
      ...addNewActionWithoutIconToolbarActionConfigData.action,
      isHidden: true
    }
  };
}

@Component({
  template: `
    <qd-container-toolbar-action [configData]="toolbarActionConfigData" (actionOutput)="action($event)">
      Toolbar Action Area
    </qd-container-toolbar-action>
  `
})
class TestToolbarCustomActionComponent {
  toolbarActionConfigData = customActionToolbarActionConfigData;
  action = jest.fn();
}

describe(`${TestToolbarActionNoConfigComponent.name} |`, () => {
  describe('without any configData', () => {
    let component: TestToolbarActionNoConfigComponent;
    let fixture: ComponentFixture<TestToolbarActionNoConfigComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionNoConfigComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionNoConfigComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the action area is rendered with container only.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('with fully disabled configData object', () => {
    let component: TestToolbarActionFullDisabledComponent;
    let fixture: ComponentFixture<TestToolbarActionFullDisabledComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionFullDisabledComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionFullDisabledComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the action area is rendered with container only.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('with preSelected disabled configData object', () => {
    let component: TestToolbarActionPreSelectDisabledComponent;
    let fixture: ComponentFixture<TestToolbarActionPreSelectDisabledComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionPreSelectDisabledComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionPreSelectDisabledComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the action area is rendered with container only.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('with fully configured configData object', () => {
    let component: TestToolbarActionFullConfigComponent;
    let fixture: ComponentFixture<TestToolbarActionFullConfigComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionFullConfigComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionFullConfigComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the actionarea is rendered with Search & without addNew Button.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('with addNew button', () => {
    let component: TestToolbarActionAddNewActionComponent;
    let fixture: ComponentFixture<TestToolbarActionAddNewActionComponent>;
    let containerActionService;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionAddNewActionComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent,
          QdMockButtonComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
      containerActionService = TestBed.inject(QdContainerActionService);
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionAddNewActionComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the actionarea is rendered with Search & addNew Button.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('action output is emitted when button is clicked', () => {
      fixture.debugElement.query(By.css('button')).nativeElement.click();

      expect(component.action).toHaveBeenCalledWith('addNew');
    });

    test('containerActionService is emitted when button is clicked', () => {
      fixture.debugElement.query(By.css('button')).nativeElement.click();

      expect(containerActionService.emitAction).toHaveBeenCalledWith('addNew');
    });

    test('the addNew Button is rendered with overwritten label.', () => {
      component.toolbarActionConfigData.action.i18n = 'i18n.my.custom.action.label';
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('config is updated correctly.', () => {
      component.toolbarActionConfigData = {
        ...component.toolbarActionConfigData,
        ...{
          action: {
            type: 'addNew',
            i18n: 'i18n.my.custom.action.label'
          }
        }
      };
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('with addNew button with hidden icon', () => {
    let component: TestToolbarActionAddNewActionWithoutIconComponent;
    let fixture: ComponentFixture<TestToolbarActionAddNewActionWithoutIconComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionAddNewActionWithoutIconComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent,
          QdMockButtonComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionAddNewActionWithoutIconComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the actionarea is rendered with Search & addNew Button with hidden icon.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('with addNew button hidden', () => {
    let component: TestToolbarActionAddNewActionHiddenComponent;
    let fixture: ComponentFixture<TestToolbarActionAddNewActionHiddenComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionAddNewActionHiddenComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent,
          QdMockButtonComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionAddNewActionHiddenComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('yields snapshot', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('with custom button', () => {
    let component: TestToolbarCustomActionComponent;
    let fixture: ComponentFixture<TestToolbarCustomActionComponent>;
    let containerActionService;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarCustomActionComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent,
          QdMockButtonComponent
        ],
        providers: [{ provide: QdContainerActionService, useClass: QdMockContainerActionService }]
      }).compileComponents();
      containerActionService = TestBed.inject(QdContainerActionService);
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarCustomActionComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the actionarea is rendered with custom Button.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('action output is emitted when button is clicked', () => {
      fixture.debugElement.query(By.css('button')).nativeElement.click();

      expect(component.action).toHaveBeenCalled();
    });

    test('containerActionService is emitted when button is clicked', () => {
      fixture.debugElement.query(By.css('button')).nativeElement.click();

      expect(containerActionService.emitAction).toHaveBeenCalledWith('edit');
    });
  });

  describe('without QdContainer and its QdContainerActionService', () => {
    let component: TestToolbarActionFullConfigComponent;
    let fixture: ComponentFixture<TestToolbarActionFullConfigComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [TranslateModule.forRoot(), FormsModule],
        declarations: [
          QdContainerToolbarActionComponent,
          TestToolbarActionFullConfigComponent,
          QdMockInputComponent,
          QdMockSearchComponent,
          QdMockIconComponent
        ]
      }).compileComponents();
      jest.spyOn(console, 'warn').mockImplementation(() => {});
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestToolbarActionFullConfigComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('a warning message has been triggered.', () => {
      expect(console.warn).toHaveBeenNthCalledWith(
        1,
        'QD-UI | QdContainer - Please wrap the component "QdContainerToolbarActionComponent" with a "QdContainer"!'
      );
    });
  });
});
