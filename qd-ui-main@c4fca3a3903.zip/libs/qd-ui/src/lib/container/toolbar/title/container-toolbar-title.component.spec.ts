// @ts-strict-ignore
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdContainerToolbarTitleComponent } from './container-toolbar-title.component';

@Component({
  template: ` <qd-container-toolbar-title> Toolbar Title </qd-container-toolbar-title> `
})
class TestTitleComponent {}

describe(`${QdContainerToolbarTitleComponent.name} | `, () => {
  let component: TestTitleComponent;
  let fixture: ComponentFixture<TestTitleComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [TestTitleComponent, QdContainerToolbarTitleComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('the title is rendered properly.', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
