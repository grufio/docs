import { Component, ViewEncapsulation } from '@angular/core';

/**
 * The **QdContainerToolbarTitle** creates a title that is displayed at the top left.
 *
 * * @see parent component: **QdContainerToolbar**.
 */
@Component({
  selector: 'qd-container-toolbar-title',
  templateUrl: './container-toolbar-title.component.html',
  styleUrls: ['./container-toolbar-title.component.scss'],
  host: { class: 'qd-container-toolbar-title' },
  encapsulation: ViewEncapsulation.None
})
export class QdContainerToolbarTitleComponent {}
