// @ts-strict-ignore
import { Component, ContentChild, HostBinding, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { QdContainerToolbarActionComponent } from './action/container-toolbar-action.component';
import { QdContainerToolbarFilterComponent } from './filter/container-toolbar-filter.component';
import { QdContainerToolbarTitleComponent } from './title/container-toolbar-title.component';

/**
 * The **QdContainerToolbar** can be used to execute some actions provided e.g. by the "Filter" or the "Search".
 *
 * * @see parent component: **QdContainer**.
 * * @see child components: **QdContainerToolbarTitle**, **QdContainerToolbarAction**, **QdContainerToolbarFilter**.
 */
@Component({
  selector: 'qd-container-toolbar',
  templateUrl: './container-toolbar.component.html',
  styleUrls: ['./container-toolbar.component.scss'],
  host: { class: 'qd-container-toolbar' },
  encapsulation: ViewEncapsulation.None
})
export class QdContainerToolbarComponent {
  @ContentChild(QdContainerToolbarTitleComponent)
  toolbarTitleComponent: QdContainerToolbarTitleComponent;

  @ContentChild(QdContainerToolbarActionComponent)
  toolbarActionComponent: QdContainerToolbarActionComponent;

  @ContentChild(QdContainerToolbarFilterComponent)
  toolbarFilterComponent: QdContainerToolbarFilterComponent;

  @HostBinding('class.qd-container-toolbar--has-title-only') get hasTitleOnly(): boolean {
    return this.toolbarTitleComponent && !this.toolbarActionComponent && !this.toolbarFilterComponent;
  }

  @HostBinding('class.qd-container-toolbar--has-title') get hasTitle(): boolean {
    return this.toolbarTitleComponent != null;
  }

  @HostBinding('class.qd-container-toolbar--has-action') get hasAction(): boolean {
    return this.toolbarActionComponent != null;
  }

  @HostBinding('class.qd-container-toolbar--has-filter') get hasFilter(): boolean {
    return this.toolbarFilterComponent != null;
  }

  @HostBinding('class.collapsable')
  collapsable = false;

  @HostBinding('class.collapsed')
  isCollapsed = false;

  private readonly _collapsedChangeSubject = new Subject<boolean>();
  collapsedChange$ = this._collapsedChangeSubject.asObservable();

  toggleCollapsed(): void {
    if (this.collapsable) {
      this.isCollapsed = !this.isCollapsed;
      this._collapsedChangeSubject.next(this.isCollapsed);
    }
  }
}
