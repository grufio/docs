import { QdChipComponent } from './chip.component';
import { QdChipModule } from '../chips.module';

const data = 'Closed';
const temp =
  '<qd-chip [state]="state" [close]="close" [data]=data (closeClickEmitter)="emitter($event)"> Chip </qd-chip>';
const config = {
  declarations: [QdChipComponent],
  imports: [QdChipModule],
  componentProperties: {
    state: 'error',
    close: false,
    data
  }
};

describe(QdChipComponent.name, () => {
  beforeEach(() => {});

  it('renders without close', () => {
    cy.mount(temp, config);
    cy.matchImage();
  });

  it('renders with close', () => {
    cy.mount(temp, {
      ...config,
      componentProperties: {
        ...config.componentProperties,
        state: 'success',
        close: true
      }
    });
    cy.matchImage();
  });

  it('invokes closeClickEmitter when closing chip', () => {
    cy.mount(temp, {
      ...config,
      componentProperties: {
        ...config.componentProperties,
        state: 'success',
        close: true,
        emitter: cy.spy().as('emitter')
      }
    });
    cy.get('.qd-icon > div').click();
    cy.get('@emitter').should('have.been.calledWith', data);
  });
});
