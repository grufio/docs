import {
  Component,
  EventEmitter,
  HostBinding,
  Input,
  Output,
  ViewEncapsulation,
  ViewChild,
  AfterContentChecked,
  ChangeDetectorRef
} from '@angular/core';
import { chipColorDefault, QdChipColor } from '../interfaces/chip.interface';

/**
 * The **QdChip** component can visualize different statuses.
 */
@Component({
  selector: 'qd-chip',
  templateUrl: './chip.component.html',
  styleUrls: ['./chip.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: { '[class]': 'classes' }
})
export class QdChipComponent implements AfterContentChecked {
  /**
   * Sets the state
   */
  @Input() state: QdChipColor = chipColorDefault;

  /**
   * If set, the chip receives an X-icon, with which an action is executed. <br /> Click/Tap triggers the "closeClickEmitter".
   */
  @Input() close = false;

  /**
   * Parameter for "closeClickEmitter".
   */
  @Input() data: any;

  /**
   * A static test ID for integration tests can be set. <br />
   * The value for the HTML attribute [data-test-id]. No property binding here.
   */
  @Input('data-test-id') testId = 'chip';

  /**
   * Emits event on click/tap of the close button. Return value is `data`.
   */
  @Output() closeClickEmitter = new EventEmitter<string>();

  @ViewChild('label') label;

  @HostBinding('class.empty') get isEmpty(): boolean {
    return this.empty;
  }

  empty = false;

  get classes(): string {
    return `qd-chip ${this.state || chipColorDefault}`;
  }

  constructor(private changeDetectorRef: ChangeDetectorRef) {}

  ngAfterContentChecked(): void {
    this.empty = this.label?.nativeElement?.innerHTML === '';
    this.changeDetectorRef.detectChanges();
  }

  clickClose(): void {
    this.closeClickEmitter.emit(this.data);
  }
}
