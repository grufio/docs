// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Component } from '@angular/core';

import { QdMockIconModule } from '../../icon/__mocks__/mock-icon.module';
import { QdChipComponent } from './chip.component';

@Component({
  template: ` <qd-chip>QdChip</qd-chip> `
})
class TestComponent {}

@Component({
  template: ` <qd-chip state="filter">QdChip</qd-chip> `
})
class TestFilterStateComponent {}

@Component({
  template: ` <qd-chip data="{ data: 'myData' }">QdChip</qd-chip> `
})
class TestDataComponent {}

@Component({
  template: ` <qd-chip close="true" (closeClickEmitter)="closeHandler()">QdChip</qd-chip> `
})
class TestCloseComponent {
  closeHandler = jest.fn();
}

@Component({
  template: ` <qd-chip>{{ label }}</qd-chip> `
})
class TestEmptyComponent {
  label: string;
}

describe(`${QdChipComponent.name} |`, () => {
  let component;
  let fixture;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [QdMockIconModule],
      declarations: [
        QdChipComponent,
        TestComponent,
        TestFilterStateComponent,
        TestDataComponent,
        TestCloseComponent,
        TestEmptyComponent
      ]
    }).compileComponents();
  }));

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  test('matches snapshot in "default" state.', () => {
    createComponent(TestComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot in "filter" state.', () => {
    createComponent(TestFilterStateComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('passes data passed into the component (used for filter).', () => {
    createComponent(TestDataComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with "close" button.', () => {
    createComponent(TestCloseComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('fires event if close buttons has benn clicked.', () => {
    createComponent(TestCloseComponent);

    fixture.debugElement.nativeElement.querySelector('.qd-icon').click();

    expect(component.closeHandler).toHaveBeenCalled();
  });

  test('matches snapshot in "empty" state.', () => {
    createComponent(TestEmptyComponent);
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot if label is set asynchronously.', done => {
    createComponent(TestEmptyComponent);

    setTimeout(() => {
      component.label = 'Async Value';
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
      done();
    }, 10);
  });
});
