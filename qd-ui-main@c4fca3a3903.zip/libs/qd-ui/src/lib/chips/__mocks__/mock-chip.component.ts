// @ts-strict-ignore
import { Component, EventEmitter, HostBinding, Input, Output } from '@angular/core';
import { chipColorDefault, QdChipColor } from '../interfaces/chip.interface';

@Component({
  selector: 'qd-chip',
  template: 'state: {{state}}, close: {{close | json}}, data: {{data}} <ng-content></ng-content>'
})
export class QdMockChipComponent {
  @Input() state: QdChipColor = chipColorDefault;
  @Input() close = false;
  @Input() data: any;

  @Input('data-test-id') testId = 'chip';

  @Output() closeClickEmitter = new EventEmitter<string>();

  @HostBinding('attr.data-test-id') get dataTestId(): string {
    return this.testId;
  }

  handleTestClose(value) {
    this.closeClickEmitter.emit(value);
  }
}
