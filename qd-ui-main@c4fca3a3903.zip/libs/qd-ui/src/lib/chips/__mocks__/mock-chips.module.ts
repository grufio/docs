import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QdMockChipComponent } from './mock-chip.component';

export { QdMockChipComponent };

@NgModule({
  imports: [CommonModule],
  declarations: [QdMockChipComponent],
  exports: [QdMockChipComponent]
})
export class QdMockChipModule {}
