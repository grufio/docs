import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { QdIconModule } from '../icon/icon.module';
import { QdChipComponent } from './chip/chip.component';
import { QdChipColor } from './interfaces/chip.interface';

export { QdChipComponent, QdChipColor };

@NgModule({
  imports: [CommonModule, QdIconModule],
  declarations: [QdChipComponent],
  exports: [QdChipComponent]
})
export class QdChipModule {}
