export type QdChipColor = 'inProcess' | 'ready' | 'success' | 'warning' | 'error' | 'archive' | 'filter' | 'none';
export const chipColorDefault: QdChipColor = 'inProcess';
