// @ts-strict-ignore
import { DialogRef } from '@angular/cdk/dialog';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterOutlet } from '@angular/router';
import { Component } from '@angular/core';
import { TranslatePipe } from '@ngx-translate/core';
import { MockComponent, MockDirective, MockPipe } from 'ng-mocks';
import { QdIconComponent } from '../icon/icon.module';
import { QdDialogComponent } from './dialog.component';
import { QdSectionComponent } from '../section/section.component';

@Component({
  template: `
    <qd-dialog>
      <qd-section></qd-section>
      <qd-section></qd-section>
      <qd-section></qd-section>
    </qd-dialog>
  `
})
class TestComponentWithSections {}

describe('DialogComponent', () => {
  let component: QdDialogComponent;
  let fixture: ComponentFixture<QdDialogComponent>;

  const dialogRefMock = {
    config: {},
    close: jest.fn()
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        MockPipe(TranslatePipe, i18n => (i18n ? 'Fake translation: ' + i18n : '')),
        MockDirective(RouterOutlet),
        MockComponent(QdIconComponent),
        MockComponent(QdSectionComponent),
        QdDialogComponent,
        TestComponentWithSections
      ],
      providers: [{ provide: DialogRef, useValue: dialogRefMock }]
    }).compileComponents();
  });

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  it('matches the snapshot', () => {
    createComponent(QdDialogComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  it('matches the snapshot with sections', () => {
    createComponent(TestComponentWithSections);
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  it('matches the snapshot with title', () => {
    createComponent(QdDialogComponent);

    component.config = {
      title: {
        i18n: 'i18n.dialog.title'
      }
    };
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  it('should close the dialog on close button click', () => {
    createComponent(QdDialogComponent);

    const closeButton = fixture.nativeElement.querySelector('.close');
    closeButton.click();
    expect(dialogRefMock.close).toHaveBeenCalled();
  });
});
