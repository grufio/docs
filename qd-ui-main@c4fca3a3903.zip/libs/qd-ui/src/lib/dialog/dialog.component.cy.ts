// @ts-strict-ignore
import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { MountConfig } from 'cypress/angular';
import { DialogExampleComponent } from '../../../../../stories/2_components/dialog/dialog-example/dialog-example.component';
import { DialogWithPageExampleComponent } from '../../../../../stories/2_components/dialog/dialog-example/dialog-with-page-example.component';
import { QdButtonModule } from '../button/button.module';
import { QdContentGridModule } from '../content-grid/content-grid.module';
import { QdStepperModule } from '../navigation/stepper/stepper.module';
import { QdPageModule } from '../page/page.module';
import { QdTextSectionModule } from '../text-section/text-section.module';
import { QdDialogComponent } from './dialog.component';
import { QdDialogModule } from './dialog.module';
import { QdDialogConfig, QdDialogSize, QdDialogTitle } from './models/dialog-config.model';
import { QdDialogService } from './services/dialog.service';
import { DialogWithBannerExampleComponent } from '../../../../../stories/2_components/dialog/dialog-example/dialog-with-banner-example.component';

const dialogConfig: QdDialogConfig = {
  data: {
    animal: 'panda'
  },
  hideCloseHeaderButton: false
};

@Component({
  selector: 'qd-dialog-test',
  template: `
    <button data-test-id="dialog-button" (click)="openDialog()">Open Dialog!</button>
    <button data-test-id="page-dialog-button" (click)="openDialogWithPage()">Open Dialog with page!</button>
    <button data-test-id="banner-dialog-button" (click)="openDialogWithBanner()">Open Dialog with banner!</button>
  `
})
class DialogTestComponent {
  private config: QdDialogConfig = dialogConfig;

  @Input()
  hideCloseHeaderButton: boolean;

  @Input()
  dialogSize: QdDialogSize;

  @Input()
  title: QdDialogTitle;

  constructor(private service: QdDialogService) {}

  openDialog() {
    this.service.open(DialogExampleComponent, {
      ...this.config,
      dialogSize: this.dialogSize,
      hideCloseHeaderButton: this.hideCloseHeaderButton,
      title: this.title
    });
  }

  openDialogWithPage() {
    this.service.open(DialogWithPageExampleComponent, {
      ...this.config,
      dialogSize: this.dialogSize,
      hideCloseHeaderButton: this.hideCloseHeaderButton,
      title: this.title
    });
  }

  openDialogWithBanner() {
    this.service.open(DialogWithBannerExampleComponent, {
      ...this.config,
      dialogSize: this.dialogSize,
      hideCloseHeaderButton: this.hideCloseHeaderButton,
      title: this.title
    });
  }
}

const template = `<qd-dialog-test [hideCloseHeaderButton]="hideCloseHeaderButton" [dialogSize]="size" [title]="title"></qd-dialog-test>`;

const mountConfig: MountConfig<any> = {
  imports: [
    QdDialogModule,
    TranslateModule.forRoot({}),
    StoreModule.forRoot({}),
    CommonModule,
    QdButtonModule,
    QdPageModule,
    QdTextSectionModule,
    QdContentGridModule,
    QdStepperModule
  ],
  declarations: [
    QdDialogComponent,
    DialogTestComponent,
    DialogExampleComponent,
    DialogWithPageExampleComponent,
    DialogWithBannerExampleComponent
  ],
  componentProperties: {
    size: QdDialogSize.Default,
    title: { i18n: 'Title' },
    hideCloseHeaderButton: true
  }
};

context(QdDialogComponent.name, () => {
  describe('with close header button', () => {
    beforeEach(() => {
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties,
          hideCloseHeaderButton: false
        }
      });
    });

    it('renders', () => {
      cy.get('[data-test-id="dialog-button"]').click();
      cy.matchImage();
    });

    it('closes dialog when pressing close header button', () => {
      cy.get('[data-test-id="dialog-button"]').click();
      cy.get('.close').click();
      cy.matchImage();
    });
  });

  describe('with small size', () => {
    beforeEach(() => {
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties,
          size: QdDialogSize.Small
        }
      });
    });

    it('renders', () => {
      cy.get('[data-test-id="dialog-button"]').click();
      cy.matchImage();
    });
  });

  describe('with mobile screen size', () => {
    beforeEach(() => {
      cy.viewport('iphone-8');
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties
        }
      });
    });

    it('renders', () => {
      cy.get('[data-test-id="dialog-button"]').click();
      cy.matchImage();
    });
  });

  describe('with mobile screen size in landscape', () => {
    beforeEach(() => {
      cy.viewport('iphone-8', 'landscape');
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties
        }
      });
    });

    it('renders', () => {
      cy.get('[data-test-id="dialog-button"]').click();
      cy.matchImage();
    });
  });

  describe('in full width with page', () => {
    beforeEach(() => {
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties,
          size: QdDialogSize.FullWidth
        }
      });
    });

    it('renders', () => {
      cy.get('[data-test-id="page-dialog-button"]').click();
      cy.matchImage();
    });
  });

  describe('with info banner', () => {
    beforeEach(() => {
      cy.mount(template, mountConfig);
    });

    it('renders', () => {
      cy.get('[data-test-id="banner-dialog-button"]').click();
      cy.matchImage();
    });
  });
});
