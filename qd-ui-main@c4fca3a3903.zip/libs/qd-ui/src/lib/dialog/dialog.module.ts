import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DialogModule as CDKDialogModule } from '@angular/cdk/dialog';
import { TranslateModule } from '@ngx-translate/core';

import { QdButtonModule } from '../button/button.module';
import { QdIconModule } from '../icon/icon.module';
import { QdNotificationsModule } from '../notifications/notifications.module';
import { QdFormModule } from '../forms/qd-form.module';
import { QdTextSectionModule } from '../text-section/text-section.module';
import { QdSpinnerModule } from '../spinner/spinner.module';

import { QdDialogActionComponent } from './action/dialog-action.component';
import { QdDialogComponent } from './dialog.component';
import { QdDialogConfig, QdDialogSize, QdDialogTitle } from './models/dialog-config.model';
import { QdDialogService } from './services/dialog.service';
import { QdDialogAuthSessionEndService } from './services/dialog-auth-session-end.service';
import { QdDialogRecordStepperComponent } from './record-stepper/dialog-record-stepper.component';
import {
  QdDialogConfirmationComponent,
  QdDialogConfirmationErrorDirective,
  QdDialogConfirmationInfoDirective,
  QdDialogConfirmationSuccessDirective
} from './confirmation/dialog-confirmation.component';
import { QdDialogAuthSessionEndComponent } from './auth-session-end/dialog-auth-session-end.component';
import {
  QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN,
  QdDialogConfirmationConfig,
  QdDialogConfirmationResolver
} from './models/confirmation.model';
import { QdDialogData } from './models/record-stepper.model';
import { QdDialogAuthSessionEndResult } from './models/session-end-result.model';
import { QdPageDialogWithBreadcrumbsComponent } from './page-dialog-with-breadcrumbs/page-dialog-with-breadcrumbs.component';
import { QdCoreModule } from '../core/core.module';
import { QdBreadcrumbsModule } from '../core/breadcrumbs/breadcrumbs.module';

export {
  QdDialogComponent,
  QdDialogActionComponent,
  QdDialogRecordStepperComponent,
  QdDialogAuthSessionEndComponent,
  QdDialogConfirmationComponent,
  QdDialogConfirmationErrorDirective,
  QdDialogConfirmationInfoDirective,
  QdDialogConfirmationSuccessDirective,
  QdDialogService,
  QdDialogAuthSessionEndService,
  QdDialogConfig,
  QdDialogTitle,
  QdDialogSize,
  QdDialogData,
  QdDialogAuthSessionEndResult,
  QdDialogConfirmationConfig,
  QdDialogConfirmationResolver,
  QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN
};

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    RouterModule,
    CDKDialogModule,
    QdButtonModule,
    QdFormModule,
    QdIconModule,
    QdNotificationsModule,
    QdSpinnerModule,
    QdTextSectionModule,
    QdCoreModule,
    QdBreadcrumbsModule
  ],
  declarations: [
    QdDialogActionComponent,
    QdDialogAuthSessionEndComponent,
    QdDialogComponent,
    QdDialogConfirmationComponent,
    QdDialogConfirmationErrorDirective,
    QdDialogConfirmationInfoDirective,
    QdDialogConfirmationSuccessDirective,
    QdDialogRecordStepperComponent,
    QdPageDialogWithBreadcrumbsComponent
  ],
  exports: [
    QdDialogActionComponent,
    QdDialogAuthSessionEndComponent,
    QdDialogComponent,
    QdDialogConfirmationComponent,
    QdDialogConfirmationErrorDirective,
    QdDialogConfirmationSuccessDirective,
    QdDialogRecordStepperComponent
  ]
})
export class QdDialogModule {}
