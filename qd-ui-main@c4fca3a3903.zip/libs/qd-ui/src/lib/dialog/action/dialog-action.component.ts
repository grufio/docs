import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'qd-dialog-action',
  templateUrl: './dialog-action.component.html',
  styleUrls: ['./dialog-action.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDialogActionComponent {}
