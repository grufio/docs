// @ts-strict-ignore
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { QdDialogActionComponent } from './dialog-action.component';

describe('DialogActionComponent', () => {
  let component: QdDialogActionComponent;
  let fixture: ComponentFixture<QdDialogActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [QdDialogActionComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(QdDialogActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should match screenshot', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
