import { DialogRef } from '@angular/cdk/dialog';
import { Component, Directive, Inject, Input, OnDestroy, OnInit, Optional } from '@angular/core';
import { Subscription } from 'rxjs';

import { QdFormCheckboxesConfiguration } from '../../forms/model/forms.interface';
import { QdNotificationsService } from '../../notifications/services/notifications-service.service';
import { QdSnackbarService } from '../../notifications/services/snackbar.service';
import {
  QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN,
  QdDialogConfirmationConfig,
  QdDialogConfirmationResolver
} from '../models/confirmation.model';
import { QdDialogService } from '../services/dialog.service';

@Directive({
  selector: '[qdDialogConfirmationInfo]'
})
export class QdDialogConfirmationInfoDirective {}

@Directive({
  selector: '[qdDialogConfirmationSuccess]'
})
export class QdDialogConfirmationSuccessDirective {}

@Directive({
  selector: '[qdDialogConfirmationError]'
})
export class QdDialogConfirmationErrorDirective {}

/**
 * `QdDialogConfirmationComponent` represents a confirmation dialog for your application.
 * It handles different states (info, success, error) based on the configuration.
 * The component uses `QdDialogConfirmationConfig` to configure its behavior and appearance.
 *
 * ####**Usage**
 *
 * ```ts
 * // Your custom confirmation resolver service
 * @Injectable()
 * export class MyDialogConfirmationService implements QdDialogConfirmationResolver {
 *   resolve(): Observable<boolean> {
 *     // Your API call
 *   }
 * }
 *
 * // Your custom dialog content component
 * @Component({
 *   selector: 'my-dialog-confirmation-content',
 *   templateUrl: 'my-dialog-confirmation-content.html',
 *   providers: [
 *     {
 *       provide: QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN,
 *       useClass: MyDialogConfirmationService
 *     }
 *   ],
 *   ...
 *   })
 * class DialogConfirmationContentComponent {
 *   dialogConfig: QdDialogConfirmationConfig = { ... }
 * }
 *
 * // Your custom dialog toggle component
 * @Component({
 *   selector: 'my-dialog-confirmation-toggle',
 *   template: ` <button qdButton (click)="open()">Open Dialog</button> `
 * })
 * class DialogConfirmationToggleErrorComponent {
 *   get config(): QdDialogConfig {
 *     return {
 *       title: { i18n: 'i18n.my.dialog.title' },
 *       dialogSize: QdDialogSize.Small
 *     };
 *   }
 *
 *   constructor(private service: QdDialogService) {}
 *
 *   open() {
 *     const dialogRef = this.service.open(DialogConfirmationContentComponent, this.config);
 *
 *     dialogRef.closed.subscribe(result => console.log(result));
 *   }
 * }
 * ```
 *
 * ```html
 * // Your custom dialog content template
 * <qd-dialog-confirmation [config]="dialogConfig">
 *   <qd-text-section qdDialogConfirmationInfo>Your custom info content</qd-text-section>
 *   <qd-text-section qdDialogConfirmationSuccess>Your custom success content</qd-text-section>
 *   <qd-text-section qdDialogConfirmationError>Your custom error content</qd-text-section>
 * </qd-dialog-confirmation>
 * ```
 */

@Component({
  selector: 'qd-dialog-confirmation',
  templateUrl: './dialog-confirmation.component.html',
  styleUrls: ['./dialog-confirmation.component.scss']
})
export class QdDialogConfirmationComponent implements OnInit, OnDestroy {
  /**
   * The configuration object of the QdDialogConfirm component.
   */
  @Input({ required: true }) config!: QdDialogConfirmationConfig;

  /**
   * A static test ID for integration tests can be set.
   * The value for the HTML attribute [data-test-id].
   */
  @Input('data-test-id') testId = 'confirmation-dialog';

  notificationContext = 'confirm-modal';
  confirmChecked: string[] = [];
  checkboxConfig?: QdFormCheckboxesConfiguration;

  private _confirmSubscription = new Subscription();

  get isLoading(): boolean {
    return this.dialogService.isConfirmationLoading;
  }

  get isInfoState(): boolean {
    return this.dialogService.isConfirmationInfo;
  }

  get isSuccessState(): boolean {
    return this.dialogService.isConfirmationSuccess;
  }

  get isErrorState(): boolean {
    return this.dialogService.isConfirmationError;
  }

  get isConfirmed(): boolean {
    return this.confirmChecked?.[0] === 'confirmed';
  }

  get useCheckbox(): boolean {
    return this.config.useCheckbox !== undefined ? this.config.useCheckbox : true;
  }

  constructor(
    @Optional()
    @Inject(QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN)
    private readonly confirmationResolver: QdDialogConfirmationResolver,
    private readonly dialogService: QdDialogService,
    private readonly qdNotificationService: QdNotificationsService,
    private readonly dialogRef: DialogRef,
    private readonly snackbarService: QdSnackbarService
  ) {}

  ngOnInit(): void {
    this.snackbarService.pause();

    this._confirmSubscription.add(
      this.dialogRef?.closed.subscribe(() => {
        this.dialogService.resetConfirmation();
        this.qdNotificationService.removeAll(this.notificationContext);
      })
    );

    this.checkboxConfig = {
      options: [
        {
          i18n: this.config.checkboxLabel?.i18n || 'i18n.qd.dialog.confirmation.checkbox.label',
          value: 'confirmed'
        }
      ]
    };
  }

  ngOnDestroy(): void {
    this.snackbarService.resume();
    this.qdNotificationService.removeAll(this.notificationContext);
    this.dialogService.resetConfirmation();
    this._confirmSubscription.unsubscribe();
  }

  close(): void {
    this.dialogRef?.close();
  }

  confirm(): void {
    this.dialogService.startConfirmation();

    this._confirmSubscription.add(
      this.confirmationResolver.resolve().subscribe({
        next: () => this.handleSuccess(),
        error: errors => this.handleError(errors)
      })
    );
  }

  submit(): void {
    this.dialogRef?.close(this.dialogService.confirmationStatus);
  }

  private handleSuccess(): void {
    this.dialogService.confirmationSuccess();
  }

  private handleError(err: string | string[]): void {
    this.dialogService.confirmationError();

    (Array.isArray(err) ? err : [err]).forEach(e => this.addErrorNotification(e));
  }

  private addErrorNotification(key: string): void {
    this.qdNotificationService.add(this.notificationContext, {
      type: 'critical',
      i18n: key,
      disableClose: true
    });
  }
}
