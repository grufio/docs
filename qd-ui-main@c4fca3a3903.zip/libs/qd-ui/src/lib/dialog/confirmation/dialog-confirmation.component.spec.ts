import { DialogRef } from '@angular/cdk/dialog';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';
import { MockComponent, MockDirective, MockService } from 'ng-mocks';
import { of, Subject, throwError } from 'rxjs';

import { QdMockTranslatePipe } from '../../core/__mocks__/mock-translate.pipe';
import { QdMockTranslateService } from '../../core/__mocks__/mock-translate.service';
import { QdCheckboxesComponent } from '../../forms/checkboxes/checkboxes.component';
import { QdIconComponent } from '../../icon/icon/icon.component';
import { QdNotificationsComponent } from '../../notifications/notifications/notifications.component';
import { QdNotificationsService } from '../../notifications/services/notifications-service.service';
import { QdSnackbarService } from '../../notifications/services/snackbar.service';
import { QdSpinnerComponent } from '../../spinner/spinner.component';
import { QdDialogActionComponent } from '../action/dialog-action.component';
import { QdDialogComponent } from '../dialog.component';
import { QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN, QdDialogConfirmationResolver } from '../models/confirmation.model';
import { QdDialogService } from '../services/dialog.service';
import {
  QdDialogConfirmationComponent,
  QdDialogConfirmationErrorDirective,
  QdDialogConfirmationInfoDirective,
  QdDialogConfirmationSuccessDirective
} from './dialog-confirmation.component';

@Component({
  template: `
    <div qdDialogConfirmationInfo></div>
    <div qdDialogConfirmationSuccess></div>
    <div qdDialogConfirmationError></div>
  `
})
class TestComponent {}

describe('Testing QdDialogConfirmDirectives |', () => {
  let fixture: ComponentFixture<TestComponent>;
  let infoDebugElement: DebugElement;
  let successDebugElement: DebugElement;
  let errorDebugElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        QdDialogConfirmationInfoDirective,
        QdDialogConfirmationSuccessDirective,
        QdDialogConfirmationErrorDirective
      ]
    });

    fixture = TestBed.createComponent(TestComponent);
    fixture.detectChanges();

    infoDebugElement = fixture.debugElement.query(By.directive(QdDialogConfirmationInfoDirective));
    successDebugElement = fixture.debugElement.query(By.directive(QdDialogConfirmationSuccessDirective));
    errorDebugElement = fixture.debugElement.query(By.directive(QdDialogConfirmationErrorDirective));
  });

  test('creates an instance of QdDialogConfirmInfoDirective', () => {
    expect(infoDebugElement).toBeTruthy();
  });

  test('creates an instance of QdDialogConfirmSuccessDirective', () => {
    expect(successDebugElement).toBeTruthy();
  });

  test('creates an instance of QdDialogConfirmErrorDirective', () => {
    expect(errorDebugElement).toBeTruthy();
  });
});

const CONFIRMATION_DIALOG_CONFIG = {
  info: {
    headline: { i18n: 'i18n.qd.example.dialog.confirmation.info.headline' },
    info: { i18n: 'i18n.qd.example.dialog.confirmation.info.info' }
  },
  success: {
    headline: { i18n: 'i18n.qd.example.dialog.confirmation.success.headline' },
    info: { i18n: 'i18n.qd.example.dialog.confirmation.success.info' }
  },
  error: {
    headline: { i18n: 'i18n.qd.example.dialog.confirmation.error.headline' },
    info: { i18n: 'i18n.qd.example.dialog.confirmation.error.info' }
  },
  buttons: {
    cancel: { i18n: 'i18n.qd.example.dialog.confirmation.buttons.cancel' },
    next: { i18n: 'i18n.qd.example.dialog.confirmation.buttons.next' },
    success: { i18n: 'i18n.qd.example.dialog.confirmation.buttons.success' },
    error: { i18n: 'i18n.qd.example.dialog.confirmation.buttons.error' }
  },
  useCheckbox: true,
  checkboxLabel: { i18n: 'i18n.qd.example.dialog.confirmation.checkbox.label' }
};

class MockQdDialogConfirmationResolver implements QdDialogConfirmationResolver {
  resolve() {
    return of(true);
  }
}

const mockDialogRef: jest.Mocked<any> = {
  closed: new Subject<void>(),
  close: jest.fn()
} as any;

describe(`Testing ${QdDialogConfirmationComponent.name} |`, () => {
  let component: QdDialogConfirmationComponent;
  let fixture: ComponentFixture<QdDialogConfirmationComponent>;
  let mockDialogService;
  let mockSnackbarService;
  let mockNotificationService;
  let mockConfirmationResolver;

  beforeEach(async () => {
    mockDialogService = MockService(QdDialogService) as jest.Mocked<QdDialogService>;
    mockNotificationService = MockService(QdNotificationsService) as jest.Mocked<QdNotificationsService>;
    mockConfirmationResolver = new MockQdDialogConfirmationResolver();
    mockSnackbarService = MockService(QdSnackbarService) as jest.Mocked<QdSnackbarService>;

    await TestBed.configureTestingModule({
      declarations: [
        QdDialogConfirmationComponent,
        MockDirective(QdDialogConfirmationInfoDirective),
        MockDirective(QdDialogConfirmationSuccessDirective),
        MockDirective(QdDialogConfirmationErrorDirective),
        MockComponent(QdDialogComponent),
        MockComponent(QdDialogActionComponent),
        MockComponent(QdNotificationsComponent),
        MockComponent(QdCheckboxesComponent),
        MockComponent(QdSpinnerComponent),
        MockComponent(QdIconComponent),
        QdMockTranslatePipe
      ],
      providers: [
        { provide: QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN, useValue: mockConfirmationResolver },
        { provide: QdDialogService, useValue: mockDialogService },
        { provide: QdSnackbarService, useValue: mockSnackbarService },
        { provide: QdNotificationsService, useValue: mockNotificationService },
        { provide: DialogRef, useValue: mockDialogRef },
        { provide: TranslateService, useClass: QdMockTranslateService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QdDialogConfirmationComponent);
    component = fixture.componentInstance;
    component.config = CONFIRMATION_DIALOG_CONFIG;

    fixture.detectChanges();
  });

  test('renders info state correctly', () => {
    mockDialogService.isConfirmationLoading = false;
    mockDialogService.isConfirmationInfo = true;

    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.headline').textContent).toContain(
      'i18n.qd.example.dialog.confirmation.info.headline'
    );
    expect(fixture.nativeElement.querySelector('.info').textContent).toContain(
      'i18n.qd.example.dialog.confirmation.info.info'
    );
    expect(fixture.nativeElement.querySelector('qd-checkboxes')).not.toBeNull();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('renders success state correctly', () => {
    mockDialogService.isConfirmationLoading = false;
    mockDialogService.isConfirmationSuccess = true;

    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.headline').textContent).toContain(
      'i18n.qd.example.dialog.confirmation.success.headline'
    );
    expect(fixture.nativeElement.querySelector('.info').textContent).toContain(
      'i18n.qd.example.dialog.confirmation.success.info'
    );

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('renders error state correctly', () => {
    mockDialogService.isConfirmationLoading = false;
    mockDialogService.isConfirmationError = true;

    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.headline').textContent).toContain(
      'i18n.qd.example.dialog.confirmation.error.headline'
    );
    expect(fixture.nativeElement.querySelector('.info').textContent).toContain(
      'i18n.qd.example.dialog.confirmation.error.info'
    );

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('does not render checkbox if useCheckbox is false in config', () => {
    mockDialogService.isConfirmationLoading = false;
    mockDialogService.isConfirmationInfo = true;
    component.config = { ...CONFIRMATION_DIALOG_CONFIG, useCheckbox: false };

    fixture.detectChanges();

    const checkbox = fixture.nativeElement.querySelector('qd-checkboxes');

    expect(checkbox).toBeNull();
  });

  test('renders checkbox and updates confirmChecked correctly', () => {
    mockDialogService.isConfirmationLoading = false;
    mockDialogService.isConfirmationInfo = true;

    fixture.detectChanges();

    const checkbox = fixture.nativeElement.querySelector('qd-checkboxes');
    expect(checkbox).not.toBeNull();

    component.confirmChecked = ['confirmed'];
    fixture.detectChanges();

    expect(component.isConfirmed).toBe(true);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('renders loading state correctly', () => {
    mockDialogService.isConfirmationLoading = true;

    fixture.detectChanges();

    expect(fixture.nativeElement.querySelector('.loading-overlay')).not.toBeNull();
    expect(fixture.nativeElement.querySelector('qd-spinner')).not.toBeNull();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('handles resolve() success correctly', () => {
    mockDialogService.isConfirmationLoading = false;
    mockDialogService.isConfirmationInfo = true;
    mockConfirmationResolver.resolve = jest.fn().mockReturnValue(of(true));

    component.confirm();

    expect(mockDialogService.startConfirmation).toHaveBeenCalled();
    expect(mockConfirmationResolver.resolve).toHaveBeenCalled();
    expect(mockDialogService.confirmationSuccess).toHaveBeenCalled();

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('handles resolve() error correctly', () => {
    const error = 'Error occurred';

    mockDialogService.isConfirmationLoading = false;
    mockDialogService.isConfirmationInfo = true;
    mockConfirmationResolver.resolve = jest.fn().mockReturnValue(throwError(() => error));

    component.confirm();

    expect(mockDialogService.startConfirmation).toHaveBeenCalled();
    expect(mockConfirmationResolver.resolve).toHaveBeenCalled();
    expect(mockDialogService.confirmationError).toHaveBeenCalled();
    expect(mockNotificationService.add).toHaveBeenCalledWith('confirm-modal', {
      type: 'critical',
      i18n: error,
      disableClose: true
    });

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('closes the dialog', () => {
    component.close();
    expect(mockDialogRef.close).toHaveBeenCalled();
  });

  test('calls dialogRef.close() on submit', () => {
    component.submit();
    expect(mockDialogRef.close).toHaveBeenCalledWith(mockDialogService.confirmationStatus);
  });

  test('calls dialogService.resetConfirmation() on dialogRef closed', () => {
    const resetConfirmationSpy = jest.spyOn(mockDialogService, 'resetConfirmation');

    mockDialogRef.closed.next();

    expect(resetConfirmationSpy).toHaveBeenCalled();
  });

  test('calls qdNotificationService.removeAll() on dialogRef closed', () => {
    const removeAllSpy = jest.spyOn(mockNotificationService, 'removeAll');

    mockDialogRef.closed.next();

    expect(removeAllSpy).toHaveBeenCalledWith('confirm-modal');
  });

  test('resets dialog service on ngOnDestroy', () => {
    component.ngOnDestroy();

    expect(mockDialogService.resetConfirmation).toHaveBeenCalled();
  });

  test('unsubscribes on ngOnDestroy', () => {
    const confirmUnsubscribeSpy = jest.spyOn(component['_confirmSubscription'], 'unsubscribe');

    component.ngOnDestroy();

    expect(confirmUnsubscribeSpy).toHaveBeenCalled();
  });

  test('pauses snackbar notifications', () => {
    expect(mockSnackbarService.pause).toHaveBeenCalled();

    component.ngOnDestroy();

    expect(mockSnackbarService.resume).toHaveBeenCalled();
  });

  test('removes all notifications on destroy', () => {
    component.ngOnDestroy();

    expect(mockNotificationService.removeAll).toHaveBeenCalled();
  });
});
