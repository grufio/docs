import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DialogRef } from '@angular/cdk/dialog';
import { MockComponent, MockProvider } from 'ng-mocks';

import { QdMockTranslatePipe } from '../../core/__mocks__/mock-translate.pipe';
import { QdDialogActionComponent } from '../action/dialog-action.component';
import { QdTextSectionComponent } from '../../text-section/text-section.component';
import { QdTextSectionParagraphComponent } from '../../text-section/text-section-paragraph/text-section-paragraph.component';
import { QdDialogComponent } from '../dialog.component';
import { QdDialogAuthSessionEndResult } from '../models/session-end-result.model';
import { QdDialogAuthSessionEndComponent } from './dialog-auth-session-end.component';

describe(`Testing ${QdDialogAuthSessionEndComponent.name} |`, () => {
  let component: QdDialogAuthSessionEndComponent;
  let fixture: ComponentFixture<QdDialogAuthSessionEndComponent>;
  let dialogRefSpy: jest.Mocked<DialogRef<QdDialogAuthSessionEndResult, QdDialogAuthSessionEndComponent>>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        QdDialogAuthSessionEndComponent,
        QdMockTranslatePipe,
        MockComponent(QdDialogComponent),
        MockComponent(QdDialogActionComponent),
        MockComponent(QdTextSectionComponent),
        MockComponent(QdTextSectionParagraphComponent)
      ],
      providers: [MockProvider(DialogRef)]
    }).compileComponents();

    fixture = TestBed.createComponent(QdDialogAuthSessionEndComponent);
    component = fixture.componentInstance;
    dialogRefSpy = TestBed.inject(DialogRef) as jest.Mocked<
      DialogRef<QdDialogAuthSessionEndResult, QdDialogAuthSessionEndComponent>
    >;

    fixture.detectChanges();
  });

  test('matches snapshot', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('closes dialog with reAuthenticate result', () => {
    component.reAuthenticate();

    expect(dialogRefSpy.close).toHaveBeenCalledWith({ doReauthenticate: true });
  });

  test('closes dialog with backToEPortal result', () => {
    component.backToEPortal();

    expect(dialogRefSpy.close).toHaveBeenCalledWith({ doLogoutViaIdentityBroker: true });
  });
});
