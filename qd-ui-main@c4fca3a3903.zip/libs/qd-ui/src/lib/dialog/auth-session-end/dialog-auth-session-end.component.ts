import { Component } from '@angular/core';
import { DialogRef } from '@angular/cdk/dialog';

import { QdDialogAuthSessionEndResult } from '../models/session-end-result.model';

/**
 * **QdDialogAuthSessionEndComponent**: Component for handling the end of an authentication session, e.g. a PAMS session.
 * It provides the user the option to either re-authenticate or log out via the Identity Broker.
 */
@Component({
  selector: 'qd-dialog-auth-session-end',
  templateUrl: './dialog-auth-session-end.component.html'
})
export class QdDialogAuthSessionEndComponent {
  constructor(private dialogRef: DialogRef<QdDialogAuthSessionEndResult, QdDialogAuthSessionEndComponent>) {}

  reAuthenticate(): void {
    this.dialogRef.close({ doReauthenticate: true });
  }

  backToEPortal(): void {
    this.dialogRef.close({ doLogoutViaIdentityBroker: true });
  }
}
