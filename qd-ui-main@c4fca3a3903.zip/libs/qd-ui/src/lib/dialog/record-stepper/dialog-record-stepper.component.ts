import {
  AfterContentInit,
  Component,
  EventEmitter,
  HostBinding,
  Input,
  OnInit,
  Output,
  ViewEncapsulation
} from '@angular/core';

import { QdDialogService } from '../services/dialog.service';
import { QdDialogData } from '../models/record-stepper.model';

/**
 * **QdDialogRecordStepperComponent** provides a pagination for the fullscreen version of **QdDialog**. <br />
 * It is possible to navigate through a list of data provided by the dialog.
 */
@Component({
  selector: 'qd-dialog-record-stepper',
  templateUrl: './dialog-record-stepper.component.html',
  styleUrls: ['./dialog-record-stepper.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: { class: 'qd-dialog-record-stepper ' }
})
export class QdDialogRecordStepperComponent implements OnInit, AfterContentInit {
  /**
   * The data processed by this component.
   */
  @Input({ required: true }) data: QdDialogData = { navigation: false, initialPaginationIndex: 0, views: [] };

  /**
   * Emits event on updateStep. Return value: currentIndex.
   */
  @Output() changeStep = new EventEmitter<any>();

  @HostBinding('class.first-item') get firstItem(): boolean {
    return this.isFirstItem();
  }

  @HostBinding('class.last-item') get lastItem(): boolean {
    return this.isLastItem();
  }

  currentIndex!: number;
  itemsCount = 0;

  constructor(private dialogService: QdDialogService) {}

  ngOnInit(): void {
    this.currentIndex = this.dialogService.dialogData.initialPaginationIndex || 0;
  }

  ngAfterContentInit(): void {
    this.setItemsCount();
    this.dialogService.updateStep(this.currentIndex);

    this.changeStep.emit(this.currentIndex);
  }

  previous(): void {
    if (!this.isFirstItem()) {
      this.currentIndex = this.currentIndex - 1;
      this.dialogService.updateStep(this.currentIndex);

      this.changeStep.emit(this.currentIndex);
    }
  }

  next(): void {
    if (!this.isLastItem()) {
      this.currentIndex = this.currentIndex + 1;
      this.dialogService.updateStep(this.currentIndex);

      this.changeStep.emit(this.currentIndex);
    }
  }

  isFirstItem(): boolean {
    return this.currentIndex === 0;
  }

  isLastItem(): boolean {
    return this.currentIndex >= this.itemsCount - 1;
  }

  private setItemsCount(): void {
    this.itemsCount = this.data.views?.length || 0;
  }
}
