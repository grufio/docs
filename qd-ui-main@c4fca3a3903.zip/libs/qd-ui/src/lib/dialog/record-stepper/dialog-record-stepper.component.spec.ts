import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MockComponent } from 'ng-mocks';

import { QdDialogService } from '../services/dialog.service';
import { QdIconComponent } from '../../icon/icon/icon.component';
import { QdDialogRecordStepperComponent } from './dialog-record-stepper.component';

describe(`Testing ${QdDialogRecordStepperComponent.name} |`, () => {
  let component: QdDialogRecordStepperComponent;
  let fixture: ComponentFixture<QdDialogRecordStepperComponent>;
  let dialogService: QdDialogService;

  const mockDialogService = {
    dialogData: { views: [{ id: 1 }, { id: 2 }], initialPaginationIndex: 0 },
    updateStep: jest.fn()
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [QdDialogRecordStepperComponent, MockComponent(QdIconComponent)],
      providers: [{ provide: QdDialogService, useValue: mockDialogService }]
    }).compileComponents();

    fixture = TestBed.createComponent(QdDialogRecordStepperComponent);
    component = fixture.componentInstance;
    dialogService = TestBed.inject(QdDialogService);

    component.data = dialogService.dialogData;

    fixture.detectChanges();
  });

  afterEach(() => jest.clearAllMocks());

  test('initializes with default values', () => {
    expect(component.currentIndex).toBe(0);
    expect(component.itemsCount).toBe(2);
  });

  test('sets currentIndex from dialogService on init', () => {
    component.ngOnInit();

    expect(component.currentIndex).toBe(0);
  });

  test('updates step and emits changeStep after content init', () => {
    const updateStepSpy = jest.spyOn(dialogService, 'updateStep');
    const emitChangeStepSpy = jest.spyOn(component.changeStep, 'emit');

    component.ngAfterContentInit();

    expect(updateStepSpy).toHaveBeenCalledWith(0);
    expect(emitChangeStepSpy).toHaveBeenCalledWith(0);
  });

  test('does not update index when at first item', () => {
    component.currentIndex = 0;
    const updateStepSpy = jest.spyOn(dialogService, 'updateStep');
    const emitChangeStepSpy = jest.spyOn(component.changeStep, 'emit');

    component.previous();

    expect(component.currentIndex).toBe(0);
    expect(updateStepSpy).toHaveBeenCalledTimes(1);
    expect(emitChangeStepSpy).not.toHaveBeenCalled();
  });

  test('updates step when next is called and not at last item', () => {
    component.currentIndex = 0;
    const updateStepSpy = jest.spyOn(dialogService, 'updateStep');
    const emitChangeStepSpy = jest.spyOn(component.changeStep, 'emit');

    component.next();

    expect(component.currentIndex).toBe(1);
    expect(updateStepSpy).toHaveBeenCalledTimes(2);
    expect(emitChangeStepSpy).toHaveBeenCalledTimes(1);
  });

  test('does not update index when at last item', () => {
    component.currentIndex = 1;
    const updateStepSpy = jest.spyOn(dialogService, 'updateStep');
    const emitChangeStepSpy = jest.spyOn(component.changeStep, 'emit');

    component.next();

    expect(component.currentIndex).toBe(1);
    expect(updateStepSpy).toHaveBeenCalledTimes(1);
    expect(emitChangeStepSpy).not.toHaveBeenCalled();
  });

  test('updates step when previous is called and not at first item', () => {
    component.currentIndex = 1;
    const updateStepSpy = jest.spyOn(dialogService, 'updateStep');
    const emitChangeStepSpy = jest.spyOn(component.changeStep, 'emit');

    component.previous();

    expect(component.currentIndex).toBe(0);
    expect(updateStepSpy).toHaveBeenCalledTimes(2);
    expect(emitChangeStepSpy).toHaveBeenCalledTimes(1);
  });

  test('initializes currentIndex and itemsCount correctly', () => {
    expect(component.currentIndex).toBe(0);
    expect(component.itemsCount).toBe(2);
  });

  test('returns true if currentIndex is 0', () => {
    component.currentIndex = 0;

    expect(component.isFirstItem()).toBe(true);
  });

  test('returns false if currentIndex is not 0', () => {
    component.currentIndex = 1;

    expect(component.isFirstItem()).toBe(false);
  });

  test('returns true if currentIndex is the last item', () => {
    component.currentIndex = 1;

    expect(component.isLastItem()).toBe(true);
  });

  test('returns false if currentIndex is not the last item', () => {
    component.currentIndex = 0;

    expect(component.isLastItem()).toBe(false);
  });

  test('sets itemsCount based on data.views length', () => {
    component.data = { views: [{ id: 1 }, { id: 2 }, { id: 3 }] };
    component['setItemsCount']();

    expect(component.itemsCount).toBe(3);
  });

  test('renders buttons and triggers methods on click', () => {
    fixture.detectChanges();

    const previousButton = fixture.debugElement.query(By.css('.previous'));
    const nextButton = fixture.debugElement.query(By.css('.next'));

    expect(previousButton).toBeTruthy();
    expect(nextButton).toBeTruthy();

    const previousSpy = jest.spyOn(component, 'previous');
    const nextSpy = jest.spyOn(component, 'next');

    previousButton.triggerEventHandler('click', null);
    nextButton.triggerEventHandler('click', null);

    expect(previousSpy).toHaveBeenCalled();
    expect(nextSpy).toHaveBeenCalled();
  });
});
