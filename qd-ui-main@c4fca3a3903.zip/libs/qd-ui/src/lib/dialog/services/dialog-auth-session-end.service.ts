import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { QdDialogAuthSessionEndComponent } from '../auth-session-end/dialog-auth-session-end.component';
import { QdDialogService } from './dialog.service';
import { QdDialogConfig, QdDialogSize } from '../models/dialog-config.model';
import { QdDialogAuthSessionEndResult } from '../models/session-end-result.model';

/**
 * **QdDialogAuthSessionEndService**: Service for handling authentication support functionalities.
 * This service is responsible for providing a handler to manage the logout process by opening a dialog.
 */
@Injectable({
  providedIn: 'root'
})
export class QdDialogAuthSessionEndService {
  config: QdDialogConfig = {
    title: {
      i18n: 'i18n.qd.authSupport.dialog.title'
    },
    dialogSize: QdDialogSize.Small
  };

  constructor(private dialogService: QdDialogService) {}

  /**
   * Returns a function that opens the `QdDialogAuthSessionEndComponent` dialog and returns an observable that emits a **QdDialogAuthSessionEndResult** object when the dialog is closed.
   */
  getLogoutHandler(): (logoutUrl?: Observable<string>) => Observable<QdDialogAuthSessionEndResult> {
    return () =>
      this.dialogService.open(QdDialogAuthSessionEndComponent, this.config)
        .closed as Observable<QdDialogAuthSessionEndResult>;
  }
}
