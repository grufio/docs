import { Dialog, DialogRef } from '@angular/cdk/dialog';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { Router } from '@angular/router';
import { QdDialogConfig, QdDialogSize } from '../models/dialog-config.model';
import { QdDialogData } from '../models/record-stepper.model';
import { QdPageDialogWithBreadcrumbsComponent } from '../page-dialog-with-breadcrumbs/page-dialog-with-breadcrumbs.component';
import { QdDialogService } from './dialog.service';

class TestComponent {}

describe(`Testing ${QdDialogService.name} |`, () => {
  let service: QdDialogService;
  let dialogMock: Partial<Dialog>;
  let dialogRefMock: Partial<DialogRef<any>>;
  let routerMock: Partial<Router>;

  beforeEach(() => {
    dialogRefMock = {
      closed: of(),
      close: jest.fn()
    };

    dialogMock = {
      open: jest.fn().mockReturnValue(dialogRefMock),
      closeAll: jest.fn()
    };

    routerMock = {
      config: [],
      navigate: jest.fn()
    };

    TestBed.configureTestingModule({
      providers: [QdDialogService, { provide: Dialog, useValue: dialogMock }, { provide: Router, useValue: routerMock }]
    });
    service = TestBed.inject(QdDialogService);
  });

  test('opens dialog with custom panel class and width', () => {
    const config: QdDialogConfig = {
      panelClass: '',
      dialogSize: QdDialogSize.Default,
      width: ''
    };

    service.open(TestComponent, config);

    expect(dialogMock.open).toHaveBeenCalledWith(TestComponent, config);
    expect(config.panelClass).toBe('qd-custom-panel');
    expect(config.width).toBe(QdDialogSize.Default);
  });

  test('closes all dialogs', () => {
    service.closeAll();

    expect(dialogMock.closeAll).toHaveBeenCalled();
  });

  test('opens dialog with FullWidth configuration', () => {
    const config: QdDialogConfig = {
      dialogSize: QdDialogSize.FullWidth
    };

    service.open(TestComponent, config);

    expect(dialogMock.open).toHaveBeenCalledWith(TestComponent, {
      panelClass: 'qd-custom-panel',
      width: '100vw',
      maxWidth: '100vw',
      maxHeight: '100vh',
      height: '100vh',
      dialogSize: QdDialogSize.FullWidth
    });
  });

  test('opens fullscreen dialog and updates dialog data', () => {
    const config: QdDialogConfig = {
      data: { someKey: 'someValue' },
      dialogSize: QdDialogSize.FullWidth
    };

    const updateDialogDataSpy = jest.spyOn(service as any, 'updateDialogData');

    service.openFullscreen(TestComponent, config);

    expect(updateDialogDataSpy).toHaveBeenCalledWith(config);
    expect(dialogMock.open).toHaveBeenCalledWith(TestComponent, config);
  });

  test('opens fullscreen dialog with default configuration when no specific size is provided', () => {
    const config: QdDialogConfig = {
      data: { someKey: 'someValue' }
    };

    const updateDialogDataSpy = jest.spyOn(service as any, 'updateDialogData');

    service.openFullscreen(TestComponent, config);

    expect(updateDialogDataSpy).toHaveBeenCalledWith(config);
    expect(dialogMock.open).toHaveBeenCalledWith(TestComponent, config);
  });

  test('starts confirmation process', () => {
    service.startConfirmation();

    expect(service.isConfirmationLoading).toBe(true);
  });

  test('handles confirmation success', () => {
    service.confirmationSuccess();

    expect(service.isConfirmationLoading).toBe(false);
    expect(service.isConfirmationSuccess).toBe(true);
  });

  test('handles confirmation error', () => {
    service.confirmationError();

    expect(service.isConfirmationLoading).toBe(false);
    expect(service.isConfirmationError).toBe(true);
  });

  test('resets confirmation process', () => {
    service.resetConfirmation();

    expect(service.isConfirmationLoading).toBe(false);
    expect(service.isConfirmationInfo).toBe(true);
  });

  test('updates step: currentRow$', done => {
    const views = [{ id: 1 }, { id: 2 }];
    service['_dialogData'].views = views;

    service.currentRow$.subscribe(currentRow => {
      expect(currentRow).toBe(views[1]);

      done();
    });

    service.updateStep(1);
  });

  test('updates step: currentIndex$', done => {
    service['_dialogData'].views = [{ id: 1 }, { id: 2 }];

    service.currentIndex$.subscribe(currentIndex => {
      expect(currentIndex).toBe(1);

      done();
    });

    service.updateStep(1);
  });

  test('sets initialPaginationIndex correctly', () => {
    (service as any).updateDialogData({
      initialPaginationIndex: 5,
      views: new Array(3)
    });

    expect(service['_dialogData'].initialPaginationIndex).toBe(2);
  });

  test('ignores undefined values', () => {
    (service as any).updateDialogData({
      someKey: undefined,
      anotherKey: 'value'
    });

    expect(service['_dialogData'].someKey).toBeUndefined();
    expect(service['_dialogData'].anotherKey).toBe('value');
  });

  test('processes null or undefined data without errors', () => {
    const config: QdDialogConfig = {
      data: null
    };

    (service as any).updateDialogData(config);

    expect(service['_dialogData']).toEqual({ navigation: false, initialPaginationIndex: 0, views: [] });
  });

  test('sets non-pagination data correctly', () => {
    (service as any).updateDialogData({
      otherKey: 'otherValue'
    });

    expect(service['_dialogData'].otherKey).toBe('otherValue');
  });

  test('returns confirmationStatus as an object', () => {
    service['_confirmationStatus'] = 'success';

    const status = service.confirmationStatus;

    expect(status).toEqual({ confirmationStatus: 'success' });
  });

  test('handles setting and getting dialogData', () => {
    const data: QdDialogData = {
      navigation: true,
      initialPaginationIndex: 1,
      views: [{ id: 1 }, { id: 2 }]
    };

    service.dialogData = data;
    expect(service.dialogData).toEqual(data);
  });

  describe('openPageDialogWithBreadcrumbs', () => {
    test('opens QdPageDialogWithBreadcrumbs with given route', () => {
      service.openPageDialogWithBreadcrumbs('my-dialog-page');

      expect(dialogMock.open).toHaveBeenCalledWith(QdPageDialogWithBreadcrumbsComponent, {
        panelClass: 'qd-custom-panel',
        width: '100vw',
        maxWidth: '100vw',
        maxHeight: '100vh',
        height: '100vh',
        dialogSize: QdDialogSize.FullWidth
      });
      expect(routerMock.navigate).toHaveBeenCalledWith(['/', { outlets: { dialog: 'my-dialog-page' } }]);
    });

    test('opens QdPageDialogWithBreadcrumbs with first dialog outlet route if no route is given', () => {
      routerMock.config = [
        {
          path: 'my-page/:my-page-id',
          data: {
            breadcrumb: {
              i18n: 'My Page'
            }
          },
          component: TestComponent
        },
        {
          path: 'my-dialog-page',
          outlet: 'dialog',
          data: {
            breadcrumb: {
              i18n: 'My Dialog Page'
            }
          },
          children: [
            {
              path: '',
              component: TestComponent
            },
            {
              path: 'my-sub-dialog-page',
              data: {
                breadcrumb: {
                  i18n: 'My Sub Dialog Page'
                }
              },
              children: [
                {
                  path: '',
                  component: TestComponent
                }
              ]
            }
          ]
        }
      ];

      service.openPageDialogWithBreadcrumbs();

      expect(dialogMock.open).toHaveBeenCalledWith(QdPageDialogWithBreadcrumbsComponent, {
        panelClass: 'qd-custom-panel',
        width: '100vw',
        maxWidth: '100vw',
        maxHeight: '100vh',
        height: '100vh',
        dialogSize: QdDialogSize.FullWidth
      });
      expect(routerMock.navigate).toHaveBeenCalledWith(['/', { outlets: { dialog: 'my-dialog-page' } }]);
    });

    test('throws if first dialog outlet route is not static', () => {
      routerMock.config = [
        {
          path: 'my-dialog-page/:my-dialog-page-id',
          outlet: 'dialog',
          data: {
            breadcrumb: {
              i18n: 'My Dialog Page'
            }
          },
          children: [
            {
              path: '',
              component: TestComponent
            }
          ]
        }
      ];

      expect(() => {
        service.openPageDialogWithBreadcrumbs();
      }).toThrow(
        new Error(
          'QdDialogService | Please provide a route for the openPageDialogWithBreadcrumbs method. ' +
            'The main dialog route could not be determined automatically.'
        )
      );
    });

    test('throws if first dialog outlet route is not defined', () => {
      routerMock.config = [
        {
          path: 'my-page/:my-page-id',
          data: {
            breadcrumb: {
              i18n: 'My Page'
            }
          },
          component: TestComponent
        }
      ];

      expect(() => {
        service.openPageDialogWithBreadcrumbs();
      }).toThrow(
        new Error(
          'QdDialogService | Please provide a route for the openPageDialogWithBreadcrumbs method. ' +
            'The main dialog route could not be determined automatically.'
        )
      );
    });

    test("sets data accordingly", () => {
      service.openPageDialogWithBreadcrumbs('my-dialog-page', { id: "XY" });

      expect(service['_dialogData'].id).toBe("XY");
    });
  });

  test('navigateInsideDialog navigates inside the dialog outlet', () => {
    service.navigateInsideDialog('my-dialog-page');

    expect(routerMock.navigate).toHaveBeenCalledWith(['/', { outlets: { dialog: 'my-dialog-page' } }]);
  });
});
