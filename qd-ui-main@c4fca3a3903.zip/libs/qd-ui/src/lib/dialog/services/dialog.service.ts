import { Dialog, DialogConfig, DialogRef } from '@angular/cdk/dialog';
import { ComponentType } from '@angular/cdk/portal';
import { Injectable } from '@angular/core';

import { Router } from '@angular/router';
import { BehaviorSubject, Subject } from 'rxjs';
import { QdConfirmationStatus } from '../models/confirmation.model';
import { QdDialogConfig, QdDialogSize } from '../models/dialog-config.model';
import { QdDialogData } from '../models/record-stepper.model';
import { QdPageDialogWithBreadcrumbsComponent } from '../page-dialog-with-breadcrumbs/page-dialog-with-breadcrumbs.component';

/**
 * **QdDialogService**: Service for managing dialogs in the application.
 * This service provides methods to open, close, and manage the handling of dialog data.
 */
@Injectable({
  providedIn: 'root'
})
export class QdDialogService {
  private _currentRowSubject = new BehaviorSubject<any>({});
  currentRow$ = this._currentRowSubject.asObservable();

  private _currentIndexSubject = new Subject<number>();
  currentIndex$ = this._currentIndexSubject.asObservable();

  private _confirmationStatus: QdConfirmationStatus = 'info';
  private _isConfirmationLoading = false;
  private _dialogData: QdDialogData = { navigation: false, initialPaginationIndex: 0, views: [] };

  get confirmationStatus(): { confirmationStatus: QdConfirmationStatus } {
    return { confirmationStatus: this._confirmationStatus };
  }

  get isConfirmationLoading(): boolean {
    return this._isConfirmationLoading;
  }

  get isConfirmationInfo(): boolean {
    return this._confirmationStatus === 'info';
  }

  get isConfirmationSuccess(): boolean {
    return this._confirmationStatus === 'success';
  }

  get isConfirmationError(): boolean {
    return this._confirmationStatus === 'error';
  }

  set dialogData(data: QdDialogData) {
    this._dialogData = data;
  }

  get dialogData(): QdDialogData {
    return this._dialogData;
  }

  constructor(
    private dialog: Dialog,
    private router: Router
  ) {}

  open<C>(component: ComponentType<C>, config: QdDialogConfig): DialogRef<unknown, C> {
    config.panelClass = 'qd-custom-panel';
    config.width = config.dialogSize || QdDialogSize.Default;

    if (config.dialogSize === QdDialogSize.FullWidth) {
      config.maxWidth = '100vw';
      config.width = '100vw';
      config.maxHeight = '100vh';
      config.height = '100vh';
    }

    return this.dialog.open(component, config as DialogConfig<C, DialogRef<unknown, C>>);
  }

  openFullscreen<C>(component: ComponentType<C>, config: QdDialogConfig): DialogRef<unknown, C> {
    this.updateDialogData(config);

    return this.dialog.open(component, config as DialogConfig<C, DialogRef<unknown, C>>);
  }

  openPageDialogWithBreadcrumbs(routePath?: string, data?: { [key: string]: any }): void {
    this.updateDialogData(data);
    this.open(QdPageDialogWithBreadcrumbsComponent, { dialogSize: QdDialogSize.FullWidth });
    this.navigateInsideDialog(routePath || this.getFirstDialogOutletRoutePathOrThrow());
  }

  navigateInsideDialog(routePath: string): void {
    this.router.navigate(['/', { outlets: { dialog: routePath } }]);
  }

  closeAll(): void {
    this.dialog.closeAll();
  }

  startConfirmation(): void {
    this._isConfirmationLoading = true;
  }

  confirmationSuccess(): void {
    this._isConfirmationLoading = false;
    this._confirmationStatus = 'success';
  }

  confirmationError(): void {
    this._isConfirmationLoading = false;
    this._confirmationStatus = 'error';
  }

  resetConfirmation(): void {
    this._isConfirmationLoading = false;
    this._confirmationStatus = 'info';
  }

  updateStep(index: number): void {
    this._currentRowSubject.next(this._dialogData.views?.[index]);
    this._currentIndexSubject.next(index);
  }

  private updateDialogData(data: { [key: string]: any }): void {
    if (!data || typeof data !== 'object') return;

    Object.entries(data).forEach(([key, value]) => {
      if (!value) return;

      if (key === 'initialPaginationIndex') {
        this._dialogData[key] = data['views'] && value >= 0 ? Math.min(value, data['views'].length - 1) : 0;
      } else {
        this._dialogData[key] = value;
      }
    });
  }

  private getFirstDialogOutletRoutePathOrThrow(): string {
    const firstDialogOutletRoutePath = this.router.config.find(route => route.outlet === 'dialog')?.path;

    if (!firstDialogOutletRoutePath || this.hasRoutePathParameters(firstDialogOutletRoutePath)) {
      throw new Error(
        'QdDialogService | Please provide a route for the openPageDialogWithBreadcrumbs method. ' +
          'The main dialog route could not be determined automatically.'
      );
    }

    return firstDialogOutletRoutePath;
  }

  private hasRoutePathParameters(routePath: string): boolean {
    return routePath.includes(':');
  }
}
