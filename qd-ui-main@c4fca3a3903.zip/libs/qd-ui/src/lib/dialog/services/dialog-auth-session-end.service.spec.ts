import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { MockService } from 'ng-mocks';

import { QdDialogService } from './dialog.service';
import { QdDialogAuthSessionEndComponent } from '../auth-session-end/dialog-auth-session-end.component';
import { QdDialogAuthSessionEndService } from './dialog-auth-session-end.service';

describe(`Testing ${QdDialogAuthSessionEndService.name} |`, () => {
  let service: QdDialogAuthSessionEndService;
  let dialogService: QdDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdDialogAuthSessionEndService, { provide: QdDialogService, useValue: MockService(QdDialogService) }]
    });

    service = TestBed.inject(QdDialogAuthSessionEndService);
    dialogService = TestBed.inject(QdDialogService);
  });

  test('returns a function that opens the dialog and returns an observable', () => {
    const mockDialogRef = { closed: of('dialog closed') };

    jest.spyOn(dialogService, 'open').mockReturnValue(mockDialogRef as any);

    const logoutHandler = service.getLogoutHandler();
    const result = logoutHandler();

    expect(dialogService.open).toHaveBeenCalledWith(QdDialogAuthSessionEndComponent, service.config);

    result.subscribe(value => expect(value).toBe('dialog closed'));
  });
});
