// @ts-strict-ignore
import {
  AfterContentChecked,
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  HostBinding,
  OnInit,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import { DialogRef } from '@angular/cdk/dialog';
import { QdDialogConfig, QdDialogSize } from './models/dialog-config.model';

/**
 * **QdDialog** creating resonsive dialogs. Three different sizes are available.
 *
 * Detailed migration guideline from QdModal to QdDialog: https://confluence.bit.admin.ch/display/DAZUIC/Migration+Dialoge
 *
 * * @see child component: **QdDialogAction**.
 *
 * **Usage:**
 *
 * @example
 * import { QdDialogService } from '@quadrel-ui/qd-ui';
 *
 * @example
 * const config: QdDialogConfig = {
 *   title: {
 *      i18n: "i18.my.modal.title",
 *   },
 *   dialogSize: QdDialogSize.Default,
 *   hideCloseHeaderButton: false
 *   data: myData // API to provide data to the dialog
 * }
 *
 * @example
 * this.dialogService.open(MyModalComponent, config);
 *
 * **Example of MyModalComponent:**
 *
 * @example
 * <qd-dialog>
 *     <!-- Dialog Content START-->
 *     ...
 *     <!-- Dialog Content ENDE-->
 *     <qd-dialog-action>
 *         <button qdButton color="secondary" (click)="close()">Cancel</button>
 *         <button qdButton (click)="close('Yes')">Submit</button>
 *     </qd-dialog-action>
 * </qd-dialog>
 */
@Component({
  selector: 'qd-dialog',
  templateUrl: './dialog.component.html',
  host: { '[class.full-width]': 'isFullWidth' },
  styleUrls: ['./dialog.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [QdDialogComponent]
})
export class QdDialogComponent implements OnInit, AfterContentChecked, AfterViewInit {
  @ViewChild('body') body: ElementRef;
  @ViewChild('banners') infoBanners: ElementRef;

  @HostBinding('class.has-sections') get hasSectionsClass(): boolean {
    return this.hasSections;
  }

  config: QdDialogConfig;
  hasSections: boolean;
  hasInfoBanner: boolean;

  constructor(public dialogRef: DialogRef<string>, private changeDetectorRef: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.config = this.dialogRef.config;
  }

  ngAfterContentChecked(): void {
    const children = Array.from(this.body?.nativeElement?.childNodes || []);
    this.hasSections = children.length > 0 && children.every((node: HTMLElement) => node.tagName === 'QD-SECTION');
    this.changeDetectorRef.detectChanges();
  }

  ngAfterViewInit(): void {
    const bannerChildren = Array.from(this.infoBanners?.nativeElement?.childNodes || []);
    this.hasInfoBanner =
      bannerChildren.length > 0 && bannerChildren.some((node: HTMLElement) => node.tagName === 'QD-PAGE-INFO-BANNER');
    this.changeDetectorRef.detectChanges();
  }

  close(): void {
    this.dialogRef.close();
  }

  get isFullWidth(): boolean {
    return this.config.dialogSize === QdDialogSize.FullWidth;
  }
}
