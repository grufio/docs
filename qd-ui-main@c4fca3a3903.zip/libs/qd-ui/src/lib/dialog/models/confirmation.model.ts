import { InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';

/**
 * Token for resolving a request for the confirmation dialog.
 */
export const QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN = new InjectionToken<string>(
  'QD_DIALOG_CONFIRMATION_RESOLVER_TOKEN'
);

/**
 * This interface represents a confirmation resolver for the confirmation dialog.
 */
export interface QdDialogConfirmationResolver {
  /**
   * This method resolves the data. A return value of type Observable from a boolean is expected, which depends on whether the operation was successful or not.
   */
  resolve(): Observable<boolean>;
}

/**
 * Interface for the configuration of the confirmation dialog.
 */
export interface QdDialogConfirmationConfig {
  /**
   * The configuration for the info state of the dialog.
   */
  info: {
    /**
     * The headline for the info state.
     */
    headline: QdDialogConfirmConfigTranslation;

    /**
     * An additional info for the info state.
     */
    info: QdDialogConfirmConfigTranslation;
  };
  /**
   * The configuration for the success state of the dialog.
   */
  success: {
    /**
     * The headline for the success state.
     *
     * * @note If not specified, the headline of the info state is displayed.
     */
    headline?: QdDialogConfirmConfigTranslation;

    /**
     * Additional information about the success status. It appears to the left of the result icon (checkCircleSolid).
     *
     * * @note If not specified, the info key of the info status is displayed. If this is also not specified, nothing is displayed.
     */
    info?: QdDialogConfirmConfigTranslation;
  };
  /**
   * The configuration for the error state of the dialog.
   */
  error: {
    /**
     * The headline for the error state.
     *
     * * @note If not specified, the headline of the info state is displayed.
     */
    headline?: QdDialogConfirmConfigTranslation;

    /**
     * Additional information about the error status. It appears to the left of the result icon (timesCircleSolid).
     *
     * * @note If not specified, the info key of the info status is displayed. If this is also not specified, nothing is displayed.
     */
    info?: QdDialogConfirmConfigTranslation;
  };
  /**
   * The configuration for the buttons in the dialog.
   */
  buttons: {
    /**
     * The cancel button text.
     */
    cancel: QdDialogConfirmConfigTranslation;

    /**
     * The next button text.
     */
    next: QdDialogConfirmConfigTranslation;

    /**
     * The success button text.
     *
     * * @note If not specified, the label of the next button is displayed.
     */
    success?: QdDialogConfirmConfigTranslation;

    /**
     * The error button text.
     *
     * * @note If not specified, the label of the next button is displayed.
     */
    error?: QdDialogConfirmConfigTranslation;
  };

  /**
   * A boolean to determine if a checkbox should be used in the dialog.
   *
   * * @default: true
   */
  useCheckbox?: boolean;

  /**
   * The label for the checkbox when the checkbox is used.
   */
  checkboxLabel?: QdDialogConfirmConfigTranslation;
}

/**
 * This interface represents the translation configuration for the QdDialogConfirm component.
 */
interface QdDialogConfirmConfigTranslation {
  /**
   * @description The i18n key for the translation.
   */
  i18n: string;
}

/**
 * Represents the status of a confirmation dialog.
 */
export type QdConfirmationStatus = 'info' | 'success' | 'error';
