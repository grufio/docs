import { DialogConfig } from '@angular/cdk/dialog';

/**
 * Configuration object for dialog.
 */
export interface QdDialogConfig extends DialogConfig {
  /**
   * Title of dialog.
   */
  title?: QdDialogTitle;

  /**
   * Hides the close button in the dialog header.
   */
  hideCloseHeaderButton?: boolean;

  /**
   * Determines the size of the dialog. There are 3 different width sizes.
   * Small - 500px
   * Default - 900px
   * FullWidth - 100%
   */
  dialogSize?: QdDialogSize;

  /**
   * Additional data for the dialog.
   */
  data?: { [key: string]: any };
}

/**
 * Configuration object for page dialog.
 */
export interface QdPageDialogConfig {
  data?: any;
}

/**
 * Title of dialog.
 */
export interface QdDialogTitle {
  /**
   * Translation key.
   */
  i18n: string;
}

/**
 * Enum for different Dialog sizes.
 */
export enum QdDialogSize {
  Small = '500px',
  Default = '900px',
  FullWidth = '100%'
}
