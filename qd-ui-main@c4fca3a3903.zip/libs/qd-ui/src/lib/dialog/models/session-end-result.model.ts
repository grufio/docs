/**
 * Interface representing the result of a session end modal.
 */
export interface QdDialogAuthSessionEndResult {
  /**
   * Indicates whether the user should reauthenticate.
   */
  doReauthenticate?: boolean;

  /**
   * Indicates whether the user should log out via the identity broker.
   */
  doLogoutViaIdentityBroker?: boolean;
}
