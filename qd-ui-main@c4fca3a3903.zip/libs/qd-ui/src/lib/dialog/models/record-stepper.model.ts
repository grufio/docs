/**
 * Interface representing the record stepper dialog data.
 */
export interface QdDialogData {
  /**
   * Indicates whether navigation is enabled.
   */
  navigation?: boolean;

  /**
   * The initial index for the record stepper.
   */
  initialPaginationIndex?: number;

  /**
   * An array of data representing views for the dialog.
   */
  views?: any[];

  /**
   * The current index in the record stepper.
   */
  currentIndex?: number;

  /**
   * Additional properties for the dialog data.
   */
  [key: string]: any;
}
