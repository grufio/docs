import { ComponentFixture, TestBed } from '@angular/core/testing';
import { QdPageDialogWithBreadcrumbsComponent } from './page-dialog-with-breadcrumbs.component';
import { MockComponent, MockDirective } from 'ng-mocks';
import { QdDialogComponent } from '../dialog.component';
import { QdBreadcrumbsComponent } from '../../core/breadcrumbs/breadcrumbs.component';
import { RouterOutlet } from '@angular/router';

describe(QdPageDialogWithBreadcrumbsComponent.name, () => {
  let component: QdPageDialogWithBreadcrumbsComponent;
  let fixture: ComponentFixture<QdPageDialogWithBreadcrumbsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        QdPageDialogWithBreadcrumbsComponent,
        MockComponent(QdDialogComponent),
        MockComponent(QdBreadcrumbsComponent),
        MockDirective(RouterOutlet)
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(QdPageDialogWithBreadcrumbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('matches the snapshot', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
