import { Component } from '@angular/core';

@Component({
  templateUrl: './page-dialog-with-breadcrumbs.component.html',
  styleUrls: ['./page-dialog-with-breadcrumbs.component.scss']
})
export class QdPageDialogWithBreadcrumbsComponent {}
