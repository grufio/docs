import { QdContactCardComponent } from './contact-card.component';
import { QdContactCardModule } from './contact-card.module';
import { QdContactData } from './model/contact-data.interface';
import { TranslateModule } from '@ngx-translate/core';

const contactData1: QdContactData = {
  contactFunction: {
    i18n: 'i18n.contact.function.sender'
  },
  contactPerson: {
    firstName: 'Max',
    lastName: 'Muster'
  },
  address: {
    street: 'Teststrasse 12',
    countryCode: 'CH',
    postalCode: '8952',
    city: 'Schlieren'
  }
};

const contactData2: QdContactData = {
  ...contactData1,
  companyName: 'Fritz Meier AG',
  businessPartnerId: 'GP5468497635',
  phoneNumber: '+49 175 64821346',
  emailAddress: 'max.muster@fritzmeier.ch'
};

describe(QdContactCardComponent.name, () => {
  beforeEach(() => {
    cy.mount(
      `
      <qd-contact-card [contactData]="contactData2" [actions]="actions"></qd-contact-card>
      <qd-contact-card [contactData]="contactData1" [hasPlaceholders]="true"></qd-contact-card>
      <qd-contact-card [contactData]="contactData1" [hasPlaceholders]="false"></qd-contact-card>
      `,
      {
        declarations: [QdContactCardComponent],
        imports: [QdContactCardModule, TranslateModule.forRoot({})],
        componentProperties: {
          contactData1,
          contactData2,
          actions: [
            {
              label: { i18n: 'i18n.qd.exampleContactCard.view' },
              handler: cy.spy().as('view')
            },
            {
              label: { i18n: 'i18n.qd.exampleContactCard.edit' },
              handler: cy.spy().as('edit')
            },
            {
              label: { i18n: 'i18n.qd.exampleContactCard.delete' },
              handler: cy.spy().as('delete'),
              isDisabled: true
            }
          ]
        }
      }
    );
  });

  it('renders', () => {
    cy.matchImage();
  });

  it('email address has correct link', () => {
    cy.get(':nth-child(1) > :nth-child(5) > a').should('have.attr', 'href', 'mailto:' + contactData2.emailAddress);
  });

  it('menu actions can be executed', () => {
    cy.get('[data-test-id="contact-card-menu-opener"]').click();
    cy.matchImage();

    cy.get('button').contains('i18n.qd.exampleContactCard.view').click();
    cy.get('@view').should('be.called');

    cy.get('[data-test-id="contact-card-menu-opener"]').click();
    cy.get('button').contains('i18n.qd.exampleContactCard.edit').click();
    cy.get('@edit').should('be.called');

    cy.get('[data-test-id="contact-card-menu-opener"]').click();
    cy.get('button').contains('i18n.qd.exampleContactCard.delete').should('be.disabled');
  });
});
