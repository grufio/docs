import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import {
  QdContactAddress,
  QdContactData,
  QdContactDataCustomField,
  QdContactPerson
} from './model/contact-data.interface';
import { QdContactCardActionsConfig } from './model/contact-card-actions-config.interface';

/**
 * With **QdContactCard** a kind of business card can be created. Multiple contact cards can be combined. <br />
 * Wrapping to the next line is the default behavior of the browser.
 *
 * **Usage:**
 *
 * @example
 * <qd-contact-card [contactData]="contactData1"></qd-contact-card>
 * <qd-contact-card [contactData]="contactData2"></qd-contact-card>
 * <qd-contact-card [contactData]="contactData3"></qd-contact-card>
 *
 * ## Placeholders
 *
 * By default, placeholders will be displayed for missing properties so that the fields are aligned for contact cards
 * that stand in the same row. To disable the placeholders, set **hasPlaceholders** to `false`.
 *
 * ```html
 * <qd-contact-card [contactData]="contactData" [hasPlaceholders]="false"></qd-contact-card>
 * ```
 *
 * ## Actions
 *
 * Optionally, an action menu can be integrated into the contact card. Just define the menu actions with the
 * **actions** input. Each action has a label and a handler that receives the `contactData` as a parameter.
 *
 * ```html
 * <qd-contact-card [contactData]="contactData" [actions]="actions"></qd-contact-card>
 * ```
 *
 * ```typescript
 * actions: QdContactCardActionsConfig = [
 *   {
 *     label: { i18n: 'i18n.qd.exampleContactCard.view' },
 *     handler: (contactData) => {}
 *   }
 * ];
 * ```
 *
 * ### Disabled and hidden actions
 *
 * An action can be hidden completely with the **isHidden** property. To hide an action conditionally, you can
 * pass a callback to the **isHidden** property that receives the `contactData` as a parameter.
 *
 * To disable an action, use the **isDisabled** property. The action is then displayed but cannot be clicked.
 *
 * ```typescript
 * actions: QdContactCardActionsConfig = [
 *   {
 *     label: { i18n: 'i18n.qd.exampleContactCard.view' },
 *     handler: (contactData) => {}
 *   },
 *   {
 *     label: { i18n: 'i18n.qd.exampleContactCard.edit' },
 *     handler: (contactData) => {}.
 *     isHidden: contactData => contactData.businessPartnerId !== 'GP5468497635'
 *   },
 *   {
 *     label: { i18n: 'i18n.qd.exampleContactCard.delete' },
 *     handler: (contactData) => {},
 *     isDisabled: contactData => contactData.businessPartnerId !== 'GP5468497635'
 *   }
 * ];
 * ```
 *
 * ## Custom Fields
 *
 * Custom fields can be defined in the contactData `customFields` property. The custom fields will be displayed
 * at the bottom of the contact card. A custom field can optionally have a label that will be displayed in front of
 * the custom field value. Label and value can be plain strings or objects with an `i18n` key if you need translation.
 *
 *
 * ```typescript
 * contactData: QdContactData = {
 *   contactFunction: {
 *     i18n: 'i18n.contact.function.sender'
 *   },
 *   companyName: 'Fritz Meier AG',
 *   businessPartnerId: 'GP5468497635',
 *   contactPerson: {
 *     firstName: 'Max',
 *     lastName: 'Muster'
 *   },
 *   address: {
 *     street: 'Teststrasse 12',
 *     countryCode: 'CH',
 *     postalCode: '8952',
 *     city: 'Schlieren'
 *   },
 *   phoneNumber: '+49 175 64821346',
 *   emailAddress: 'max.muster@fritzmeier.ch',
 *   customFields: [
 *     {
 *       label: 'UID',
 *       value: '798347982674'
 *     },
 *     {
 *       label: {
 *         i18n: 'i18n.qd.exampleContactCard.bafuNumber'
 *       },
 *       value: 'B87384789CH23'
 *     }
 *   ]
 * };
 * ```
 */
@Component({
  selector: 'qd-contact-card',
  templateUrl: './contact-card.component.html',
  styleUrls: ['./contact-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdContactCardComponent {
  /**
   * Data for the **QdContactCard**
   */
  @Input() contactData!: QdContactData;

  /**
   * Configuration for the **QdContactCard** actions
   */
  @Input() actions?: QdContactCardActionsConfig;

  /**
   * Display placeholders instead of the missing properties
   *
   * @default true
   */
  @Input() set hasPlaceholders(hasPlaceholders: boolean) {
    this._hasPlaceholders = hasPlaceholders;
  }

  get hasPlaceholders(): boolean {
    return this._hasPlaceholders !== false;
  }

  /**
   * A static test ID for integration tests can be set. <br />
   * The value for the HTML attribute [data-test-id].
   */
  @Input('data-test-id') testId = 'contact-card';

  /**
   * Emits event on click/tap on the e-mail address.
   */
  @Output() emailAddressClicked = new EventEmitter();

  private _hasPlaceholders = true;

  constructor(public readonly translateService: TranslateService) {}

  get contactFunction(): string {
    return this.contactData.contactFunction.i18n;
  }

  get contactTag(): string | undefined {
    return this.contactData.tag?.i18n;
  }

  get companyName(): string | undefined {
    if (!this.hasCompanyName()) {
      if (!this.hasPlaceholders) return '';
      return this.translateService.instant('i18n.contact.companyName.placeholder');
    }

    return this.contactData.companyName;
  }

  get businessPartnerId(): string | undefined {
    if (!this.hasBusinessPartnerId()) {
      if (!this.hasPlaceholders) return '';
      return this.translateService.instant('i18n.contact.businessPartnerId.placeholder');
    }

    return this.contactData.businessPartnerId;
  }

  get contactPerson(): QdContactPerson {
    if (!this.hasContactPerson()) {
      return {
        firstName: this.hasPlaceholders ? this.translateService.instant('i18n.contact.contactPerson.placeholder') : '',
        lastName: ''
      };
    }

    return this.contactData.contactPerson!;
  }

  get firstName(): string {
    return this.contactPerson.firstName;
  }

  get lastName(): string {
    return this.contactPerson.lastName;
  }

  get address(): QdContactAddress {
    if (!this.hasAddress()) {
      if (!this.hasPlaceholders) {
        return {
          careOf: '',
          street: '',
          countryCode: '',
          postalCode: '',
          city: ''
        };
      }

      return {
        careOf: this.translateService.instant('i18n.contact.careOf.placeholder'),
        street: this.translateService.instant('i18n.contact.street.placeholder'),
        countryCode: this.translateService.instant('i18n.contact.countryCode.placeholder'),
        postalCode: this.translateService.instant('i18n.contact.postalCode.placeholder'),
        city: this.translateService.instant('i18n.contact.city.placeholder')
      };
    }

    return this.contactData.address!;
  }

  get careOf(): string | undefined {
    return this.address.careOf;
  }

  get street(): string | undefined {
    return this.address.street;
  }

  get countryCode(): string {
    if (!this.address.countryCode) return '';

    return this.address.countryCode + (this.postalCode ? '-' : '');
  }

  get postalCode(): string | undefined {
    return this.address.postalCode;
  }

  get city(): string {
    return this.address.city;
  }

  get phoneNumber(): string {
    if (!this.hasPhoneNumber()) {
      if (!this.hasPlaceholders) return '';
      return this.translateService.instant('i18n.contact.phoneNumber.placeholder');
    }

    return this.contactData.phoneNumber!;
  }

  get emailAddress(): string {
    if (!this.hasEmailAddress()) {
      if (!this.hasPlaceholders) return '';
      return this.translateService.instant('i18n.contact.emailAddress.placeholder');
    }

    return this.contactData.emailAddress!;
  }

  get customFields(): QdContactDataCustomField[] {
    return this.contactData.customFields!;
  }

  hasTag(): boolean {
    return !!this.contactData.tag;
  }

  hasCompanyName(): boolean {
    return !!this.contactData.companyName;
  }

  hasBusinessPartnerId(): boolean {
    return !!this.contactData.businessPartnerId;
  }

  hasContactPerson(): boolean {
    return !!this.contactData.contactPerson;
  }

  hasPhoneNumber(): boolean {
    return !!this.contactData.phoneNumber;
  }

  hasAddress(): boolean {
    return !!this.contactData.address;
  }

  hasCareOf(): boolean {
    return !!this.contactData.address?.careOf;
  }

  hasStreet(): boolean {
    return !!this.contactData.address?.street;
  }

  hasEmailAddress(): boolean {
    return !!this.contactData.emailAddress;
  }
}
