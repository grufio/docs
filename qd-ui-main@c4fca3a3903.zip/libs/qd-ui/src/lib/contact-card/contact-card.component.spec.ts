import { Component, Input } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { MockComponent, MockPipe } from 'ng-mocks';
import { By } from '@angular/platform-browser';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { QdMockTranslateService } from '../core/__mocks__/mock-translate.service';
import { QdContactCardComponent } from './contact-card.component';
import { QdContactData } from './model/contact-data.interface';
import { QdContactCardMenuComponent } from './menu/contact-card-menu.component';
import { QdContactCardActionsConfig } from './model/contact-card-actions-config.interface';
import { QdMockPopoverOnClickDirective } from '../core/popover/__mocks__/mock-popover-on-click.directive';
import { QdIconComponent } from '../icon/icon.module';
import { QdButtonComponent } from '../button/button.module';
import { QdPopoverService } from '../core/popover/popover.service';

@Component({
  selector: 'test-component-with-complete-contact-data',
  template: `
    <qd-contact-card
      [contactData]="contactData"
      [hasPlaceholders]="hasPlaceholders"
      (emailAddressClicked)="emailAddressClicked($event)"
    ></qd-contact-card>
  `
})
class TestComponentWithCompleteContactData {
  @Input() hasPlaceholders: boolean;

  emailAddressClicked = jest.fn();

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs. Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'max.muster@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-without-phone-number',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutPhoneNumber {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs. Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    emailAddress: 'max.muster@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-without-email-address',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutEmailAddress {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346'
  };
}

@Component({
  selector: 'test-component-without-contact-person',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutContactPerson {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'max.muster@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-without-company-name',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutCompanyName {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    businessPartnerId: 'GP5468497635',
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'max.muster@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-without-title',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutTitle {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'max.muster@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-only-with-contact-person-and-address',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentOnlyWithContactPersonAndAddress {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    }
  };
}

@Component({
  selector: 'test-component-without-contact-person-and-address',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutContactPersonAndAddress {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    phoneNumber: '+49 175 64821346',
    emailAddress: 'info@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-without-title-and-address',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutTitleAndAddress {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'info@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-without-country-code',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutCountryCode {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      postalCode: '8952',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'max.muster@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-without-postal-code',
  template: ` <qd-contact-card [contactData]="contactData" [hasPlaceholders]="hasPlaceholders"></qd-contact-card> `
})
class TestComponentWithoutPostalCode {
  @Input() hasPlaceholders: boolean;

  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    tag: { i18n: 'i18n.contact.tag' },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'max.muster@fritzmeier.ch'
  };
}

@Component({
  selector: 'test-component-with-actions-menu',
  template: ` <qd-contact-card [contactData]="contactData" [actions]="actions"></qd-contact-card> `
})
class TestComponentWithActionsMenu {
  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    phoneNumber: '+49 175 64821346',
    emailAddress: 'info@fritzmeier.ch'
  };

  actions: QdContactCardActionsConfig = [
    {
      label: { i18n: 'i18n.qd.exampleContactCard.view' },
      handler: jest.fn()
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.edit' },
      handler: jest.fn()
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.delete' },
      handler: jest.fn(),
      isDisabled: true
    }
  ];
}

@Component({
  selector: 'test-component-with-actions-menu-with-callback-properties',
  template: `
    <qd-contact-card [contactData]="contactData1" [actions]="actions"></qd-contact-card>
    <qd-contact-card [contactData]="contactData2" [actions]="actions"></qd-contact-card>
    <qd-contact-card [contactData]="contactData3" [actions]="actions"></qd-contact-card>
  `
})
class TestComponentWithActionsMenuWithCallbackProperties {
  contactData1: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    phoneNumber: '+49 175 64821346',
    emailAddress: 'info@fritzmeier.ch'
  };

  contactData2: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    address: {
      careOf: 'c/o Mrs.Robinson',
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    phoneNumber: '+49 175 64821346',
    emailAddress: 'max.muster@fritzmeier.ch'
  };

  contactData3: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    }
  };

  actions: QdContactCardActionsConfig = [
    {
      label: { i18n: 'i18n.qd.exampleContactCard.view' },
      handler: jest.fn()
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.edit' },
      handler: jest.fn(),
      isHidden: contactData => contactData.emailAddress === 'max.muster@fritzmeier.ch'
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.delete' },
      handler: jest.fn(),
      isDisabled: contactData => contactData.businessPartnerId !== 'GP5468497635'
    }
  ];
}

@Component({
  selector: 'test-component-with-custom-fields',
  template: ` <qd-contact-card [contactData]="contactData"></qd-contact-card> `
})
class TestComponentWithCustomFields {
  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    companyName: 'Fritz Meier AG',
    businessPartnerId: 'GP5468497635',
    phoneNumber: '+49 175 64821346',
    emailAddress: 'info@fritzmeier.ch',
    customFields: [
      {
        label: 'UID',
        value: '798347982674'
      },
      {
        label: {
          i18n: 'i18n.qd.exampleContactCard.bafuNumber'
        },
        value: 'B87384789CH23'
      },
      {
        label: {
          i18n: 'i18n.qd.exampleContactCard.customsOffice'
        },
        value: {
          i18n: 'i18n.qd.exampleContactCard.city.basel'
        }
      }
    ]
  };
}

describe(QdContactCardComponent.name, () => {
  let component;
  let fixture;
  let hasPlaceholders;

  async function configureTestingModule(): Promise<void> {
    return TestBed.configureTestingModule({
      declarations: [
        TestComponentWithCompleteContactData,
        TestComponentWithoutPhoneNumber,
        TestComponentWithoutEmailAddress,
        TestComponentWithoutContactPerson,
        TestComponentWithoutCompanyName,
        TestComponentWithoutTitle,
        TestComponentOnlyWithContactPersonAndAddress,
        TestComponentWithoutContactPersonAndAddress,
        TestComponentWithoutTitleAndAddress,
        TestComponentWithoutCountryCode,
        TestComponentWithoutPostalCode,
        TestComponentWithActionsMenu,
        TestComponentWithCustomFields,
        QdContactCardComponent,
        MockComponent(QdContactCardMenuComponent),
        MockPipe(TranslatePipe, value => 'Fake translation: ' + value)
      ],
      providers: [
        {
          provide: TranslateService,
          useClass: QdMockTranslateService
        }
      ]
    }).compileComponents();
  }

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    component.hasPlaceholders = hasPlaceholders;
    fixture.detectChanges();
  }

  const hasPlaceholdersDataProvider = [
    {
      description: 'with placeholders (default)',
      hasPlaceholders: undefined
    },
    {
      description: 'without placeholders',
      hasPlaceholders: false
    }
  ];

  hasPlaceholdersDataProvider.forEach(testData => {
    describe(testData.description, () => {
      beforeEach(async () => await configureTestingModule());

      beforeEach(() => {
        hasPlaceholders = testData.hasPlaceholders;
      });

      test('is rendered correctly with complete contact data', () => {
        createComponent(TestComponentWithCompleteContactData);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without phone number', () => {
        createComponent(TestComponentWithoutPhoneNumber);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without email address', () => {
        createComponent(TestComponentWithoutEmailAddress);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without contact person', () => {
        createComponent(TestComponentWithoutContactPerson);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without company name', () => {
        createComponent(TestComponentWithoutCompanyName);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without title', () => {
        createComponent(TestComponentWithoutTitle);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly only with contact person and address', () => {
        createComponent(TestComponentOnlyWithContactPersonAndAddress);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without contact person and address', () => {
        createComponent(TestComponentWithoutContactPersonAndAddress);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without title and address', () => {
        createComponent(TestComponentWithoutTitleAndAddress);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without country code', () => {
        createComponent(TestComponentWithoutCountryCode);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly without postal code', () => {
        createComponent(TestComponentWithoutPostalCode);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('emits emailAddressClicked output when email address is clicked', () => {
        createComponent(TestComponentWithCompleteContactData);
        const emailAddress = fixture.debugElement.query(By.css('a')).nativeElement;

        expect(component.emailAddressClicked).not.toHaveBeenCalled();
        emailAddress.click();
        expect(component.emailAddressClicked).toHaveBeenCalled();
      });

      test('is rendered correctly with actions menu', () => {
        createComponent(TestComponentWithActionsMenu);

        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('is rendered correctly with custom fields', () => {
        createComponent(TestComponentWithCustomFields);

        expect(fixture.nativeElement).toMatchSnapshot();
      });
    });
  });

  describe('contact card actions menu with callback properties', () => {
    beforeEach(async () => {
      await TestBed.configureTestingModule({
        declarations: [
          TestComponentWithActionsMenuWithCallbackProperties,
          QdContactCardComponent,
          QdContactCardMenuComponent,
          QdMockPopoverOnClickDirective,
          MockComponent(QdIconComponent),
          MockComponent(QdButtonComponent),
          MockPipe(TranslatePipe, value => 'Fake translation: ' + value)
        ],
        providers: [
          QdPopoverService,
          {
            provide: TranslateService,
            useClass: QdMockTranslateService
          }
        ]
      }).compileComponents();
    });

    function getMenuItemLabels(): string[] {
      const menuItemElements = fixture.debugElement.queryAll(By.css('qd-mock-popover button'));

      return menuItemElements.map(debugElement => debugElement.nativeElement.innerHTML.trim());
    }

    function getMenuItemButton(buttonLabel: string): HTMLButtonElement {
      return fixture.debugElement
        .queryAll(By.css('button'))
        .filter(debugElement => debugElement.nativeElement.innerHTML.includes(buttonLabel))[0].nativeElement;
    }

    test('renders correctly filtered actions for each contact card', () => {
      createComponent(TestComponentWithActionsMenuWithCallbackProperties);

      const contactCards = fixture.debugElement.queryAll(By.directive(QdContactCardComponent));

      // first contact card
      let menuIconElement = contactCards[0].query(By.directive(QdIconComponent)).nativeElement;
      menuIconElement.click();
      expect(getMenuItemLabels()).toEqual([
        'Fake translation: i18n.qd.exampleContactCard.view',
        'Fake translation: i18n.qd.exampleContactCard.edit',
        'Fake translation: i18n.qd.exampleContactCard.delete'
      ]);
      expect(getMenuItemButton('delete').disabled).toBe(false);

      // second contact card
      menuIconElement = contactCards[1].query(By.directive(QdIconComponent)).nativeElement;
      menuIconElement.click();
      expect(getMenuItemLabels()).toEqual([
        'Fake translation: i18n.qd.exampleContactCard.view',
        'Fake translation: i18n.qd.exampleContactCard.delete'
      ]);
      expect(getMenuItemButton('delete').disabled).toBe(false);

      // third contact card
      menuIconElement = contactCards[2].query(By.directive(QdIconComponent)).nativeElement;
      menuIconElement.click();
      expect(getMenuItemLabels()).toEqual([
        'Fake translation: i18n.qd.exampleContactCard.view',
        'Fake translation: i18n.qd.exampleContactCard.edit',
        'Fake translation: i18n.qd.exampleContactCard.delete'
      ]);
      expect(getMenuItemButton('delete').disabled).toBe(true);
    });
  });
});
