import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { QdContactCardComponent } from './contact-card.component';
import { QdContactCardMenuComponent } from './menu/contact-card-menu.component';
import { QdIconModule } from '../icon/icon.module';
import { QdButtonModule } from '../button/button.module';
import { QdPopoverModule } from '../core/popover/popover.module';
import { QdCoreModule } from '../core/core.module';

export { QdContactCardComponent };

@NgModule({
  imports: [CommonModule, QdCoreModule, TranslateModule, QdIconModule, QdButtonModule, QdPopoverModule],
  declarations: [QdContactCardComponent, QdContactCardMenuComponent],
  exports: [QdContactCardComponent]
})
export class QdContactCardModule {}
