import { Component } from '@angular/core';
import { Subject } from 'rxjs';
import { TestBed } from '@angular/core/testing';
import { TranslatePipe } from '@ngx-translate/core';
import { MockComponent, MockPipe, MockProvider } from 'ng-mocks';
import { By } from '@angular/platform-browser';
import { QdContactCardMenuComponent } from './contact-card-menu.component';
import { QdContactCardActionsConfig } from '../model/contact-card-actions-config.interface';
import { QdIconComponent } from '../../icon/icon/icon.component';
import { QdButtonComponent } from '../../button/button/button.component';
import { QdMockPopoverOnClickDirective } from '../../core/popover/__mocks__/mock-popover-on-click.directive';
import { QdPageStoreService } from '../../page/shared/services/page-store.service';
import { QdContactData } from '../model/contact-data.interface';

@Component({
  selector: 'test-component',
  template: ` <qd-contact-card-menu [contactData]="contactData" [actions]="contactCardActions"></qd-contact-card-menu> `
})
class TestComponent {
  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    }
  };

  contactCardActions: QdContactCardActionsConfig = [
    {
      label: { i18n: 'i18n.qd.exampleContactCard.view' },
      handler: jest.fn()
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.edit' },
      handler: jest.fn()
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.delete' },
      handler: jest.fn(),
      isDisabled: true
    },
    {
      label: { i18n: 'My View Mode Action' },
      handler: jest.fn(),
      operationMode: 'view'
    },
    {
      label: { i18n: 'My Edit Mode Action 1' },
      handler: jest.fn(),
      operationMode: 'edit'
    },
    {
      label: { i18n: 'My Edit Mode Action 2' },
      handler: jest.fn(),
      operationMode: 'edit'
    }
  ];
}

@Component({
  selector: 'test-component-hidden-actions',
  template: ` <qd-contact-card-menu [contactData]="contactData" [actions]="contactCardActions"></qd-contact-card-menu> `
})
class TestComponentHiddenActions {
  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    }
  };

  contactCardActions: QdContactCardActionsConfig = [
    {
      label: { i18n: 'i18n.qd.exampleContactCard.view' },
      handler: jest.fn(),
      isHidden: true
    },
    {
      label: { i18n: 'My View Mode Action' },
      handler: jest.fn(),
      operationMode: 'view'
    },
    {
      label: { i18n: 'My Edit Mode Action 1' },
      handler: jest.fn(),
      operationMode: 'edit'
    },
    {
      label: { i18n: 'My Edit Mode Action 2' },
      handler: jest.fn(),
      operationMode: 'edit'
    }
  ];
}

@Component({
  selector: 'test-component-with-callback-properties',
  template: ` <qd-contact-card-menu [contactData]="contactData" [actions]="contactCardActions"></qd-contact-card-menu> `
})
class TestComponentWithCallbackProperties {
  contactData: QdContactData = {
    contactFunction: {
      i18n: 'i18n.contact.function.sender'
    },
    contactPerson: {
      firstName: 'Max',
      lastName: 'Muster'
    },
    address: {
      street: 'Teststrasse 12',
      countryCode: 'CH',
      postalCode: '8952',
      city: 'Schlieren'
    },
    emailAddress: 'max.muster@fritzmeier.ch'
  };

  contactCardActions: QdContactCardActionsConfig = [
    {
      label: { i18n: 'i18n.qd.exampleContactCard.view' },
      handler: jest.fn()
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.edit' },
      handler: jest.fn(),
      isHidden: contactData => contactData.businessPartnerId !== 'GP5468497635'
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.delete' },
      handler: jest.fn(),
      isDisabled: contactData => contactData.businessPartnerId !== 'GP5468497635'
    },
    {
      label: { i18n: 'i18n.qd.exampleContactCard.copy' },
      handler: jest.fn(),
      isDisabled: contactData => contactData.emailAddress !== 'max.muster@fritzmeier.ch'
    }
  ];
}

describe(QdContactCardMenuComponent.name, () => {
  let fixture;
  let component;
  let isViewonlySubject = new Subject<boolean>();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        TestComponentHiddenActions,
        TestComponentWithCallbackProperties,
        QdContactCardMenuComponent,
        QdMockPopoverOnClickDirective,
        MockComponent(QdIconComponent),
        MockComponent(QdButtonComponent),
        MockPipe(TranslatePipe, i18n => (i18n ? 'Fake translation: ' + i18n : ''))
      ],
      providers: [MockProvider(QdPageStoreService, { isViewonly$: isViewonlySubject })]
    }).compileComponents();
  });

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  function getMenuItemLabels(): string[] {
    const menuItemElements = fixture.debugElement.queryAll(By.css('button'));

    return menuItemElements.map(debugElement => debugElement.nativeElement.innerHTML.trim());
  }

  function getMenuItemButton(buttonLabel: string): HTMLButtonElement {
    return fixture.debugElement
      .queryAll(By.css('button'))
      .filter(debugElement => debugElement.nativeElement.innerHTML.includes(buttonLabel))[0].nativeElement;
  }

  test('is rendered correctly', () => {
    createComponent(TestComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('menu opener is not rendered if there are no visible actions', () => {
    createComponent(TestComponentHiddenActions);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('menu is opened when the dots are clicked', () => {
    createComponent(TestComponent);

    const menuIconElement = fixture.debugElement.query(By.directive(QdIconComponent)).nativeElement;
    menuIconElement.click();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('menu action handler are triggered correctly', () => {
    createComponent(TestComponent);

    const menuIconElement = fixture.debugElement.query(By.directive(QdIconComponent)).nativeElement;
    menuIconElement.click();

    const menuItemElements = fixture.debugElement.queryAll(By.css('button'));

    menuItemElements[0].nativeElement.click();
    expect(component.contactCardActions[0].handler).toHaveBeenCalledWith(component.contactData);
    menuItemElements[1].nativeElement.click();
    expect(component.contactCardActions[1].handler).toHaveBeenCalledWith(component.contactData);
    menuItemElements[2].nativeElement.click();
    expect(component.contactCardActions[2].handler).not.toHaveBeenCalled(); // disabled action
  });

  test('menu actions are updated correctly', () => {
    createComponent(TestComponent);

    component.contactCardActions = [
      {
        label: { i18n: 'i18n.qd.exampleContactCard.view' },
        handler: jest.fn()
      }
    ];
    fixture.detectChanges();

    const menuIconElement = fixture.debugElement.query(By.directive(QdIconComponent)).nativeElement;
    menuIconElement.click();

    const menuItemLabels = getMenuItemLabels();
    expect(menuItemLabels.length).toBe(1);
    expect(menuItemLabels[0]).toBe('Fake translation: i18n.qd.exampleContactCard.view');
  });

  test('menu actions are filtered correctly by operation mode when changed', () => {
    createComponent(TestComponent);

    isViewonlySubject.next(true);
    fixture.detectChanges();

    const menuIconElement = fixture.debugElement.query(By.directive(QdIconComponent)).nativeElement;
    menuIconElement.click();

    let menuItemLabels = getMenuItemLabels();
    expect(menuItemLabels.length).toBe(4);
    expect(menuItemLabels[0]).toBe('Fake translation: i18n.qd.exampleContactCard.view');
    expect(menuItemLabels[1]).toBe('Fake translation: i18n.qd.exampleContactCard.edit');
    expect(menuItemLabels[2]).toBe('Fake translation: i18n.qd.exampleContactCard.delete');
    expect(menuItemLabels[3]).toBe('Fake translation: My View Mode Action');

    isViewonlySubject.next(false);
    fixture.detectChanges();

    menuItemLabels = getMenuItemLabels();
    expect(menuItemLabels.length).toBe(5);
    expect(menuItemLabels[0]).toBe('Fake translation: i18n.qd.exampleContactCard.view');
    expect(menuItemLabels[1]).toBe('Fake translation: i18n.qd.exampleContactCard.edit');
    expect(menuItemLabels[2]).toBe('Fake translation: i18n.qd.exampleContactCard.delete');
    expect(menuItemLabels[3]).toBe('Fake translation: My Edit Mode Action 1');
    expect(menuItemLabels[4]).toBe('Fake translation: My Edit Mode Action 2');
  });

  test('menu actions can be hidden', () => {
    createComponent(TestComponentHiddenActions);

    isViewonlySubject.next(true);
    fixture.detectChanges();

    const menuIconElement = fixture.debugElement.query(By.directive(QdIconComponent)).nativeElement;
    menuIconElement.click();

    let menuItemLabels = getMenuItemLabels();
    expect(menuItemLabels.length).toBe(1);
    expect(menuItemLabels[0]).toBe('Fake translation: My View Mode Action');
  });

  test('properties can be defined with callbacks', () => {
    createComponent(TestComponentWithCallbackProperties);

    const menuIconElement = fixture.debugElement.query(By.directive(QdIconComponent)).nativeElement;
    menuIconElement.click();

    let menuItemLabels = getMenuItemLabels();
    expect(menuItemLabels.length).toBe(3);
    expect(menuItemLabels[0]).toBe('Fake translation: i18n.qd.exampleContactCard.view');
    expect(menuItemLabels[1]).toBe('Fake translation: i18n.qd.exampleContactCard.delete');
    expect(menuItemLabels[2]).toBe('Fake translation: i18n.qd.exampleContactCard.copy');
    expect(getMenuItemButton('view').disabled).toBe(false);
    expect(getMenuItemButton('delete').disabled).toBe(true);
    expect(getMenuItemButton('copy').disabled).toBe(false);
  });
});
