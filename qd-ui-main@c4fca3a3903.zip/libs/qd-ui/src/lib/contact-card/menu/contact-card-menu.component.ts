import { ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit, Optional } from '@angular/core';
import { BehaviorSubject, combineLatest, Observable, Subject } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';
import { QdContactCardActionConfig, QdContactCardActionsConfig } from '../model/contact-card-actions-config.interface';
import { QdInspectOperationMode } from '../../page/model/page-config.interface';
import { QdPageStoreService } from '../../page/shared/services/page-store.service';
import { QdContactData } from '../model/contact-data.interface';

@Component({
  selector: 'qd-contact-card-menu',
  templateUrl: './contact-card-menu.component.html',
  styleUrls: ['./contact-card-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdContactCardMenuComponent implements OnInit, OnDestroy {
  /**
   * Data for the **QdContactCard**
   */
  @Input() contactData!: QdContactData;

  /**
   * Configuration for the **QdContactCard** actions
   */
  @Input() set actions(actions: QdContactCardActionsConfig) {
    this._actionsSubject.next(actions);
  }

  get actions$(): Observable<QdContactCardActionConfig[]> {
    return combineLatest([this._actionsSubject, this._operationModeSubject]).pipe(
      takeUntil(this._destroyed$),
      map(([actions, operationMode]) => this.getActionsFilteredByOperationMode(actions, operationMode)),
      map(actions => actions.filter(action => !this.isHidden(action))),
      map(actions => actions.map(action => ({ ...action, isDisabled: this.isDisabled(action) })))
    );
  }

  @Input('data-test-id') testId = 'contact-card-menu';

  private _destroyed$: Subject<void> = new Subject();
  private _actionsSubject = new BehaviorSubject<QdContactCardActionConfig[]>([]);
  private _operationModeSubject = new BehaviorSubject<QdInspectOperationMode | undefined>(undefined);

  constructor(@Optional() private pageStoreService: QdPageStoreService<object>) {}

  ngOnInit(): void {
    this.syncPageOperationMode();
  }

  ngOnDestroy(): void {
    this._destroyed$.next();
    this._destroyed$.complete();
  }

  private isDisabled(action: QdContactCardActionConfig): boolean {
    const { isDisabled } = action;

    return (typeof isDisabled === 'function' ? isDisabled(this.contactData) : isDisabled) ?? false;
  }

  private isHidden(action: QdContactCardActionConfig): boolean {
    const { isHidden } = action;

    return (typeof isHidden === 'function' ? isHidden(this.contactData) : isHidden) ?? false;
  }

  private syncPageOperationMode(): void {
    if (this.pageStoreService) {
      this.pageStoreService.isViewonly$.pipe(takeUntil(this._destroyed$)).subscribe(viewonly => {
        this._operationModeSubject.next(viewonly ? 'view' : 'edit');
      });
    }
  }

  private getActionsFilteredByOperationMode(
    actions: QdContactCardActionsConfig,
    operationMode: QdInspectOperationMode | undefined
  ): QdContactCardActionConfig[] {
    return actions
      .filter(action => !action.operationMode || action.operationMode === operationMode)
      .map(action => {
        const contactCardAction = { ...action };
        delete contactCardAction.operationMode;
        return contactCardAction;
      });
  }
}
