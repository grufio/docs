import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QdMockContactCardComponent } from './mock-contact-card.component';

export { QdMockContactCardComponent };

@NgModule({
  imports: [CommonModule],
  declarations: [QdMockContactCardComponent],
  exports: [QdMockContactCardComponent]
})
export class QdMockContactCardModule {}
