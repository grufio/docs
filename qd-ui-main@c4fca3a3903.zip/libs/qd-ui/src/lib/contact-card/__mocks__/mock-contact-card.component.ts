// @ts-strict-ignore
import { Component, Input } from '@angular/core';
import { QdContactData } from '../model/contact-data.interface';

@Component({
  selector: 'qd-contact-card',
  template: 'contactData: {{contactData | json}}'
})
export class QdMockContactCardComponent {
  @Input() contactData: QdContactData;
}
