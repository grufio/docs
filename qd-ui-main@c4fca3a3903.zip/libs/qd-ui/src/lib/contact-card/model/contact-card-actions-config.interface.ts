import { QdInspectOperationMode } from '../../page/model/page-config.interface';
import { QdContactData } from './contact-data.interface';

/**
 * @description Configuration for the QdContactCard actions
 */
export type QdContactCardActionsConfig = (QdContactCardActionConfig & { operationMode?: QdInspectOperationMode })[];

/**
 * @description Configuration for a single QdContactCard action
 */
export interface QdContactCardActionConfig {
  /**
   * @description The label is shown as text in the UI for this action.
   */
  label: QdContactCardActionLabel;

  /**
   * @description The handler to execute when the action is clicked.
   */
  handler: (contactData: QdContactData) => void;

  /**
   * @description Whether the action is disabled or not
   *
   * * @default false
   */
  isDisabled?: boolean | ((contactData: QdContactData) => boolean);

  /**
   * @description Whether the action is hidden or not
   *
   * * @default false
   */
  isHidden?: boolean | ((contactData: QdContactData) => boolean);
}

/**
 * Type for the label of a QdContactCardAction.
 */
interface QdContactCardActionLabel {
  /**
   * This i18n key is translated directly inside the QdContactCard component.
   */
  i18n: string;
}
