export interface QdContactData {
  /**
   * @description Defines the function of the contact
   *
   * * @example { i18n: "i18n.sender" }
   */
  contactFunction: QdContactFunction;

  /**
   * @description Adds a tag to the contact
   *
   * * @example { i18n:  "i18n.contact.tag" }
   */
  tag?: QdContactTag;

  /**
   * @description Defines the company name
   *
   * * @example "Fritz Meier AG"
   */
  companyName?: string;

  /**
   * @description Defines the business partner id
   *
   * * @example "GP54689497635"
   */
  businessPartnerId?: string;

  /**
   * @description Defines the contact person
   *
   * * @example { firstName: "Max", lastName: "Muster" }
   */
  contactPerson?: QdContactPerson;

  /**
   * @description Defines the contact address (without name)
   *
   * * @example { street: "Teststrasse 12", countryCode: "CH", postalCode: "8952", city: "Schlieren" }
   */
  address?: QdContactAddress;

  /**
   * @description Defines the phone number of the contact
   *
   * * @example "+49 175 64821346"
   */
  phoneNumber?: string;

  /**
   * @description Defines the email address of the contact
   *
   * * @example "max.muster@fritzmeier.ch"
   */
  emailAddress?: string;

  /**
   * @description Custom fields can be defined here that will be displayed at the bottom of the contact card.
   * A custom field can optionally have a label that will be displayed in front of the custom field value.
   * Label and value can be plain strings or objects with an `i18n` key if you need translation.
   *
   * * @example
   * [
   *   {
   *     label: "UID",
   *     value: "798347982674"
   *   },
   *   {
   *     label: {
   *       i18n: "i18n.bafuNumber"
   *     },
   *     value: "B87384789CH23"
   *   },
   *   {
   *     label: {
   *       i18n: "i18n.status"
   *     },
   *     value: {
   *       i18n: "i18n.status.approved"
   *     }
   *   }
   * ]
   */
  customFields?: QdContactDataCustomField[];
}

export interface QdContactFunction {
  /**
   * @description Defines the translation key
   *
   * * @example "i18n.contact.function.sender"
   */
  i18n: string;
}

export interface QdContactTag {
  /**
   * @description Defines the translation key
   *
   * * @example "i18n.contact.tag"
   */
  i18n: string;
}

export interface QdContactPerson {
  /**
   * @description Defines the first name of the contact person
   *
   * * @example "Max"
   */
  firstName: string;

  /**
   * @description Defines the last name of the contact person
   *
   * * @example "Muster"
   */
  lastName: string;
}

export interface QdContactAddress {
  /**
   * @description Defines the street of the contact
   *
   * * @example "Teststrasse 12"
   */
  street?: string;

  /**
   * @description Defines the country code of the contact
   *
   * * @example "CH"
   */
  countryCode?: string;

  /**
   * @description Defines the postal code of the contact
   *
   * * @example "8952"
   */
  postalCode?: string;

  /**
   * @description Defines the city of the contact
   *
   * * @example "Schlieren"
   */
  city: string;

  /**
   * @description Defines the careOf (c/o) of the contact
   *
   * * @example "c/o Mrs. Robinson"
   */
  careOf?: string;
}

export interface QdContactDataCustomField {
  /**
   * @description Optional label that will be displayed in front of the custom field value.
   * Can be a plain string or an object with i18n key for translation.
   *
   * * @example { i18n: "i18n.bafuNumber" }
   */
  label?: QdContactDataCustomFieldEntry;

  /**
   * @description Defines value of the custom field. Can be a plain string or an object with i18n key for translation.
   *
   * * @example "B87384789CH23"
   */
  value: QdContactDataCustomFieldEntry;
}

export type QdContactDataCustomFieldEntry = string | QdContactDataCustomTranslatedEntry;

export interface QdContactDataCustomTranslatedEntry {
  /**
   * @description The i18n key for the translation.
   */
  i18n: string;
}
