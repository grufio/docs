// @ts-strict-ignore
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { QdStoryBookApiBaseUrlInterceptor } from './base-url-interceptor.service';

describe(QdStoryBookApiBaseUrlInterceptor.name, () => {
  let interceptor: QdStoryBookApiBaseUrlInterceptor;
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: QdStoryBookApiBaseUrlInterceptor,
          multi: true
        }
      ]
    });

    interceptor = TestBed.inject(HTTP_INTERCEPTORS).find(
      interceptor => interceptor instanceof QdStoryBookApiBaseUrlInterceptor
    ) as QdStoryBookApiBaseUrlInterceptor;
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  test("don't prefix if request has absolute path.", done => {
    httpClient.get('https://path-to-resource').subscribe(res => {
      expect(res).toEqual('some data');

      done();
    });

    httpTestingController.expectOne('https://path-to-resource').flush('some data');

    httpTestingController.verify();
  });

  test('prefixes reqUrl with baseUrl.', done => {
    // @ts-ignore
    interceptor.baseUrl = 'DAZUIC-XXXX';

    httpClient.get('path-to-resource').subscribe(res => {
      expect(res).toEqual('some data');

      done();
    });

    httpTestingController.expectOne('DAZUIC-XXXX/path-to-resource').flush('some data');

    httpTestingController.verify();
  });

  test("don't prefix if ticket name is not replaced.", done => {
    // @ts-ignore
    interceptor.baseUrl = '{TICKET_NAME}';

    httpClient.get('path-to-resource').subscribe(res => {
      expect(res).toEqual('some data');

      done();
    });

    httpTestingController.expectOne('path-to-resource').flush('some data');

    httpTestingController.verify();
  });
});
