import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { QdCoreModule } from '../core/core.module';
import { QdSanitizeHtmlPipe } from '../core/pipes/sanitize-html.pipe';
import { QdPopoverModule } from '../core/popover/popover.module';
import { QdIconModule } from '../icon/icon.module';
import { QdNotificationsModule } from '../notifications/notifications.module';
import { QdTextSectionModule } from '../text-section/text-section.module';
import { QdButtonGridComponent } from './button-grid/button-grid.component';
import { QdButtonStackButtonComponent } from './button-stack/button-stack-button/button-stack-button.component';
import { QdButtonStackComponent } from './button-stack/button-stack-container/button-stack.component';
import { QdButtonAdditionalInfoComponent } from './button/additional-info/button-additional-info.component';
import { QdButtonComponent } from './button/button.component';
import { QdButtonGhostDirective, QdButtonLinkDirective } from './directives/button.directives';
import { QdIconButtonComponent } from './icon-button/icon-button.component';
import { QdMenuButtonComponent } from './menu-button/menu-button.component';
import { QdMenuButtonConfig } from './model/button-config';

export {
  QdButtonComponent,
  QdButtonGhostDirective,
  QdButtonGridComponent,
  QdButtonLinkDirective,
  QdButtonStackButtonComponent,
  QdButtonStackComponent,
  QdIconButtonComponent,
  QdMenuButtonComponent,
  QdMenuButtonConfig
};

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    QdIconModule,
    QdTextSectionModule,
    QdPopoverModule,
    QdCoreModule,
    QdNotificationsModule
  ],
  declarations: [
    QdButtonComponent,
    QdButtonGhostDirective,
    QdButtonGridComponent,
    QdButtonLinkDirective,
    QdButtonStackButtonComponent,
    QdButtonStackComponent,
    QdIconButtonComponent,
    QdMenuButtonComponent,
    QdButtonAdditionalInfoComponent,
    QdSanitizeHtmlPipe
  ],
  exports: [
    QdButtonComponent,
    QdButtonGhostDirective,
    QdButtonGridComponent,
    QdButtonLinkDirective,
    QdButtonStackButtonComponent,
    QdButtonStackComponent,
    QdIconButtonComponent,
    QdMenuButtonComponent
  ]
})
export class QdButtonModule {}
