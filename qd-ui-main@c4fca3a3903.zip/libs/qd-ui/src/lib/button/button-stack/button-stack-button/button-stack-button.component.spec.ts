// @ts-strict-ignore
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdMockIconComponent } from '../../../icon/__mocks__/mock-icon.component';
import { QdButtonStackButtonComponent } from './button-stack-button.component';

@Component({
  selector: 'my-qd-button-stack-button',
  template: ` <button qdButtonStack>My Button Content</button> `
})
class ButtonComponent {}

@Component({
  selector: 'my-deprecated-qd-button-stack-button',
  template: ` <button qd-button-stack>My Button Content</button> `
})
class DeprecatedButtonComponent {}

@Component({
  selector: 'my-qd-button-stack-button',
  template: ` <button qdButtonStack disabled>My Button Content</button> `
})
class ButtonComponentDisabled {}

@Component({
  selector: 'my-qd-button-stack-button',
  template: ` <button qdButtonStack [completed]="true">My Button Content</button> `
})
class ButtonComponentCompleted {}

@Component({
  selector: 'my-qd-button-stack-button',
  template: `
    <button qdButtonStack>
      <qd-icon>My own Icon</qd-icon>
      My Button Content
    </button>
  `
})
class ButtonComponentWithIcon {}

describe('Testing QdButtonStackButtonComponent |', () => {
  describe('When the component was mounted with no attributes & no content is projected,', () => {
    let component: ButtonComponent;
    let fixture: ComponentFixture<ButtonComponent>;
    let consoleWarn: jest.SpyInstance;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [QdMockIconComponent, ButtonComponent, QdButtonStackButtonComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});
      fixture = TestBed.createComponent(ButtonComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('the rendered markup matched the snapshot with default icon.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
      expect(consoleWarn).not.toHaveBeenCalled();
    });
  });

  describe('If deprecated syntax is used,', () => {
    let component: DeprecatedButtonComponent;
    let fixture: ComponentFixture<DeprecatedButtonComponent>;
    let consoleWarn: jest.SpyInstance;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [QdMockIconComponent, DeprecatedButtonComponent, QdButtonStackButtonComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});
      fixture = TestBed.createComponent(DeprecatedButtonComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('it has been properly rendered.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
      expect(consoleWarn).toHaveBeenNthCalledWith(
        1,
        'QD-UI | QdButtonStack - The directive "qd-button-stack" is deprecated. Please use "qdButtonStack" instead.'
      );
    });
  });

  describe('When the component was mounted with "disabled" attribute & no content is projected,', () => {
    let component: ButtonComponentDisabled;
    let fixture: ComponentFixture<ButtonComponentDisabled>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [QdMockIconComponent, ButtonComponentDisabled, QdButtonStackButtonComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(ButtonComponentDisabled);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the rendered markup matched the snapshot with "disabled" state.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('When the component was mounted with "completed" is set to "true" & no content is projected,', () => {
    let component: ButtonComponentCompleted;
    let fixture: ComponentFixture<ButtonComponentCompleted>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [QdMockIconComponent, ButtonComponentCompleted, QdButtonStackButtonComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(ButtonComponentCompleted);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the rendered markup matched the snapshot with "disabled" state.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('When the component was mounted with an icon content is projected,', () => {
    let component: ButtonComponentWithIcon;
    let fixture: ComponentFixture<ButtonComponentWithIcon>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [QdMockIconComponent, ButtonComponentWithIcon, QdButtonStackButtonComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(ButtonComponentWithIcon);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('the rendered markup matched the projected icon.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });
});
