import { Component, ElementRef, HostBinding, Input, OnInit, ViewEncapsulation } from '@angular/core';

/**
 * With the **QdButtonStackButton** you can display and set up various states in the process.
 *
 * * @see parent component **QdButtonStack**.
 */
@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'button[qd-button-stack], button[qdButtonStack]',
  templateUrl: './button-stack-button.component.html',
  styleUrls: ['./button-stack-button.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: { class: 'qd-button-stack__button' }
})
export class QdButtonStackButtonComponent implements OnInit {
  /**
   * Disabled the button
   */
  @Input() disabled = false;

  /**
   * When completed a check mark appears on the left side.
   */
  @Input() completed = false;

  @HostBinding('class.qd-button-stack__button--completed') get hasCompleted(): boolean {
    return this.completed;
  }

  constructor(private readonly _elementRef: ElementRef) {}

  ngOnInit(): void {
    // TODO: Delete directive "qd-button-stack" in Version 15
    if (this._elementRef.nativeElement.attributes.hasOwnProperty('qd-button-stack')) {
      console.warn(
        'QD-UI | QdButtonStack - The directive "qd-button-stack" is deprecated. Please use "qdButtonStack" instead.'
      );
    }
  }
}
