import { QdButtonComponent, QdButtonModule, QdButtonStackComponent } from '../../button.module';

describe(QdButtonStackComponent.name, () => {
  beforeEach(() => {});

  it('renders', () => {
    cy.mount(
      `<qd-button-stack>
        <button qdButtonStack>Button 1</button>
        <button qdButtonStack [completed]="true">Button 2</button>
        <button qdButtonStack [completed]="false">Button 3</button>
      </qd-button-stack>`,
      {
        declarations: [QdButtonComponent, QdButtonStackComponent],
        imports: [QdButtonModule]
      }
    );

    cy.matchImage();
  });
});
