// @ts-strict-ignore
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdMockButtonStackButtonComponent } from '../../__mocks__/mock-button-stack-button.component';
import { QdMockContainerLayoutService } from '../../../container/__mocks__/mock-container-layout.service';
import { QdContainerLayoutService } from '../../../container/services/container-layout.service';
import { QdButtonStackComponent } from './button-stack.component';

jest.mock('../../../container/services/container-layout.service', () => ({ QdContainerLayoutService: class {} }));

@Component({
  selector: 'my-qd-button-stack',
  template: `
    <qd-button-stack>
      <button qdButtonStack>Stack Button 1</button>
      <button qdButtonStack>Stack Button 2</button>
      <button qd-button-stack>Stack Button 3</button>
    </qd-button-stack>
  `
})
class ButtonStackComponent {}

@Component({
  selector: 'my-qd-button-stack',
  template: `
    <qd-button-stack>
      <button qdIconButton>Link Button</button>
      <button qd-button>Link Button</button>
      <button qd-button-link>Link Button</button>
      Some Nonsense!
    </qd-button-stack>
  `
})
class ButtonComponentWithVariousOtherButtons {}

describe('Testing QdButtonStackComponent |', () => {
  describe('If stack buttons were projected into the component,', () => {
    let component: ButtonStackComponent;
    let fixture: ComponentFixture<ButtonStackComponent>;
    let containerLayoutService: QdContainerLayoutService;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [ButtonStackComponent, QdButtonStackComponent, QdMockButtonStackButtonComponent],
        providers: [
          {
            provide: QdContainerLayoutService,
            useClass: QdMockContainerLayoutService
          }
        ]
      }).compileComponents();

      containerLayoutService = TestBed.inject(QdContainerLayoutService);
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(ButtonStackComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('it has been properly rendered.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('"updateContent" have been called, if QdContainerActionService is injected.', () => {
      expect(containerLayoutService.updateContent).toHaveBeenNthCalledWith(1, { 'button-stack': true });
    });
  });

  describe('If other buttons were projected into the component,', () => {
    let component: ButtonComponentWithVariousOtherButtons;
    let fixture: ComponentFixture<ButtonComponentWithVariousOtherButtons>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [ButtonComponentWithVariousOtherButtons, QdButtonStackComponent, QdMockButtonStackButtonComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(ButtonComponentWithVariousOtherButtons);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('it has been rendered without any buttons.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });
});
