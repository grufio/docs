import { Component, ElementRef, OnInit, Optional } from '@angular/core';
import { QdContainerLayoutService } from '../../../container/services/container-layout.service';

/**
 * With the **QdButtonStack** component you can display and set up various states in the process.
 *
 * * @see child component **QdButtonStackButton**.
 */
@Component({
  selector: 'qd-button-stack',
  template: `
    <ng-content select="button[qdButtonStack]"></ng-content>
    <ng-content select="button[qd-button-stack]"></ng-content>
  `,
  styleUrls: ['./button-stack.component.scss'],
  host: { class: 'qd-button-stack' }
})
export class QdButtonStackComponent implements OnInit {
  constructor(
    @Optional() private readonly containerLayoutService: QdContainerLayoutService,
    private readonly _elementRef: ElementRef
  ) {}

  ngOnInit(): void {
    if (this.containerLayoutService) {
      this.containerLayoutService.updateContent({
        'button-stack': true
      });
    }
  }
}
