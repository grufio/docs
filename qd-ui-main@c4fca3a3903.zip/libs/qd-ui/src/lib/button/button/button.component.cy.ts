import { QdButtonComponent } from './button.component';
import { QdButtonGhostDirective, QdButtonLinkDirective } from '../directives/button.directives';
import { QdButtonModule } from '../button.module';

const defaultButton = {
  name: 'default button',
  temp: `<button qdButton [disabled]="disabled" [color]="'primary'">Klick mich</button>`
};
const ghostButton = {
  name: 'ghost button',
  temp: `<button qdButton qdButtonGhost [disabled]="disabled" [color]="'secondary'">Klick mich</button>`
};
const linkButton = {
  name: 'link button',
  temp: `<button qdButton qdButtonLink [disabled]="disabled" [color]="'error'">Klick mich</button>`
};

const config = {
  declarations: [QdButtonComponent, QdButtonGhostDirective, QdButtonLinkDirective],
  imports: [QdButtonModule],
  componentProperties: {
    disabled: false
  }
};

[defaultButton, ghostButton, linkButton].forEach(button => {
  describe(QdButtonComponent.name + ' ' + button.name, () => {
    beforeEach(() => {});
    it('renders', () => {
      cy.mount(button.temp, config);

      cy.matchImage();
    });

    it('enabled button is clickable', () => {
      cy.mount(button.temp, config);
      cy.get('[data-test-id="button"]').should('be.enabled');
    });

    it('disabled button is not clickable', () => {
      cy.mount(button.temp, {
        ...config,
        componentProperties: {
          ...config.componentProperties,
          disabled: true
        }
      });
      cy.get('[data-test-id="button"]').should('not.be.enabled');
    });
  });
});
