import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MockComponent, MockService } from 'ng-mocks';
import { QdMockPopoverModule } from '../../../core/popover/__mocks__/mock-popover.module';
import { QdIconComponent } from '../../../icon/icon/icon.component';
import { QdNotificationsService } from '../../../notifications/notifications.module';
import { QdButtonAdditionalInfoType } from '../../model/button-config';
import { QdButtonAdditionalInfoComponent } from './button-additional-info.component';

describe(QdButtonAdditionalInfoComponent.name, () => {
  let component: QdButtonAdditionalInfoComponent;
  let fixture: ComponentFixture<QdButtonAdditionalInfoComponent>;
  let notificationsService: QdNotificationsService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QdMockPopoverModule],
      declarations: [QdButtonAdditionalInfoComponent, MockComponent(QdIconComponent)],
      providers: [{ provide: QdNotificationsService, useValue: MockService(QdNotificationsService) }]
    }).compileComponents();

    notificationsService = TestBed.inject(QdNotificationsService);

    fixture = TestBed.createComponent(QdButtonAdditionalInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('renders nothing if buttonAdditionalInfo is not set', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('renders nothing if count is zero', () => {
    component.buttonAdditionalInfo = {
      infoType: 'warning',
      message: { i18n: 'i18n.qd.page.submit.errorInfo' }
    };
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  const infoTypesCases = [
    {
      infoType: 'warning' as QdButtonAdditionalInfoType,
      expectedIcon: 'warningHexFilled'
    },
    {
      infoType: 'info' as QdButtonAdditionalInfoType,
      expectedIcon: 'exclamationCircle'
    }
  ];
  test.each(infoTypesCases)('renders correctly with info type $infoType', ({ infoType, expectedIcon }) => {
    component.buttonAdditionalInfo = {
      infoType,
      message: { i18n: 'i18n.qd.page.submit.errorInfo' }
    };
    fixture.detectChanges();

    const iconComponent = fixture.debugElement.query(By.directive(QdIconComponent)).componentInstance;
    expect(iconComponent.icon).toBe(expectedIcon);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('opens notification on click', () => {
    component.buttonAdditionalInfo = {
      infoType: 'warning',
      message: { i18n: 'i18n.qd.page.submit.errorInfo' }
    };
    fixture.detectChanges();

    const box = fixture.debugElement.nativeElement;
    box.click();

    expect(notificationsService.add).toHaveBeenCalledWith('page', {
      type: 'warning',
      i18n: 'i18n.qd.page.submit.errorInfo',
      showAsSnackbar: true
    });
  });
});
