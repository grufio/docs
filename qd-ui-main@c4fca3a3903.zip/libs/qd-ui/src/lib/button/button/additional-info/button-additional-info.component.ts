import { Component, HostBinding, HostListener, Input } from '@angular/core';
import { QdNotificationsService } from '../../../notifications/services/notifications-service.service';
import { QdButtonAdditionalInfo, QdButtonAdditionalInfoType } from '../../model/button-config';

@Component({
  selector: 'qd-button-additional-info',
  templateUrl: './button-additional-info.component.html',
  styleUrls: ['./button-additional-info.component.scss']
})
export class QdButtonAdditionalInfoComponent {
  @Input() buttonAdditionalInfo!: QdButtonAdditionalInfo;

  @HostBinding('class')
  get infoTypeClass(): string {
    return this.infoType || '';
  }

  constructor(private notificationsService: QdNotificationsService) {}

  @HostListener('click')
  showMessage(): void {
    this.notificationsService.add('page', {
      type: this.infoType,
      i18n: this.buttonAdditionalInfo.message.i18n,
      showAsSnackbar: true
    });
  }

  get icon(): string {
    switch (this.infoType) {
      case 'warning':
        return 'warningHexFilled';
      case 'info':
        return 'exclamationCircle';
    }
  }

  get infoType(): QdButtonAdditionalInfoType {
    return this.buttonAdditionalInfo?.infoType;
  }
}
