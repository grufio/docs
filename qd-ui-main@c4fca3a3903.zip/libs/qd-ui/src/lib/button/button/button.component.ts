// @ts-strict-ignore
import { Component, ElementRef, Host, Input, OnInit, Optional } from '@angular/core';

import { QdButtonGhostDirective, QdButtonLinkDirective } from '../directives/button.directives';
import { QdButtonAdditionalInfo } from '../model/button-config';
import { QdButtonColor } from '../model/button.types';

/**
 * The **QdButton** component, as the name suggests, provides a simple button.<br />
 * It is possible to bind it to either a `button` tag or to an `a` tag.
 */
@Component({
  selector: 'button[qdButton], a[qdButton], button[qd-button]',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
  host: { '[attr.class]': 'classes', '[attr.disabled]': 'isDisabled', '[attr.data-test-id]': 'testId' }
})
export class QdButtonComponent implements OnInit {
  /**
   * Disables the button
   */
  @Input() disabled: boolean;

  /**
   * Sets the color
   */
  @Input() color: QdButtonColor = 'primary';

  /**
   * This allows you to specify an icon.
   */
  @Input() icon: string;

  /**
   * A static test ID for integration tests can be set. <br />
   * The value for the HTML attribute [data-test-id].
   */
  @Input('data-test-id') testId = 'button';

  @Input('additionalInfo') additionalInfo: QdButtonAdditionalInfo;

  get hasIcon(): boolean {
    return !!this.icon;
  }

  get isDisabled(): boolean | null {
    if (this.disabled === false) return null;

    return this.disabled !== undefined || null;
  }

  get classes(): string {
    return (
      'qd-button' +
      (' qd-button-' + this.color) +
      (this.isDisabled ? ' qd-button-disabled' : '') +
      (this.hasIcon ? ' qd-button-has-icon' : '') +
      (this.buttonLink ? ' qd-button-link' : '') +
      (this.buttonGhost ? ' qd-button-ghost' : '')
    );
  }

  constructor(
    @Optional() @Host() public buttonLink: QdButtonLinkDirective,
    @Optional() @Host() public buttonGhost: QdButtonGhostDirective,
    private readonly _elementRef: ElementRef
  ) {}

  ngOnInit(): void {
    // TODO: Delete directive "qd-button" in Version 15
    if (this._elementRef.nativeElement.attributes.hasOwnProperty('qd-button')) {
      console.warn(
        'QD-UI | QdButtonComponent - The directive "qd-button" is deprecated. Please use "qdButton" instead.'
      );
    }
  }
}
