// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';

import { QdMockIconModule } from '../../icon/__mocks__/mock-icon.module';
import { QdMockButtonGhostDirective, QdMockButtonLinkDirective } from '../__mocks__/mock-button.directives';

import { QdButtonComponent } from './button.component';
import { QdButtonGhostDirective, QdButtonLinkDirective } from '../directives/button.directives';

@Component({
  selector: 'my-button',
  template: ` <button qd-button>Click</button> `
})
class TestComponent {}

@Component({
  selector: 'my-button',
  template: ` <a href="https://example.com" qdButton>Click</a> `
})
class AnkerTagTestComponent {}

@Component({
  selector: 'my-button',
  template: ` <button qdButton qdButtonLink>Click</button> `
})
class LinkButtonTestComponent {}

@Component({
  selector: 'my-button',
  template: ` <button qdButton qdButtonGhost>Click</button> `
})
class GhostButtonTestComponent {}

@Component({
  selector: 'my-button',
  template: ` <button qdButton disabled>Click</button> `
})
class DisabledAttributeTestComponent {}

@Component({
  selector: 'my-button',
  template: ` <button qdButton [disabled]="disabled">Click</button> `
})
class DisabledInputTestComponent {
  disabled = false;
}

describe(QdButtonComponent.name, () => {
  afterEach(() => jest.resetAllMocks());

  describe('Classnames:', () => {
    let component: QdButtonComponent;
    let fixture: ComponentFixture<QdButtonComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [QdMockIconModule],
        declarations: [QdMockButtonLinkDirective, QdMockButtonGhostDirective, QdButtonComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(QdButtonComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('matches snapshot', () => {
      expect(component).toBeTruthy();
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('Set correct color class', () => {
      component.color = 'secondary';
      fixture.detectChanges();

      expect(By.css('.qd-button-secondary')).toBeTruthy();
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('Set correct Icon.', () => {
      component.icon = 'delivery';
      fixture.detectChanges();

      expect(By.css('.qd-button-has-icon')).toBeTruthy();
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('Using a tag: ', () => {
    let component: AnkerTagTestComponent;
    let fixture: ComponentFixture<AnkerTagTestComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [QdButtonComponent, AnkerTagTestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(AnkerTagTestComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('matches snapshot.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('Disabled HTML Attribute: ', () => {
    let component: DisabledAttributeTestComponent;
    let fixture: ComponentFixture<DisabledAttributeTestComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [QdButtonComponent, DisabledAttributeTestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(DisabledAttributeTestComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('Set correct disabled class.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('Disabled Input: ', () => {
    let component: DisabledInputTestComponent;
    let fixture: ComponentFixture<DisabledInputTestComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [QdButtonComponent, DisabledInputTestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(DisabledInputTestComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('Set correct disabled class.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
      component.disabled = true;
      fixture.detectChanges();
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('Warnings: ', () => {
    let component: TestComponent;
    let fixture: ComponentFixture<TestComponent>;
    let consoleWarn: jest.SpyInstance;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [QdMockIconModule],
        declarations: [QdMockButtonLinkDirective, QdMockButtonGhostDirective, QdButtonComponent, TestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});
      fixture = TestBed.createComponent(TestComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('Warns in case of deprecated syntax.', () => {
      expect(consoleWarn).toHaveBeenNthCalledWith(
        1,
        'QD-UI | QdButtonComponent - The directive "qd-button" is deprecated. Please use "qdButton" instead.'
      );
    });
  });

  describe('Link Buttons: ', () => {
    let component: LinkButtonTestComponent;
    let fixture: ComponentFixture<LinkButtonTestComponent>;
    let consoleWarn: jest.SpyInstance;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [QdMockIconModule],
        declarations: [QdButtonLinkDirective, QdButtonComponent, LinkButtonTestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});
      fixture = TestBed.createComponent(LinkButtonTestComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('Component sets the correct CSS class.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
      expect(consoleWarn).not.toHaveBeenCalled();
    });
  });

  describe('Ghost Buttons: ', () => {
    let component: GhostButtonTestComponent;
    let fixture: ComponentFixture<GhostButtonTestComponent>;
    let consoleWarn: jest.SpyInstance;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [QdMockIconModule],
        declarations: [QdButtonGhostDirective, QdButtonComponent, GhostButtonTestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});
      fixture = TestBed.createComponent(GhostButtonTestComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('Component sets the correct CSS class.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
      expect(consoleWarn).not.toHaveBeenCalled();
    });
  });
});
