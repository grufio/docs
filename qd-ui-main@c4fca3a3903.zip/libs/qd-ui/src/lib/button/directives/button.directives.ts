import { Directive, ElementRef, OnInit } from '@angular/core';

/**
 * The **QdButtonLink** can be used in combination with the **QdButton** component.
 *
 * * @see **QdButton** component.
 */
@Directive({ selector: 'button[qdButtonLink], a[qdButtonLink], button[qd-button-link]' })
export class QdButtonLinkDirective implements OnInit {
  constructor(private readonly _elementRef: ElementRef) {}

  ngOnInit(): void {
    // TODO: Delete directive "qd-button-link" in Version 18
    if (this._elementRef.nativeElement.attributes.hasOwnProperty('qd-button-link')) {
      console.warn(
        'QD-UI | QdButtonLinkDirective - The directive "qd-button-link" is deprecated. Please use "qdButtonLink" instead.'
      );
    }
  }
}

/**
 * The **QdButtonGhost** can be used in combination with the **QdButton** and **QdMenuButton**.
 *
 * * @see **QdButton** component.
 * * @see **QdMenuButton** component.
 */
@Directive({ selector: 'button[qdButtonGhost], a[qdButtonGhost]' })
export class QdButtonGhostDirective {}
