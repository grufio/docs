// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Component } from '@angular/core';

import { QdButtonGhostDirective, QdButtonLinkDirective } from './button.directives';

@Component({
  selector: 'my-button',
  template: ` <button qd-button-link>Click</button> `
})
class TestComponent {}

describe(QdButtonLinkDirective.name, () => {
  test('Directive can be instantiated.', () => {
    expect(new QdButtonLinkDirective({ nativeElement: document.createElement('button') })).toBeTruthy();
  });

  describe('Deprecated syntax', () => {
    let component: TestComponent;
    let fixture: ComponentFixture<TestComponent>;
    let consoleWarn: jest.SpyInstance;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [QdButtonLinkDirective, TestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});
      fixture = TestBed.createComponent(TestComponent);
      component = fixture.componentInstance;

      fixture.detectChanges();
    });

    test('triggers a warning.', () => {
      expect(consoleWarn).toHaveBeenNthCalledWith(
        1,
        'QD-UI | QdButtonLinkDirective - The directive "qd-button-link" is deprecated. Please use "qdButtonLink" instead.'
      );
    });
  });
});

describe(QdButtonGhostDirective.name, () => {
  test('Directive can be instantiated.', () => {
    expect(new QdButtonGhostDirective()).toBeTruthy();
  });
});
