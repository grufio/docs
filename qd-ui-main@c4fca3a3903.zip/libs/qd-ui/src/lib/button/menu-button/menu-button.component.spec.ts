import { Overlay } from '@angular/cdk/overlay';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { QdMockTranslatePipe } from '../../core/__mocks__/mock-translate.pipe';
import { QdMockPopoverModule } from '../../core/popover/__mocks__/mock-popover.module';
import { QdMockIconModule } from '../../icon/__mocks__/mock-icon.module';
import { QdMockButtonGhostDirective, QdMockButtonModule } from '../__mocks__/mock-button.module';

import { QdMenuButtonConfig } from '../model/button-config';
import { QdMenuButtonComponent } from './menu-button.component';

const mockOverlayRef = {
  detach: jest.fn(),
  hasAttached: jest.fn(),
  attach: jest.fn(() => ({ instance: {} }))
};

const mockOverlay = {
  create: jest.fn(() => mockOverlayRef)
};

@Component({
  selector: 'menu-button-test',
  template: `<button [qdMenuButton]="config">Menu</button>`
})
class MenuButtonTestComponent {
  config: QdMenuButtonConfig = {
    actions: [
      {
        label: { i18n: 'i18n.create' },
        handler: jest.fn(),
        isDisabled: false,
        isHidden: false
      },
      {
        label: { i18n: 'i18n.release' },
        handler: jest.fn(),
        isDisabled: false,
        isHidden: false
      },
      {
        label: { i18n: 'i18n.delete' },
        handler: jest.fn(),
        isDisabled: true,
        isHidden: false
      }
    ],
    isDisabled: false
  };
}

describe(`Testing ${MenuButtonTestComponent.name} |`, () => {
  let fixture: ComponentFixture<MenuButtonTestComponent>;
  let component: MenuButtonTestComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QdMockButtonModule, QdMockPopoverModule, QdMockIconModule],
      declarations: [QdMockTranslatePipe, MenuButtonTestComponent, QdMenuButtonComponent],
      providers: [{ provide: Overlay, useValue: mockOverlay }]
    }).compileComponents();

    jest.spyOn(console, 'error').mockImplementation(() => {});

    fixture = TestBed.createComponent(MenuButtonTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => jest.clearAllMocks());

  test('logs error if config is not provided', () => {
    component.config = undefined;

    fixture.detectChanges();
    fixture.debugElement.query(By.directive(QdMenuButtonComponent)).componentInstance.ngOnInit();

    expect(console.error).toHaveBeenCalledWith('QD-UI | QdMenuButtonComponent - Please provide a valid config.');
  });

  test('matches the snapshot', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches the snapshot with ghost styling', () => {
    const buttonElement = fixture.debugElement.query(By.css('button'));
    buttonElement.injector.get(QdMenuButtonComponent).qdButtonGhost = new QdMockButtonGhostDirective();

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('displays all actions when open', () => {
    fixture.debugElement.query(By.css('button[qdbutton]')).nativeElement.click();

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('renders actions when `isDisabled` and `isHidden` are not set', () => {
    component.config.actions = [
      {
        label: { i18n: 'i18n.newAction' },
        handler: jest.fn()
      }
    ];

    fixture.detectChanges();
    fixture.debugElement.query(By.css('button[qdbutton]')).nativeElement.click();
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('hides actions when `isHidden` is true', () => {
    component.config.actions[1].isHidden = true;

    fixture.debugElement.query(By.css('button[qdbutton]')).nativeElement.click();
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('disables menu button when all actions are hidden', () => {
    component.config.actions.forEach(action => (action.isHidden = true));

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('disables menu button when `isDisabled` is set in config', () => {
    component.config.isDisabled = true;

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('invokes handler on action click', () => {
    fixture.debugElement.query(By.css('button[qdbutton]')).nativeElement.click();

    fixture.detectChanges();
    const actionButton = fixture.debugElement.query(By.css('.entry')).nativeElement;
    actionButton.click();

    expect(component.config.actions[0].handler).toHaveBeenCalled();
  });

  test('disables individual actions when `isDisabled` is true', () => {
    fixture.debugElement.query(By.css('button[qdbutton]')).nativeElement.click();

    fixture.detectChanges();
    const disabledActionButton = fixture.debugElement.queryAll(By.css('.entry'))[2].nativeElement;

    expect(disabledActionButton.disabled).toBe(true);
  });

  test('prevents handler invocation on disabled action click', () => {
    fixture.debugElement.query(By.css('button[qdbutton]')).nativeElement.click();

    fixture.detectChanges();
    const disabledActionButton = fixture.debugElement.queryAll(By.css('.entry'))[2].nativeElement;

    expect(disabledActionButton.disabled).toBe(true);

    disabledActionButton.click();

    expect(component.config.actions[2].handler).not.toHaveBeenCalled();
  });
});
