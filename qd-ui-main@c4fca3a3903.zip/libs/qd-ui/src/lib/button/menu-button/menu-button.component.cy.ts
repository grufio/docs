import { TranslateModule } from '@ngx-translate/core';
import { QdButtonComponent, QdButtonModule, QdMenuButtonComponent } from '../button.module';
import { QdMenuButtonConfig } from '../model/button-config';

const config: QdMenuButtonConfig = {
  actions: [
    {
      label: { i18n: 'Create' },
      handler: () => cy.spy().as('create')()
    },
    {
      label: { i18n: 'Release' },
      handler: () => cy.spy().as('release')()
    },
    {
      label: { i18n: 'Delete' },
      handler: (): void => {},
      isDisabled: true
    }
  ]
};

describe(QdMenuButtonComponent.name, () => {
  beforeEach(() => {
    cy.mount(`<button [qdMenuButton]="config"> Menu Button </button>`, {
      declarations: [QdMenuButtonComponent, QdButtonComponent],
      imports: [QdButtonModule, TranslateModule.forRoot({})],
      componentProperties: {
        config
      }
    });
  });

  it('renders', () => {
    cy.matchImage();
  });

  it('enabled actions are executed', () => {
    cy.get('.qd-button').click();
    cy.get('qd-popover > :nth-child(1)').click();
    cy.get('@create').should('be.called');

    cy.get('.qd-button').click();
    cy.get('qd-popover > :nth-child(2)').click();
    cy.get('@release').should('be.called');
  });

  it('disabled action is not clickable', () => {
    cy.get('.qd-button').click();
    cy.get('qd-popover > :nth-child(3)').should('be.disabled');
  });
});
