import { Component, Host, Input, OnInit, Optional } from '@angular/core';

import { QdButtonGhostDirective } from '../directives/button.directives';
import { QdMenuButtonConfig } from '../model/button-config';

/**
 * **QdMenuButtonComponent** provides a button with a dropdown menu for triggering actions.
 *
 * #### **Features**
 *
 * - **Configurable Actions**: Displays a button that opens a dropdown menu when clicked. Each action must have its own handler function.
 * - **Ghost Button Option**: Supports a transparent "ghost" style using the **QdButtonGhostDirective** for secondary actions.
 *
 * #### **Interactions**
 *
 * - **Visibility and Availability**: Actions can be shown or hidden based on configuration.
 * - **Disabled State**: Actions and the menu button can be disabled. The menu button is also disabled if there are no unhidden actions.
 *
 * #### **Error Handling**
 *
 * Logs an error if the component is initialized without a valid configuration.
 *
 * #### **Usage**
 *
 * ```typescript
 * menuConfig: QdMenuButtonConfig = {
 *   actions: [
 *     { label: { i18n: 'i18n.actions.first' }, handler: () => doSomething() },
 *     { label: { i18n: 'i18n.actions.second' }, handler: () => doSomethingElse() }
 *   ]
 * };
 * ```
 *
 * ```html
 * <!-- Primary style (used as a custom action within a QdPage) -->
 * <button [qdMenuButton]="menuConfig">Open Menu</button>
 *
 * <!-- Secondary style (used as an action within a QdSection) -->
 * <button qdButtonGhost [qdMenuButton]="menuConfig">Open Menu</button>
 * ```
 */
@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'button[qdMenuButton], a[qdMenuButton]',
  templateUrl: './menu-button.component.html',
  styleUrls: ['./menu-button.component.scss']
})
export class QdMenuButtonComponent implements OnInit {
  /**
   * @description The configuration for QdMenuButton
   */
  @Input('qdMenuButton') config?: QdMenuButtonConfig;

  @Input('data-test-id') dataTestId = '';

  isOpen = false;

  constructor(@Optional() @Host() public qdButtonGhost: QdButtonGhostDirective) {}

  ngOnInit(): void {
    if (!this.config) console.error('QD-UI | QdMenuButtonComponent - Please provide a valid config.');
  }

  hasUnhiddenActions(): boolean {
    return this.config?.actions?.some(action => !action.isHidden) ?? false;
  }
}
