export function hasAttribute(value: any): boolean {
  return value === '';
}
