import { Component, ElementRef, HostBinding, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { QdButtonColor } from '../model/button.types';

/**
 * The **QdIconButton** can only display icons, in contrast to the **QdButton**. <br />
 * It is possible to bind it to either a `button` tag or to an `a` tag.
 */
@Component({
  selector: 'button[qdIconButton], a[qdIconButton], button[qd-icon-button]',
  templateUrl: './icon-button.component.html',
  styleUrls: ['./icon-button.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: { class: 'qd-icon-button' }
})
export class QdIconButtonComponent implements OnInit {
  /**
   * Sets the color
   */
  @Input() color: QdButtonColor = 'primary';

  /**
   * A static test ID for integration tests can be set. <br />
   * The value for the HTML attribute [data-test-id]. No property binding here.
   */
  @Input('data-test-id') testId = 'icon-button';

  @HostBinding('class') get colorClassName(): string {
    return this.color;
  }

  @HostBinding('attr.data-test-id') get dataTestId(): string {
    return this.testId;
  }

  constructor(private readonly _elementRef: ElementRef) {}

  ngOnInit(): void {
    // TODO: Delete directive "qd-icon-button" in Version 15
    if (this._elementRef.nativeElement.attributes.hasOwnProperty('qd-icon-button')) {
      console.warn(
        'QD-UI | QdIconButtonComponent - The directive "qd-icon-button" is deprecated. Please use "qdIconButton" instead.'
      );
    }
  }
}
