// @ts-strict-ignore
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component } from '@angular/core';

import { QdMockIconModule } from '../../icon/__mocks__/mock-icon.module';
import { QdIconButtonComponent } from './icon-button.component';

@Component({
  selector: 'test-component',
  template: `
    <button qd-icon-button color="primary" data-test-id="my-test-button" class="my-test-button">
      <qd-icon icon="plusCircleSolid"></qd-icon>
    </button>
  `
})
class TestComponentDeprecatedNotation {}

@Component({
  selector: 'test-component',
  template: `
    <button qdIconButton color="primary" data-test-id="my-test-button" class="my-test-button">
      <qd-icon icon="plusCircleSolid"></qd-icon>
    </button>
  `
})
class TestComponentCurrentNotation {}

describe(QdIconButtonComponent.name, () => {
  let consoleWarn: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();

    TestBed.configureTestingModule({
      imports: [QdMockIconModule],
      declarations: [QdIconButtonComponent, TestComponentDeprecatedNotation, TestComponentCurrentNotation]
    }).compileComponents();
  });

  describe('Deprecated notation: ', () => {
    let fixture: ComponentFixture<TestComponentDeprecatedNotation>;

    test('matches snapshot', () => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});

      fixture = TestBed.createComponent(TestComponentDeprecatedNotation);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
      expect(consoleWarn).toHaveBeenNthCalledWith(
        1,
        'QD-UI | QdIconButtonComponent - The directive "qd-icon-button" is deprecated. Please use "qdIconButton" instead.'
      );
    });
  });

  describe('Current notation: ', () => {
    let fixture: ComponentFixture<TestComponentCurrentNotation>;

    test('matches snapshot', () => {
      consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});

      fixture = TestBed.createComponent(TestComponentCurrentNotation);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
      expect(consoleWarn).not.toHaveBeenCalled();
    });
  });
});
