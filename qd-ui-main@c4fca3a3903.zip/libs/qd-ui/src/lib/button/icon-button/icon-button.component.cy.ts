import { QdIconComponent } from '../../icon/icon/icon.component';
import { QdIconModule } from '../../icon/icon.module';
import { QdIconButtonComponent } from './icon-button.component';
import { QdButtonComponent } from '../button/button.component';
import { QdButtonModule } from '../button.module';

describe(QdIconButtonComponent.name, () => {
  beforeEach(() => {});

  it('renders', () => {
    cy.mount(
      `
        <button qdIconButton [color]="'primary'"> <qd-icon icon="eye"> </qd-icon></button>
        <button qdIconButton [color]="'secondary'"> <qd-icon icon="pencil"> </qd-icon></button>
        <button qdIconButton [color]="'error'"> <qd-icon icon="exclamationCircleSolid"> </qd-icon></button>
        <button qdIconButton [disabled]="true"> <qd-icon icon="eye"> </qd-icon></button>
      `,
      {
        declarations: [QdButtonComponent, QdIconButtonComponent, QdIconComponent],
        imports: [QdButtonModule, QdIconModule]
      }
    );

    cy.matchImage();
  });
});
