import { Component } from '@angular/core';

@Component({
  selector: 'qd-button-stack',
  template: '<ng-content></ng-content>'
})
export class QdMockButtonStackComponent {}
