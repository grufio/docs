import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QdMockButtonComponent } from './mock-button.component';
import { QdMockButtonGhostDirective, QdMockButtonLinkDirective } from './mock-button.directives';
import { QdMockButtonGridComponent } from './mock-button-grid.component';
import { QdMockButtonStackButtonComponent } from './mock-button-stack-button.component';
import { QdMockButtonStackComponent } from './mock-button-stack.component';
import { QdMockIconButtonComponent } from './mock-icon-button.component';

export {
  QdMockButtonComponent,
  QdMockButtonGhostDirective,
  QdMockButtonGridComponent,
  QdMockButtonLinkDirective,
  QdMockButtonStackButtonComponent,
  QdMockButtonStackComponent,
  QdMockIconButtonComponent
};

@NgModule({
  imports: [CommonModule],
  declarations: [
    QdMockButtonComponent,
    QdMockButtonGhostDirective,
    QdMockButtonGridComponent,
    QdMockButtonLinkDirective,
    QdMockButtonStackButtonComponent,
    QdMockButtonStackComponent,
    QdMockIconButtonComponent
  ],
  exports: [
    QdMockButtonComponent,
    QdMockButtonGhostDirective,
    QdMockButtonGridComponent,
    QdMockButtonLinkDirective,
    QdMockButtonStackButtonComponent,
    QdMockButtonStackComponent,
    QdMockIconButtonComponent
  ]
})
export class QdMockButtonModule {}
