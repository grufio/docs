import { Component, Input } from '@angular/core';
import { QdButtonColor } from '../model/button.types';

@Component({
  selector: 'button[qd-icon-button], button[qdIconButton]',
  template: 'color: {{color}} <ng-content></ng-content>'
})
export class QdMockIconButtonComponent {
  @Input() color: QdButtonColor = 'primary';
}
