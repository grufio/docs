import { Component } from '@angular/core';

@Component({
  selector: 'qd-button-grid',
  template: '<ng-content></ng-content>'
})
export class QdMockButtonGridComponent {}
