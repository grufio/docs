// @ts-strict-ignore
import { Component, Input } from '@angular/core';
import { QdButtonColor } from '../model/button.types';

@Component({
  selector: 'button[qdButton], a[qdButton], button[qd-button]',
  template:
    'disabled: {{disabled | json}}, color: {{color}}, icon: {{icon}}, testId: {{testId}} <ng-content></ng-content>',
  host: { '[attr.data-test-id]': 'testId' }
})
export class QdMockButtonComponent {
  @Input() disabled = false;
  @Input() color: QdButtonColor = 'primary';
  @Input() icon: string;
  @Input('data-test-id') testId = 'mocked';
}
