import { Component, Input } from '@angular/core';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'button[qd-button-stack], button[qdButtonStack]',
  template: 'completed: {{completed}}, disabled: {{disabled}} <ng-content></ng-content>'
})
export class QdMockButtonStackButtonComponent {
  @Input() completed = false;
  @Input() disabled = false;
}
