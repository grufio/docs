import { Directive } from '@angular/core';

@Directive({ selector: 'button[qd-button-link], button[qdButtonLink]' })
export class QdMockButtonLinkDirective {}

@Directive({ selector: ' button[qdButtonGhost]' })
export class QdMockButtonGhostDirective {}
