export type QdButtonColor = 'primary' | 'secondary' | 'error';
