/**
 * @description The configuration for QdMenuButton
 */
export interface QdMenuButtonConfig {
  /**
   * @description The actions in the button's menu
   */
  actions: QdMenuButtonActionConfig[];

  /**
   * @description Whether the QdMenuButton is disabled or not
   *
   * * @default false
   */
  isDisabled?: boolean;
}

/**
 * @description Configuration for a QdButtonAction
 */
export interface QdMenuButtonActionConfig {
  /**
   * @description The label is shown as text in the UI for this action.
   */
  label: QdMenuButtonActionLabel;

  /**
   * @description The handler to execute when the action is clicked.
   */
  handler: () => void;

  /**
   * @description Whether the QdButtonAction is disabled or not
   *
   * * @default false
   */
  isDisabled?: boolean;

  /**
   * @description Whether the QdButtonAction is hidden or not
   *
   * * @default false
   */
  isHidden?: boolean;
}

/**
 * Type for the label of a QdButtonAction.
 */
export interface QdMenuButtonActionLabel {
  /**
   * This i18n key is translated directly inside the QdMenuButton component.
   */
  i18n: string;
}

/**
 * Type for a small info icon box that can be attached to a button like a flap. When this flap is clicked the
 * info message will be displayed in a notification. Therefore you need to place the snackbar listener eventually.
 */
export interface QdButtonAdditionalInfo {
  /**
   * The info type determines the color and icon of the button info flap.
   */
  infoType: QdButtonAdditionalInfoType;

  /**
   * You can define a message that will be displayed in the notification that is opened when
   * the button info flap is clicked.
   */
  message: QdButtonAdditionalInfoMessage;
}

/**
 * The info type determines the color and icon of the button info flap.
 */
export type QdButtonAdditionalInfoType = 'warning' | 'info';

/**
 * Message that is displayed when the button info flap is clicked.
 * You can insert the defined additional info count in the translation text with the {{count}} placeholder.
 */
export interface QdButtonAdditionalInfoMessage {
  i18n: string;
}
