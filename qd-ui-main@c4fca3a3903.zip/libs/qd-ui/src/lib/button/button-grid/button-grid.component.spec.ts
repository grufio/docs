// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdButtonGridComponent } from './button-grid.component';

describe('QdButtonListComponent', () => {
  let component: QdButtonGridComponent;
  let fixture: ComponentFixture<QdButtonGridComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QdButtonGridComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdButtonGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('it should create', () => {
    expect(component).toBeTruthy();
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
