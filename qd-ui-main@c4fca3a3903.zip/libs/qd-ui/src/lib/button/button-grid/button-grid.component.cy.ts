import {
  QdButtonComponent,
  QdButtonGhostDirective,
  QdButtonGridComponent,
  QdButtonLinkDirective,
  QdButtonModule
} from '../button.module';

describe(QdButtonGridComponent.name, () => {
  beforeEach(() => {});

  it('renders', () => {
    cy.mount(
      `<qd-button-grid>
        <button qdButton qdButtonGhost [disabled]="false" [color]="'primary'">Button 1</button>
        <button qdButton qdButtonLink [disabled]="false" [color]="'secondary'">Button 2</button>
        <button qdButton [disabled]="false" [color]="'error'">Button 3</button>
        <button qdButton qdButtonGhost [disabled]="true" icon="exclamationCircle">Button 4</button>
      </qd-button-grid>`,
      {
        declarations: [QdButtonComponent, QdButtonGridComponent, QdButtonLinkDirective, QdButtonGhostDirective],
        imports: [QdButtonModule]
      }
    );

    cy.matchImage();
  });
});
