import { Component, ViewEncapsulation } from '@angular/core';

/**
 * The **QdButtonGrid** component provides a container that allows to arrange multiple buttons horizontally.
 *
 * * @see parent component **QdButton**.
 */
@Component({
  selector: 'qd-button-grid',
  templateUrl: './button-grid.component.html',
  styleUrls: ['./button-grid.component.scss'],
  encapsulation: ViewEncapsulation.None,
  host: { class: 'qd-button-grid' }
})
export class QdButtonGridComponent {}
