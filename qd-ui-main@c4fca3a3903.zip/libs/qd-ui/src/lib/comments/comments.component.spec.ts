import { ComponentFixture, TestBed } from '@angular/core/testing';
import { QdCommentsComponent } from './comments.component';
import { TranslateModule } from '@ngx-translate/core';
import { By } from '@angular/platform-browser';
import { QdDialogModule } from '../dialog/dialog.module';
import { QdButtonModule } from '../button/button.module';
import { QdIconModule } from '../icon/icon.module';
import { QdStriphtmlPipe } from './pipes/stripe-html.pipe';
import { QdPopoverModule } from '../core/popover/popover.module';
import { AddCommentDialogComponent } from './add-comment/add-comment-dialog.component';
import { QdFormModule } from '../forms/qd-form.module';
import { QdCoreModule } from '../core/core.module';
import { ReactiveFormsModule } from '@angular/forms';

describe(QdCommentsComponent.name, () => {
  let component: QdCommentsComponent;
  let fixture: ComponentFixture<QdCommentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        TranslateModule.forRoot(),
        QdDialogModule,
        QdButtonModule,
        QdIconModule,
        QdPopoverModule,
        QdFormModule,
        ReactiveFormsModule,
        QdCoreModule
      ],
      declarations: [QdCommentsComponent, QdStriphtmlPipe, AddCommentDialogComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(QdCommentsComponent);
    component = fixture.componentInstance;
    component.config = {
      addConfig: {
        addButton: {
          i18n: 'New'
        },
        confirmDialogHandler: () => {},
        authorField: {
          value: '',
          label: {
            i18n: ''
          }
        }
      }
    };
  });

  describe('hasComments', () => {
    test('emits false for hasComments$ when comments input has no comments', done => {
      component.comments = [];
      fixture.detectChanges();

      component.hasComments$.subscribe(hasComments => {
        expect(hasComments).toBe(false);
        done();
      });

      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('emits true for hasComments$ when comments input has one comment', done => {
      component.comments = [
        {
          author: 'Test',
          date: new Date(),
          comment: 'Single comment',
          custom: {
            listDisplayName: {
              i18n: 'CH004163'
            },
            dropdownDisplayName: {
              i18n: 'CH004163 - Dogana Sud - Mendrisio Confine TC'
            }
          }
        }
      ];
      fixture.detectChanges();

      component.hasComments$.subscribe(hasComments => {
        expect(hasComments).toBe(true);
        done();
      });

      // Fix date to avoid snapshot mismatch between pipeline and local execution
      const dateElement = fixture.nativeElement.querySelector('.comment-date');
      if (dateElement) dateElement.textContent = 'Fixed Date';
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('emits true for hasComments$ when comments input has multiple comments', done => {
      component.comments = [
        {
          author: 'Test1',
          date: new Date(),
          comment: 'First comment',
          custom: {
            listDisplayName: {
              i18n: 'CH004471'
            },
            dropdownDisplayName: {
              i18n: 'CH004471 - Dogana Sud - Dirinella'
            }
          }
        },
        {
          author: 'Test2',
          date: new Date(),
          comment: 'Second comment',
          custom: {
            listDisplayName: {
              i18n: 'CH005081'
            },
            dropdownDisplayName: {
              i18n: 'CH005081 - Zoll West - Gondo'
            }
          }
        }
      ];
      fixture.detectChanges();

      component.hasComments$.subscribe(hasComments => {
        expect(hasComments).toBe(true);
        done();
      });

      // Fix date to avoid snapshot mismatch between pipeline and local execution
      const dateElements = fixture.nativeElement.querySelectorAll('.comment-date');
      dateElements.forEach(element => {
        element.textContent = 'Fixed Date'; // Replace with your fixed value
      });
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('renders deleted comment meta data', done => {
      component.comments = [
        {
          author: 'Test1',
          date: new Date(),
          comment: 'First comment',
          custom: {
            listDisplayName: {
              i18n: 'CH005121'
            },
            dropdownDisplayName: {
              i18n: 'CH005121 - Douane Ouest - St. Gingolph'
            }
          },
          deletedMeta: {
            deletedBy: 'Example',
            date: new Date('10/10/2024'),
            custom: {
              listDisplayName: {
                i18n: 'CH004101'
              },
              dropdownDisplayName: {
                i18n: 'CH004101 - Dogana Sud - Ponte Tresa'
              }
            }
          }
        },
        {
          author: 'Test2',
          date: new Date(),
          comment: 'Second comment',
          custom: {
            listDisplayName: {
              i18n: 'CH005051'
            },
            dropdownDisplayName: {
              i18n: 'CH005051 - Zoll West - Gamsen'
            }
          }
        }
      ];
      fixture.detectChanges();

      const divElement = fixture.debugElement.query(By.css('.deleted-meta')).nativeElement;
      expect(divElement).toBeTruthy();
      done();

      // Fix date to avoid snapshot mismatch between pipeline and local execution
      const dateElements = fixture.nativeElement.querySelectorAll('.comment-date');
      dateElements.forEach(element => {
        element.textContent = 'Fixed Date'; // Replace with your fixed value
      });
      const deletedDateElement = fixture.nativeElement.querySelector('.deleted-meta');
      deletedDateElement.innerHTML = deletedDateElement.innerHTML.replace(
        /- \d{2}\.\d{2}\.\d{4}, \d{2}:\d{2}/,
        '- Fixed Date'
      );
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('primaryActionHandler', () => {
    test('clickComment calls primaryActionHandler if defined', () => {
      const comment = { author: 'Test', date: new Date(), comment: 'Single comment' };
      component.config.primaryActionHandler = jest.fn();
      component.clickComment(comment);

      expect(component.config.primaryActionHandler).toHaveBeenCalledWith(comment);
    });

    test('clickComment does not call primaryActionHandler if not defined', () => {
      const comment = { author: 'Test', date: new Date(), comment: 'Single comment' };
      component.config.primaryActionHandler = undefined;
      component.clickComment(comment);

      expect(component.config.primaryActionHandler).toBeUndefined();
    });
  });

  describe('menu button', () => {
    test('is rendered if there are secondary actions', () => {
      component.comments = [
        {
          author: 'Test',
          date: new Date(),
          comment: 'Single comment',
          custom: {
            listDisplayName: {
              i18n: 'CH005491'
            },
            dropdownDisplayName: {
              i18n: 'CH005491 - Douane Centre - Les Verrières'
            }
          }
        }
      ];
      component.config.secondaryActions = [{ i18n: 'edit', handler: () => {} }];
      fixture.detectChanges();

      // Fix date to avoid snapshot mismatch between pipeline and local execution
      const dateElement = fixture.nativeElement.querySelector('.comment-date');
      if (dateElement) dateElement.textContent = 'Fixed Date';
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('addButton', () => {
    test('addButton handler is called when button is clicked', () => {
      component.config.addConfig.addButton.handler = jest.fn();
      let button = fixture.debugElement.nativeElement.querySelector('button');
      button.click();

      expect(component.config.addConfig.addButton.handler).toHaveBeenCalled();
    });

    test('addButton handler is not called if add button is disabled', () => {
      component.config.addConfig.addButton.handler = jest.fn();
      component.config.addConfig.addButton.disabled = true;
      let button = fixture.debugElement.nativeElement.querySelector('button');
      fixture.detectChanges();
      button.click();

      expect(component.config.addConfig.addButton.handler).not.toHaveBeenCalled();
    });
  });
});
