import { QdComment, QdCommentsConfig } from './model/comments.interface';
import { QdCommentsComponent } from './comments.component';
import { MountConfig } from 'cypress/angular';
import { QdDialogModule } from '../dialog/dialog.module';
import { TranslateModule } from '@ngx-translate/core';
import { StoreModule } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { QdPageModule } from '../page/page.module';
import { QdCommentsModule } from './comments.module';

const NORMAL_TEXT = 'Lorem ipsum dolor sit amet';
const CUSTOMS_NDS_NUM_1 = 'CH001141';
const CUSTOMS_NDS_NAME_1 = 'Boncourt/Delle-Autoroute';
const CUSTOMS_NDS_NUM_2 = 'CH001712';
const CUSTOMS_NDS_NAME_2 = 'Zoll Nord - Basel Flughafen Kurier';
const CUSTOMS_NDS_NUM_3 = 'CH003121';
const CUSTOMS_NDS_NAME_3 = 'Zoll Ost - Kriessern';

export const comments: QdComment[] = [
  {
    author: 'Arnold Schwarzenegger',
    date: new Date(2023, 10, 10),
    custom: {
      listDisplayName: {
        i18n: 'CH001841'
      },
      dropdownDisplayName: {
        i18n: 'CH001841 - Zoll Nord - Basel/St.Louis Autobahn'
      }
    },
    comment:
      'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure'
  },
  {
    author: 'Sylvester Stallone',
    date: new Date(2023, 10, 10),
    custom: {
      listDisplayName: {
        i18n: 'CH006521'
      },
      dropdownDisplayName: {
        i18n: 'CH006521 - Douane Ouest - Genève Aéroport'
      }
    },
    comment: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor.',
    deletedMeta: {
      deletedBy: 'Manfred Steyer',
      date: new Date(2023, 10, 10),
      custom: {
        listDisplayName: {
          i18n: 'CH003301'
        },
        dropdownDisplayName: {
          i18n: 'CH003301 - Zoll Ost - Müstair'
        }
      }
    }
  },
  {
    author: 'Bruce Willis',
    date: new Date(2023, 10, 10),
    custom: {
      listDisplayName: {
        i18n: 'CH003011'
      },
      dropdownDisplayName: {
        i18n: 'CH003011 - Zoll Ost - St. Gallen'
      }
    },
    comment: '<b>Mein Title</b> <p>Abssatz weiter going</p>'
  }
];

export const commentsConfig: QdCommentsConfig = {
  addConfig: {
    addButton: {
      i18n: 'Neu',
      disabled: false
    },
    customField: {
      label: {
        i18n: ''
      },
      listDisplayName: {
        i18n: CUSTOMS_NDS_NUM_1
      },
      dropdownDisplayName: {
        i18n: CUSTOMS_NDS_NUM_1 + ' - ' + CUSTOMS_NDS_NAME_1
      },
      options: [
        {
          listDisplayName: {
            i18n: CUSTOMS_NDS_NUM_1
          },
          dropdownDisplayName: {
            i18n: CUSTOMS_NDS_NUM_1 + ' - ' + CUSTOMS_NDS_NAME_1
          }
        },
        {
          listDisplayName: {
            i18n: CUSTOMS_NDS_NUM_2
          },
          dropdownDisplayName: {
            i18n: CUSTOMS_NDS_NUM_2 + ' - ' + CUSTOMS_NDS_NAME_2
          }
        },
        {
          listDisplayName: {
            i18n: CUSTOMS_NDS_NUM_3
          },
          dropdownDisplayName: {
            i18n: CUSTOMS_NDS_NUM_3 + ' - ' + CUSTOMS_NDS_NAME_3
          }
        }
      ]
    },
    confirmDialogHandler: () => {},
    authorField: {
      label: {
        i18n: ''
      },
      value: ''
    },
    commentField: {
      minLength: 10,
      maxLength: 100
    }
  },
  numberOfDisplayedRows: 8,
  primaryActionHandler: () => {},
  secondaryActions: []
};

const mountConfig: MountConfig<any> = {
  imports: [
    QdDialogModule,
    TranslateModule.forRoot({}),
    StoreModule.forRoot({}),
    CommonModule,
    QdPageModule,
    QdCommentsModule
  ],
  componentProperties: {
    comments,
    config: commentsConfig
  }
};

export const template = `<qd-comments [comments]="comments" [config]="config"></qd-comments>`;

context(QdCommentsComponent.name, () => {
  describe('renders correctly with different configs', () => {
    it('with numberOfDisplayedRows 8', () => {
      cy.viewport('iphone-8');
      cy.mount(template, mountConfig);
      cy.matchImage();
    });

    it('with numberOfDisplayedRows 3', () => {
      cy.viewport('iphone-8');
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties,
          config: {
            ...commentsConfig,
            numberOfDisplayedRows: 3
          }
        }
      });
      cy.matchImage();
    });

    it('with add new disabled ', () => {
      cy.viewport('iphone-8');
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties,
          config: {
            ...commentsConfig,
            addConfig: {
              ...commentsConfig.addConfig,
              addButton: {
                ...commentsConfig.addConfig.addButton,
                disabled: true
              }
            }
          }
        }
      });
      cy.matchImage();
    });

    it('with secondary actions ', () => {
      cy.viewport('iphone-8');
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties,
          config: {
            ...commentsConfig,
            secondaryActions: [
              {
                i18n: 'edit',
                handler: () => {}
              },
              {
                i18n: 'delete',
                handler: () => {}
              }
            ]
          }
        }
      });
      cy.matchImage();
    });

    it('submit passes new item to submit callback', () => {
      cy.viewport('iphone-8');
      cy.mount(template, {
        ...mountConfig,
        componentProperties: {
          ...mountConfig.componentProperties,
          config: {
            ...commentsConfig,
            addConfig: {
              ...commentsConfig.addConfig,
              confirmDialogHandler: cy.stub().as('confirmDialogHandler')
            }
          }
        }
      });

      cy.contains('Neu').click();
      cy.get('[data-test-id="richtext-input"]').find('input, textarea, [contenteditable="true"]').type(NORMAL_TEXT);
      cy.get('[data-test-id="button-submit"]').click();

      cy.get('@confirmDialogHandler').should('have.been.calledOnce');

      cy.get('@confirmDialogHandler').should('have.been.calledWithMatch', {
        comment: '<p>' + NORMAL_TEXT + '</p>',
        author: '',
        custom: {
          listDisplayName: {
            i18n: CUSTOMS_NDS_NUM_1
          },
          dropdownDisplayName: {
            i18n: CUSTOMS_NDS_NUM_1 + ' - ' + CUSTOMS_NDS_NAME_1
          }
        }
      });
    });
  });
});
