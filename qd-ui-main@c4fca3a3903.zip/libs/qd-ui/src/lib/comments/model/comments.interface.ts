/**
 * @description Configuration model of QdComments.
 */
export interface QdCommentsConfig {
  /**
   * @description Defines the config for the adding comments.
   */
  addConfig: QdCommentsAddConfig;

  /**
   * @description Defines the number of displayed rows in the comment list.
   */
  numberOfDisplayedRows?: number;

  /**
   * @description Defines a handler that is triggered by clicking a comment
   */
  primaryActionHandler?: (comment: QdComment) => void;

  /**
   * @description Defines a list of actions that can be executed for each comment through a menu.
   *
   * * @example
   * This is how the two actions "edit" and "delete" are created.
   * ```ts
   * secondaryActions: [
   *    {
   *      i18n: 'i18n.qd.edit',
   *      handler: comment => doSomethingWith(comment)
   *    },
   *    {
   *      i18n: 'i18n.qd.delete',
   *      handler: comment => doSomethingWith(comment)
   *    }
   * ]
   * ```
   */
  secondaryActions?: QdCommentSecondaryActionConfig[];
}

/**
 * @description Configuration of adding comments.
 */
export interface QdCommentsAddConfig {
  /**
   * @description configuration of the add button.
   */
  addButton: QdCommentsAddButtonConfig;

  /**
   * @description Configuration of the author field.
   */
  authorField: QdCommentAuthorFieldConfig;

  /**
   * @description Configuration of the custom field.
   */
  customField?: QdCommentCustomFieldConfig;

  /**
   * @description Configuration of the comment rich text editor.
   */
  commentField?: QdCommentRichtextConfig;
  /**
   * @description Defines a handler that is triggered by confirming the dialog. Typically used to save a new comment.
   */
  confirmDialogHandler: (comment: QdComment) => void;
}

/**
 * @description Configuration of the add comment button.
 */
export interface QdCommentsAddButtonConfig {
  /**
   * @description Translation string of the button label
   */
  i18n: string;

  /**
   * @description Defines a handler that is triggered by clicking the button
   */
  handler?: () => void;

  /**
   * @description sets button to "disabled"
   * * @default: false
   */
  disabled?: boolean;
}

/**
 * @description External configuration of the secondary action
 */
export interface QdCommentSecondaryActionConfig {
  /**
   * @description Translation string of the action.
   */
  i18n: string;

  /**
   * @description Defines a handler that is triggered by selecting a menu item.
   */
  handler?: (comment: QdComment) => void;
}

/**
 * @description External configuration of the author field
 */
export interface QdCommentAuthorFieldConfig {
  /**
   * Label of the field.
   */
  label?: {
    /**
     * Translation key of the label.
     */
    i18n: string;
  };
  /**
   * Value of the field.
   */
  value: string;
}

/**
 * @description External configuration of the custom field
 */
export interface QdCommentCustomFieldConfig extends CustomField {
  /**
   * @description Label language asset code
   */
  label?: {
    i18n: string;
  };

  /**
   * @description Options for the dropdown
   */
  options: CustomField[];
}

/**
 * @description External configuration of the rich text (comment) field
 */
export interface QdCommentRichtextConfig {
  /**
   * Minimum length of text
   */
  minLength?: number;

  /**
   * Minimum length of text
   */
  maxLength?: number;
}

/**
 * @description Interface for one comment
 */
export interface QdComment {
  /**
   * @description The author of the comment
   */
  author: string;

  /**
   * @description The timestamp when the comment was made
   */
  date: Date;

  /**
   * @description The content of the comment
   */
  comment: string;

  /**
   * Data of the custom field.
   */
  custom?: CustomField;

  /**
   * @description Metadata about the deletion.
   * You can mark comments as deleted. These comments will be shown in deleted style with metadata of deletion.
   */
  deletedMeta?: QdCommentDeletedMeta;
}

export interface CustomField {
  /**
   * Value displayed in the list of comments
   */
  listDisplayName: { i18n: string };

  /**
   * Value displayed in the create comment dialog
   */
  dropdownDisplayName: { i18n: string };
}

export interface QdCommentDeletedMeta {
  /**
   * Name of the user, who deleted the comment
   */
  deletedBy: string;

  /**
   * Date of deletion.
   */
  date: Date;

  /**
   * Custom field for the deletion.
   */
  custom?: CustomField;
}
