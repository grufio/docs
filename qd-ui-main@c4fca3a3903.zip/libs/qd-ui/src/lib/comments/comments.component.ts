import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { QdComment, QdCommentsConfig } from './model/comments.interface';
import { TranslateService } from '@ngx-translate/core';
import { AddCommentDialogComponent } from './add-comment/add-comment-dialog.component';
import { QdDialogService } from '../dialog/services/dialog.service';
import { QdDialogSize } from '../dialog/dialog.module';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'qd-comments',
  styleUrls: ['./comments.component.scss'],
  templateUrl: './comments.component.html'
})
export class QdCommentsComponent {
  @Input({ required: true }) config!: QdCommentsConfig;

  @Input()
  set comments(value: QdComment[]) {
    this.commentList = value;
    this._hasComments$.next(value?.length > 0);
  }

  private _hasComments$ = new BehaviorSubject<boolean>(false);
  private readonly _locale: string;
  commentList: QdComment[] = [];

  get hasComments$(): Observable<boolean> {
    return this._hasComments$.asObservable();
  }

  constructor(private translateService: TranslateService, private dialogService: QdDialogService) {
    this._locale = this.translateService.currentLang;
  }

  formatDate(date: Date): string {
    return new Intl.DateTimeFormat(this._locale || 'de', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(date);
  }

  clickComment(comment: QdComment): void {
    if (this.config.primaryActionHandler !== undefined) {
      this.config.primaryActionHandler(comment);
    }
  }

  addNew(): void {
    if (this.config.addConfig.addButton.handler) {
      this.config.addConfig.addButton.handler();
    }

    this.dialogService.open(AddCommentDialogComponent, {
      data: this.config.addConfig,
      dialogSize: QdDialogSize.Small,
      title: { i18n: 'i18n.qd.comments.add.dialog.title' }
    });
  }
}
