import { ChangeDetectionStrategy, Component, Inject, Optional } from '@angular/core';
import { DialogRef } from '@angular/cdk/dialog';
import {
  QdFormDropdownConfiguration,
  QdFormInputConfiguration,
  QdRichtextConfig
} from '../../forms/model/forms.interface';
import { QdComment, QdCommentsAddConfig } from '../model/comments.interface';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';
import { QdFormControl, ValidatorFnWithProps } from '../../forms/reactive-forms/controls/form-control';
import { getPlainTextFromHtml } from '../../helpers/html-plaintext.helper';

@Component({
  selector: 'qd-comment-dialog',
  templateUrl: './add-comment-dialog.component.html',
  styleUrls: ['./add-comment-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddCommentDialogComponent {
  objectKeys = Object.keys;

  richtextConfig: QdRichtextConfig;

  addCommentsConfig: QdCommentsAddConfig;

  authorInputConfig?: QdFormInputConfiguration;
  customInputConfig?: QdFormDropdownConfiguration;

  qdAuthUsername?: string;

  form: FormGroup;

  constructor(
    private dialogRef: DialogRef<string>,
    @Optional() @Inject('QdAuthenticationService') private readonly authenticationService: any
  ) {
    this.addCommentsConfig = dialogRef.config?.data;

    this.richtextConfig = {
      label: { i18n: 'i18n.qd.comments.add.richtext.label' }
    };

    this.form = new FormGroup({
      comment: new QdFormControl('', [
        ...(this.addCommentsConfig?.commentField?.minLength != null
          ? [this.plainTextMinLength(this.addCommentsConfig?.commentField?.minLength)]
          : []),
        ...(this.addCommentsConfig?.commentField?.maxLength != null
          ? [this.plainTextMaxLength(this.addCommentsConfig?.commentField?.maxLength)]
          : []),
        this.plainTextRequired()
      ]),
      custom: new FormControl(this.findSelectedCustomOption(), [])
    });

    const isQdAuthUsed = !!this.authenticationService;
    if (isQdAuthUsed) {
      authenticationService.name$.pipe(takeUntilDestroyed()).subscribe((name: string) => {
        if (name) this.qdAuthUsername = name;
        this.createConfig();
      });
    } else {
      this.createConfig();
    }
  }

  private findSelectedCustomOption(): string {
    if (!this.addCommentsConfig.customField) return '';

    return (
      this.addCommentsConfig.customField.options.find(
        customValue =>
          this.addCommentsConfig.customField?.dropdownDisplayName.i18n === customValue.dropdownDisplayName.i18n
      )?.dropdownDisplayName.i18n ?? ''
    );
  }

  private createConfig(): void {
    if (!this.addCommentsConfig) return;
    this.authorInputConfig = {
      value: this.qdAuthUsername || this.addCommentsConfig?.authorField?.value,
      disabled: true,
      label: {
        i18n: this.addCommentsConfig?.authorField?.label?.i18n || 'i18n.qd.comments.add.author.label'
      }
    };

    if (this.addCommentsConfig.customField) {
      this.customInputConfig = {
        options: this.addCommentsConfig.customField.options.map(customValue => ({
          value: customValue.dropdownDisplayName.i18n,
          i18n: customValue.dropdownDisplayName.i18n,
          active: this.addCommentsConfig.customField?.dropdownDisplayName.i18n === customValue.dropdownDisplayName.i18n
        })),
        label: {
          i18n: this.addCommentsConfig.customField.label?.i18n || ''
        }
      };
    }
  }

  close(result?: any): void {
    if (result === 'Yes' && this.addCommentsConfig.confirmDialogHandler) {
      const comment: QdComment = {
        comment: this.form.get('comment')?.value,
        date: new Date(),
        author: this.qdAuthUsername || this.addCommentsConfig?.authorField?.value,
        custom:
          this.addCommentsConfig?.customField?.options.find(
            customValue => this.form.get('custom')?.value === customValue.dropdownDisplayName.i18n
          ) ?? this.addCommentsConfig?.customField
      };
      this.addCommentsConfig.confirmDialogHandler(comment);
    }
    this.dialogRef.close();
  }

  plainTextMinLength(min: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      if (control.value == null) return null;

      const sanitizedValue = getPlainTextFromHtml(control.value);
      return sanitizedValue.length >= min ? null : { minLength: 'i18n.qd.form.error.minLength' };
    };
  }

  plainTextMaxLength(max: number): ValidatorFnWithProps {
    const validator: ValidatorFnWithProps = (control: AbstractControl): ValidationErrors | null => {
      if (control.value == null) return null;

      const sanitizedValue = getPlainTextFromHtml(control.value);
      return sanitizedValue.length <= max ? null : { maxLength: 'i18n.qd.form.error.maxLength' };
    };

    validator.maxLength = max;

    return validator;
  }

  plainTextRequired(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const sanitizedValue = getPlainTextFromHtml(control.value);
      return sanitizedValue == null || sanitizedValue.length === 0 ? { required: 'i18n.qd.form.error.required' } : null;
    };
  }
}
