import { AddCommentDialogComponent } from './add-comment-dialog.component';
import { DialogRef } from '@angular/cdk/dialog';
import { QdComment } from '../model/comments.interface';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { QdMockTranslatePipe } from '../../core/__mocks__/mock-translate.pipe';
import { NO_ERRORS_SCHEMA } from '@angular/core';

const mockDialog = {
  close() {},
  config: {
    data: {
      authorField: { value: 'TestAuthor', label: { i18n: 'AuthorFieldLabelKey' } },
      customField: {
        listDisplayName: {
          i18n: 'CH001841'
        },
        dropdownDisplayName: {
          i18n: 'CH001841 - Zoll Nord - Basel/St.Louis Autobahn'
        },
        label: { i18n: 'CustomFieldLabelKey' },
        options: [
          {
            listDisplayName: {
              i18n: 'CH001712'
            },
            dropdownDisplayName: {
              i18n: 'CH001712 - Zoll Nord - Basel Flughafen Kurier'
            }
          },
          {
            listDisplayName: {
              i18n: 'CH002411'
            },
            dropdownDisplayName: {
              i18n: 'CH002411 - Zoll Nordost - Ramsen'
            }
          },
          {
            listDisplayName: {
              i18n: 'CH002754'
            },
            dropdownDisplayName: {
              i18n: 'CH002754 - Zoll Nordost - Zürich Kurier'
            }
          },
          {
            listDisplayName: {
              i18n: 'CH001841'
            },
            dropdownDisplayName: {
              i18n: 'CH001841 - Zoll Nord - Basel/St.Louis Autobahn'
            }
          }
        ]
      },
      confirmDialogHandler: jest.fn()
    }
  }
} as DialogRef<string>;

describe('AddCommentDialogComponent with Authentication Service', () => {
  let component: AddCommentDialogComponent;
  let fixture: ComponentFixture<AddCommentDialogComponent>;
  let mockDialogRef: DialogRef<string>;

  beforeEach(async () => {
    mockDialogRef = mockDialog;

    await TestBed.configureTestingModule({
      declarations: [AddCommentDialogComponent, QdMockTranslatePipe],
      providers: [
        { provide: DialogRef, useValue: mockDialogRef },
        {
          provide: 'QdAuthenticationService',
          useValue: {
            name$: of('AuthenticatedUser')
          }
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(AddCommentDialogComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should set qdAuthUsername when authentication service provides a name', () => {
    expect(component.qdAuthUsername).toBe('AuthenticatedUser');
    expect(component.authorInputConfig?.value).toBe('AuthenticatedUser');
    expect(component.authorInputConfig?.label.i18n).toBe('AuthorFieldLabelKey');
  });

  it('should create customInputConfig when customField is provided', () => {
    expect(component.customInputConfig?.options).toStrictEqual([
      {
        value: 'CH001712 - Zoll Nord - Basel Flughafen Kurier',
        i18n: 'CH001712 - Zoll Nord - Basel Flughafen Kurier',
        active: false
      },
      {
        value: 'CH002411 - Zoll Nordost - Ramsen',
        i18n: 'CH002411 - Zoll Nordost - Ramsen',
        active: false
      },
      {
        value: 'CH002754 - Zoll Nordost - Zürich Kurier',
        i18n: 'CH002754 - Zoll Nordost - Zürich Kurier',
        active: false
      },
      {
        value: 'CH001841 - Zoll Nord - Basel/St.Louis Autobahn',
        i18n: 'CH001841 - Zoll Nord - Basel/St.Louis Autobahn',
        active: true
      }
    ]);
    expect(component.customInputConfig?.label.i18n).toBe('CustomFieldLabelKey');
  });

  it('should cancel dialog without saving comment', () => {
    const spy = jest.spyOn(mockDialogRef, 'close');

    component.close();

    expect(spy).toHaveBeenCalled();
  });

  it('should close dialog and handle confirmation', () => {
    component.qdAuthUsername = 'Test User';
    const resultParameter: QdComment = {
      comment: 'Test Comment Input',
      date: new Date(),
      author: 'Test User'
    };

    component.addCommentsConfig = {
      confirmDialogHandler: () => {},
      addButton: {
        i18n: null
      },
      authorField: null
    };
    component.form.get('comment').setValue('Test Comment Input');

    const spyConfirmHandler = jest.spyOn(component.addCommentsConfig, 'confirmDialogHandler');
    const spyDialogRefClose = jest.spyOn(mockDialogRef, 'close');

    component.close('Yes');

    expect(spyConfirmHandler).toHaveBeenCalledWith(
      expect.objectContaining({
        comment: resultParameter.comment,
        author: resultParameter.author
      })
    );
    expect(spyDialogRefClose).toHaveBeenCalled();
  });
});

describe('AddCommentDialogComponent without Authentication Service', () => {
  let component: AddCommentDialogComponent;
  let fixture: ComponentFixture<AddCommentDialogComponent>;
  let mockDialogRef: DialogRef<string>;

  beforeEach(async () => {
    mockDialogRef = mockDialog;

    await TestBed.configureTestingModule({
      declarations: [AddCommentDialogComponent, QdMockTranslatePipe],
      providers: [{ provide: DialogRef, useValue: mockDialogRef }],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(AddCommentDialogComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should not set qdAuthUsername if no authentication service is provided', async () => {
    const fixtureWithoutAuth = TestBed.createComponent(AddCommentDialogComponent);
    const componentWithoutAuth = fixtureWithoutAuth.componentInstance;

    fixtureWithoutAuth.detectChanges();

    expect(componentWithoutAuth.qdAuthUsername).toBeUndefined();
    expect(componentWithoutAuth.authorInputConfig?.value).toBe('TestAuthor');
  });
});
