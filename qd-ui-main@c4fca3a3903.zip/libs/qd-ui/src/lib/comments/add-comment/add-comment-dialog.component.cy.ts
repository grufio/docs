import { QdCommentsConfig } from '../model/comments.interface';
import { MountConfig } from 'cypress/angular';
import { QdDialogModule } from '../../dialog/dialog.module';
import { TranslateModule } from '@ngx-translate/core';
import { StoreModule } from '@ngrx/store';
import { CommonModule } from '@angular/common';
import { QdPageModule } from '../../page/page.module';
import { QdCommentsModule } from '../comments.module';
import { AddCommentDialogComponent } from './add-comment-dialog.component';

const LONG_TEXT =
  'The quick, brown fox jumps over a lazy dog. DJs flock by when MTV ax quiz prog. Junk MTV quiz graced.';
const SHORT_TEXT = 'The quick';
const NORMAL_TEXT = 'This is a normal text.';

const NDS_NUM_1 = 'CH003041';
const NDS_NAME_1 = 'Zoll Ost - Altenrhein-Flughafen';
const NDS_NUM_2 = 'CH003301';
const NDS_NAME_2 = 'Zoll Ost - Müstair';
const NDS_NUM_3 = 'CH004011';
const NDS_NAME_3 = 'Dogana Sud - Vedeggio';
export const commentsConfig: QdCommentsConfig = {
  addConfig: {
    addButton: {
      i18n: 'Neu',
      disabled: false
    },
    customField: {
      label: {
        i18n: ''
      },
      listDisplayName: {
        i18n: NDS_NUM_1
      },
      dropdownDisplayName: {
        i18n: NDS_NUM_1 + ' - ' + NDS_NAME_1
      },
      options: [
        {
          listDisplayName: {
            i18n: NDS_NUM_1
          },
          dropdownDisplayName: {
            i18n: NDS_NUM_1 + ' - ' + NDS_NAME_1
          }
        },
        {
          listDisplayName: {
            i18n: NDS_NUM_2
          },
          dropdownDisplayName: {
            i18n: NDS_NUM_2 + ' - ' + NDS_NAME_2
          }
        },
        {
          listDisplayName: {
            i18n: NDS_NUM_3
          },
          dropdownDisplayName: {
            i18n: NDS_NUM_3 + ' - ' + NDS_NAME_3
          }
        }
      ]
    },
    confirmDialogHandler: () => {},
    authorField: {
      label: {
        i18n: ''
      },
      value: 'Author'
    },
    commentField: {
      minLength: 10,
      maxLength: 100
    }
  },
  numberOfDisplayedRows: 8,
  primaryActionHandler: () => {},
  secondaryActions: []
};

const mountConfig: MountConfig<any> = {
  imports: [
    QdDialogModule,
    TranslateModule.forRoot({}),
    StoreModule.forRoot({}),
    CommonModule,
    QdPageModule,
    QdCommentsModule
  ],
  componentProperties: {
    config: commentsConfig
  }
};

export const template = `<qd-comments [config]="config"></qd-comments
  >`;

context(AddCommentDialogComponent.name, () => {
  describe('renders correctly', () => {
    it('submit disabled by default', () => {
      cy.viewport('iphone-8');
      cy.mount(template, mountConfig);
      cy.contains('Neu').click();
      cy.get('[data-test-id="comment-validation-minLength"]').should('not.exist');
      cy.get('[data-test-id="comment-validation-maxLength"]').should('not.exist');
      cy.matchImage();
    });

    it('submit disabled with 101 characters long comment', () => {
      cy.viewport('iphone-8');
      cy.mount(template, mountConfig);
      cy.contains('Neu').click();
      cy.get('[data-test-id="richtext-input"]').find('input, textarea, [contenteditable="true"]').type(LONG_TEXT);
      cy.get('[data-test-id="comment-validation-minLength"]').should('not.exist');
      cy.get('[data-test-id="comment-validation-maxLength"]').should('exist');
      cy.matchImage();
    });

    it('submit disabled with 9 characters long comment', () => {
      cy.viewport('iphone-8');
      cy.mount(template, mountConfig);
      cy.contains('Neu').click();
      cy.get('[data-test-id="richtext-input"]').find('input, textarea, [contenteditable="true"]').type(SHORT_TEXT);
      cy.get('[data-test-id="comment-validation-minLength"]').should('exist');
      cy.get('[data-test-id="comment-validation-maxLength"]').should('not.exist');
      cy.matchImage();
    });

    it('submit enabled with valid comment', () => {
      cy.viewport('iphone-8');
      cy.mount(template, mountConfig);
      cy.contains('Neu').click();
      cy.get('[data-test-id="richtext-input"]').find('input, textarea, [contenteditable="true"]').type(NORMAL_TEXT);
      cy.get('[data-test-id="comment-validation-minLength"]').should('not.exist');
      cy.get('[data-test-id="comment-validation-maxLength"]').should('not.exist');
      cy.matchImage();
    });

    it('custom field can be edited', () => {
      cy.viewport('iphone-8');
      cy.mount(template, mountConfig);
      cy.contains('Neu').click();

      cy.get('[data-test-id="comment-custom"]').click();
      cy.get('.qd-dropdown__option-label').contains(`${NDS_NUM_2} - ${NDS_NAME_2}`).click();

      cy.get('[data-test-id="richtext-input"]').find('input, textarea, [contenteditable="true"]').type(NORMAL_TEXT);

      cy.get('[data-test-id="comment-validation-minLength"]').should('not.exist');
      cy.get('[data-test-id="comment-validation-maxLength"]').should('not.exist');
      cy.matchImage();
    });
  });
});
