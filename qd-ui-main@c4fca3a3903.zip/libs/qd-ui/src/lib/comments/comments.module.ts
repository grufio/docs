import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { QdCommentsComponent } from './comments.component';
import { QdStriphtmlPipe } from './pipes/stripe-html.pipe';
import { QdCommentMenuComponent } from './menu/comment-menu.component';
import { AddCommentDialogComponent } from './add-comment/add-comment-dialog.component';
import { QdPopoverModule } from '../core/popover/popover.module';
import { QdIconModule } from '../icon/icon.module';
import { QdButtonModule } from '../button/button.module';
import { QdDialogModule } from '../dialog/dialog.module';
import { QdFormModule } from '../forms/qd-form.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { QdCoreModule } from '../core/core.module';

export { QdCommentsComponent };
export * from './model/comments.interface';

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    QdPopoverModule,
    QdIconModule,
    QdButtonModule,
    QdFormModule,
    QdDialogModule,
    FormsModule,
    ReactiveFormsModule,
    QdCoreModule
  ],
  declarations: [QdCommentsComponent, QdCommentMenuComponent, AddCommentDialogComponent, QdStriphtmlPipe],
  exports: [QdCommentsComponent]
})
export class QdCommentsModule {}
