import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { QdComment, QdCommentSecondaryActionConfig } from '../model/comments.interface';

@Component({
  selector: 'qd-comment-menu',
  templateUrl: './comment-menu.component.html',
  styleUrls: ['./comment-menu.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdCommentMenuComponent {
  @Input() menuActions?: QdCommentSecondaryActionConfig[];
  @Input(/* TODO (Angular 16): { required: true } */) comment!: QdComment;
}
