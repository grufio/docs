import { QdCommentMenuComponent } from './comment-menu.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateModule } from '@ngx-translate/core';

describe(QdCommentMenuComponent.name, () => {
  let component: QdCommentMenuComponent;
  let fixture: ComponentFixture<QdCommentMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [QdCommentMenuComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(QdCommentMenuComponent);
    component = fixture.componentInstance;
    component.comment = { author: 'Test', date: new Date(), comment: 'A comment' };
    component.menuActions = [
      { i18n: 'edit', handler: jest.fn() },
      { i18n: 'delete', handler: jest.fn() }
    ];
    fixture.detectChanges();
  });

  test('renders button for each secondary action', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('action handler is called when selecting action', () => {
    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(component.menuActions[0].handler).toHaveBeenCalled();
  });
});
