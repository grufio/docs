import { QdStriphtmlPipe } from './stripe-html.pipe';

describe('StripHtmlPipe', () => {
  let pipe: QdStriphtmlPipe;

  beforeEach(() => {
    pipe = new QdStriphtmlPipe();
  });

  it('should create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should strip HTML tags from input', () => {
    const htmlString = '<p>This is a <strong>test</strong> string.</p>';
    const expectedResult = 'This is a test string.';

    const result = pipe.transform(htmlString);

    expect(result).toEqual(expectedResult);
  });

  it('should handle input with no HTML tags', () => {
    const inputString = 'This is a normal string without any HTML tags.';
    const expectedResult = 'This is a normal string without any HTML tags.';

    const result = pipe.transform(inputString);

    expect(result).toEqual(expectedResult);
  });

  it('should handle null input', () => {
    const result = pipe.transform(null);

    expect(result).toEqual('');
  });

  it('should handle empty input', () => {
    const result = pipe.transform('');

    expect(result).toEqual('');
  });
});
