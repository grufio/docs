import { Component } from '@angular/core';

/**
 * **QdContentGridColumn** is a structure component within a **QdContainer** in combination with **QdContentGrid** and **QdContentGridRow**. <br />
 * With this component it is possible to add any number of columns.
 *
 * * @see parent component: **QdContentGridRow**.
 */
@Component({
  selector: 'qd-content-grid-column',
  templateUrl: './content-grid-column.component.html',
  styleUrls: ['./content-grid-column.component.scss']
})
export class QdContentGridColumnComponent {}
