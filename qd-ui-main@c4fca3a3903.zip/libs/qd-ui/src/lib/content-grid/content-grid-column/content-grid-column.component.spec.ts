import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { projectContent } from '../../../../../../tools/testHelpers/content';

import { QdContentGridColumnComponent } from './content-grid-column.component';

describe('Testing QdContentGridColumnComponent |', () => {
  let component: QdContentGridColumnComponent;
  let fixture: ComponentFixture<QdContentGridColumnComponent>;
  let markup: string;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QdContentGridColumnComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdContentGridColumnComponent);
    component = fixture.componentInstance;
  });

  describe('When the component has been initialized,', () => {
    markup = '<div>Column Content</div>';

    test('it matches the snapshot.', () => {
      const componentRef = projectContent(QdContentGridColumnComponent, markup);
      fixture.detectChanges();

      expect(componentRef.location.nativeElement).toMatchSnapshot();
    });
  });
});
