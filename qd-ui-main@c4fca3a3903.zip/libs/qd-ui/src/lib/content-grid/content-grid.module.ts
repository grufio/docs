import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QdContentGridComponent } from './content-grid/content-grid.component';
import { QdContentGridRowComponent } from './content-grid-row/content-grid-row.component';
import { QdContentGridColumnComponent } from './content-grid-column/content-grid-column.component';

export { QdContentGridComponent, QdContentGridRowComponent, QdContentGridColumnComponent };

@NgModule({
  imports: [CommonModule],
  declarations: [QdContentGridComponent, QdContentGridRowComponent, QdContentGridColumnComponent],
  exports: [QdContentGridComponent, QdContentGridRowComponent, QdContentGridColumnComponent]
})
export class QdContentGridModule {}
