import { Component } from '@angular/core';

/**
 * **QdContentGridRow** is a structure component within a **QdContainer** in combination with **QdContentGrid**. <br />
 * With this component it is possible to add any number of columns.
 *
 * * @see parent component: **QdContentGrid**.
 * * @see child component: **QdContentGridRow**.
 */
@Component({
  selector: 'qd-content-grid-row',
  templateUrl: './content-grid-row.component.html',
  styleUrls: ['./content-grid-row.component.scss']
})
export class QdContentGridRowComponent {}
