import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { projectContent } from '../../../../../../tools/testHelpers/content';

import { QdContentGridRowComponent } from './content-grid-row.component';

describe('Testing QdContentGridRowComponent |', () => {
  let component: QdContentGridRowComponent;
  let fixture: ComponentFixture<QdContentGridRowComponent>;
  let markup: string;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QdContentGridRowComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdContentGridRowComponent);
    component = fixture.componentInstance;
  });

  describe('When the component has been initialized,', () => {
    markup = '<div>Content grid columns</div>';

    test('it matches the snapshot.', () => {
      const componentRef = projectContent(QdContentGridRowComponent, markup);
      fixture.detectChanges();

      expect(componentRef.location.nativeElement).toMatchSnapshot();
    });
  });
});
