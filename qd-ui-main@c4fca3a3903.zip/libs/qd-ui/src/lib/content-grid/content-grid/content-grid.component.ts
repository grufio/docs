import { Component, OnInit, Optional } from '@angular/core';
import { QdContainerLayoutService } from '../../container/services/container-layout.service';

/**
 * **QdContentGrid** is a structural component for use within a **QdContainer**. You can display content in the form of a grid.
 *
 * * @see child component: **QdContentGridRow**.
 */
@Component({
  selector: 'qd-content-grid',
  templateUrl: './content-grid.component.html',
  styleUrls: ['./content-grid.component.scss']
})
export class QdContentGridComponent implements OnInit {
  constructor(@Optional() private containerLayoutService: QdContainerLayoutService) {}

  ngOnInit(): void {
    if (this.containerLayoutService) {
      this.containerLayoutService.updateContent({
        'content-grid': true
      });
    }
  }
}
