import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { projectContent } from '../../../../../../tools/testHelpers/content';
import { QdContentGridComponent } from './content-grid.component';
import { QdMockContainerLayoutService } from '../../container/__mocks__/mock-container-layout.service';

describe('Testing QdContentGridComponent |', () => {
  let component: QdContentGridComponent;
  let fixture: ComponentFixture<QdContentGridComponent>;
  let markup: string;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QdContentGridComponent],
      providers: [QdMockContainerLayoutService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdContentGridComponent);
    component = fixture.componentInstance;
  });

  describe('When the component has been initialized,', () => {
    markup = '<div>Content grid items</div>';

    test('it matches the snapshot.', () => {
      const componentRef = projectContent(QdContentGridComponent, markup);
      fixture.detectChanges();

      expect(componentRef.location.nativeElement).toMatchSnapshot();
    });
  });
});
