import { NgModule } from '@angular/core';

import { QdMockContentGridComponent } from './mock-content-grid';
import { QdMockContentGridColumnComponent } from './mock-content-grid-column';
import { QdMockContentGridRowComponent } from './mock-content-grid-row';

export { QdMockContentGridComponent, QdMockContentGridColumnComponent, QdMockContentGridRowComponent };

@NgModule({
  declarations: [QdMockContentGridComponent, QdMockContentGridColumnComponent, QdMockContentGridRowComponent],
  exports: [QdMockContentGridComponent, QdMockContentGridColumnComponent, QdMockContentGridRowComponent]
})
export class QdMockContentGridModule {}
