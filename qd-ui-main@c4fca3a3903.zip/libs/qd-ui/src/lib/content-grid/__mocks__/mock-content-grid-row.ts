import { Component } from '@angular/core';

@Component({
  selector: 'qd-content-grid-row',
  template: '<ng-content></ng-content>'
})
export class QdMockContentGridRowComponent {}
