import { Component } from '@angular/core';

@Component({
  selector: 'qd-content-grid',
  template: '<ng-content></ng-content>'
})
export class QdMockContentGridComponent {}
