import { Component } from '@angular/core';

@Component({
  selector: 'qd-content-grid-column',
  template: '<ng-content></ng-content>'
})
export class QdMockContentGridColumnComponent {}
