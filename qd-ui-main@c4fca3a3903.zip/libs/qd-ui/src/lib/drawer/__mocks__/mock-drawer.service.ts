// @ts-strict-ignore
import { ApplicationRef, ComponentFactoryResolver, Injectable } from '@angular/core';
import { QdDrawerContainerDirective } from '../drawer-container/drawer-container.directive';

@Injectable()
export class QdMockDrawerService {
  private containers = {};

  constructor(private componentFactoryResolver: ComponentFactoryResolver, private appRef: ApplicationRef) {}

  registerContainer = jest.fn((containerId: string, container) => {
    this.containers[containerId] = container;
  });
  registerContainerElement = jest.fn(
    (containerId: string, containerElement: HTMLElement): QdDrawerContainerDirective => {
      const containerDirective = new QdDrawerContainerDirective(
        { nativeElement: containerElement },
        // @ts-ignore
        this,
        this.componentFactoryResolver,
        this.appRef
      );

      this.containers[containerId] = containerDirective;

      return containerDirective;
    }
  );
  isDrawerAttached = jest.fn(() => false);
  openDrawer = jest.fn();
  registerDrawer = jest.fn();
  registerDrawerInContainerElement = jest.fn();
  updateContainerMargins = jest.fn();
  changeContainerMarginsBy = jest.fn();
  resetContainerMargins = jest.fn();
  releaseContainerAlignment = jest.fn();
}
