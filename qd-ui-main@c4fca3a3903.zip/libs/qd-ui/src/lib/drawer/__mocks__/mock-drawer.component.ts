//@ts-nocheck
import { Component, HostBinding, Input } from '@angular/core';
import { DomPortalOutlet } from '@angular/cdk/portal';
import { QdDrawerConfig } from '../model/drawer.config.interface';
import { QdDrawerComponent } from '../drawer.component';
import { QdDrawerBackgroundFaderComponent } from '../drawer-background-fader/drawer-background-fader.component';
import { QdDrawerContainerDirective } from '../drawer-container/drawer-container.directive';

const DEFAULT_DRAWER_CONFIG: Partial<QdDrawerConfig> = { mode: 'over', alignment: 'left' };

@Component({
  selector: 'qd-drawer',
  template: ''
})
export class QdMockDrawerComponent {
  @Input() sliding: boolean;
  @Input() nestedRootDrawer: QdDrawerComponent;
  @Input() drawerBackgroundFader: QdDrawerBackgroundFaderComponent;
  @Input() portal: DomPortalOutlet;
  @Input() container: QdDrawerContainerDirective;
  @Input() set config(config: QdDrawerConfig) {
    this._config = { ...DEFAULT_DRAWER_CONFIG, ...config };
  }

  get config(): QdDrawerConfig {
    return this._config;
  }

  _config;

  @HostBinding('attr.class') get modeAndAlignmentClassName() {
    const { mode, alignment } = this.config;

    return `${mode} ${alignment}`;
  }

  closeDrawer = jest.fn();
  blink = jest.fn();
}
