//@ts-nocheck
import { ComponentPortal, DomPortalOutlet } from '@angular/cdk/portal';
import { AfterViewInit, ApplicationRef, ComponentFactoryResolver, Directive, ElementRef, Input } from '@angular/core';
import { QdDrawerBackgroundFaderComponent } from '../drawer-background-fader/drawer-background-fader.component';
import { QdDrawerComponent } from '../drawer.component';
import { QdDrawerConfig } from '../model/drawer.config.interface';
import { QdDrawerService } from '../services/drawer.service';

@Directive({
  selector: '[qdDrawerContainer]'
})
export class QdMockDrawerContainerDirective implements AfterViewInit {
  @Input() qdDrawerContainer: string;

  containerElement: HTMLElement;

  constructor(
    private hostRef: ElementRef<HTMLElement>,
    private drawerService: QdDrawerService,
    private componentFactoryResolver: ComponentFactoryResolver,
    private appRef: ApplicationRef
  ) {
    this.containerElement = hostRef.nativeElement;
  }

  ngAfterViewInit(): void {
    // @ts-ignore
    this.drawerService.registerContainer(this.qdDrawerContainer, this);
  }

  openDrawer(config: QdDrawerConfig, nestedRootDrawer: QdDrawerComponent): QdDrawerComponent {
    const drawerPortal = new DomPortalOutlet(this.hostRef.nativeElement, this.componentFactoryResolver, this.appRef);
    const drawerComponentRef = drawerPortal.attach(new ComponentPortal(QdDrawerComponent));
    const drawerComponent = drawerComponentRef.instance;
    drawerComponent.config = config;
    drawerComponent.sliding = true;
    drawerComponent.portal = drawerPortal;

    if (config.mode === 'nested') {
      drawerComponent.nestedRootDrawer = nestedRootDrawer ?? drawerComponent;
    }

    if (config.faded) {
      drawerComponent.drawerBackgroundFader = this.fadeDrawerBackground();
    }

    return drawerComponent;
  }

  private fadeDrawerBackground(): QdDrawerBackgroundFaderComponent {
    const faderPortal = new DomPortalOutlet(this.hostRef.nativeElement, this.componentFactoryResolver, this.appRef);
    const faderComponentRef = faderPortal.attach(new ComponentPortal(QdDrawerBackgroundFaderComponent));
    const faderComponent = faderComponentRef.instance;
    faderComponent.portal = faderPortal;

    return faderComponent;
  }

  updateMargins = jest.fn();
  resetMargins = jest.fn();
  changeMarginsBy = jest.fn();
  registerDrawer = jest.fn();
  release = jest.fn();
}
