//@ts-nocheck
import { Component, Input } from '@angular/core';
import { DomPortalOutlet } from '@angular/cdk/portal';

@Component({
  selector: 'qd-drawer-background-fader',
  template: ''
})
export class QdMockDrawerBackgroundFaderComponent {
  @Input() portal: DomPortalOutlet;

  destroy = jest.fn();
}
