// @ts-strict-ignore
import { Directive, Input } from '@angular/core';
import { QdDrawerConfig } from '../model/drawer.config.interface';

@Directive({
  selector: '[qdDrawerOnClick]'
})
export class QdMockDrawerOnClickDirective {
  @Input() qdDrawerOnClick: QdDrawerConfig;
}
