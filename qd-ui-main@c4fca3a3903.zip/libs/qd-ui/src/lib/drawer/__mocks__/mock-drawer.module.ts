import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QdMockDrawerComponent } from './mock-drawer.component';
import { QdMockDrawerBackgroundFaderComponent } from './mock-drawer-background-fader.component';
import { QdMockDrawerContainerDirective } from './mock-drawer-container.directive';
import { QdMockDrawerOnClickDirective } from './mock-drawer-on-click.directive';

export { QdMockDrawerOnClickDirective };

@NgModule({
  imports: [CommonModule],
  declarations: [
    QdMockDrawerOnClickDirective,
    QdMockDrawerComponent,
    QdMockDrawerBackgroundFaderComponent,
    QdMockDrawerContainerDirective
  ],
  exports: [QdMockDrawerOnClickDirective]
})
export class QdMockDrawerModule {}
