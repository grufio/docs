//@ts-nocheck
import { Injectable } from '@angular/core';

@Injectable()
export class QdMockScrollbarService {
  hideHorizontalScrollbarPermanentlyIfCurrentlyHidden = jest.fn();
  resetHorizontalScrollbar = jest.fn();
}
