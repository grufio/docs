// @ts-strict-ignore
import { DomPortalOutlet } from '@angular/cdk/portal';
import { AfterViewInit, Component, ElementRef, HostBinding, Input } from '@angular/core';

/**
 * The **QdDrawerBackgroundFader** provides a background for the **QdDrawer**.
 */
@Component({
  selector: 'qd-drawer-background-fader',
  template: '',
  styleUrls: ['./drawer-background-fader.component.scss']
})
export class QdDrawerBackgroundFaderComponent implements AfterViewInit {
  @Input() portal: DomPortalOutlet;

  faded = false;

  @HostBinding('class.faded') get isFaded(): boolean {
    return this.faded;
  }

  constructor(private element: ElementRef<HTMLElement>) {}

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.faded = true;
    }, 10);
  }

  destroy(): void {
    this.element.nativeElement.addEventListener(
      'transitionend',
      event => {
        event.stopPropagation();
        this.portal.detach();
      },
      { once: true }
    );

    this.faded = false;
  }
}
