// @ts-strict-ignore
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { QdDrawerBackgroundFaderComponent } from './drawer-background-fader.component';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';

@Component({
  template: '<qd-drawer-background-fader [portal]="portal"></qd-drawer-background-fader>'
})
class TestComponent {
  portal = {
    detach: jest.fn()
  };
}

describe(QdDrawerBackgroundFaderComponent.name, () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let fader;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TestComponent, QdDrawerBackgroundFaderComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    jest.useFakeTimers();
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    fader = fixture.debugElement.query(By.directive(QdDrawerBackgroundFaderComponent));
  });

  afterEach(jest.useRealTimers);

  test('faded class is not set', () => {
    expect(fader.nativeElement.className).toBe('');
  });

  describe('after short time', () => {
    beforeEach(() => {
      jest.advanceTimersByTime(10);
      fixture.detectChanges();
    });

    test('faded class is set', () => {
      expect(fader.nativeElement.className).toBe('faded');
    });

    describe('after destroy', () => {
      beforeEach(() => {
        fader.componentInstance.destroy();
        fixture.detectChanges();
      });

      test('faded class is removed again', () => {
        expect(fader.nativeElement.className).toBe('');
      });

      describe('after transition end', () => {
        beforeEach(() => {
          fader.nativeElement.dispatchEvent(new Event('transitionend'));
          fixture.detectChanges();
        });

        test('portal is detached', () => {
          expect(fixture.componentInstance.portal.detach).toHaveBeenCalled();
        });
      });
    });
  });
});
