// @ts-strict-ignore
import { Directive, HostListener, Input } from '@angular/core';
import { QdDrawerConfig } from '../model/drawer.config.interface';
import { QdDrawerService } from '../services/drawer.service';

/**
 * The **QdDrawerOnClick** directive is responsible for the click handling for opening the **QdDrawer**.
 */
@Directive({
  selector: '[qdDrawerOnClick]'
})
export class QdDrawerOnClickDirective {
  @Input() qdDrawerOnClick: QdDrawerConfig;

  constructor(private drawerService: QdDrawerService) {}

  @HostListener('click', ['$event'])
  show(event: any): void {
    event.stopPropagation();
    this.drawerService.openDrawer(this.qdDrawerOnClick);
  }
}
