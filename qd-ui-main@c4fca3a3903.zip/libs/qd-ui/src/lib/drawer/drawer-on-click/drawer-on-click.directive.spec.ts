// @ts-strict-ignore
import { Component, TemplateRef, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { QdDrawerService } from '../services/drawer.service';
import { QdMockDrawerService } from '../__mocks__/mock-drawer.service';
import { QdDrawerOnClickDirective } from './drawer-on-click.directive';

jest.mock('../services/drawer.service', () => ({ QdDrawerService: class {} }));

@Component({
  selector: 'test-component',
  template: `
    <button [qdDrawerOnClick]="{ template: drawerTemplate, mode: 'compress', alignment: 'right' }"></button>
    <ng-template #drawerTemplate> Test Template </ng-template>
  `
})
class TestComponent {
  @ViewChild(QdDrawerOnClickDirective) directive;
  @ViewChild('drawerTemplate') drawerTemplate: TemplateRef<any>;
}

describe(QdDrawerOnClickDirective.name, () => {
  let fixture: ComponentFixture<TestComponent>;
  let drawerService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, QdDrawerOnClickDirective],
      providers: [
        {
          provide: QdDrawerService,
          useClass: QdMockDrawerService
        }
      ]
    });

    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(TestComponent);
      fixture.detectChanges();
    });

    drawerService = TestBed.inject(QdDrawerService);
  });

  test('drawer is opened on click with the given config', () => {
    fixture.debugElement.query(By.css('button')).nativeElement.click();

    expect(drawerService.openDrawer).toHaveBeenCalledWith({
      template: fixture.componentInstance.drawerTemplate,
      mode: 'compress',
      alignment: 'right'
    });
  });
});
