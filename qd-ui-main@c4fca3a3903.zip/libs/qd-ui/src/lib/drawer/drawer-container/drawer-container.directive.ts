// @ts-strict-ignore
import { ComponentPortal, DomPortalOutlet } from '@angular/cdk/portal';
import {
  AfterViewInit,
  ApplicationRef,
  ComponentFactoryResolver,
  Directive,
  ElementRef,
  HostBinding,
  Input
} from '@angular/core';
import { QdDrawerBackgroundFaderComponent } from '../drawer-background-fader/drawer-background-fader.component';
import { QdDrawerComponent } from '../drawer.component';
import { QdDrawerAlignment, QdDrawerConfig } from '../model/drawer.config.interface';
import { QdDrawerService } from '../services/drawer.service';

/**
 * **QdDrawerContainer** - Directive for the display of content used by **QdDrawer**.
 */
@Directive({
  selector: '[qdDrawerContainer]'
})
export class QdDrawerContainerDirective implements AfterViewInit {
  @Input() qdDrawerContainer: string;

  @HostBinding('style.position') private position = 'relative';
  @HostBinding('style.marginLeft') private marginLeft = '0px';
  @HostBinding('style.marginRight') private marginRight = '0px';

  private drawers: { [alignment: string]: QdDrawerComponent } = {};

  containerElement: HTMLElement;

  constructor(
    hostRef: ElementRef<HTMLElement>,
    private drawerService: QdDrawerService,
    private componentFactoryResolver: ComponentFactoryResolver,
    private appRef: ApplicationRef
  ) {
    this.containerElement = hostRef.nativeElement;
  }

  ngAfterViewInit(): void {
    if (!this.qdDrawerContainer) {
      throw new Error(
        'Quadrel UI | QdDrawer - The container id has to be provided for the [qdDrawerContainer] directive!'
      );
    }

    this.drawerService.registerContainer(this.qdDrawerContainer, this);
  }

  openDrawer(config: QdDrawerConfig, nestedRootDrawer: QdDrawerComponent = null): QdDrawerComponent {
    if (this.drawers[config.alignment]) {
      throw new Error(
        `Quadrel UI | QdDrawer - Cannot open drawer in alignment ${config.alignment} because another drawer is open!`
      );
    }

    const drawerPortal = new DomPortalOutlet(this.containerElement, this.componentFactoryResolver, this.appRef);
    const drawerComponentRef = drawerPortal.attach(new ComponentPortal(QdDrawerComponent));
    const drawerComponent = drawerComponentRef.instance;

    drawerComponent.config = config;
    drawerComponent.sliding = true;
    drawerComponent.portal = drawerPortal;

    if (config.mode === 'nested') {
      drawerComponent.nestedRootDrawer = nestedRootDrawer ?? drawerComponent;
    }

    if (config.faded) {
      drawerComponent.drawerBackgroundFader = this.fadeDrawerBackground();
    }

    drawerComponentRef.changeDetectorRef.detectChanges();

    return drawerComponent;
  }

  private fadeDrawerBackground(): QdDrawerBackgroundFaderComponent {
    const faderPortal = new DomPortalOutlet(this.containerElement, this.componentFactoryResolver, this.appRef);
    const faderComponentRef = faderPortal.attach(new ComponentPortal(QdDrawerBackgroundFaderComponent));
    const faderComponent = faderComponentRef.instance;
    faderComponent.portal = faderPortal;

    return faderComponent;
  }

  registerDrawer(drawerComponent: QdDrawerComponent): void {
    const { alignment } = drawerComponent.config;

    if (this.drawers[alignment]) {
      throw new Error(
        'Quadrel UI | QdDrawer - Cannot register drawer in container because there is already another one!'
      );
    }

    this.drawers[alignment] = drawerComponent;
  }

  getDrawerIfAttached(alignment: QdDrawerAlignment): QdDrawerComponent | undefined {
    return this.drawers[alignment];
  }

  release(alignment: QdDrawerAlignment): void {
    delete this.drawers[alignment];
  }

  updateMargins(drawerWidth: number, config: QdDrawerConfig): void {
    if (config.mode === 'over') return;

    switch (config.alignment) {
      case 'right':
        this.containerElement.style.marginRight = drawerWidth + 'px';

        if (config.mode === 'push') {
          this.containerElement.style.marginLeft = -drawerWidth + 'px';
        }
        break;
      case 'left':
      default:
        this.containerElement.style.marginLeft = drawerWidth + 'px';

        if (config.mode === 'push') {
          this.containerElement.style.marginRight = -drawerWidth + 'px';
        }
    }
  }

  changeMarginsBy(width: number, config: QdDrawerConfig, done: () => void = (): void => {}): void {
    if (config.mode === 'over') return done();

    this.containerElement.addEventListener('transitionend', done, { once: true });

    switch (config.alignment) {
      case 'right':
        this.containerElement.style.marginRight =
          parseInt(this.containerElement.style.marginRight || '0') + width + 'px';

        if (config.mode === 'push') {
          this.containerElement.style.marginLeft =
            parseInt(this.containerElement.style.marginLeft || '0') - width + 'px';
        }
        break;
      case 'left':
      default:
        this.containerElement.style.marginLeft = parseInt(this.containerElement.style.marginLeft || '0') + width + 'px';

        if (config.mode === 'push') {
          this.containerElement.style.marginRight =
            parseInt(this.containerElement.style.marginRight || '0') - width + 'px';
        }
    }
  }

  resetMargins(config: QdDrawerConfig): void {
    if (config.mode === 'over') return;

    if (config.alignment === 'left') {
      this.containerElement.style.marginLeft = '0px';

      if (config.mode === 'push') this.containerElement.style.marginRight = '0px';
    } else {
      this.containerElement.style.marginRight = '0px';

      if (config.mode === 'push') this.containerElement.style.marginLeft = '0px';
    }
  }
}
