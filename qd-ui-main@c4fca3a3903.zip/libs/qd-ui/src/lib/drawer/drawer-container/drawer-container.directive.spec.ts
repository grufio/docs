// @ts-strict-ignore
import { DomPortalOutlet } from '@angular/cdk/portal';
import { Component, TemplateRef, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { QdMockDrawerService } from '../__mocks__/mock-drawer.service';
import { QdDrawerBackgroundFaderComponent } from '../drawer-background-fader/drawer-background-fader.component';
import { QdDrawerComponent } from '../drawer.component';
import { QdDrawerConfig } from '../model/drawer.config.interface';
import { QdDrawerService } from '../services/drawer.service';
import { QdDrawerContainerDirective } from './drawer-container.directive';

jest.mock('../services/drawer.service', () => ({
  QdDrawerService: class {}
}));

jest.mock('../drawer.component', () => ({
  QdDrawerComponent: require('../__mocks__/mock-drawer.component').QdMockDrawerComponent
}));

jest.mock('../drawer-background-fader/drawer-background-fader.component', () => ({
  QdDrawerBackgroundFaderComponent: require('../__mocks__/mock-drawer-background-fader.component')
    .QdMockDrawerBackgroundFaderComponent
}));

@Component({
  selector: 'test-component',
  template: `
    <div qdDrawerContainer="drawer-container"></div>
    <ng-template #testDrawerTemplate> Test </ng-template>
  `
})
class TestComponent {
  @ViewChild(QdDrawerContainerDirective) directive: QdDrawerContainerDirective;
  @ViewChild('testDrawerTemplate') testDrawerTemplate: TemplateRef<any>;
}

@Component({
  selector: 'test-component',
  template: ` <div qdDrawerContainer></div> `
})
class TestErrorComponent {}

describe(QdDrawerContainerDirective.name, () => {
  let fixture: ComponentFixture<TestComponent>;
  let containerDirective: QdDrawerContainerDirective;
  let testDrawerTemplate: TemplateRef<any>;
  let drawerService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TestComponent, TestErrorComponent, QdDrawerContainerDirective],
      providers: [
        {
          provide: QdDrawerService,
          useClass: QdMockDrawerService
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(TestComponent);
    fixture.detectChanges();

    containerDirective = fixture.componentRef.instance.directive;
    testDrawerTemplate = fixture.componentRef.instance.testDrawerTemplate;
    drawerService = TestBed.inject(QdDrawerService);
  });

  function getTestDrawerComponent(config: Partial<QdDrawerConfig> = {}): QdDrawerComponent {
    const drawerComponent = new QdDrawerComponent(null, null, null, null);
    // @ts-ignore
    drawerComponent.config = config;

    return drawerComponent;
  }

  function resetContainerDirectiveMargins(): void {
    containerDirective.containerElement.style.marginLeft = '0px';
    containerDirective.containerElement.style.marginLeft = '0px';
  }

  test('the container directive is registered in the drawer service correctly', () => {
    expect(drawerService.registerContainer).toHaveBeenCalledWith('drawer-container', containerDirective);
  });

  test('the correct styles are applied to the element', () => {
    expect(fixture.debugElement).toMatchSnapshot();
  });

  test('the container can open a drawer', () => {
    const drawerComponent = containerDirective.openDrawer({ template: testDrawerTemplate, alignment: 'left' });

    expect(fixture.debugElement).toMatchSnapshot();
    expect(drawerComponent).toBe(fixture.debugElement.query(By.directive(QdDrawerComponent)).componentInstance);
    expect(drawerComponent.config.mode).toBe('over');
    expect(drawerComponent.config.alignment).toBe('left');
    expect(drawerComponent.config.template).toBe(testDrawerTemplate);
    expect(Object.keys(drawerComponent.config)).toEqual(['mode', 'alignment', 'template']);
    expect(drawerComponent.sliding).toBe(true);
    expect(drawerComponent.portal).toBeInstanceOf(DomPortalOutlet);
  });

  test('the drawer can be detached', () => {
    const drawerComponent = containerDirective.openDrawer({ template: testDrawerTemplate, alignment: 'left' });

    drawerComponent.portal.detach();

    expect(fixture.debugElement).toMatchSnapshot();
  });

  test('in nested mode this drawer is set as nestedRootDrawer if no drawer is given', () => {
    const drawerComponent = containerDirective.openDrawer({ template: testDrawerTemplate, mode: 'nested' });

    expect(drawerComponent.nestedRootDrawer).toBe(drawerComponent);
  });

  test('in nested mode the given drawer is set as nestedRootDrawer if one is given', () => {
    const testDrawerComponent = getTestDrawerComponent();

    const drawerComponent = containerDirective.openDrawer(
      { template: testDrawerTemplate, mode: 'nested' },
      testDrawerComponent
    );

    expect(drawerComponent.nestedRootDrawer).toBe(testDrawerComponent);
  });

  test('if faded is enabled, a fader is rendered', () => {
    containerDirective.openDrawer({ template: testDrawerTemplate, faded: true });
    const faderComponent = fixture.debugElement.query(By.directive(QdDrawerBackgroundFaderComponent)).componentInstance;

    expect(fixture.debugElement).toMatchSnapshot();
    expect(faderComponent.portal).toBeInstanceOf(DomPortalOutlet);
  });

  test('the fader can be detached', () => {
    containerDirective.openDrawer({ template: testDrawerTemplate, faded: true });
    const faderComponent = fixture.debugElement.query(By.directive(QdDrawerBackgroundFaderComponent)).componentInstance;

    faderComponent.portal.detach();

    expect(fixture.debugElement).toMatchSnapshot();
  });

  test('a drawer can be registered for this container', () => {
    const drawerComponent = getTestDrawerComponent({ alignment: 'right' });

    containerDirective.registerDrawer(drawerComponent);

    expect(containerDirective.getDrawerIfAttached('right')).toBe(drawerComponent);
  });

  test('a container alignment can be released', () => {
    containerDirective.openDrawer({ template: testDrawerTemplate, alignment: 'right' });
    containerDirective.release('right');

    expect(containerDirective.getDrawerIfAttached('right')).toBeUndefined();
  });

  test('a drawer cannot be registered if there is already another one in the container', () => {
    containerDirective.registerDrawer(getTestDrawerComponent({ alignment: 'right' }));

    expect(() => {
      containerDirective.registerDrawer(getTestDrawerComponent({ alignment: 'right' }));
    }).toThrow(
      new Error('Quadrel UI | QdDrawer - Cannot register drawer in container because there is already another one!')
    );
  });

  test('an error is thrown if there is another drawer is this position', () => {
    containerDirective.registerDrawer(getTestDrawerComponent({ alignment: 'right' }));

    expect(() => {
      containerDirective.openDrawer({ template: testDrawerTemplate, alignment: 'right' });
    }).toThrow(
      new Error('Quadrel UI | QdDrawer - Cannot open drawer in alignment right because another drawer is open!')
    );
  });

  describe('the margins are updated correctly for the different modes', () => {
    const config = { template: testDrawerTemplate };

    beforeEach(resetContainerDirectiveMargins);

    test('mode: "over"', () => {
      containerDirective.updateMargins(100, { ...config, mode: 'over' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('0px');
    });

    test('mode: "compress", alignment: "left"', () => {
      containerDirective.updateMargins(100, { ...config, mode: 'compress', alignment: 'left' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('100px');
      expect(containerDirective.containerElement.style.marginRight).toBe('0px');
    });

    test('mode: "compress", alignment: "right"', () => {
      containerDirective.updateMargins(100, { ...config, mode: 'compress', alignment: 'right' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('100px');
    });

    test('mode: "push", alignment: "left"', () => {
      containerDirective.updateMargins(100, { ...config, mode: 'push', alignment: 'left' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('100px');
      expect(containerDirective.containerElement.style.marginRight).toBe('-100px');
    });

    test('mode: "push", alignment: "right"', () => {
      containerDirective.updateMargins(100, { ...config, mode: 'push', alignment: 'right' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('-100px');
      expect(containerDirective.containerElement.style.marginRight).toBe('100px');
    });
  });

  describe('the margins are changed correctly for the different modes', () => {
    const config = { template: testDrawerTemplate };

    beforeEach(resetContainerDirectiveMargins);

    test('mode: "over"', () => {
      const done = jest.fn();
      containerDirective.changeMarginsBy(100, { ...config, mode: 'over' }, done);
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('0px');
      expect(done).toHaveBeenCalled();

      containerDirective.containerElement.style.marginLeft = '99px';
      containerDirective.containerElement.style.marginRight = '99px';
      containerDirective.changeMarginsBy(100, { ...config, mode: 'over' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('99px');
      expect(containerDirective.containerElement.style.marginRight).toBe('99px');
    });

    test('mode: "compress", alignment: "left"', () => {
      const done = jest.fn();
      containerDirective.containerElement.style.marginLeft = '300px';
      containerDirective.changeMarginsBy(-100, { ...config, mode: 'compress', alignment: 'left' }, done);
      expect(containerDirective.containerElement.style.marginLeft).toBe('200px');
      expect(containerDirective.containerElement.style.marginRight).toBe('0px');
      expect(done).not.toHaveBeenCalled();
      containerDirective.containerElement.dispatchEvent(new Event('transitionend'));
      expect(done).toHaveBeenCalled();
    });

    test('mode: "compress", alignment: "right"', () => {
      const done = jest.fn();
      containerDirective.containerElement.style.marginRight = '0px';
      containerDirective.changeMarginsBy(100, { ...config, mode: 'compress', alignment: 'right' }, done);
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('100px');
      expect(done).not.toHaveBeenCalled();
      containerDirective.containerElement.dispatchEvent(new Event('transitionend'));
      expect(done).toHaveBeenCalled();

      containerDirective.changeMarginsBy(100, { ...config, mode: 'compress', alignment: 'right' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('200px');
    });

    test('mode: "push", alignment: "left"', () => {
      const done = jest.fn();
      Object.defineProperty(containerDirective.containerElement.style, 'marginLeft', { value: '', writable: true });
      Object.defineProperty(containerDirective.containerElement.style, 'marginRight', { value: '', writable: true });
      containerDirective.changeMarginsBy(300, { ...config, mode: 'push', alignment: 'left' }, done);
      expect(containerDirective.containerElement.style.marginLeft).toBe('300px');
      expect(containerDirective.containerElement.style.marginRight).toBe('-300px');
      expect(done).not.toHaveBeenCalled();
      containerDirective.containerElement.dispatchEvent(new Event('transitionend'));
      expect(done).toHaveBeenCalled();

      containerDirective.changeMarginsBy(100, { ...config, mode: 'push', alignment: 'left' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('400px');
      expect(containerDirective.containerElement.style.marginRight).toBe('-400px');
    });

    test('mode: "push", alignment: "right"', () => {
      const done = jest.fn();
      Object.defineProperty(containerDirective.containerElement.style, 'marginLeft', { value: '', writable: true });
      Object.defineProperty(containerDirective.containerElement.style, 'marginRight', { value: '', writable: true });
      containerDirective.changeMarginsBy(-200, { ...config, mode: 'push', alignment: 'right' }, done);
      expect(containerDirective.containerElement.style.marginLeft).toBe('200px');
      expect(containerDirective.containerElement.style.marginRight).toBe('-200px');
      expect(done).not.toHaveBeenCalled();
      containerDirective.containerElement.dispatchEvent(new Event('transitionend'));
      expect(done).toHaveBeenCalled();

      containerDirective.changeMarginsBy(-100, { ...config, mode: 'push', alignment: 'right' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('300px');
      expect(containerDirective.containerElement.style.marginRight).toBe('-300px');
    });
  });

  describe('the margins are changed correctly for the different modes', () => {
    const config = { template: testDrawerTemplate };

    beforeEach(resetContainerDirectiveMargins);

    test('mode: "over"', () => {
      containerDirective.containerElement.style.marginLeft = '100px';
      containerDirective.containerElement.style.marginRight = '100px';
      containerDirective.resetMargins({ ...config, mode: 'over' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('100px');
      expect(containerDirective.containerElement.style.marginRight).toBe('100px');
    });

    test('mode: "compress", alignment: "left"', () => {
      containerDirective.containerElement.style.marginLeft = '100px';
      containerDirective.containerElement.style.marginRight = '100px';
      containerDirective.resetMargins({ ...config, mode: 'compress', alignment: 'left' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('100px');
    });

    test('mode: "compress", alignment: "right"', () => {
      containerDirective.containerElement.style.marginLeft = '100px';
      containerDirective.containerElement.style.marginRight = '100px';
      containerDirective.resetMargins({ ...config, mode: 'compress', alignment: 'right' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('100px');
      expect(containerDirective.containerElement.style.marginRight).toBe('0px');
    });

    test('mode: "push", alignment: "left"', () => {
      containerDirective.containerElement.style.marginLeft = '100px';
      containerDirective.containerElement.style.marginRight = '-100px';
      containerDirective.resetMargins({ ...config, mode: 'push', alignment: 'left' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('0px');
    });

    test('mode: "push", alignment: "right"', () => {
      containerDirective.containerElement.style.marginLeft = '-100px';
      containerDirective.containerElement.style.marginRight = '100px';
      containerDirective.resetMargins({ ...config, mode: 'push', alignment: 'right' });
      expect(containerDirective.containerElement.style.marginLeft).toBe('0px');
      expect(containerDirective.containerElement.style.marginRight).toBe('0px');
    });
  });

  describe('missing containerId', () => {
    let fixture: ComponentFixture<TestErrorComponent>;

    test('an error is thrown if no containerId is given for the directive', done => {
      TestBed.compileComponents().then(() => {
        expect(() => {
          fixture = TestBed.createComponent(TestErrorComponent);
          fixture.detectChanges();
        }).toThrow(
          new Error(
            'Quadrel UI | QdDrawer - The container id has to be provided for the [qdDrawerContainer] directive!'
          )
        );
        done();
      });
    });
  });
});
