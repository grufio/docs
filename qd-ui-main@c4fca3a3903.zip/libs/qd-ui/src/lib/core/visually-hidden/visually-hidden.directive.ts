import { Directive } from '@angular/core';

@Directive({
  selector: '[qdVisuallyHidden]',
  host: { class: 'qd-visually-hidden' }
})
export class QdVisuallyHiddenDirective {}
