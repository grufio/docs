// @ts-strict-ignore
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { Component } from '@angular/core';
import { QdVisuallyHiddenDirective } from './visually-hidden.directive';

@Component({
  template: ` <p qdVisuallyHidden>My Visually Hidden paragraph</p> `
})
class TestComponent {}

describe('Testing QdVisuallyHiddenDirective |', () => {
  describe('When an element received the directive,', () => {
    let component: TestComponent;
    let fixture: ComponentFixture<TestComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [QdVisuallyHiddenDirective, TestComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(TestComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('this element matches the snapshot with the correct class name.', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });
});
