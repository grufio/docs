// @ts-strict-ignore
import { QdDisabledDirective } from './disabled.directive';

describe('QdDisabledDirective', () => {
  test('it should create an instance', () => {
    const directive = new QdDisabledDirective();
    expect(directive).toBeTruthy();
  });
});
