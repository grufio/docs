import { Directive } from '@angular/core';

@Directive({
  selector: '[qdDisabled]',
  host: { class: 'qd-disabled' }
})
export class QdDisabledDirective {}
