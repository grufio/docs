import { TestBed } from '@angular/core/testing';
import { QdBreadcrumbsComponent } from './breadcrumbs.component';
import { MockComponent, MockPipe, MockProvider } from 'ng-mocks';
import { TranslatePipe } from '@ngx-translate/core';
import { QdBreadcrumbsService } from './services/breadcrumbs.service';
import { ReplaySubject } from 'rxjs';
import { QdIconComponent } from '../../icon/icon/icon.component';
import { Component, Directive, ElementRef, Input, OnInit } from '@angular/core';
import { QdPlaceholdersPipe } from '../pipes/placeholders.pipe';
import { QdDialogComponent, QdDialogService } from '../../dialog/dialog.module';
import { DialogRef } from '@angular/cdk/dialog';
import { QdDialogBreadcrumbsService } from './services/dialog-breadcrumbs.service';

@Directive({
  // eslint-disable-next-line @angular-eslint/directive-selector
  selector: 'a[routerLink]'
})
export class QdRouterLinkMockDirective implements OnInit {
  @Input() routerLink;

  constructor(private hostRef: ElementRef<HTMLElement>) {}

  ngOnInit(): void {
    this.hostRef.nativeElement.setAttribute('data-router-link', JSON.stringify(this.routerLink));
  }
}

@Component({
  template: '<qd-breadcrumbs></qd-breadcrumbs>'
})
class TestComponent {}

@Component({
  selector: 'qd-dialog',
  template: '<ng-content></ng-content>',
  providers: [QdDialogComponent]
})
class QdDialogComponentMock {}

@Component({
  template: `
    <qd-dialog>
      <qd-breadcrumbs></qd-breadcrumbs>
    </qd-dialog>
  `
})
class TestInsideDialogComponent {}

describe(`${QdBreadcrumbsComponent.name} |`, () => {
  let component;
  let fixture;
  let primaryBreadcrumbsService;
  let dialogBreadcrumbsService;

  const translations = {
    'i18n.breadcrumbs.page': 'Page',
    'i18n.breadcrumbs.sub-page': 'Sub Page',
    'i18n.breadcrumbs.sub-sub-page': 'Sub Sub Page ({{subSubPageId}})',
    'i18n.breadcrumbs.dialog-page': 'Dialog Page',
    'i18n.breadcrumbs.dialog-sub-page': 'Dialog Sub Page',
    'i18n.breadcrumbs.dialog-sub-sub-page': 'Dialog Sub Sub Page ({{subSubPageId}})'
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        TestInsideDialogComponent,
        QdBreadcrumbsComponent,
        QdDialogComponentMock,
        MockComponent(QdIconComponent),
        MockPipe(TranslatePipe, i18n => translations[i18n]),
        QdPlaceholdersPipe,
        QdRouterLinkMockDirective
      ],
      providers: [
        MockProvider(QdBreadcrumbsService, { breadcrumbs$: new ReplaySubject(1) }),
        MockProvider(QdDialogBreadcrumbsService, { breadcrumbs$: new ReplaySubject(1) }),
        MockProvider(DialogRef, { config: {} }),
        MockProvider(QdDialogService)
      ]
    }).compileComponents();

    primaryBreadcrumbsService = TestBed.inject(QdBreadcrumbsService);
    dialogBreadcrumbsService = TestBed.inject(QdDialogBreadcrumbsService);
  });

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  describe('default case', () => {
    beforeEach(() => {
      createComponent(TestComponent);
    });

    test('renders nothing if the breadcrumbs are not emitted', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('renders nothing if there are no breadcrumbs', () => {
      primaryBreadcrumbsService.breadcrumbs$.next([]);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('renders breadcrumbs correctly with multiple breadcrumbs', () => {
      primaryBreadcrumbsService.breadcrumbs$.next([
        {
          i18n: 'i18n.breadcrumbs.page',
          parameters: {},
          url: 'page'
        },
        {
          i18n: 'i18n.breadcrumbs.sub-page',
          parameters: {},
          url: 'page/sub-page'
        },
        {
          i18n: 'i18n.breadcrumbs.sub-sub-page',
          parameters: { subSubPageId: 'ABCDEFG' },
          url: 'page/sub-page/ABCDEFG'
        }
      ]);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('renders breadcrumbs correctly with single breadcrumb', () => {
      primaryBreadcrumbsService.breadcrumbs$.next([{ i18n: 'i18n.breadcrumbs.page', parameters: {}, url: 'page' }]);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('inside dialog', () => {
    beforeEach(() => {
      createComponent(TestInsideDialogComponent);
    });

    test('renders breadcrumbs correctly with multiple breadcrumbs', () => {
      dialogBreadcrumbsService.breadcrumbs$.next([
        {
          i18n: 'i18n.breadcrumbs.dialog-page',
          parameters: {},
          url: 'dialog-page'
        },
        {
          i18n: 'i18n.breadcrumbs.dialog-sub-page',
          parameters: {},
          url: 'dialog-page/dialog-sub-page'
        },
        {
          i18n: 'i18n.breadcrumbs.dialog-sub-sub-page',
          parameters: { subSubPageId: 'ABCDEFG' },
          url: 'dialog-page/dialog-sub-page/ABCDEFG'
        }
      ]);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });
});
