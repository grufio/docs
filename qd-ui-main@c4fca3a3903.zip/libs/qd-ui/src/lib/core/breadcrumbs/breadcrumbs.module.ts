import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

import { QdBreadcrumbsComponent } from './breadcrumbs.component';
import { QdPlaceholdersPipe } from '../pipes/placeholders.pipe';

@NgModule({
  imports: [CommonModule, RouterModule, TranslateModule],
  declarations: [QdBreadcrumbsComponent, QdPlaceholdersPipe],
  exports: [QdBreadcrumbsComponent]
})
export class QdBreadcrumbsModule {}
