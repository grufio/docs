import { TestBed } from '@angular/core/testing';
import { QdDialogBreadcrumbsService } from './dialog-breadcrumbs.service';
import { Router, RouterModule } from '@angular/router';
import { Component } from '@angular/core';
import { firstValueFrom } from 'rxjs';

@Component({ template: '' })
class BlankComponent {}

describe(`${QdDialogBreadcrumbsService.name} |`, () => {
  let service: QdDialogBreadcrumbsService;
  let router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdDialogBreadcrumbsService],
      imports: [
        RouterModule.forRoot([
          { path: '', component: BlankComponent },
          { path: 'page', component: BlankComponent },
          { path: 'page/sub-page', component: BlankComponent },
          { path: '', outlet: 'dialog', component: BlankComponent },
          {
            path: 'dialog-page',
            outlet: 'dialog',
            data: {
              breadcrumb: {
                i18n: 'i18n.breadcrumbs.dialog-page'
              }
            },
            children: [
              {
                path: '',
                component: BlankComponent
              },
              {
                path: 'dialog-sub-page',
                data: {
                  breadcrumb: {
                    i18n: 'i18n.breadcrumbs.dialog-sub-page'
                  }
                },
                children: [
                  {
                    path: '',
                    component: BlankComponent
                  },
                  {
                    path: ':dialogSubSubPageId',
                    data: {
                      breadcrumb: {
                        i18n: 'i18n.breadcrumbs.dialog-sub-sub-page'
                      }
                    },
                    children: [
                      {
                        path: '',
                        component: BlankComponent
                      }
                    ]
                  }
                ]
              }
            ]
          },
          {
            path: 'dialog-page-without-breadcrumb',
            outlet: 'dialog',
            component: BlankComponent
          }
        ])
      ]
    });
    service = TestBed.inject(QdDialogBreadcrumbsService);
    service.initialize();
    router = TestBed.inject(Router);
  });

  async function navigateByUrl(url: string): Promise<void> {
    router.navigateByUrl(url);
    await Promise.resolve();
  }

  async function navigateByUrlInDialogOutlet(url: string): Promise<void> {
    router.navigate([{ outlets: { dialog: url } }]);
    await Promise.resolve();
  }

  test('breadcrumbs are emitted correctly when navigating', async () => {
    await navigateByUrl('/page');
    await navigateByUrlInDialogOutlet('dialog-page');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      {
        i18n: 'i18n.breadcrumbs.dialog-page',
        url: 'dialog-page',
        parameters: {}
      }
    ]);

    await navigateByUrlInDialogOutlet('dialog-page/dialog-sub-page');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      {
        i18n: 'i18n.breadcrumbs.dialog-page',
        url: 'dialog-page',
        parameters: {}
      },
      {
        i18n: 'i18n.breadcrumbs.dialog-sub-page',
        url: 'dialog-page/dialog-sub-page',
        parameters: {}
      }
    ]);

    await navigateByUrlInDialogOutlet('dialog-page/dialog-sub-page/ABCDEFG');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      {
        i18n: 'i18n.breadcrumbs.dialog-page',
        url: 'dialog-page',
        parameters: {}
      },
      {
        i18n: 'i18n.breadcrumbs.dialog-sub-page',
        url: 'dialog-page/dialog-sub-page',
        parameters: {}
      },
      {
        i18n: 'i18n.breadcrumbs.dialog-sub-sub-page',
        url: 'dialog-page/dialog-sub-page/ABCDEFG',
        parameters: {
          dialogSubSubPageId: 'ABCDEFG'
        }
      }
    ]);
  });

  test('url is emitted correctly when navigating', async () => {
    await navigateByUrl('/page');
    await navigateByUrlInDialogOutlet('dialog-page');

    expect(await firstValueFrom(service.url$)).toBe('dialog-page');

    await navigateByUrlInDialogOutlet('dialog-page/dialog-sub-page');

    expect(await firstValueFrom(service.url$)).toBe('dialog-page/dialog-sub-page');

    await navigateByUrlInDialogOutlet('dialog-page/dialog-sub-page/ABCDEFG');

    expect(await firstValueFrom(service.url$)).toBe('dialog-page/dialog-sub-page/ABCDEFG');
  });

  test('empty url is emitted for root url', async () => {
    await navigateByUrl('/page');
    await navigateByUrlInDialogOutlet('/');

    expect(await firstValueFrom(service.url$)).toBe('');
  });

  test('no error occurs if breadcrumb is not defined for route', async () => {
    await navigateByUrl('/page');
    await navigateByUrlInDialogOutlet('dialog-page-without-breadcrumb');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      {
        i18n: '',
        url: 'dialog-page-without-breadcrumb',
        parameters: {}
      }
    ]);
  });
});
