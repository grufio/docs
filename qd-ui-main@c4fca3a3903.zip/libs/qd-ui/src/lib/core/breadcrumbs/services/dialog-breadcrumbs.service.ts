import { Injectable } from '@angular/core';
import { QdBreadcrumbsService } from './breadcrumbs.service';

@Injectable({
  providedIn: 'root'
})
export class QdDialogBreadcrumbsService extends QdBreadcrumbsService {
  override outlet = 'dialog';
}
