import { TestBed } from '@angular/core/testing';
import { QdBreadcrumbsService } from './breadcrumbs.service';
import { Router, RouterModule } from '@angular/router';
import { Component } from '@angular/core';
import { firstValueFrom } from 'rxjs';

@Component({ template: '' })
class BlankComponent {}

describe(`${QdBreadcrumbsService.name} |`, () => {
  let service: QdBreadcrumbsService;
  let router;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdBreadcrumbsService],
      imports: [
        RouterModule.forRoot([
          { path: '', component: BlankComponent },
          {
            path: 'page',
            data: {
              breadcrumb: {
                i18n: 'i18n.breadcrumbs.page'
              }
            },
            children: [
              {
                path: '',
                component: BlankComponent
              },
              {
                path: 'sub-page',
                data: {
                  breadcrumb: {
                    i18n: 'i18n.breadcrumbs.sub-page'
                  }
                },
                children: [
                  {
                    path: '',
                    component: BlankComponent
                  },
                  {
                    path: ':subSubPageId',
                    data: {
                      breadcrumb: {
                        i18n: 'i18n.breadcrumbs.sub-sub-page'
                      }
                    },
                    children: [
                      {
                        path: '',
                        component: BlankComponent
                      }
                    ]
                  }
                ]
              }
            ]
          },
          {
            path: 'page-without-breadcrumb',
            component: BlankComponent
          }
        ])
      ]
    });
    service = TestBed.inject(QdBreadcrumbsService);
    service.initialize();
    router = TestBed.inject(Router);
  });

  async function navigateByUrl(url: string): Promise<void> {
    router.navigateByUrl(url);
    await Promise.resolve();
  }

  test('breadcrumbs are emitted correctly when navigating', async () => {
    await navigateByUrl('/page');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      { i18n: 'i18n.breadcrumbs.page', url: 'page', parameters: {} }
    ]);

    await navigateByUrl('/page/sub-page');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      { i18n: 'i18n.breadcrumbs.page', url: 'page', parameters: {} },
      { i18n: 'i18n.breadcrumbs.sub-page', url: 'page/sub-page', parameters: {} }
    ]);

    await navigateByUrl('page/sub-page/ABCDEFG');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      { i18n: 'i18n.breadcrumbs.page', url: 'page', parameters: {} },
      { i18n: 'i18n.breadcrumbs.sub-page', url: 'page/sub-page', parameters: {} },
      { i18n: 'i18n.breadcrumbs.sub-sub-page', url: 'page/sub-page/ABCDEFG', parameters: { subSubPageId: 'ABCDEFG' } }
    ]);
  });

  test('url is emitted correctly when navigating', async () => {
    await navigateByUrl('/page');

    expect(await firstValueFrom(service.url$)).toBe('page');

    await navigateByUrl('/page/sub-page');

    expect(await firstValueFrom(service.url$)).toBe('page/sub-page');

    await navigateByUrl('page/sub-page/ABCDEFG');

    expect(await firstValueFrom(service.url$)).toBe('page/sub-page/ABCDEFG');
  });

  test('empty url is emitted for root url', async () => {
    await navigateByUrl('/');

    expect(await firstValueFrom(service.url$)).toBe('');
  });

  test('no error occurs if breadcrumb is not defined for route', async () => {
    await navigateByUrl('page-without-breadcrumb');

    expect(await firstValueFrom(service.breadcrumbs$)).toEqual([
      { i18n: '', url: 'page-without-breadcrumb', parameters: {} }
    ]);
  });
});
