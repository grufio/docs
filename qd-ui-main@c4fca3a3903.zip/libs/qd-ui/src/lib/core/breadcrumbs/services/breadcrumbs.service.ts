import { Injectable, OnDestroy } from '@angular/core';
import { ActivatedRouteSnapshot, ActivationEnd, Router } from '@angular/router';
import { filter, map } from 'rxjs/operators';
import { Observable, ReplaySubject, Subject } from 'rxjs';

import { QdBreadcrumbs } from '../model/breadcrumbs.interface';

@Injectable({
  providedIn: 'root'
})
export class QdBreadcrumbsService implements OnDestroy {
  private breadcrumbsSubject = new ReplaySubject<QdBreadcrumbs>(1);
  private destroyed$ = new Subject<void>();
  protected outlet = 'primary';

  breadcrumbs$ = this.breadcrumbsSubject.asObservable();
  url$ = this.breadcrumbsSubject.pipe(map(breadcrumbs => breadcrumbs[breadcrumbs.length - 1]?.url || ''));

  constructor(private readonly router: Router) {}

  initialize(): void {
    this.getOutletRouteSnapshot$()
      .pipe(map(snapshot => this.getSnapshotPathHierarchy(snapshot)))
      .subscribe(snapshotPathHierarchy => {
        let urlParts: string[] = [];

        this.breadcrumbsSubject.next(
          snapshotPathHierarchy.map(snapshot => {
            urlParts = [...urlParts, ...snapshot.url.map(url => url.path)];

            return {
              i18n: snapshot.data['breadcrumb']?.i18n || '',
              parameters: snapshot.params,
              url: urlParts.join('/')
            };
          })
        );
      });
  }

  ngOnDestroy(): void {
    this.destroyed$.next();
    this.destroyed$.complete();
  }

  private getOutletRouteSnapshot$(): Observable<ActivatedRouteSnapshot> {
    return this.router.events.pipe(
      filter(event => event instanceof ActivationEnd),
      map(event => (event as ActivationEnd).snapshot),
      filter(snapshot => snapshot.outlet === this.outlet)
    );
  }

  private getSnapshotPathHierarchy(rootSnapshot: ActivatedRouteSnapshot): ActivatedRouteSnapshot[] {
    const snapshots = [];
    let shapshot: ActivatedRouteSnapshot | null = rootSnapshot;

    while (shapshot) {
      if (shapshot.routeConfig?.path === '') {
        shapshot = shapshot.firstChild;
        continue;
      }

      snapshots.push(shapshot);
      shapshot = shapshot.firstChild;
    }

    return snapshots;
  }
}
