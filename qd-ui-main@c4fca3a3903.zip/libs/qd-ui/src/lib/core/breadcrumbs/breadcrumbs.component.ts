import { Component, Optional } from '@angular/core';
import { Observable } from 'rxjs';

import { QdBreadcrumbsService } from './services/breadcrumbs.service';
import { QdDialogBreadcrumbsService } from './services/dialog-breadcrumbs.service';
import { QdDialogComponent } from '../../dialog/dialog.component';
import { QdBreadcrumb, QdBreadcrumbs } from './model/breadcrumbs.interface';

/**
 * **Breadcrumbs for the QdPageDialog** display a user's location within a hierarchical navigation structure
 * inside dialog-based page flows. This follows Quadrel's navigation principles: the first two levels are
 * standard pages, and further levels use dialogs. Breadcrumbs are exclusively supported within the QdPageDialog.
 *
 * #### **Features**
 *
 * - **Dialog-Specific Support**: Integrates seamlessly with Quadrel's page-dialog structure.
 * - **Routing Configuration-Based**: Derives breadcrumbs directly from route definitions.
 * - **Back Navigation**: Dynamically generates links for returning to previous dialog levels.
 * - **Parameter Support**: Integrates route parameters into localized breadcrumb labels using placeholders.
 *
 * #### **Hierarchy Structure**
 *
 * Quadrel follows a clear and consistent navigation structure:
 * - **First Level**: Overview pages.
 * - **Second Level**: Create or Inspect pages.
 * - **Third Level and Beyond**: Managed in page dialogs.
 *
 * #### **Routing Configuration**
 *
 * Breadcrumbs are generated using the `data.breadcrumb` field in the route configuration. This field specifies
 * the localized label (`i18n`) for each breadcrumb.
 *
 * #### **"outlet" Property**
 *
 * Dialog-based routes must include the `outlet` property to specify their named outlet. This ensures the route is rendered in the QdPageDialog correctly.
 *
 * #### **Usage**
 *
 * ```json
 * // Multi Language Support & Params
 * {
 *   "i18n.breadcrumb.registration": "Registration {{refNumber}}"
 * }
 * ```
 *
 * ```typescript
 * // Route Configuration
 * {
 *   path: ':refNumber',
 *   outlet: 'dialog',
 *   data: {
 *     breadcrumb: { i18n: 'i18n.breadcrumb.registration' }
 *   },
 *   children: [...]
 * }
 * ```
 *
 * ```typescript
 * // Open Dialog with Route
 * constructor(private dialogService: QdDialogService) {}
 *
 * this.dialogService.openPageDialogWithBreadcrumbs('549861')
 * ```
 *
 * #### **Full Routes Configuration Example**
 *
 * ```typescript
 * const routes: Routes = [
 *   {
 *     path: '',
 *     component: AppFirstLevelComponent
 *   },
 *   {
 *     path: 'second',
 *     component: AppSecondLevelComponent,
 *     data: {
 *       breadcrumb: { i18n: 'Second Level' }
 *     }
 *   },
 *   {
 *     path: 'third',
 *     outlet: 'dialog',
 *     data: {
 *       breadcrumb: { i18n: 'Dialog (Third Level)' }
 *     },
 *     children: [
 *       {
 *         path: '',
 *         component: AppThirdLevelComponent
 *       },
 *       {
 *         path: 'fourth',
 *         data: {
 *           breadcrumb: { i18n: 'Dialog (Fourth Level)' }
 *         },
 *         children: [
 *           {
 *             path: '',
 *             component: AppFourthLevelComponent
 *           },
 *           {
 *             path: 'fifth',
 *             data: {
 *               breadcrumb: { i18n: 'Dialog (Fifth Level)' }
 *             },
 *             component: AppFifthLevelComponent
 *           }
 *         ]
 *       }
 *     ]
 *   }
 * ];
 * ```
 */
@Component({
  selector: 'qd-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})
export class QdBreadcrumbsComponent {
  breadcrumbs$: Observable<QdBreadcrumbs>;

  private get breadcrumbsService(): QdBreadcrumbsService {
    switch (this.outlet) {
      case 'dialog':
        return this.dialogBreadcrumbsService;
      case 'primary':
      default:
        return this.primaryBreadcrumbsService;
    }
  }

  private get outlet(): string {
    return this.dialogComponent ? 'dialog' : 'primary';
  }

  constructor(
    private readonly primaryBreadcrumbsService: QdBreadcrumbsService,
    private readonly dialogBreadcrumbsService: QdDialogBreadcrumbsService,
    @Optional() private readonly dialogComponent: QdDialogComponent
  ) {
    this.breadcrumbs$ = this.breadcrumbsService.breadcrumbs$;
  }

  getBreadcrumbRouterLink(breadcrumb: QdBreadcrumb): any[] {
    return ['/', { outlets: { [this.outlet]: breadcrumb.url } }];
  }
}
