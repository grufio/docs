/**
 * Represents an array of breadcrumbs used for navigation.
 * Each breadcrumb contains a localized label and a corresponding URL.
 */
export type QdBreadcrumbs = QdBreadcrumb[];

/**
 * Represents a single breadcrumb in a navigation path.
 */
export interface QdBreadcrumb {
  /**
   * The localized label for the breadcrumb
   */
  i18n: string;

  /**
   * Here parameters are defined that will be inserted in the translated i18n message with placeholders.
   * To insert a placeholder for a parameter in the translation text, enclose the parameter key
   * with doubled curly braces (e.g. "Declaration {{declarationNumber}}").
   */
  parameters: { [key: string]: string };

  /**
   * The URL associated with the breadcrumb
   */
  url: string;
}
