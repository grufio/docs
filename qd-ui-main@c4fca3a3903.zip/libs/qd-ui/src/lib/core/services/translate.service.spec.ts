// @ts-strict-ignore
import { TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { QdTranslateService } from './translate.service';
import { QdMockTranslateService } from '../__mocks__/mock-translate.service';
import { QdTranslatable } from '../model/translation.interface';

describe('Testing QdTranslateService', () => {
  let service: QdTranslateService;
  let translateService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        QdTranslateService,
        {
          provide: TranslateService,
          useClass: QdMockTranslateService
        }
      ]
    });
    service = TestBed.inject(QdTranslateService);
    translateService = TestBed.inject(TranslateService);
  });

  test('translates translatable with i18n.', () => {
    const translation = service.translate({
      i18n: 'i18n.qd.exampleFormField.goodsDeclaration.import'
    });

    expect(translation).toBe('Fake translation: i18n.qd.exampleFormField.goodsDeclaration.import');
  });

  describe('translations from backend | ', () => {
    const translatable: QdTranslatable = {
      i18n: null,
      translation: {
        de: 'kundenspezifische Bereitstellung',
        fr: 'disposition personnalisée',
        it: 'fornitura personalizzata',
        en: 'custom provision'
      }
    };

    const languageDataProvider = [
      {
        currentLang: 'de',
        expectedTranslation: 'kundenspezifische Bereitstellung'
      },
      {
        currentLang: 'fr',
        expectedTranslation: 'disposition personnalisée'
      },
      {
        currentLang: 'it',
        expectedTranslation: 'fornitura personalizzata'
      },
      {
        currentLang: 'en',
        expectedTranslation: 'custom provision'
      },
      {
        currentLang: undefined,
        expectedTranslation: 'kundenspezifische Bereitstellung'
      }
    ];

    languageDataProvider.forEach(({ currentLang, expectedTranslation }) => {
      test(`translates translatable with translations from backend for language "${currentLang}".`, () => {
        translateService.currentLang = currentLang;
        expect(service.translate(translatable)).toBe(expectedTranslation);
      });
    });

    test('logs error for undefined language.', () => {
      jest.spyOn(console, 'error');
      // @ts-ignore
      console.error.mockImplementation(() => {});

      translateService.currentLang = 'es';

      expect(service.translate(translatable)).toBe('');
      expect(console.error).toHaveBeenCalledWith('Language "es" is not implemented!');
    });
  });

  describe('passed properties of TranslateService | ', () => {
    test('returns currentLang.', () => {
      translateService.currentLang = 'fr';

      expect(service.currentLang).toBe('fr');
    });

    test('returns onLangChange.', () => {
      expect(service.onLangChange).toBe(translateService.onLangChange);
    });

    test('returns instant.', () => {
      expect(service.instant).toBe(translateService.instant);
    });

    test('returns use.', () => {
      expect(service.use).toBe(translateService.use);
    });

    test('returns getTranslation.', () => {
      expect(service.getTranslation).toBe(translateService.getTranslation);
    });
  });
});
