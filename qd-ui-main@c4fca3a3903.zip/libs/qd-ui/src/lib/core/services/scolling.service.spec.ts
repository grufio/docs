// @ts-strict-ignore
import { BorderDirection, QdScrollingService } from './scrolling.service';

describe(QdScrollingService.name, () => {
  let service;
  let element;

  beforeEach(() => {
    service = new QdScrollingService();

    element = document.createElement('div');
    element.getBoundingClientRect = jest.fn();

    jest.spyOn(window, 'scrollBy');
    // @ts-ignore
    window.scrollBy.mockImplementation(() => {});
  });

  afterEach(jest.clearAllMocks);

  describe('scrollIntoView', () => {
    const scrollIntoViewDataProvider: Array<{
      boundingClientRect: Partial<DOMRect>;
      borderDirection: BorderDirection;
      targetBorderDistance: number;
      expectedScrolling: Partial<{ [key in BorderDirection]: number }>;
    }> = [
      {
        boundingClientRect: {
          top: -50,
          left: 50,
          bottom: 50,
          right: 150
        },
        borderDirection: 'top',
        targetBorderDistance: 10,
        expectedScrolling: { top: -60 }
      },
      {
        boundingClientRect: {
          top: 10,
          left: -50,
          bottom: 110,
          right: 50
        },
        borderDirection: 'left',
        targetBorderDistance: 25,
        expectedScrolling: { left: -75 }
      },
      {
        boundingClientRect: {
          top: 10,
          left: 1000,
          bottom: 110,
          right: 1100
        },
        borderDirection: 'right',
        targetBorderDistance: 0,
        expectedScrolling: { left: 76 }
      },
      {
        boundingClientRect: {
          top: 700,
          left: 10,
          bottom: 800,
          right: 110
        },
        borderDirection: 'bottom',
        targetBorderDistance: 15,
        expectedScrolling: { top: 47 }
      }
    ];

    scrollIntoViewDataProvider.forEach(
      ({ boundingClientRect, borderDirection, targetBorderDistance, expectedScrolling }) => {
        test(`scrolls element to the correct ${borderDirection} distance`, () => {
          window.innerWidth = 1024;
          window.innerHeight = 768;
          element.getBoundingClientRect.mockReturnValue(boundingClientRect);

          service.scrollIntoView(element, borderDirection, targetBorderDistance);

          expect(window.scrollBy).toHaveBeenCalledWith({ ...expectedScrolling, ...{ behavior: 'smooth' } });
        });
      }
    );

    test('uses top as default borderDirection', () => {
      window.innerWidth = 1024;
      window.innerHeight = 768;
      element.getBoundingClientRect.mockReturnValue({
        top: -50,
        left: 50,
        bottom: 50,
        right: 150
      });

      service.scrollIntoView(element);

      expect(window.scrollBy).toHaveBeenCalledWith({ behavior: 'smooth', top: -50 });
    });

    test('uses 0 as default targetBorderDistance', () => {
      window.innerWidth = 1024;
      window.innerHeight = 768;
      element.getBoundingClientRect.mockReturnValue({
        top: 700,
        left: 10,
        bottom: 800,
        right: 110
      });

      service.scrollIntoView(element, 'bottom');

      expect(window.scrollBy).toHaveBeenCalledWith({ behavior: 'smooth', top: 32 });
    });
  });

  describe('scrollIntoViewIfNeeded', () => {
    const outsideViewportDataProvider = [
      {
        overlappingDirection: 'top',
        boundingClientRect: {
          top: -50,
          left: 50,
          bottom: 50,
          right: 150
        }
      },
      {
        overlappingDirection: 'left',
        boundingClientRect: {
          top: 10,
          left: -50,
          bottom: 110,
          right: 50
        }
      },
      {
        overlappingDirection: 'right',
        boundingClientRect: {
          top: 10,
          left: 1000,
          bottom: 110,
          right: 1100
        }
      },
      {
        overlappingDirection: 'bottom',
        boundingClientRect: {
          top: 700,
          left: 10,
          bottom: 800,
          right: 110
        }
      }
    ];

    outsideViewportDataProvider.forEach(({ overlappingDirection, boundingClientRect }) => {
      test(`scrolls if element is outside viewport (overlapping ${overlappingDirection})`, () => {
        window.innerWidth = 1024;
        window.innerHeight = 768;
        element.getBoundingClientRect.mockReturnValue(boundingClientRect);

        service.scrollIntoViewIfNeeded(element);

        expect(window.scrollBy).toHaveBeenCalled();
      });
    });

    test('does not scroll if element is inside viewport', () => {
      window.innerWidth = undefined;
      window.innerHeight = undefined;
      Object.defineProperty(document.documentElement, 'clientWidth', { value: 1024 });
      Object.defineProperty(document.documentElement, 'clientHeight', { value: 768 });
      element.getBoundingClientRect.mockReturnValue({
        top: 10,
        left: 10,
        bottom: 110,
        right: 110
      });

      service.scrollIntoViewIfNeeded(element);

      expect(window.scrollBy).not.toHaveBeenCalled();
    });
  });

  describe('getBorderDistances', () => {
    test('returns correct border distances', () => {
      element.getBoundingClientRect.mockReturnValue({
        top: 10,
        left: 10,
        bottom: 110,
        right: 110
      });

      expect(service.getBorderDistances(element)).toEqual({
        top: 10,
        left: 10,
        bottom: 658,
        right: 914
      });
    });
  });
});
