import { TestBed } from '@angular/core/testing';
import { NEVER } from 'rxjs';
import { take } from 'rxjs/operators';

import { QdPushEventsService } from './push-events.service';

class MockEventSource {
  static instances: MockEventSource[] = [];

  url: string;
  listeners: Record<string, EventListener[]> = {};
  readyState = 0;
  onerror: ((this: EventSource, ev: Event) => any) | null = null;

  constructor(url: string) {
    this.url = url;
    MockEventSource.instances.push(this);
  }

  static reset() {
    this.instances = [];
  }

  addEventListener(type: string, listener: EventListener) {
    if (!this.listeners[type]) this.listeners[type] = [];
    this.listeners[type].push(listener);
  }

  removeEventListener(type: string, listener: EventListener) {
    if (this.listeners[type]) {
      this.listeners[type] = this.listeners[type].filter(l => l !== listener);
      if (this.listeners[type].length === 0) delete this.listeners[type];
    }
  }

  dispatchEvent(type: string, event: Event) {
    (this.listeners[type] || []).forEach(listener => listener(event));
  }

  close() {
    this.readyState = 2;
    this.listeners = {};
  }
}

describe(`Testing ${QdPushEventsService.name} |`, () => {
  let service: QdPushEventsService;
  let consoleWarn: jest.SpyInstance;
  let consoleError: jest.SpyInstance;

  beforeEach(() => {
    global.EventSource = MockEventSource as unknown as typeof EventSource;
    MockEventSource.reset();

    consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});
    consoleError = jest.spyOn(console, 'error').mockImplementation(() => {});

    TestBed.configureTestingModule({ providers: [QdPushEventsService] });

    service = TestBed.inject(QdPushEventsService);

    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  function getLatestEventSource() {
    return MockEventSource.instances[MockEventSource.instances.length - 1];
  }

  describe('connect()', () => {
    test('creates connection', () => {
      service.connect('test-url');
      expect(service['_eventSource']!.url).toBe('test-url');
    });

    test('rejects new connection when already connected', () => {
      const mockEventSource = new MockEventSource('test-url');
      mockEventSource.readyState = EventSource.OPEN;
      service['_eventSource'] = mockEventSource as unknown as EventSource;

      service.connect('second-connection-test-url');

      expect(MockEventSource.instances.length).toBe(1);
      expect(MockEventSource.instances[0].url).toBe('test-url');
    });

    test('prevents multiple connections', () => {
      service.connect('test-url');
      service.connect('test-url');
      service.connect('test-url');

      expect(MockEventSource.instances.length).toBe(1);
    });

    test('handles heartbeat timeouts', () => {
      service.connect('test-url');
      const es = getLatestEventSource();

      const reconnectSpy = jest.spyOn(service as any, 'reconnect');

      es.dispatchEvent('HEARTBEAT', {
        type: 'HEARTBEAT',
        data: JSON.stringify({ interval: 5000 })
      } as MessageEvent);

      jest.advanceTimersByTime(5000 + 100);

      expect(reconnectSpy).toHaveBeenCalledTimes(1);
    });

    test('reconnects on error when connection closed', () => {
      service.connect('test-url');
      const es = getLatestEventSource();

      es.readyState = EventSource.CLOSED;

      const reconnectSpy = jest.spyOn(service as any, 'reconnect');

      (es as unknown as EventSource).onerror!(new Event('error'));

      expect(reconnectSpy).toHaveBeenCalledTimes(1);
    });

    test('logs error without reconnect when connection open', () => {
      service.connect('test-url');
      const es = getLatestEventSource();

      Object.defineProperty(es, 'readyState', { get: () => 1 });

      const reconnectSpy = jest.spyOn(service as any, 'reconnect');

      const errorEvent = new Event('error');

      (es as any).onerror(errorEvent);

      expect(reconnectSpy).not.toHaveBeenCalled();
      expect(consoleError).toHaveBeenCalledWith('QD-UI | QdPushEventsService - SSE connection error:', errorEvent);
    });
  });

  describe('disconnect()', () => {
    test('closes connection and clears listeners', () => {
      service.connect('test-url');
      service.observe('RESOURCE_UPDATED').subscribe();

      service.disconnect();
      const es = getLatestEventSource();

      expect(es.readyState).toBe(2);
      expect(es.listeners['RESOURCE_UPDATED']).toBeUndefined();
    });

    test('logs warning when no active connection', () => {
      const warnSpy = jest.spyOn(console, 'warn');

      service.disconnect();

      expect(warnSpy).toHaveBeenCalledWith('QD-UI | QdPushEventsService - No active connection to disconnect.');
    });

    test('keeps subscriptions for reconnect', () => {
      service.connect('test-url');

      service.observe('RESOURCE_UPDATED').subscribe();
      service.disconnect();

      expect(service['_eventSubscriptionSubjects'].size).toBe(1);
    });
  });

  describe('observe()', () => {
    test('supports all event types', () => {
      service.connect('test-url');
      const eventNames = ['RESOURCE_CREATED', 'RESOURCE_UPDATED', 'RESOURCE_DELETED'];

      eventNames.forEach(name => {
        service.observe(name as any).subscribe();

        expect(service['_eventSubscriptionSubjects'].has(name)).toBe(true);
      });
    });

    test('emits events to subscribers', done => {
      service.connect('test-url');
      const es = getLatestEventSource();

      service.observe('RESOURCE_UPDATED').subscribe(event => {
        expect(event.type).toBe('RESOURCE_UPDATED');
        expect(event.data).toBe('test-data');
        done();
      });

      es.dispatchEvent('RESOURCE_UPDATED', {
        type: 'RESOURCE_UPDATED',
        data: 'test-data'
      } as MessageEvent);
    });

    test('does not add duplicate listeners for the same event', () => {
      service.connect('test-url');

      service.observe('RESOURCE_UPDATED').subscribe();
      service.observe('RESOURCE_UPDATED').subscribe();

      const es = getLatestEventSource();

      expect(es.listeners['RESOURCE_UPDATED'].length).toBe(1);
    });

    test('returns NEVER when not connected', () => {
      const result = service.observe('RESOURCE_UPDATED');

      expect(result).toBe(NEVER);
      expect(consoleError).toHaveBeenCalledWith(
        'QD-UI | QdPushEventsService - Cannot observe events without a connection. Call connect() first.',
        undefined
      );
    });

    test('maintains subscriptions after reconnect', done => {
      service.connect('test-url');

      service
        .observe('RESOURCE_UPDATED')
        .pipe(take(1))
        .subscribe(event => {
          expect(event.type).toBe('RESOURCE_UPDATED');
          expect(event.data).toBe('test-data');
          done();
        });

      const es = getLatestEventSource();

      es.close();
      jest.advanceTimersByTime(10000);

      service.connect('test-url');

      es.dispatchEvent('RESOURCE_UPDATED', {
        type: 'RESOURCE_UPDATED',
        data: 'test-data'
      } as MessageEvent);
    });
  });

  describe('unobserveAll()', () => {
    test('clears all listeners and subjects', () => {
      service.connect('test-url');
      const es = getLatestEventSource();

      service.observe('RESOURCE_UPDATED').subscribe();

      expect(service['_listeners']).toHaveLength(1);
      expect(service['_eventSubscriptionSubjects'].size).toBe(1);

      service.unobserveAll();

      expect(service['_listeners']).toHaveLength(0);
      expect(service['_eventSubscriptionSubjects'].size).toBe(0);
    });

    test('keeps connection alive', () => {
      service.connect('test-url');

      service.observe('RESOURCE_UPDATED').subscribe();
      service.unobserveAll();

      const es = getLatestEventSource();

      expect(es.readyState).not.toBe(EventSource.CLOSED);
    });
  });

  describe('isConnectedOrConnecting()', () => {
    test('preserves listeners during reconnect', () => {
      service.connect('test-url');
      service.observe('RESOURCE_UPDATED').subscribe();

      const firstES = getLatestEventSource();
      firstES.close();
      jest.advanceTimersByTime(10000);

      const secondES = getLatestEventSource();
      expect(secondES.listeners['RESOURCE_UPDATED']?.length).toBe(1);
    });
  });

  describe('removeAllEventListenersFromEventSource()', () => {
    test('logs warning when no connection exists', () => {
      service['_eventSource'] = undefined;

      consoleWarn.mockClear();

      service['removeAllEventListenersFromEventSource']();

      expect(consoleWarn).toHaveBeenCalledWith(
        'QD-UI | QdPushEventsService - Cannot remove listeners: No active connection.'
      );
      expect(consoleWarn).toHaveBeenCalledTimes(1);
    });
  });
});
