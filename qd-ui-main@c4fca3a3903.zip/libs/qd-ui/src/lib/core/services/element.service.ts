import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class QdElementService {
  isOverflown(element: HTMLElement): boolean {
    return element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth;
  }
}
