import { TestBed } from '@angular/core/testing';
import { QdBreakpointService } from './breakpoint.service';
import { breakpoints } from '../model/breakpoint.interface';

describe(`Testing ${QdBreakpointService.name} |`, () => {
  let service: QdBreakpointService;
  let matchMediaMock: jest.Mock;

  beforeEach(() => {
    matchMediaMock = jest.fn((query: string) => {
      const minWidthMatch = query.match(/\(min-width:\s*(\d+)px\)/);
      const minWidth = minWidthMatch ? parseInt(minWidthMatch[1], 10) : 0;

      return {
        matches: minWidth <= 1024,
        media: query,
        onchange: null,
        addListener: jest.fn(), // Deprecated
        removeListener: jest.fn(), // Deprecated
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn()
      };
    });

    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: matchMediaMock
    });

    TestBed.configureTestingModule({
      providers: [QdBreakpointService]
    });

    service = TestBed.inject(QdBreakpointService);
  });

  function setViewportWidth(width: number) {
    matchMediaMock.mockImplementation(query => {
      const minWidthMatch = query.match(/\(min-width:\s*(\d+)px\)/);
      const minWidth = minWidthMatch ? parseInt(minWidthMatch[1], 10) : 0;

      return {
        matches: minWidth <= width,
        media: query,
        onchange: null,
        addListener: jest.fn(), // Deprecated
        removeListener: jest.fn(), // Deprecated
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn()
      };
    });

    Object.keys(breakpoints).forEach(key => {
      const event = new Event('change');
      window.dispatchEvent(event);
    });
  }

  test('returns the correct initial breakpoint', done => {
    service.getMatchingBreakpoint().subscribe(breakpoint => {
      expect(breakpoint).toBe('md');
      done();
    });
  });

  test('returns the correct breakpoint when the viewport width changes', done => {
    setViewportWidth(1600);

    service.getMatchingBreakpoint().subscribe(breakpoint => {
      expect(breakpoint).toBe('xl');
      done();
    });
  });

  test('returns the correct breakpoint for smaller viewport width', done => {
    setViewportWidth(600);

    service.getMatchingBreakpoint().subscribe(breakpoint => {
      expect(breakpoint).toBe('sm');
      done();
    });
  });

  test('returns the smallest breakpoint for extremely small viewport width', done => {
    setViewportWidth(200);

    service.getMatchingBreakpoint().subscribe(breakpoint => {
      expect(breakpoint).toBe('xs');
      done();
    });
  });

  test('returns the largest breakpoint for extremely large viewport width', done => {
    setViewportWidth(2000);

    service.getMatchingBreakpoint().subscribe(breakpoint => {
      expect(breakpoint).toBe('xxl');
      done();
    });
  });
});
