import { Injectable } from '@angular/core';
import { combineLatest, concat, fromEvent, Observable } from 'rxjs';
import { debounceTime, map, startWith, take } from 'rxjs/operators';
import { breakpoints, QdBreakpoint } from '../model/breakpoint.interface';

@Injectable({
  providedIn: 'root'
})
export class QdBreakpointService {
  private _breakpoints = breakpoints;

  get breakpoints(): {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
  } {
    return this._breakpoints;
  }

  public getMatchingBreakpoint(): Observable<QdBreakpoint> {
    const queries = Object.values(this.breakpoints).map(bp => `(min-width: ${bp}px)`);

    const matches$ = queries.map(query => {
      const mql = window.matchMedia(query);

      return fromEvent<MediaQueryListEvent>(mql, 'change').pipe(
        map(event => event.matches),
        startWith(mql.matches)
      );
    });

    const breakpoint: Observable<QdBreakpoint> = combineLatest(matches$).pipe(
      map(
        matches =>
          (Object.keys(this.breakpoints)[matches.lastIndexOf(true)] || Object.keys(this.breakpoints)[0]) as QdBreakpoint
      )
    );

    return concat(breakpoint.pipe(take(1)), breakpoint.pipe(debounceTime(100)));
  }
}
