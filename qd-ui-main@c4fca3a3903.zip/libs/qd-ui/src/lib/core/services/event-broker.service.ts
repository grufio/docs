import { Injectable } from '@angular/core';
import { BehaviorSubject, EMPTY, Observable, shareReplay } from 'rxjs';
import { distinctUntilChanged, filter } from 'rxjs/operators';
import { isEqual } from 'lodash';

/**
 * Inspired by Kafka's message broker architecture, the QdEventBrokerService provides a lightweight, event-driven
 * communication layer within the Quadrel framework.
 *
 * #### Usage:
 *
 * **Produce an Event**
 * Use the `produce` method to send an event to a specific topic.
 *
 * ```typescript
 * eventBrokerService.produce('userLoggedIn', { userId: 123, name: 'John Doe' });
 * ```
 *
 * **Consuming an Event**
 * Subscribe to a topic to receive updates when an event is produced.
 *
 * ```typescript
 * eventBrokerService.consume<{ userId: number; name: string }>('userLoggedIn')
 *   .subscribe(event => {
 *     console.log('User logged in:', event.payload);
 *   });
 * ```
 *
 * **Unsubscribing from a Topic**
 * Calling `unsubscribeFrom(topic)` removes the topic and closes its event stream.
 * This affects all consumers** subscribed to the topic, as no more updates will be sent.
 *
 * ```typescript
 * eventBrokerService.unsubscribeFrom('userLoggedIn');
 * ```
 * After this method is called, subscribing to the topic will return an empty stream.
 *
 * **Ensuring Topic Existence**
 * The `produce` method automatically creates a topic if it does not exist. However, topics are only removed when
 * explicitly unsubscribed using `unsubscribeFrom()`.
 *
 * **What are Topics?**
 * A **topic** is a named communication channel where events are published and consumed.
 * Topics allow different parts of an application to exchange information **without being directly connected**.
 * This makes the system more flexible and easier to maintain.
 */
@Injectable()
export class QdEventBrokerService {
  private _topics = new Map<string, BehaviorSubject<{ topic: string; payload: any }>>();

  produce<T>(topic: string, payload: T): void {
    this.ensureTopicExists(topic);
    this._topics.get(topic)!.next({ topic, payload });
  }

  consume<T>(topic: string): Observable<{ topic: string; payload: T }> {
    if (!this._topics.has(topic)) {
      console.warn(`QD-UI | QdEventBrokerService - Topic "${topic}" does not exist.`);

      return EMPTY;
    }

    return this._topics.get(topic)!.pipe(
      filter(event => event.payload != null),
      distinctUntilChanged((prev, curr) => isEqual(prev, curr)),
      shareReplay(1)
    );
  }

  unsubscribeFrom(topic: string): void {
    const subject = this._topics.get(topic);

    if (subject && !subject.closed) subject.complete();

    this._topics.delete(topic);
  }

  private ensureTopicExists(topic: string): void {
    if (!this._topics.has(topic))
      this._topics.set(topic, new BehaviorSubject<{ topic: string; payload: unknown }>({ topic, payload: undefined }));
  }
}
