// @ts-strict-ignore
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { QdTranslatable } from '../model/translation.interface';

@Injectable({
  providedIn: 'root'
})
export class QdTranslateService {
  constructor(private translateService: TranslateService) {}

  translate(translatable: QdTranslatable): string {
    let translation;

    if (translatable.i18n) {
      translation = this.translateService.instant(translatable.i18n);
    } else if (translatable.translation) {
      translation = translatable.translation[this.translateService.currentLang || 'de'];

      if (translation === undefined) {
        console.error(`Language "${this.translateService.currentLang}" is not implemented!`);
      }
    }

    return translation || '';
  }

  get currentLang(): string {
    return this.translateService.currentLang;
  }

  get onLangChange(): TranslateService['onLangChange'] {
    return this.translateService.onLangChange;
  }

  get instant(): TranslateService['instant'] {
    return this.translateService.instant;
  }

  get use(): TranslateService['use'] {
    return this.translateService.use;
  }

  get getTranslation(): TranslateService['getTranslation'] {
    return this.translateService.getTranslation;
  }
}
