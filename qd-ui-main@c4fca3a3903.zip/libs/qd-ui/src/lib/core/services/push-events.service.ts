import { Injectable } from '@angular/core';
import { NEVER, Observable, Subject } from 'rxjs';

type EventName = 'RESOURCE_CREATED' | 'RESOURCE_UPDATED' | 'RESOURCE_DELETED';

/**
 * Service for handling real-time server-sent events.
 *
 * ### Benefits
 *
 * - **Real-Time Interaction**: Enables live updates without user actions or polling.
 * - **Scalable and Flexible**: The system is flexible and easily expandable to handle new events.
 * - **Consistency**: Ensures synchronization between server and client states for a consistent user experience.
 *
 * ### Usage
 *
 * ```ts
 * // Start the connection to the events
 * pushEventsService.connect('http://service-endpint/events');
 *
 * // Subscribe to the event (Side Effect)
 * const subscription = pushEventsService.observe('RESOURCE_UPDATED').subscribe(event => handleEvent(event));
 *
 * // Unsubscribe to prevent memory leaks
 * subscription.unsubscribe();
 *
 * // Disconnect the connection
 * pushEventsService.disconnect();
 * ```
 */
@Injectable({
  providedIn: 'root'
})
export class QdPushEventsService {
  private _eventSource!: EventSource;
  private _eventSubscriptionSubjects = new Map<string, Subject<MessageEvent>>();
  private _listeners: [string, (message: MessageEvent) => void][] = [];
  private _heartbeatTimeout!: ReturnType<typeof setTimeout>;
  private _reconnectDelayTime = 10000;
  private _heartbeatReconnectDelayTime = 100;

  /**
   * Establishes an EventSource connection to the given URL.
   * Automatically reconnects if heartbeat fails or is delayed.
   * Subscribers are retained across reconnections.
   *
   * @param url The backend URL for the event stream.
   */
  connect(url: string): void {
    if (this.isConnectedOrConnecting()) return;

    if (!this._eventSource || this._eventSource.readyState === EventSource.CLOSED)
      this._eventSource = new EventSource(url);

    this._eventSource.onerror = (err: Event): void => {
      if (this._eventSource.readyState === EventSource.CLOSED) this.reconnect();

      this.logError('SSE connection error:', err);
    };

    this._eventSource.addEventListener('HEARTBEAT', message => {
      if (this._heartbeatTimeout) clearTimeout(this._heartbeatTimeout);

      const interval = JSON.parse(message.data).interval;

      this._heartbeatTimeout = setTimeout(() => this.reconnect(), interval + this._heartbeatReconnectDelayTime);
    });

    this._heartbeatTimeout = setTimeout(() => this.reconnect(), this._reconnectDelayTime);

    this.addEventListenersForExistingSubscriptions();
  }

  /**
   * Closes the EventSource connection and clears all listeners.
   * Subscribers are preserved for reconnection.
   */
  disconnect(): void {
    if (!this._eventSource) {
      this.logWarn('No active connection to disconnect.');

      return;
    }

    this.removeAllEventListenersFromEventSource();

    this._eventSource.close();
  }

  /**
   * Returns an Observable for the specified event name.
   * If not connected, returns `NEVER` and logs an error.
   * Automatically adds a listener for the event if needed.
   *
   * @param eventName The event type ('RESOURCE_CREATED', 'RESOURCE_UPDATED', 'RESOURCE_DELETED').
   * @returns Observable<MessageEvent> The event stream.
   */
  observe(eventName: EventName): Observable<MessageEvent> {
    if (!this._eventSource) {
      this.logError('Cannot observe events without a connection. Call connect() first.');

      return NEVER;
    }

    if (!this._eventSubscriptionSubjects.has(eventName)) {
      this._eventSubscriptionSubjects.set(eventName, new Subject<MessageEvent>());

      this.addEventListenerForEventName(eventName);
    }

    return this._eventSubscriptionSubjects.get(eventName)!.asObservable();
  }

  /**
   * Removes all listeners and clears all subscriptions.
   * The EventSource connection remains open.
   */
  unobserveAll(): void {
    this.removeAllEventListenersFromEventSource();
    this._eventSubscriptionSubjects.clear();
  }

  /**
   * Checks if the EventSource is connected or in the process of connecting.
   */
  isConnectedOrConnecting(): boolean {
    return (
      this._eventSource &&
      (this._eventSource.readyState === EventSource.OPEN || this._eventSource.readyState === EventSource.CONNECTING)
    );
  }

  private reconnect(): void {
    if (!this.isConnectedOrConnecting()) {
      this.disconnect();
      this.connect(this._eventSource.url);
    }
  }

  private addEventListenerForEventName(eventName: EventName): void {
    const callback = (messageEvent: MessageEvent): void => {
      const subject = this._eventSubscriptionSubjects.get(eventName);

      if (subject) subject.next(messageEvent);
    };

    this._eventSource.addEventListener(eventName, callback);
    this._listeners.push([eventName, callback]);
  }

  private addEventListenersForExistingSubscriptions(): void {
    this._eventSubscriptionSubjects.forEach((subject, eventName) =>
      this.addEventListenerToEventSource(eventName as EventName, (messageEvent: MessageEvent) =>
        subject.next(messageEvent)
      )
    );
  }

  private addEventListenerToEventSource(eventName: EventName, callback: (messageEvent: MessageEvent) => void): void {
    this._eventSource.addEventListener(eventName, callback);
    this._listeners.push([eventName, callback]);
  }

  private removeAllEventListenersFromEventSource(): void {
    if (!this._eventSource) {
      this.logWarn('Cannot remove listeners: No active connection.');

      return;
    }

    this._listeners.forEach(([eventName, callback]) => this._eventSource.removeEventListener(eventName, callback));
    this._listeners = [];
  }

  private logWarn(message: string): void {
    console.warn(`QD-UI | QdPushEventsService - ${message}`);
  }

  private logError(message: string, err?: Event): void {
    console.error(`QD-UI | QdPushEventsService - ${message}`, err);
  }
}
