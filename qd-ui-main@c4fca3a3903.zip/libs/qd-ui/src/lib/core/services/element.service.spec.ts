import { TestBed } from '@angular/core/testing';
import { QdElementService } from './element.service';

describe(`Testing ${QdElementService.name} |`, () => {
  let service: QdElementService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdElementService]
    });

    service = TestBed.inject(QdElementService);
  });

  test('isOverflown returns false if there is no overflow', () => {
    const element = document.createElement('div');

    Object.defineProperty(element, 'clientWidth', { value: 200 });
    Object.defineProperty(element, 'clientHeight', { value: 200 });
    Object.defineProperty(element, 'scrollWidth', { value: 200 });
    Object.defineProperty(element, 'scrollHeight', { value: 200 });

    expect(service.isOverflown(element)).toBe(false);
  });

  test('isOverflown returns true if overflown horizontally', () => {
    const element = document.createElement('div');

    Object.defineProperty(element, 'clientWidth', { value: 100 });
    Object.defineProperty(element, 'scrollWidth', { value: 200 });

    expect(service.isOverflown(element)).toBe(true);
  });

  test('isOverflown returns true if overflown vertically', () => {
    const element = document.createElement('div');

    Object.defineProperty(element, 'clientHeight', { value: 100 });
    Object.defineProperty(element, 'scrollHeight', { value: 200 });

    expect(service.isOverflown(element)).toBe(true);
  });
});
