import { Injectable } from '@angular/core';

export type BorderDirection = 'top' | 'left' | 'right' | 'bottom';
type BorderDistances = { [key in BorderDirection]: number };

@Injectable({
  providedIn: 'root'
})
export class QdScrollingService {
  scrollIntoViewIfNeeded(
    element: HTMLElement,
    borderDirection: BorderDirection = 'top',
    targetBorderDistance = 0
  ): void {
    this.scrollIntoView(element, borderDirection, targetBorderDistance, true);
  }

  scrollIntoView(
    element: HTMLElement,
    borderDirection: BorderDirection = 'top',
    targetBorderDistance = 0,
    onlyIfOutsideView = false
  ): void {
    const borderDistances = this.getBorderDistances(element);

    if (onlyIfOutsideView && this.isInViewport(borderDistances)) return;

    switch (borderDirection) {
      case 'top':
        window.scrollBy({ behavior: 'smooth', top: -(targetBorderDistance - borderDistances.top) });
        break;
      case 'left':
        window.scrollBy({ behavior: 'smooth', left: -(targetBorderDistance - borderDistances.left) });
        break;
      case 'right':
        window.scrollBy({ behavior: 'smooth', left: targetBorderDistance - borderDistances.right });
        break;
      case 'bottom':
        window.scrollBy({ behavior: 'smooth', top: targetBorderDistance - borderDistances.bottom });
        break;
    }
  }

  getBorderDistances(element: HTMLElement): BorderDistances {
    const boundingClientRect = element.getBoundingClientRect();

    return {
      top: boundingClientRect.top,
      left: boundingClientRect.left,
      right: (window.innerWidth || document.documentElement.clientWidth) - boundingClientRect.right,
      bottom: (window.innerHeight || document.documentElement.clientHeight) - boundingClientRect.bottom
    };
  }

  private isInViewport(borderDistances: BorderDistances): boolean {
    return Object.values(borderDistances).every(distance => distance > 0);
  }
}
