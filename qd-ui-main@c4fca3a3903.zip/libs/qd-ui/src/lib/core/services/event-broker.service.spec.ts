import { TestBed } from '@angular/core/testing';
import { EMPTY } from 'rxjs';

import { QdEventBrokerService } from './event-broker.service';

describe(`Testing ${QdEventBrokerService.name} |`, () => {
  let service: QdEventBrokerService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [QdEventBrokerService] });

    service = TestBed.inject(QdEventBrokerService);
  });

  test('logs a warning when consuming a non-existent topic', () => {
    const topic = 'case_of_the_missing_pillow';
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    service.consume(topic).subscribe({
      next: () => fail("Monk's eye would spot this anomaly — no value should be emitted!"),
      error: () => fail('Even Monk would agree—there should be no errors here!'),
      complete: () => {}
    });

    expect(warnSpy).toHaveBeenCalledWith(`QD-UI | QdEventBrokerService - Topic "${topic}" does not exist.`);
    warnSpy.mockRestore();
  });

  test('produces and consumes events', done => {
    const topic = 'who_stole_sharonas_sandwich';
    const payload = { key: 'Randy Disher' };

    service.produce(topic, payload);

    service.consume(topic).subscribe(event => {
      expect(event).toEqual({ topic, payload });
      done();
    });
  });

  test('emits distinct values only', () => {
    const topic = 'monks_obsessive_clues';
    let count = 0;

    service.produce(topic, { key: 'crooked picture frame' });

    service.consume(topic).subscribe(event => {
      if ((event.payload as any).key !== 'crooked picture frame') count++;
    });

    service.produce(topic, { key: 'shoeprint facing east' });
    service.produce(topic, { key: 'shoeprint facing east' });
    service.produce(topic, { key: 'coffee stain on the map' });

    expect(count).toBe(2);
  });

  test('returns EMPTY when consuming a non-existent topic', done => {
    const topic = 'forgotten_napkin_with_motive';
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    const observable = service.consume(topic);

    expect(observable).toBe(EMPTY);

    let emitted = false;
    observable.subscribe({
      next: () => (emitted = true),
      error: () => fail('Should not throw an error'),
      complete: () => {
        expect(emitted).toBe(false);
        expect(warnSpy).toHaveBeenCalledWith(`QD-UI | QdEventBrokerService - Topic "${topic}" does not exist.`);
        warnSpy.mockRestore();

        done();
      }
    });
  });

  test('unsubscribes and removes topics', () => {
    const topic = 'discarded_evidence_at_the_diner';

    service.produce(topic, { key: 'napkin with a cryptic message' });

    expect(service['_topics'].has(topic)).toBe(true);

    service.unsubscribeFrom(topic);

    expect(service['_topics'].has(topic)).toBe(false);
  });
});
