import { Type } from '@angular/core';

import { QdDataFacetsBlankComponent } from './blank/data-facets-blank.component';
import { QdDataFacetsBooleanComponent } from './boolean/data-facets-boolean.component';
import { QdDataFacetsChipComponent } from './chip/data-facets-chip.component';
import { QdDataFacetsCurrencyComponent } from './currency/data-facets-currency.component';
import { QdDataFacetsDateComponent } from './date/data-facets-date.component';
import { QdDataFacetsIconComponent } from './icon/data-facets-icon.component';
import { QdDataFacetsIntegerComponent } from './integer/data-facets-integer.component';
import { QdDataFacetsLinkComponent } from './link/data-facets-link.component';
import { QdDataFacetsProgressComponent } from './progress/data-facets-progress.component';
import { QdDataFacetsStatusComponent } from './status/data-facets-status.component';
import { QdDataFacetsTextComponent } from './text/data-facets-text.component';

/**
 * @description Represents all possible component types for different data facets.
 */
export type QdDataFacetsComponent =
  | QdDataFacetsBlankComponent
  | QdDataFacetsBooleanComponent
  | QdDataFacetsChipComponent
  | QdDataFacetsCurrencyComponent
  | QdDataFacetsDateComponent
  | QdDataFacetsIconComponent
  | QdDataFacetsIntegerComponent
  | QdDataFacetsLinkComponent
  | QdDataFacetsProgressComponent
  | QdDataFacetsStatusComponent
  | QdDataFacetsTextComponent;

/**
 * @description Defines the valid types of data facets.
 * These types are used to map to corresponding components in `COMPONENT_MAP`.
 */
export type QdDataFacetsType =
  | 'blank'
  | 'boolean'
  | 'chip'
  | 'currency'
  | 'date'
  | 'icon'
  | 'integer'
  | 'link'
  | 'progress'
  | 'status'
  | 'text'
  | 'enum';

/**
 * @description Maps each `QdDataFacetsType` to a corresponding Angular component type.
 */
export type QdComponentMap = {
  [K in QdDataFacetsType]: Type<QdDataFacetsComponent>;
};

/**
 * @description A constant map that associates each `QdDataFacetsType` with its corresponding component.
 *
 * #### Usage:
 * ```ts
 * const booleanComponent = COMPONENT_MAP['boolean']; // Resolves to QdDataFacetsBooleanComponent
 * ```
 */
export const COMPONENT_MAP: QdComponentMap = {
  blank: QdDataFacetsBlankComponent,
  boolean: QdDataFacetsBooleanComponent,
  chip: QdDataFacetsChipComponent,
  currency: QdDataFacetsCurrencyComponent,
  date: QdDataFacetsDateComponent,
  icon: QdDataFacetsIconComponent,
  integer: QdDataFacetsIntegerComponent,
  link: QdDataFacetsLinkComponent,
  progress: QdDataFacetsProgressComponent,
  status: QdDataFacetsStatusComponent,
  text: QdDataFacetsTextComponent,
  enum: QdDataFacetsTextComponent
};
