import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { of } from 'rxjs';
import { MockProvider } from 'ng-mocks';

import { QdDataFacetsContextService } from '../data-facets-context.service';
import { QdDataFacetsLinkComponent } from './data-facets-link.component';
import { QdTableExternalActionResultService } from '../../../table/services/external-action-result.service';

describe(`Testing ${QdDataFacetsLinkComponent.name} |`, () => {
  let component: QdDataFacetsLinkComponent;
  let fixture: ComponentFixture<QdDataFacetsLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [QdDataFacetsLinkComponent],
      providers: [
        MockProvider(QdDataFacetsContextService, {
          getContext: () => ({ myContext: 'my context data' })
        }),
        MockProvider(QdTableExternalActionResultService)
      ]
    }).compileComponents();
  });

  describe('with array data:', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(QdDataFacetsLinkComponent);
      component = fixture.componentInstance;
      component.config = { handler: jest.fn() };
      component.data = ['42', '4711', '815'];
      fixture.detectChanges();
    });

    test('matches the snapshot', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('isList returns true:', () => {
      expect(component.isList).toBe(true);
    });

    test('handleLinkMultiAction is triggered with correct params', () => {
      jest.spyOn(component, 'handleLinkMultiAction');
      const items = fixture.debugElement.queryAll(By.css('.item'));
      const event = { stopPropagation: jest.fn() };

      items[1].triggerEventHandler('click', event);

      expect(component.handleLinkMultiAction).toHaveBeenCalledWith(1, '4711', event);
      expect(component.config.handler).toHaveBeenCalledWith({
        myContext: 'my context data',
        selectedIndex: 1,
        selectedValue: '4711'
      });
      expect(event.stopPropagation).toHaveBeenCalled();
    });
  });

  describe('with string data:', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(QdDataFacetsLinkComponent);
      component = fixture.componentInstance;
      component.config = { handler: jest.fn() };
      component.data = '815';
      fixture.detectChanges();
    });

    test('matches the snapshot', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });

    test('isList returns false', () => {
      expect(component.isList).toBe(false);
    });

    test('handleLinkSingleAction is triggered with correct params', () => {
      jest.spyOn(component, 'handleLinkSingleAction');
      const item = fixture.debugElement.query(By.css('.item'));
      item.nativeElement.click();

      expect(component.handleLinkSingleAction).toHaveBeenCalled();
      expect(component.config.handler).toHaveBeenCalledWith({
        myContext: 'my context data',
        selectedValue: '815'
      });
    });
  });

  describe('without context service:', () => {
    beforeEach(() => {
      TestBed.overrideProvider(QdDataFacetsContextService, { useValue: null });
      fixture = TestBed.createComponent(QdDataFacetsLinkComponent);
      component = fixture.componentInstance;
      component.config = { handler: jest.fn() };
    });

    describe('with string data & without context', () => {
      beforeEach(() => {
        component.data = '815';
        fixture.detectChanges();
      });

      test('matches the snapshot', () => {
        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('handleLinkSingleAction works correctly', () => {
        jest.spyOn(component, 'handleLinkSingleAction');
        const item = fixture.debugElement.query(By.css('.item'));
        item.nativeElement.click();

        expect(component.handleLinkSingleAction).toHaveBeenCalled();
        expect(component.config.handler).toHaveBeenCalledWith({
          selectedValue: '815'
        });
      });
    });

    describe('with array data:', () => {
      beforeEach(() => {
        component.data = ['42', '4711', '815'];
        fixture.detectChanges();
      });

      test('matches the snapshot', () => {
        expect(fixture.nativeElement).toMatchSnapshot();
      });

      test('handleLinkMultiAction works correctly', () => {
        jest.spyOn(component, 'handleLinkMultiAction');
        const items = fixture.debugElement.queryAll(By.css('.item'));
        const event = { stopPropagation: jest.fn() };

        items[1].triggerEventHandler('click', event);

        expect(component.handleLinkMultiAction).toHaveBeenCalledWith(1, '4711', event);
        expect(component.config.handler).toHaveBeenCalledWith({
          selectedIndex: 1,
          selectedValue: '4711'
        });
        expect(event.stopPropagation).toHaveBeenCalled();
      });
    });
  });

  describe('executeHandler (refresh handling):', () => {
    let actionServiceMock: QdTableExternalActionResultService;

    beforeEach(() => {
      actionServiceMock = {
        notifyActionSuccess: jest.fn(),
        actionSuccess$: of()
      } as any;

      TestBed.overrideProvider(QdTableExternalActionResultService, { useValue: actionServiceMock });

      fixture = TestBed.createComponent(QdDataFacetsLinkComponent);
      component = fixture.componentInstance;
    });

    test('does NOT trigger refresh if result is not an observable', () => {
      const handler = jest.fn().mockReturnValue(undefined);

      component.config = {
        handler,
        refresh: { isEnabled: true, page: 2 }
      };

      component['executeHandler']({ test: 1 });

      expect(handler).toHaveBeenCalled();
      expect(actionServiceMock.notifyActionSuccess).not.toHaveBeenCalled();
    });

    test('triggers refresh if observable emits true and isEnabled is true', () => {
      const handler = jest.fn().mockReturnValue(of(true));

      component.config = {
        handler,
        refresh: { isEnabled: true, page: 7 }
      };

      component['executeHandler']({ foo: 'bar' });

      expect(handler).toHaveBeenCalled();
      expect(actionServiceMock.notifyActionSuccess).toHaveBeenCalledWith(7);
    });

    test('does NOT trigger refresh if observable emits false', () => {
      const handler = jest.fn().mockReturnValue(of(false));

      component.config = {
        handler,
        refresh: { isEnabled: true, page: 99 }
      };

      component['executeHandler']({});

      expect(handler).toHaveBeenCalled();
      expect(actionServiceMock.notifyActionSuccess).not.toHaveBeenCalled();
    });

    test('triggers refresh with default page 0 if page is undefined', () => {
      const handler = jest.fn().mockReturnValue(of(true));

      component.config = {
        handler,
        refresh: { isEnabled: true }
      };

      component['executeHandler']({ something: 'cool' });

      expect(actionServiceMock.notifyActionSuccess).toHaveBeenCalledWith(0);
    });

    test('does NOT trigger refresh if isEnabled is false', () => {
      const handler = jest.fn().mockReturnValue(of(true));

      component.config = {
        handler,
        refresh: { isEnabled: false, page: 5 }
      };

      component['executeHandler']({ test: 'x' });

      expect(actionServiceMock.notifyActionSuccess).not.toHaveBeenCalled();
    });
  });
});
