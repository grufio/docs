import { Observable } from 'rxjs';

/**
 * @description Configuration for a link facet.
 */
export type QdDataFacetsLinkConfig = {
  /**
   * @description The handler function triggered on link click.
   *
   * - Receives a context object with dynamic parameters.
   * - Can return `void` (synchronous) or an `Observable<boolean>` (asynchronous).
   */
  handler: (params: unknown) => QdDataFacetsLinkActionResult;

  /**
   * @description Configuration for triggering a table refresh after the action completes.
   */
  refresh?: QdDataFacetsLinkRefreshConfig;
};

/**
 * @description Result type of link action handler.
 *
 * - `void`: For synchronous actions.
 * - `Observable<boolean>`: For asynchronous actions:
 *   - Emits `true` if the action succeeds → triggers refresh.
 *   - Emits `false` if the action fails or is cancelled → no refresh.
 */
export type QdDataFacetsLinkActionResult = void | Observable<boolean>;

/**
 * @description Configuration options for refreshing the table after a link action.
 */
export interface QdDataFacetsLinkRefreshConfig {
  /**
   * @description If `true`, triggers a table refresh when the action completes successfully.
   *
   * - Requires a valid `handler` function and a table resolver to be set up.
   * - If omitted or `false`, no refresh is triggered.
   *
   * @default false
   */
  isEnabled?: boolean;

  /**
   * @description Page number to load when refreshing the table.
   *
   * - If specified, the table will jump to this page after the refresh.
   * - If omitted, the current page is preserved.
   *
   * @default current page
   */
  page?: number;
}
