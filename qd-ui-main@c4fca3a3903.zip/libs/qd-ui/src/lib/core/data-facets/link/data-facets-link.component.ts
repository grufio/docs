import { ChangeDetectionStrategy, Component, Input, Optional } from '@angular/core';
import { isObservable } from 'rxjs';

import { QdDataFacetsContextService } from '../data-facets-context.service';
import { QdTableExternalActionResultService } from '../../../table/services/external-action-result.service';
import { QdDataFacetsLinkConfig } from './data-facets-link.interfaces';

/**
 * @description Renders one or multiple links.
 * Click handler is parameterized using data from the context service.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-link',
  templateUrl: './data-facets-link.component.html',
  styleUrls: ['./data-facets-link.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsLinkComponent {
  @Input() config!: QdDataFacetsLinkConfig;
  @Input() data?: string | string[];
  @Input() testId?: string;

  get isList(): boolean {
    return Array.isArray(this.data);
  }

  constructor(
    @Optional() private readonly contextService: QdDataFacetsContextService,
    @Optional() private readonly actionService: QdTableExternalActionResultService
  ) {}

  handleLinkMultiAction(index: number, value: string, event: any): void {
    this.executeHandler({
      ...this.contextService?.getContext(),
      selectedValue: value,
      selectedIndex: index
    });

    event.stopPropagation();
  }

  handleLinkSingleAction(event: any): void {
    this.executeHandler({
      ...this.contextService?.getContext(),
      selectedValue: this.data
    });

    event.stopPropagation();
  }

  private executeHandler(params: unknown): void {
    const result = this.config.handler(params);

    if (!isObservable(result)) return;

    result.subscribe(success => {
      const shouldRefresh = success === true && this.config.refresh?.isEnabled;

      if (shouldRefresh) this.actionService?.notifyActionSuccess(this.config.refresh?.page ?? 0);
    });
  }
}
