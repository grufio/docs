import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { QdDataFacetsProgressComponent } from './data-facets-progress.component';

@Component({
  template: `<qd-data-facets-progress [testId]="testId"></qd-data-facets-progress>`
})
class TestComponent {
  testId = 'myTestId';
}

@Component({
  template: `<qd-data-facets-progress [data]="percentage"></qd-data-facets-progress>`
})
class TestComponentWithData {
  percentage = 60;
}

describe(`Testing ${QdDataFacetsProgressComponent.name} |`, () => {
  let component: QdDataFacetsProgressComponent;
  let fixture: ComponentFixture<QdDataFacetsProgressComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, TestComponentWithData, QdDataFacetsProgressComponent]
    }).compileComponents();
  }));

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  test('matches the snapshot without data', () => {
    createComponent(TestComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches the snapshot with data', () => {
    createComponent(TestComponentWithData);

    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
