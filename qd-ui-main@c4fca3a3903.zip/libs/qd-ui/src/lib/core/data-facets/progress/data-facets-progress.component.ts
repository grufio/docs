import { AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, Input } from '@angular/core';

/**
 * @description Renders a progress bar.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-progress',
  templateUrl: './data-facets-progress.component.html',
  styleUrls: ['./data-facets-progress.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsProgressComponent implements AfterViewInit {
  @Input() data?: number;
  @Input() testId?: string;

  constructor(private elementRef: ElementRef) {}

  ngAfterViewInit(): void {
    this.setProgress();
  }

  setProgress(): void {
    const element = this.elementRef.nativeElement.querySelector('.qd-data-facets-progress-bar-progress');

    element.setAttribute(`style`, `width: ${this.data ? this.data : 0}%`);
  }
}
