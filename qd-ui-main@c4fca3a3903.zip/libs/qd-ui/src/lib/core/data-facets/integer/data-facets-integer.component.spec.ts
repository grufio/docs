import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdDataFacetsIntegerComponent } from './data-facets-integer.component';

@Component({
  template: ` <qd-data-facets-integer [data]="data" [testId]="testId"></qd-data-facets-integer>`
})
class TestComponent {
  data = 4711;
  testId = 'myTestId';
}

describe(`Testing ${QdDataFacetsIntegerComponent.name} |`, () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, QdDataFacetsIntegerComponent]
    }).compileComponents();
  }));

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  test('matches the snapshot', () => {
    createComponent(TestComponent);

    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
