import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

/**
 * @description Renders a number/quantity.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-integer',
  templateUrl: './data-facets-integer.component.html',
  styleUrls: ['./data-facets-integer.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsIntegerComponent {
  @Input() data?: number;
  @Input() testId?: string;
}
