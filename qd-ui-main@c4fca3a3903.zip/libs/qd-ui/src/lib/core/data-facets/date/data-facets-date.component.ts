import { ChangeDetectionStrategy, Component, Input, OnChanges, OnDestroy, OnInit, Optional } from '@angular/core';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { getRelativeTime, Style } from '../../../helpers/relative-time.helper';
import { QdDataFacetsDateConfig } from './data-facets-date.interfaces';

/**
 * @description Renders a date and time.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-date',
  templateUrl: './data-facets-date.component.html',
  styleUrls: ['./data-facets-date.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsDateComponent implements OnInit, OnChanges, OnDestroy {
  @Input() config?: QdDataFacetsDateConfig;
  @Input() data?: string | number | Date;
  @Input() testId?: string;

  private _destroyed$ = new Subject<void>();
  private _locale!: string;
  private _displayedDateSubject = new ReplaySubject<string>(1);

  displayedDate$ = this._displayedDateSubject.asObservable();

  get relative(): boolean {
    return this.config?.isRelative || false;
  }

  constructor(@Optional() private translateService: TranslateService) {
    this.translateService?.onLangChange
      .pipe(takeUntil(this._destroyed$))
      .subscribe((event: LangChangeEvent) => this.setDisplayedDate(event.lang));
  }

  ngOnInit(): void {
    this.setDisplayedDate();
  }

  ngOnChanges(): void {
    this.setDisplayedDate();
  }

  ngOnDestroy(): void {
    this._destroyed$.complete();
  }

  setDisplayedDate(locale?: string): void {
    this._locale =
      locale || this.translateService?.currentLang || this.translateService?.defaultLang || navigator.language;
    this._displayedDateSubject.next(this.getDisplayedDate());
  }

  private getDisplayedDate(): string {
    if (this.data == null) return '';

    if (this.relative) return this.getRelativeTime(this.convertToDate(this.data));

    return this.getAbsoluteDate(this.convertToDate(this.data));
  }

  private getRelativeTime(date: Date): string {
    return getRelativeTime(date, this._locale, this.getRelativeTimeStyle(), this.config?.unitIfRelative || 'day');
  }

  private getRelativeTimeStyle(): Style {
    return this.config?.format && ['long', 'short', 'narrow'].includes(this.config.format)
      ? this.config.format
      : 'long';
  }

  private getAbsoluteDate(date: Date): string {
    const config: QdDataFacetsDateConfig = {
      ...(this.config || {}),
      hasTime: this.config?.hasTime ?? true
    };

    const dateTimeFormatOptions = {
      dateStyle: this.mapFormatToDateTimeStyle(config?.format),
      ...(config?.hasTime ? { timeStyle: this.mapFormatToDateTimeStyle(config?.format) } : {}),
      timeZone: config.timezone
    } as Intl.DateTimeFormatOptions;

    return new Intl.DateTimeFormat(this._locale, dateTimeFormatOptions).format(date);
  }

  private mapFormatToDateTimeStyle(format = 'long'): string {
    return { short: 'medium', narrow: 'short' }[format] || 'long';
  }

  private convertToDate(value: string | number | Date): Date {
    return Object.prototype.toString.call(value) === '[object Date]'
      ? (value as Date)
      : typeof value === 'number'
      ? new Date(value * 1000)
      : new Date(value);
  }
}
