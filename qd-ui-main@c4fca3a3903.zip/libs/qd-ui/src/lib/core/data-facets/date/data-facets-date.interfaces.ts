/**
 * @description Configuration options
 * The components supports formatting for strings, numbers or Date objects, providing multiple display options.
 */
export type QdDataFacetsDateConfig = {
  /**
   * @description Set the format to be used for date display.
   * * Note: Supports both the pre-defined format options (long, short, narrow) for relative time, and custom formats from Intl API for absolute Date/Time.
   *
   *  * @default: 'long'
   */
  format?: 'long' | 'short' | 'narrow';

  /**
   * @description Set the timezone to be used for date display.
   *
   * * @note Will be used for absolute time display using the Intl.DateTimeFormat.
   *
   * * If not provided, the timezone will be determined based on the user's browser settings.
   * * The provided timezone takes precedence over the timezone derived from the ISO string or numeric timestamp.
   * * If both ISO string/numeric timestamp and timezone are provided, the date will be formatted in the specified timezone.
   * * If only the ISO string/numeric timestamp is provided, it will be formatted in the user's local timezone or the browser's timezone.
   *
   * @default undefined
   */
  timezone?: string;

  /**
   * @description If "true", the value is used as relative time format.
   * * Note: When `isRelative` is set to `true`, the component utilizes the Intl.RelativeTimeFormat API for displaying relative time.
   *
   *  * @default: false
   */
  isRelative?: boolean;

  /**
   * @description The time unit to use when displaying relative time.
   *
   * * @note Possible values: "year", "quarter", "month", "week", "day", "hour", "minute", "second".This unit is determined by the Intl.RelativeTimeFormat API.
   *
   * * @default: "day"
   */
  unitIfRelative?: 'year' | 'quarter' | 'month' | 'week' | 'day' | 'hour' | 'minute' | 'second';

  /**
   * @description If "true", the time portion of the value is included in the display.
   *
   *  * @default: true
   */
  hasTime?: boolean;
};
