import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { MockProvider } from 'ng-mocks';
import { BehaviorSubject } from 'rxjs';

import { QdDataFacetsDateComponent } from './data-facets-date.component';

@Component({
  template: ` <qd-data-facets-date [config]="config" [data]="data" [testId]="testId"></qd-data-facets-date>`
})
class TestComponent {
  data: string | number | Date;
  config = {};
  testId = 'myTestId';
}

const absoluteDataProvider = [
  {
    description: 'default format with date input',
    data: new Date('1900-02-08T12:30:00'),
    config: {},
    expectedDisplayedDate: '8. Februar 1900 um 12:30:00 UTC',
    expectedDisplayedDateForEnglish: 'February 8, 1900 at 12:30:00 PM UTC'
  },
  {
    description: 'date input as ISO string with time',
    data: new Date(1699766400),
    config: { hasTime: true },
    expectedDisplayedDate: '20. Januar 1970 um 16:09:26 UTC',
    expectedDisplayedDateForEnglish: 'January 20, 1970 at 4:09:26 PM UTC'
  },
  {
    description: 'date input as ISO string without time',
    data: new Date(1699766400),
    config: { hasTime: false },
    expectedDisplayedDate: '20. Januar 1970',
    expectedDisplayedDateForEnglish: 'January 20, 1970'
  },
  {
    description: 'date input as string with custom format',
    data: new Date(1699766400),
    config: { format: 'long' },
    expectedDisplayedDate: '20. Januar 1970 um 16:09:26 UTC',
    expectedDisplayedDateForEnglish: 'January 20, 1970 at 4:09:26 PM UTC'
  },
  {
    description: 'date input as number with custom format',
    data: new Date(1699766400),
    config: { format: 'narrow' },
    expectedDisplayedDate: '20.01.70, 16:09',
    expectedDisplayedDateForEnglish: '1/20/70, 4:09 PM'
  },
  {
    description: 'numeric date input with default format',
    data: 1699766400,
    config: {},
    expectedDisplayedDate: '12. November 2023 um 05:20:00 UTC',
    expectedDisplayedDateForEnglish: 'November 12, 2023 at 5:20:00 AM UTC'
  },
  {
    description: 'date input as ISO string with default format',
    data: '2024-02-08T12:30:00',
    config: {},
    expectedDisplayedDate: '8. Februar 2024 um 12:30:00 UTC',
    expectedDisplayedDateForEnglish: 'February 8, 2024 at 12:30:00 PM UTC'
  }
];

const relativeDataProvider = [
  {
    description: 'input as Date with default format',
    data: new Date('2024-01-10T10:00:00'),
    config: { isRelative: true },
    expectedDisplayedDate: 'in 9 Tagen',
    expectedDisplayedDateForEnglish: 'in 9 days'
  },
  {
    description: 'input as Date with long format',
    data: new Date('2024-01-10T10:00:00'),
    config: { format: 'long', isRelative: true },
    expectedDisplayedDate: 'in 9 Tagen',
    expectedDisplayedDateForEnglish: 'in 9 days'
  },
  {
    description: 'input as Date with short format',
    data: new Date('2024-01-10T10:00:00'),
    config: { format: 'short', isRelative: true },
    expectedDisplayedDate: 'in 9 Tagen',
    expectedDisplayedDateForEnglish: 'in 9 days'
  },
  {
    description: 'input as number',
    data: new Date(1699766400),
    config: { isRelative: true },
    expectedDisplayedDate: 'vor 19.704 Tagen',
    expectedDisplayedDateForEnglish: '19,704 days ago'
  },
  {
    description: 'input as string',
    data: '2024-01-10T10:00:00',
    config: { isRelative: true },
    expectedDisplayedDate: 'in 9 Tagen',
    expectedDisplayedDateForEnglish: 'in 9 days'
  },
  {
    description: 'input as Date with past date and time (unitIfRelative: year)',
    data: new Date('2021-01-10T14:00:00'),
    config: { isRelative: true, unitIfRelative: 'year' },
    expectedDisplayedDate: 'vor 3 Jahren',
    expectedDisplayedDateForEnglish: '3 years ago'
  },
  {
    description: 'input as Date with future date and time (unitIfRelative: hour)',
    data: new Date('2024-01-10T14:00:00'),
    config: { isRelative: true, unitIfRelative: 'hour' },
    expectedDisplayedDate: 'in 220 Stunden',
    expectedDisplayedDateForEnglish: 'in 220 hours'
  },
  {
    description: 'input as Date with future date and time (unitIfRelative: minute)',
    data: new Date('2024-01-10T14:00:00'),
    config: { isRelative: true, unitIfRelative: 'minute' },
    expectedDisplayedDate: 'in 13.200 Minuten',
    expectedDisplayedDateForEnglish: 'in 13,200 minutes'
  }
];

describe(`Testing ${QdDataFacetsDateComponent.name} | `, () => {
  let translateService: TranslateService;
  let fixture;
  let component;

  function createComponent(componentClass, useTranslateService = true): void {
    TestBed.configureTestingModule({
      declarations: [TestComponent, QdDataFacetsDateComponent],
      providers: useTranslateService
        ? [
            MockProvider(TranslateService, {
              defaultLang: 'de' as any,
              onLangChange: new BehaviorSubject('de') as any
            })
          ]
        : null
    }).compileComponents();

    if (useTranslateService) translateService = TestBed.inject(TranslateService);

    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
  }

  function getContent(): string {
    // eslint-disable-next-line no-irregular-whitespace
    return fixture.debugElement.nativeElement.textContent.trim().replace(/[  ]/g, ' ');
  }

  describe('date type is absolute:', () => {
    absoluteDataProvider.forEach(
      ({ description, data, config, expectedDisplayedDate, expectedDisplayedDateForEnglish }) => {
        test(description, () => {
          createComponent(TestComponent);

          component.data = data;
          // Pipeline Fix!
          component.config = { ...config, timezone: 'UTC' };

          fixture.detectChanges();

          expect(fixture.nativeElement).toMatchSnapshot();
          expect(getContent()).toBe(expectedDisplayedDate);

          translateService.onLangChange.next({ lang: 'en', translations: {} });
          fixture.detectChanges();

          expect(getContent()).toBe(expectedDisplayedDateForEnglish);
        });
      }
    );
  });

  describe('date type is relative:', () => {
    beforeEach(() => {
      jest.useFakeTimers();
      jest.setSystemTime(new Date('2024-01-01T10:00:00'));
    });

    relativeDataProvider.forEach(
      ({ description, data, config, expectedDisplayedDate, expectedDisplayedDateForEnglish }) => {
        test(description, () => {
          createComponent(TestComponent);

          component.data = data;
          component.config = config;

          fixture.detectChanges();

          expect(fixture.nativeElement).toMatchSnapshot();
          expect(getContent()).toBe(expectedDisplayedDate);

          translateService.onLangChange.next({ lang: 'en', translations: {} });
          fixture.detectChanges();

          expect(fixture.nativeElement).toMatchSnapshot();
          expect(getContent()).toBe(expectedDisplayedDateForEnglish);
        });
      }
    );
  });

  describe('react to changes:', () => {
    test('updates data', () => {
      createComponent(TestComponent);

      component.data = new Date('2024-01-10T14:00:00');
      component.config = { isRelative: true, unitIfRelative: 'hour' };

      fixture.detectChanges();
      expect(getContent()).toBe('in 220 Stunden');

      component.data = new Date('2024-01-11T14:00:00');
      fixture.detectChanges();

      expect(getContent()).toBe('in 244 Stunden');
    });

    test('updates config', () => {
      createComponent(TestComponent);

      component.data = new Date('2024-01-10T14:00:00');
      component.config = { isRelative: true, unitIfRelative: 'hour' };

      fixture.detectChanges();
      expect(getContent()).toBe('in 220 Stunden');

      component.config = { isRelative: true, unitIfRelative: 'day' };
      fixture.detectChanges();

      expect(getContent()).toBe('in 9 Tagen');
    });

    test('updates localisation', () => {
      createComponent(TestComponent);

      component.data = new Date('2024-01-10T14:00:00');
      component.config = { isRelative: true, unitIfRelative: 'hour' };

      fixture.detectChanges();
      expect(getContent()).toBe('in 220 Stunden');

      translateService.onLangChange.next({ lang: 'fr' } as any);
      fixture.detectChanges();

      expect(getContent()).toBe('dans 220 heures');
    });
  });

  describe('without translate service', () => {
    test('uses navigator language', () => {
      jest.spyOn(window.navigator, 'language', 'get').mockReturnValue('fr');

      createComponent(TestComponent, false);

      component.data = new Date('2024-01-10T14:00:00');
      component.config = { isRelative: true, unitIfRelative: 'hour' };

      fixture.detectChanges();

      expect(getContent()).toBe('dans 220 heures');
    });
  });

  describe('config is undefined:', () => {
    test('renders default representation', () => {
      createComponent(TestComponent);

      component.data = new Date('2024-01-10T14:00:00');
      component.config = undefined;

      fixture.detectChanges();

      expect(getContent()).toBe('10. Januar 2024 um 14:00:00 UTC');
    });
  });

  describe('data is undefined:', () => {
    test('renders empty string', () => {
      createComponent(QdDataFacetsDateComponent);

      component.data = undefined;
      component.config = { format: 'short', isRelative: true };

      fixture.detectChanges();

      expect(getContent()).toBe('');
    });
  });

  describe('data is null:', () => {
    test('renders empty string', () => {
      createComponent(QdDataFacetsDateComponent);

      component.data = null;
      component.config = { format: 'short', isRelative: true };

      fixture.detectChanges();

      expect(getContent()).toBe('');
    });
  });
});
