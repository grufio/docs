import { QdChipColor } from '../../../chips/chips.module';

/**
 * @description defines the config.
 */
export interface QdDataFacetsChipConfig {
  /**
   * @description If "true", the value is used as i18n key segment.
   *
   *  * @default: false
   */
  isTranslated?: boolean;

  /**
   * @description With this mapping you can define the chip level for each label.
   */
  levelMapping?: {
    [label: string]: QdChipColor;
  };

  /**
   * @description Maximum number of chips that will be displayed in the cell.
   * If this number is exceeded, a small chip with the number of exceeding chips will be displayed.
   * When this small chip is hovered or tapped, the truncated chips will be displayed in a tooltip.
   *
   * @default null (unlimited)
   */
  maxChipCount?: number;
}

/**
 * @description Type definition for data
 */
export type QdDataFacetsChipData =
  | string
  | string[]
  | QdDataFacetsChipDataObject
  | (QdDataFacetsChipDataObject | string)[];

/**
 * @description object variant for data
 */
export type QdDataFacetsChipDataObject = {
  /**
   * @description label to display
   */
  label: string;

  /**
   * @description level of the chip, represents the chip color
   */
  level: QdChipColor;
};
