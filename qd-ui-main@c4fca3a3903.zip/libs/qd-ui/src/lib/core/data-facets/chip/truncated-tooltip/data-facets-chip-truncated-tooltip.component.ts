import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  HostBinding,
  Input,
  OnChanges,
  OnDestroy,
  SimpleChanges
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { debounceTime } from 'rxjs/operators';
import { fromEvent, merge, Subject, Subscription } from 'rxjs';
import { OverlayRef } from '@angular/cdk/overlay';
import isNumber from 'lodash/isNumber';

import { QdElementService } from '../../../../core/services/element.service';
import { QdDataFacetsChipConfig, QdDataFacetsChipDataObject } from '../data-facets-chip.interfaces';

const TOOLTIP_MIN_MAX_WIDTH = 320;

@Component({
  selector: 'qd-data-facets-chip-truncated-tooltip',
  templateUrl: './data-facets-chip-truncated-tooltip.component.html',
  styleUrls: ['./data-facets-chip-truncated-tooltip.component.scss']
})
export class QdDataFacetsChipTruncatedTooltipComponent implements AfterViewInit, OnChanges, OnDestroy {
  @Input() truncatedChips!: QdDataFacetsChipDataObject[];
  @Input() i18n!: string;
  @Input() columnOptions!: QdDataFacetsChipConfig;
  @Input() overlayRef!: OverlayRef;

  @HostBinding('style.maxWidth') get styleMaxWidth(): string {
    return this.maxWidth + 'px';
  }

  @HostBinding('style.visibility') get styleVisibility(): string {
    return this.visibility;
  }

  private get element(): HTMLElement {
    return this.hostRef.nativeElement;
  }

  maxWidth = TOOLTIP_MIN_MAX_WIDTH;
  visibility = 'hidden';
  closable = false;

  private changesSubject = new Subject<void>();
  private adjustWidthSubscription!: Subscription;

  constructor(
    private readonly hostRef: ElementRef<HTMLElement>,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly translateService: TranslateService,
    private readonly elementService: QdElementService
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (
      changes['truncatedChips']?.isFirstChange() === false ||
      changes['i18n']?.isFirstChange() === false ||
      changes['columnOptions']?.isFirstChange() === false
    ) {
      this.changesSubject.next();
    }
  }

  ngOnDestroy(): void {
    this.adjustWidthSubscription?.unsubscribe();
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.adjustWidthToFitInViewport();
      this.visibility = 'visible';
    }, 1);

    this.adjustWidthSubscription = merge(
      this.changesSubject,
      this.translateService.onLangChange,
      fromEvent(window, 'resize')
    )
      .pipe(debounceTime(100))
      .subscribe(() => this.adjustWidthToFitInViewport());
  }

  close(): void {
    this.overlayRef.detach();
  }

  private adjustWidthToFitInViewport(): void {
    const viewportWidth = document.documentElement.clientWidth;
    if (!isNumber(viewportWidth)) return;

    /* The tooltip has a max width. If the tooltip overlaps the viewport this max width
     * will be increased so that the tooltip fits into the viewport.
     * When the width is readjusted (e.g. after window resize or content change) the max width
     * will be decreased again until there is an overlapping again. After that it will
     * be increased again (one step) to fix the overlapping. In this way, the width is
     * only increased as much as is necessary. The maximum width will
     * not be reduced further than the minimum (initial) maximum width.
     */
    this.decreaseWidthIfNotExceeded();
    this.increaseWidthIfExceeded(viewportWidth);

    this.maxWidth = this.getElementMaxWidth();
    this.overlayRef.updatePosition();

    this.closable = this.isFillingMoreThanHalfScreenSize();
    this.changeDetectorRef.detectChanges();
  }

  private decreaseWidthIfNotExceeded(): void {
    let maxWidth = this.getElementMaxWidth();

    while (!this.isOverflown() && maxWidth > TOOLTIP_MIN_MAX_WIDTH) {
      maxWidth = Math.max(maxWidth - 10, TOOLTIP_MIN_MAX_WIDTH);
      // set element width directly here to prevent rendering, width will finally also be set with angular
      this.setElementMaxWidth(maxWidth);
      this.overlayRef.updatePosition();
    }
  }

  private increaseWidthIfExceeded(viewportWidth: number): void {
    let maxWidth = this.getElementMaxWidth();

    while (this.isOverflown() && maxWidth < viewportWidth) {
      maxWidth = Math.min(maxWidth + 10, viewportWidth);
      // set element width directly here to prevent rendering, width will finally also be set with angular
      this.setElementMaxWidth(maxWidth);
      this.overlayRef.updatePosition();
    }
  }

  private isOverflown(): boolean {
    return this.elementService.isOverflown(this.element);
  }

  private setElementMaxWidth(maxWidth: number): void {
    this.element.style.maxWidth = maxWidth + 'px';
  }

  private getElementMaxWidth(): number {
    return parseInt(this.element.style.maxWidth);
  }

  private isFillingMoreThanHalfScreenSize(): boolean {
    const viewPortSize = document.documentElement.clientWidth * document.documentElement.clientHeight;
    const tooltipRect = this.element.getBoundingClientRect();
    const tooltipSize = tooltipRect.width * tooltipRect.height;

    return tooltipSize / viewPortSize > 0.5;
  }
}
