import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QdMockTranslatePipe } from '../../../core/__mocks__/mock-translate.pipe';
import { QdMockChipModule } from './../../../chips/__mocks__/mock-chips.module';
import { QdDataFacetsChipComponent } from './data-facets-chip.component';

describe(`Testing ${QdDataFacetsChipComponent.name} |`, () => {
  let component: QdDataFacetsChipComponent;
  let fixture: ComponentFixture<QdDataFacetsChipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [QdDataFacetsChipComponent, QdMockTranslatePipe],
      imports: [QdMockChipModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QdDataFacetsChipComponent);
    component = fixture.componentInstance;
  });

  test('matches snapshot with a string.', () => {
    component.data = 'a sting';
    component.config = {};

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with an object.', () => {
    component.data = { label: 'my label', level: 'warning' };
    component.config = {};

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with multiple chips.', () => {
    component.data = ['ABC', 'DEF', { label: 'GHJ', level: 'archive' }];
    component.config = {};

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with content translation & a string.', () => {
    component.data = 'STRING_TO_TRANSLATE';
    component.config = { isTranslated: true };
    component.i18n = 'i18n.translations';

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with content translation & an object.', () => {
    component.data = { label: 'LABEL_TO_TRANSLATE', level: 'warning' };
    component.config = { isTranslated: true };
    component.i18n = 'i18n.translations';

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with content translation & multiple chips.', () => {
    component.data = ['STRING_TO_TRANSLATE', 'STRING_TO_TRANSLATE', { label: 'LABEL_TO_TRANSLATE', level: 'archive' }];
    component.config = { isTranslated: true };
    component.i18n = 'i18n.translations';

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with levelMapping & multiple chips.', () => {
    component.data = ['ABC', 'DEF', { label: 'GHJ', level: 'archive' }, { label: 'IKL', level: 'archive' }];
    component.config = {
      levelMapping: {
        ABC: 'error',
        DEF: 'warning',
        IKL: 'success'
      }
    };

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with undefined data.', () => {
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with changed data.', () => {
    component.data = [];
    component.config = {};

    fixture.detectChanges();

    component.data = ['ABC', 'DEF', { label: 'GHJ', level: 'archive' }, { label: 'IKL', level: 'archive' }];
    component.config = {
      levelMapping: {
        ABC: 'error',
        DEF: 'warning',
        IKL: 'success'
      }
    };

    component.ngOnChanges();
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
