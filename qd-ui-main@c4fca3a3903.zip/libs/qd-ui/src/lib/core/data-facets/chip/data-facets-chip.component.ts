// @ts-strict-ignore
import { ChangeDetectionStrategy, Component, Input, OnChanges, OnInit } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';

import {
  QdDataFacetsChipConfig,
  QdDataFacetsChipData,
  QdDataFacetsChipDataObject
} from './data-facets-chip.interfaces';

import { chipColorDefault } from '../../../chips/interfaces/chip.interface';
import { QdTableContentDataChipObject } from '../../../table/model/table-data.interface';
import { map } from 'rxjs/operators';

/**
 * @description Renders one or multiple chips.
 *
 * * Note: The content type "chip" can handle a single chip or an array of chips. A chip can be a simple string or an object of the form { label: string; level: QdChipColor }.
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-chip',
  templateUrl: './data-facets-chip.component.html',
  styleUrls: ['./data-facets-chip.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsChipComponent implements OnInit, OnChanges {
  @Input() config: QdDataFacetsChipConfig;
  @Input() data: QdDataFacetsChipData;
  @Input() i18n: string;
  @Input() testId?: string;

  private _chipsSubject = new ReplaySubject<QdDataFacetsChipDataObject[]>(1);

  chips$!: Observable<QdDataFacetsChipDataObject[]>;
  truncatedChips$!: Observable<QdTableContentDataChipObject[]>;

  get maxChipCount(): number {
    return this.config?.maxChipCount ?? Number.MAX_SAFE_INTEGER;
  }

  ngOnInit(): void {
    this.chips$ = this._chipsSubject.pipe(map(chips => chips.slice(0, this.maxChipCount)));
    this.truncatedChips$ = this._chipsSubject.pipe(map(chips => chips.slice(this.maxChipCount)));

    this.setChips();
  }

  ngOnChanges(): void {
    this.setChips();
  }

  private setChips(): void {
    this._chipsSubject.next(this.getChips());
  }

  private getChips(): QdDataFacetsChipDataObject[] {
    if (!this.data) return [];

    const chips = Array.isArray(this.data) ? this.data : [this.data];

    return chips.map(chip => ({
      label: (chip as any).label ?? chip,
      level: this.config?.levelMapping?.[(chip as any).label ?? chip] || (chip as any).level || chipColorDefault
    }));
  }
}
