import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges
} from '@angular/core';
import { debounceTime } from 'rxjs/operators';
import { fromEvent, merge, Subscription } from 'rxjs';
import { ComponentPortal } from '@angular/cdk/portal';
import { Overlay, OverlayPositionBuilder, OverlayRef } from '@angular/cdk/overlay';

import { QdDataFacetsChipConfig, QdDataFacetsChipDataObject } from '../data-facets-chip.interfaces';
import { QdDataFacetsChipTruncatedTooltipComponent } from '../truncated-tooltip/data-facets-chip-truncated-tooltip.component';

export const HIDE_DELAY = 300;

@Component({
  selector: 'qd-data-facets-chip-truncated-indicator',
  templateUrl: './data-facets-chip-truncated-indicator.component.html',
  styleUrls: ['./data-facets-chip-truncated-indicator.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsChipTruncatedIndicatorComponent implements OnInit, OnChanges, OnDestroy {
  @Input() truncatedChips: QdDataFacetsChipDataObject[] = [];
  @Input() i18n!: string;
  @Input() columnOptions!: QdDataFacetsChipConfig;

  private readonly hostElement: HTMLElement;
  private overlayRef!: OverlayRef;
  private readonly showEvents = ['mouseenter', 'mousemove'];
  private showTooltipSubscription!: Subscription;
  private hideTooltipSubscription!: Subscription;
  private tooltipComponent!: QdDataFacetsChipTruncatedTooltipComponent | undefined;

  constructor(
    private readonly hostRef: ElementRef<HTMLElement>,
    private readonly overlayPositionBuilder: OverlayPositionBuilder,
    private readonly overlay: Overlay
  ) {
    this.hostElement = this.hostRef.nativeElement;
  }

  ngOnInit(): void {
    this.overlayRef = this.overlay.create({
      positionStrategy: this.overlayPositionBuilder
        .flexibleConnectedTo(this.hostElement)
        .withPositions([{ originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'top' }]),
      scrollStrategy: this.overlay.scrollStrategies.reposition()
    });

    this.subscribeShowTooltip();
    this.subscribeHideTooltip();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      changes['truncatedChips']?.isFirstChange() === false ||
      changes['i18n']?.isFirstChange() === false ||
      changes['columnOptions']?.isFirstChange() === false
    ) {
      this.setTooltipComponentProperties();
    }
  }

  ngOnDestroy(): void {
    this.showTooltipSubscription?.unsubscribe();
    this.hideTooltipSubscription?.unsubscribe();
    this.hideTooltip();
  }

  private subscribeShowTooltip(): void {
    this.showTooltipSubscription = merge(
      ...this.showEvents.map(event => fromEvent(this.hostElement, event)),
      ...this.showEvents.map(event => fromEvent(this.overlayRef.hostElement, event))
    ).subscribe(() => {
      this.hideTooltipSubscription?.unsubscribe();
      this.subscribeHideTooltip();

      this.showTooltip();
    });
  }

  private showTooltip(): void {
    if (this.overlayRef.hasAttached()) return;

    this.tooltipComponent = this.overlayRef.attach(
      new ComponentPortal(QdDataFacetsChipTruncatedTooltipComponent)
    ).instance;
    this.setTooltipComponentProperties();
  }

  private setTooltipComponentProperties(): void {
    if (!this.overlayRef.hasAttached() || !this.tooltipComponent) return;

    this.tooltipComponent.truncatedChips = this.truncatedChips;
    this.tooltipComponent.i18n = this.i18n;
    this.tooltipComponent.columnOptions = this.columnOptions;
    this.tooltipComponent.overlayRef = this.overlayRef;
  }

  private subscribeHideTooltip(): void {
    this.hideTooltipSubscription = merge(
      fromEvent(this.hostElement, 'mouseleave'),
      fromEvent(this.overlayRef.hostElement, 'mouseleave')
    )
      .pipe(debounceTime(HIDE_DELAY))
      .subscribe(() => this.hideTooltip());
  }

  private hideTooltip(): void {
    if (!this.overlayRef.hasAttached()) return;

    this.tooltipComponent = undefined;
    this.overlayRef.detach();
  }
}
