import { SimpleChange, SimpleChanges } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NgForOf } from '@angular/common';
import { Overlay, RepositionScrollStrategy } from '@angular/cdk/overlay';
import { TranslatePipe } from '@ngx-translate/core';
import cloneDeep from 'lodash/cloneDeep';
import { MockComponent, MockPipe } from 'ng-mocks';

import { QdChipComponent } from '../../../../chips/chip/chip.component';
import { QdDataFacetsChipTruncatedIndicatorComponent } from './data-facets-chip-truncated-indicator.component';
import { QdDataFacetsChipTruncatedTooltipComponent } from '../truncated-tooltip/data-facets-chip-truncated-tooltip.component';

describe(`Testing ${QdDataFacetsChipTruncatedIndicatorComponent.name} |`, () => {
  let component: QdDataFacetsChipTruncatedIndicatorComponent;
  let fixture: ComponentFixture<QdDataFacetsChipTruncatedIndicatorComponent>;
  const overlayComponentMock = {};
  const overlay = {
    create: jest.fn(() => overlayRef),
    scrollStrategies: {
      reposition: () => new RepositionScrollStrategy(null, null, null, null)
    }
  };
  const overlayRef = {
    hostElement: document.createElement('div'),
    hasAttached: jest.fn(),
    attach: jest.fn(function () {
      this.hasAttached.mockReturnValue(true);
      return { instance: overlayComponentMock };
    }),
    detach: jest.fn()
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        QdDataFacetsChipTruncatedIndicatorComponent,
        MockComponent(QdChipComponent),
        MockComponent(QdDataFacetsChipTruncatedTooltipComponent),
        MockPipe(TranslatePipe, i18n => (i18n ? 'Fake translation: ' + i18n : ''))
      ],
      providers: [
        {
          provide: Overlay,
          useValue: overlay
        }
      ],
      imports: [NgForOf]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QdDataFacetsChipTruncatedIndicatorComponent);
    component = fixture.componentInstance;
    overlayRef.hasAttached.mockReturnValue(false);
  });

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
  });

  test('nothing is rendered if no chips are given.', () => {
    component.truncatedChips = [];
    component.columnOptions = {};

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('number of chips is rendered correctly.', () => {
    component.truncatedChips = [
      { label: 'ABC', level: 'inProcess' },
      { label: 'DEF', level: 'inProcess' },
      { label: 'GHJ', level: 'archive' }
    ];
    component.columnOptions = {};

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('overlay tooltip is prepared correctly.', () => {
    fixture.detectChanges();

    expect(overlay.create).toHaveBeenCalledWith(
      expect.objectContaining({
        positionStrategy: expect.objectContaining({
          _preferredPositions: [{ originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'top' }]
        }),
        scrollStrategy: expect.any(RepositionScrollStrategy)
      })
    );
  });

  const showTooltipCases = [{ eventName: 'mouseenter' }, { eventName: 'mousemove' }];
  test.each(showTooltipCases)(
    'opens tooltip overlay with truncated chips on $eventName on indicator.',
    ({ eventName }) => {
      component.truncatedChips = [
        { label: 'ABC', level: 'inProcess' },
        { label: 'DEF', level: 'inProcess' },
        { label: 'GHJ', level: 'archive' }
      ];
      component.i18n = 'i18n.translations';
      component.columnOptions = {};

      fixture.detectChanges();

      fixture.nativeElement.dispatchEvent(new Event(eventName));

      expect(overlayRef.attach).toHaveBeenCalledWith(
        expect.objectContaining({
          component: QdDataFacetsChipTruncatedTooltipComponent
        })
      );
      expect(overlayComponentMock).toEqual({
        truncatedChips: component.truncatedChips,
        i18n: component.i18n,
        columnOptions: component.columnOptions,
        overlayRef
      });
    }
  );

  test.each(showTooltipCases)('does not open tooltip overlay on $eventName if already open.', ({ eventName }) => {
    overlayRef.hasAttached.mockReturnValue(true);

    fixture.detectChanges();

    fixture.nativeElement.dispatchEvent(new Event(eventName));

    expect(overlayRef.attach).not.toHaveBeenCalled();
  });

  test('closes overlay on indicator chip mouseleave after 300ms delay.', () => {
    fixture.detectChanges();

    fixture.nativeElement.dispatchEvent(new Event('mouseenter'));

    fixture.nativeElement.dispatchEvent(new Event('mouseleave'));
    jest.advanceTimersByTime(300);

    expect(overlayRef.detach).toHaveBeenCalled();
  });

  test('closes overlay on tooltip mouseleave after 300ms delay.', () => {
    fixture.detectChanges();

    fixture.nativeElement.dispatchEvent(new Event('mouseenter'));

    overlayRef.hostElement.dispatchEvent(new Event('mouseleave'));
    jest.advanceTimersByTime(300);

    expect(overlayRef.detach).toHaveBeenCalled();
  });

  test('keeps overlay open if there is another mouseenter/mousemove event during the 300ms closing delay.', () => {
    fixture.detectChanges();

    fixture.nativeElement.dispatchEvent(new Event('mouseenter'));

    overlayRef.hostElement.dispatchEvent(new Event('mouseleave'));
    jest.advanceTimersByTime(299);
    overlayRef.hostElement.dispatchEvent(new Event('mouseenter'));
    jest.advanceTimersByTime(1);
    overlayRef.hostElement.dispatchEvent(new Event('mouseleave'));
    fixture.nativeElement.dispatchEvent(new Event('mouseenter'));
    jest.advanceTimersByTime(300);

    expect(overlayRef.detach).not.toHaveBeenCalled();
  });

  const changedPropertiesCases = [
    {
      changedPropertyName: 'truncatedChips',
      newPropertyValue: [{ label: 'ABC', level: 'inProcess' }]
    },
    {
      changedPropertyName: 'i18n',
      newPropertyValue: 'i18n.translations.new'
    },
    {
      changedPropertyName: 'columnOptions',
      newPropertyValue: { isTranslated: true }
    }
  ];

  test.each(changedPropertiesCases)(
    'property $changedPropertyName is updated correctly',
    ({ changedPropertyName, newPropertyValue }) => {
      component.truncatedChips = [
        { label: 'ABC', level: 'inProcess' },
        { label: 'DEF', level: 'inProcess' },
        { label: 'GHJ', level: 'archive' }
      ];
      component.i18n = 'i18n.translations';
      component.columnOptions = {};

      fixture.detectChanges();

      fixture.nativeElement.dispatchEvent(new Event('mouseenter'));

      expect(overlayRef.attach).toHaveBeenCalled();

      expect(overlayComponentMock).toEqual({
        truncatedChips: component.truncatedChips,
        i18n: component.i18n,
        columnOptions: component.columnOptions,
        overlayRef
      });

      const simpleChanges: Partial<SimpleChanges> = {
        [changedPropertyName]: {
          isFirstChange: () => false,
          firstChange: false,
          previousValue: cloneDeep(component[changedPropertyName])
        } as SimpleChange
      };

      component[changedPropertyName] = newPropertyValue;
      simpleChanges[changedPropertyName].currentValue = component[changedPropertyName];

      component.ngOnChanges(simpleChanges);
      fixture.detectChanges();

      expect(overlayComponentMock).toEqual({
        truncatedChips: component.truncatedChips,
        i18n: component.i18n,
        columnOptions: component.columnOptions,
        overlayRef
      });
    }
  );

  test('no error occurs if properties are updated but tooltip is closed', () => {
    component.truncatedChips = [
      { label: 'ABC', level: 'inProcess' },
      { label: 'DEF', level: 'inProcess' },
      { label: 'GHJ', level: 'archive' }
    ];
    component.i18n = 'i18n.translations';
    component.columnOptions = {};

    fixture.detectChanges();

    const simpleChanges: Partial<SimpleChanges> = {
      truncatedChips: {
        isFirstChange: () => false,
        firstChange: false,
        previousValue: cloneDeep(component.truncatedChips)
      } as SimpleChange
    };

    component.truncatedChips = [{ label: 'ABC', level: 'inProcess' }];
    simpleChanges.truncatedChips.currentValue = component.truncatedChips;

    expect(() => {
      component.ngOnChanges(simpleChanges);
      fixture.detectChanges();
    }).not.toThrow();
  });

  test('tooltip is closed when component is destroyed', () => {
    fixture.detectChanges();

    fixture.nativeElement.dispatchEvent(new Event('mouseenter'));

    expect(overlayRef.detach).not.toHaveBeenCalled();

    component.ngOnDestroy();

    expect(overlayRef.detach).toHaveBeenCalled();
  });
});
