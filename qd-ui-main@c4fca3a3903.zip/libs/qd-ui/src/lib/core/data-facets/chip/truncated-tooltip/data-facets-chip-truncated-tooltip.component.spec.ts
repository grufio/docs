import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { EventEmitter, SimpleChange, SimpleChanges } from '@angular/core';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import cloneDeep from 'lodash/cloneDeep';
import { MockComponent, MockPipe, MockProvider } from 'ng-mocks';

import { QdChipComponent } from '../../../../chips/chip/chip.component';
import { QdIconComponent } from '../../../../icon/icon/icon.component';
import { QdElementService } from '../../../../core/services/element.service';
import { QdDataFacetsChipTruncatedTooltipComponent } from './data-facets-chip-truncated-tooltip.component';

describe(`Testing ${QdDataFacetsChipTruncatedTooltipComponent.name} |`, () => {
  let component: QdDataFacetsChipTruncatedTooltipComponent;
  let fixture: ComponentFixture<QdDataFacetsChipTruncatedTooltipComponent>;
  let elementService;
  let translateService;
  const overlayRef = {
    detach: jest.fn(),
    updatePosition: jest.fn()
  };

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        QdDataFacetsChipTruncatedTooltipComponent,
        MockComponent(QdChipComponent),
        MockComponent(QdIconComponent),
        MockPipe(TranslatePipe, i18n => (i18n ? 'Fake translation: ' + i18n : ''))
      ],
      providers: [
        MockProvider(TranslateService, { onLangChange: new EventEmitter() }),
        MockProvider(QdElementService, { isOverflown: jest.fn() })
      ]
    }).compileComponents();
    elementService = TestBed.inject(QdElementService);
    elementService.isOverflown.mockReturnValue(false);
    translateService = TestBed.inject(TranslateService);
  }));

  beforeEach(async () => {
    fixture = TestBed.createComponent(QdDataFacetsChipTruncatedTooltipComponent);
    component = fixture.componentInstance;
    component.overlayRef = overlayRef as any;
  });

  beforeEach(() => {
    Object.defineProperty(document.documentElement, 'clientWidth', { value: 1280, writable: true });
    Object.defineProperty(document.documentElement, 'clientHeight', { value: 720, writable: true });
  });

  async function wait(milliseconds: number): Promise<void> {
    fixture.detectChanges();
    await new Promise(resolve => setTimeout(resolve, milliseconds));
    fixture.detectChanges();
  }

  test('matches snapshot with multiple chips.', async () => {
    component.truncatedChips = [
      { label: 'ABC', level: 'inProcess' },
      { label: 'DEF', level: 'inProcess' },
      { label: 'GHJ', level: 'archive' }
    ];
    component.columnOptions = {};

    await wait(1);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('chip properties are passed correctly with multiple chips.', () => {
    component.truncatedChips = [
      { label: 'ABC', level: 'inProcess' },
      { label: 'DEF', level: 'inProcess' },
      { label: 'GHJ', level: 'archive' }
    ];
    component.columnOptions = {};

    fixture.detectChanges();

    expect(fixture.debugElement.queryAll(By.directive(QdChipComponent)).map(d => d.componentInstance.state)).toEqual([
      'inProcess',
      'inProcess',
      'archive'
    ]);
  });

  test('matches snapshot with content translation & multiple chips.', async () => {
    component.truncatedChips = [
      { label: 'STRING_TO_TRANSLATE', level: 'inProcess' },
      { label: 'STRING_TO_TRANSLATE', level: 'inProcess' },
      { label: 'LABEL_TO_TRANSLATE', level: 'archive' }
    ];
    component.columnOptions = { isTranslated: true };
    component.i18n = 'i18n.translations';

    await wait(1);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches snapshot with undefined truncatedChips.', async () => {
    await wait(1);

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('adjusts maxWidth to fit viewport if exceeded (10px steps)', async () => {
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 1001;
    });

    await wait(1);

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');
  });

  test(
    'does not increase maxWidth more than viewport width if overflow can not be resolved ' +
      '(scrollbar will be displayed)',
    async () => {
      elementService.isOverflown.mockImplementation(() => true);

      await wait(1);

      expect(fixture.nativeElement.style.maxWidth).toBe('1280px');
    }
  );

  test('reduces maxWidth until the tooltip just fits in the viewport when readjusting', async () => {
    // open tooltip with content that has a fitting width boundary of 1001px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 1001;
    });
    await wait(1);

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    // content changes: new fitting width boundary is 500px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 500;
    });
    const simpleChanges: Partial<SimpleChanges> = {
      truncatedChips: {
        isFirstChange: () => false,
        firstChange: false,
        previousValue: cloneDeep(component.truncatedChips)
      } as SimpleChange
    };
    component.truncatedChips = [{ label: 'ABC', level: 'inProcess' }];
    simpleChanges.truncatedChips.currentValue = component.truncatedChips;
    jest.useFakeTimers();
    component.ngOnChanges(simpleChanges);

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    jest.advanceTimersByTime(100);

    expect(fixture.nativeElement.style.maxWidth).toBe('500px');

    jest.useRealTimers();
  });

  test('reduces maxWidth not lower than the min max width', async () => {
    // open tooltip with content that has a fitting width boundary of 1001px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 1001;
    });
    await wait(1);

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    // content changes: new fitting width boundary is 100px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 100;
    });
    jest.useFakeTimers();
    window.dispatchEvent(new Event('resize'));

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    jest.advanceTimersByTime(100);

    expect(fixture.nativeElement.style.maxWidth).toBe('320px');

    jest.useRealTimers();
  });

  const changedPropertiesCases = [
    {
      changedPropertyName: 'truncatedChips',
      newPropertyValue: [{ label: 'ABC', level: 'inProcess' }]
    },
    {
      changedPropertyName: 'i18n',
      newPropertyValue: 'i18n.translations.new'
    },
    {
      changedPropertyName: 'columnOptions',
      newPropertyValue: { isTranslated: true }
    }
  ];

  test.each(changedPropertiesCases)(
    'readjusts maxWidth when property $changedPropertyName changes',
    async ({ changedPropertyName, newPropertyValue }) => {
      // open tooltip with content that has a fitting width boundary of 1001px
      elementService.isOverflown.mockImplementation(element => {
        return parseInt(element.style.maxWidth) < 1001;
      });
      await wait(1);

      expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

      // content changes: new fitting width boundary is 500px
      elementService.isOverflown.mockImplementation(element => {
        return parseInt(element.style.maxWidth) < 500;
      });
      const simpleChanges: Partial<SimpleChanges> = {
        [changedPropertyName]: {
          isFirstChange: () => false,
          firstChange: false,
          previousValue: cloneDeep(component[changedPropertyName])
        } as SimpleChange
      };
      component[changedPropertyName] = newPropertyValue;
      simpleChanges[changedPropertyName].currentValue = component[changedPropertyName];
      jest.useFakeTimers();
      component.ngOnChanges(simpleChanges);

      expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

      jest.advanceTimersByTime(100);

      expect(fixture.nativeElement.style.maxWidth).toBe('500px');

      jest.useRealTimers();
    }
  );

  test('readjusts maxWidth when window is resize', async () => {
    // open tooltip with content that has a fitting width boundary of 1001px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 1001;
    });
    await wait(1);

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    // content changes: new fitting width boundary is 500px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 500;
    });
    jest.useFakeTimers();
    window.dispatchEvent(new Event('resize'));

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    jest.advanceTimersByTime(100);

    expect(fixture.nativeElement.style.maxWidth).toBe('500px');

    jest.useRealTimers();
  });

  test('readjusts maxWidth when language is changed', async () => {
    // open tooltip with content that has a fitting width boundary of 1001px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 1001;
    });
    await wait(1);

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    // content changes: new fitting width boundary is 500px
    elementService.isOverflown.mockImplementation(element => {
      return parseInt(element.style.maxWidth) < 500;
    });
    jest.useFakeTimers();
    translateService.onLangChange.emit('en');

    expect(fixture.nativeElement.style.maxWidth).toBe('1010px');

    jest.advanceTimersByTime(100);

    expect(fixture.nativeElement.style.maxWidth).toBe('500px');

    jest.useRealTimers();
  });

  test('no error occurs if document.documentElement.clientWidth is not defined', async () => {
    Object.defineProperty(document.documentElement, 'clientWidth', { value: undefined });

    await wait(1);

    expect(fixture.nativeElement.style.maxWidth).toBe('320px');
  });

  test('tooltip will be rendered with closer if tooltip covers more than half of the screen', async () => {
    fixture.nativeElement.getBoundingClientRect = jest.fn(() => ({
      width: 800,
      height: 600
    }));

    await wait(1);

    const closer = fixture.debugElement.query(By.css('.closer'))?.nativeElement;
    expect(closer).not.toBeUndefined();

    expect(overlayRef.detach).not.toHaveBeenCalled();

    closer.click();

    expect(overlayRef.detach).toHaveBeenCalled();
  });
});
