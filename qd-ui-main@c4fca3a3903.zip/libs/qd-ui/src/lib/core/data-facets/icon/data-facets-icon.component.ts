import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

/**
 * @description Renders an icon of the Quadrel icon set.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-icon',
  templateUrl: './data-facets-icon.component.html',
  styleUrls: ['./data-facets-icon.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsIconComponent {
  @Input() data?: string;
  @Input() testId?: string;
}
