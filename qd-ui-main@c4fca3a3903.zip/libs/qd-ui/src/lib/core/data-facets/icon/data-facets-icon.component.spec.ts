import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QdMockIconModule } from '../../../icon/__mocks__/mock-icon.module';
import { QdDataFacetsIconComponent } from './data-facets-icon.component';

describe(`${QdDataFacetsIconComponent.name} | `, () => {
  let component: QdDataFacetsIconComponent;
  let fixture: ComponentFixture<QdDataFacetsIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [QdDataFacetsIconComponent],
      imports: [QdMockIconModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QdDataFacetsIconComponent);
    component = fixture.componentInstance;
  });

  test('matches the snapshot.', () => {
    component.data = 'coatCh';

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
