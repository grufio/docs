import { TestBed } from '@angular/core/testing';

import { QdDataFacetsContextService } from './data-facets-context.service';

describe(`Testing ${QdDataFacetsContextService.name} |`, () => {
  let service: QdDataFacetsContextService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdDataFacetsContextService]
    });
    service = TestBed.inject(QdDataFacetsContextService);
  });

  test('initial context is empty', () => {
    const context = service.getContext();

    expect(context).toEqual({});
  });

  test('updates multiple context parameters', () => {
    service.setContext({ key1: 'value1', key2: 'value2', index: 1 });

    const context = service.getContext();

    expect(context).toEqual({ key1: 'value1', key2: 'value2', index: 1 });
  });

  test('updates and overwrites existing parameters', () => {
    service.setContext({ key1: 'value1', key2: 'value2' });
    service.setContext({ key1: 'newValue1', index: 2 });

    const context = service.getContext();

    expect(context).toEqual({ key1: 'newValue1', key2: 'value2', index: 2 });
  });
});
