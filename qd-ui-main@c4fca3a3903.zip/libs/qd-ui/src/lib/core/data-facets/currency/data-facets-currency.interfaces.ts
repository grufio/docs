/**
 * @description Configuration options for currency
 */
export type QdDataFacetsCurrencyConfig = {
  /**
   * @description The currency code (e.g., 'usd', 'eur', 'chf') for formatting currency values.
   *
   * * @default 'chf'
   */
  currency?: string;

  /**
   * @description Show or hide the currency unit per column. Useful when the currency per column is always the same. If this is the case, the currency unit can be displayed in the table header instead.
   *
   * * @default false
   */
  showCurrencyUnit?: boolean;
};
