import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { MockProvider } from 'ng-mocks';
import { Subject } from 'rxjs';

import { QdDataFacetsCurrencyComponent } from './data-facets-currency.component';

describe(`Testing ${QdDataFacetsCurrencyComponent.name} |`, () => {
  let component: QdDataFacetsCurrencyComponent;
  let fixture: ComponentFixture<QdDataFacetsCurrencyComponent>;
  let translateService;

  function createComponent(useTranslateService = true, currentLang = 'de'): void {
    const providers = [
      useTranslateService
        ? MockProvider(TranslateService, {
            currentLang,
            defaultLang: 'de' as any,
            onLangChange: new Subject() as any
          })
        : null
    ].filter(provider => provider !== null);

    TestBed.configureTestingModule({
      declarations: [QdDataFacetsCurrencyComponent],
      providers
    });

    fixture = TestBed.createComponent(QdDataFacetsCurrencyComponent);
    component = fixture.componentInstance;

    if (useTranslateService) translateService = TestBed.inject(TranslateService);
  }

  function getContent(): string {
    // eslint-disable-next-line no-irregular-whitespace
    return fixture.debugElement.nativeElement.textContent.trim().replace(/[  ]/g, ' ');
  }

  afterEach(() => {
    fixture.destroy();
  });

  test('default data', () => {
    createComponent();

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
    expect(getContent()).toBe('0.00');
  });

  test('default config', () => {
    createComponent();
    component.data = 1234.56;

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
    expect(getContent()).toBe('1’234.56');
  });

  test('default with browser language', () => {
    jest.spyOn(window.navigator, 'language', 'get').mockReturnValue('zh');

    createComponent(false);
    component.data = 1234.56;

    fixture.detectChanges();

    expect(getContent()).toBe('1,234.56');
  });

  test('formatting with specified currency (USD) and showCurrencyUnit option enabled', () => {
    createComponent();
    component.data = 1234.56;
    component.config = { currency: 'USD', showCurrencyUnit: true };

    fixture.detectChanges();

    expect(getContent()).toBe('$ 1’234.56');
  });

  test('formatting with specified currency (JPY) and showCurrencyUnit option enabled', () => {
    createComponent();
    component.data = 1234.56;
    component.config = { currency: 'JPY', showCurrencyUnit: true };

    fixture.detectChanges();

    expect(getContent()).toBe('¥ 1’235');
  });

  test('formatting with specified currency (EUR) and showCurrencyUnit option enabled', () => {
    createComponent();
    component.data = 1234.56;
    component.config = { currency: 'EUR', showCurrencyUnit: true };

    fixture.detectChanges();

    expect(getContent()).toBe('EUR 1’234.56');
  });

  test('default formatting with browser language (French)', () => {
    jest.spyOn(window.navigator, 'language', 'get').mockReturnValue('fr-CH');

    createComponent(false);
    component.data = 1234.56;

    fixture.detectChanges();

    expect(getContent()).toBe('1 234,56');
  });

  test('formatting with specified currency (GBP) and browser language (French)', () => {
    jest.spyOn(window.navigator, 'language', 'get').mockReturnValue('fr-CH');

    createComponent(false);
    component.data = 1234.56;
    component.config = { currency: 'GBP', showCurrencyUnit: true };

    fixture.detectChanges();

    expect(getContent()).toBe('1 234.56 £GB');
  });

  test('default formatting without showCurrencyUnit option', () => {
    createComponent();
    component.data = 1234.56;
    component.config = { showCurrencyUnit: false };

    fixture.detectChanges();

    expect(getContent()).toBe('1’234.56');
  });

  test('default formatting with showCurrencyUnit option', () => {
    createComponent();
    component.data = 1234.56;
    component.config = { showCurrencyUnit: true };

    fixture.detectChanges();

    expect(getContent()).toBe('CHF 1’234.56');
  });

  test('default formatting with showCurrencyUnit option and currentLang (French)', () => {
    createComponent(true, 'fr');

    component.data = 1234.56;
    component.config = { showCurrencyUnit: true };

    fixture.detectChanges();

    expect(getContent()).toBe('1 234.56 CHF');
  });

  test('updates on change of value or language', () => {
    createComponent(true, 'fr');

    component.data = 1234.56;
    component.config = { showCurrencyUnit: true };
    fixture.detectChanges();

    expect(getContent()).toBe('1 234.56 CHF');

    component.data = 9876.56;
    component.ngOnChanges();
    fixture.detectChanges();
    expect(getContent()).toBe('9 876.56 CHF');

    translateService.onLangChange.next({ lang: 'de' });
    fixture.detectChanges();
    expect(getContent()).toBe('CHF 9’876.56');
  });

  test('yields empty for null', () => {
    createComponent();
    component.data = null;

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('yields empty for undefined', () => {
    createComponent();
    component.data = null;

    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
