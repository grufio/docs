import { ChangeDetectionStrategy, Component, Input, OnChanges, OnDestroy, OnInit, Optional } from '@angular/core';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import { ReplaySubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { QdDataFacetsCurrencyConfig } from './data-facets-currency.interfaces';

/**
 * @description Renders currency values.
 *
 *
 */
@Component({
  selector: 'qd-data-facets-currency',
  templateUrl: './data-facets-currency.component.html',
  styleUrls: ['./data-facets-currency.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsCurrencyComponent implements OnInit, OnChanges, OnDestroy {
  @Input() config?: QdDataFacetsCurrencyConfig;
  @Input() data = 0;
  @Input() testId?: string;

  private _destroyed$ = new Subject<void>();
  private _currencySubject = new ReplaySubject<string>(1);

  currency$ = this._currencySubject.asObservable();

  constructor(@Optional() private translateService: TranslateService) {
    this.translateService?.onLangChange
      .pipe(takeUntil(this._destroyed$))
      .subscribe((event: LangChangeEvent) => this.setCurrency(event.lang));
  }

  ngOnInit(): void {
    this.setCurrency();
  }

  ngOnChanges(): void {
    this.setCurrency();
  }

  ngOnDestroy(): void {
    this._destroyed$.complete();
  }

  setCurrency(lang?: string): void {
    const currency = this.getCurrency(
      lang || this.translateService?.currentLang || this.translateService?.defaultLang || navigator.language
    );
    this._currencySubject.next(currency);
  }

  private getCurrency(lang: string): string {
    if (this.data == null) return '';

    // Swiss speciality with a period instead of a comma
    const localeWithSuffix = ['de', 'fr', 'it'].includes(lang) ? `${lang}-CH` : lang;

    if (this.config?.showCurrencyUnit) {
      return new Intl.NumberFormat(localeWithSuffix, {
        style: 'currency',
        currency: this.config?.currency ?? 'chf'
      }).format(this.data);
    }

    return new Intl.NumberFormat(localeWithSuffix, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(this.data);
  }
}
