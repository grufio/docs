import { Injectable } from '@angular/core';

@Injectable()
export class QdDataFacetsContextService {
  private _context: { [key: string]: any } = {};

  setContext(newContext: { [key: string]: any }): void {
    this._context = { ...this._context, ...newContext };
  }

  getContext(): { [key: string]: any } {
    return { ...this._context };
  }
}
