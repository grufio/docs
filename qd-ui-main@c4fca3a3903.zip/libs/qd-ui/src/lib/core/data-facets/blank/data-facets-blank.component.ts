// @ts-strict-ignore
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

/**
 * @description Renders just a blank element.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-blank',
  template: '',
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsBlankComponent {
  @Input() data?: unknown;
  @Input() config?: unknown;
  @Input() class: string;
  @Input() testId?: string;
}
