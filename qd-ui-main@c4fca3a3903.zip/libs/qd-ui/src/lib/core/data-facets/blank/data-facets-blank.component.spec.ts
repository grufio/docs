import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdDataFacetsBlankComponent } from './data-facets-blank.component';

describe(`Testing ${QdDataFacetsBlankComponent.name} |`, () => {
  let component: QdDataFacetsBlankComponent;
  let fixture: ComponentFixture<QdDataFacetsBlankComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QdDataFacetsBlankComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QdDataFacetsBlankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('matches the snapshot', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
