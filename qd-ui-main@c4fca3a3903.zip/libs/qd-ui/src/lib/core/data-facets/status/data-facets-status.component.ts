import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { QdDataFacetsStatusData } from './data-facets-status.interfaces';

/**
 * @description Renders a status indicator.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-status',
  templateUrl: './data-facets-status.component.html',
  styleUrls: ['./data-facets-status.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsStatusComponent {
  @Input() data!: QdDataFacetsStatusData;
  @Input() testId?: string;
}
