import {
  QdStatusIndicatorLevel,
  QdStatusIndicatorType
} from '../../../status-indicator/interfaces/status-indicator.interface';

/**
 * @description Type definition for data
 */
export type QdDataFacetsStatusData = {
  /**
   * level of the status indicator
   */
  level: QdStatusIndicatorLevel;

  /**
   * type of the status indicator
   */
  type: QdStatusIndicatorType;
};
