import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QdMockStatusIndicatorModule } from '../../../status-indicator/__mocks__/mock-status-indicator.module';
import { QdDataFacetsStatusComponent } from './data-facets-status.component';

describe(`Testing ${QdDataFacetsStatusComponent.name} |`, () => {
  let component: QdDataFacetsStatusComponent;
  let fixture: ComponentFixture<QdDataFacetsStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [QdDataFacetsStatusComponent],
      imports: [QdMockStatusIndicatorModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QdDataFacetsStatusComponent);
    component = fixture.componentInstance;
    component.data = { level: 1, type: 'critical' };

    fixture.detectChanges();
  });

  test('matches the snapshot', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
