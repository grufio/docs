import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { QdMockIconComponent } from '../../../icon/__mocks__/mock-icon.component';
import { QdDataFacetsBooleanComponent } from './data-facets-boolean.component';

@Component({
  template: ` <qd-data-facets-boolean [data]="data" [testId]="testId"></qd-data-facets-boolean>`
})
class DataFalseTestComponent {
  data = false;
  testId = 'myTestId';
}

@Component({
  template: ` <qd-data-facets-boolean [data]="data" [testId]="testId"></qd-data-facets-boolean>`
})
class DataTrueTestComponent {
  data = true;
  testId = 'myTestId';
}

describe(`Testing ${QdDataFacetsBooleanComponent.name} |`, () => {
  describe('data is set to "false":,', () => {
    let component: DataFalseTestComponent;
    let fixture: ComponentFixture<DataFalseTestComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DataFalseTestComponent, QdDataFacetsBooleanComponent, QdMockIconComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(DataFalseTestComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('matches the snapshot', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('data is set to "true":,', () => {
    let component: DataTrueTestComponent;
    let fixture: ComponentFixture<DataTrueTestComponent>;

    beforeEach(waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [DataTrueTestComponent, QdDataFacetsBooleanComponent, QdMockIconComponent]
      }).compileComponents();
    }));

    beforeEach(() => {
      fixture = TestBed.createComponent(DataTrueTestComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    test('matches the snapshot', () => {
      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });
});
