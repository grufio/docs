import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

/**
 * @description Renders a checkmark icon if the value is true. Otherwise, it renders a "x" icon.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-boolean',
  templateUrl: './data-facets-boolean.component.html',
  styleUrls: ['./data-facets-boolean.component.scss'],
  host: { class: 'qd-data-facets', '[attr.data-test-id]': 'testId' },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsBooleanComponent {
  @Input() data?: boolean;
  @Input() testId?: string;
}
