import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { QdDataFacetsTextConfig } from './data-facets-text.interfaces';

/**
 * @description Renders a text or multiple text paragraphs.
 *
 * * Note: This is a base component for all potentially derived components and classes.
 */
@Component({
  selector: 'qd-data-facets-text',
  templateUrl: './data-facets-text.component.html',
  styleUrls: ['./data-facets-text.component.scss'],
  host: {
    '[class]': `'qd-data-facets ' + textTransformClassName + (isList ? ' has-list' : '')`,
    '[attr.data-test-id]': 'testId'
  },
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QdDataFacetsTextComponent {
  @Input() config?: QdDataFacetsTextConfig;
  @Input() data?: string | string[];
  @Input() i18n?: string;
  @Input() testId?: string;

  get textTransformClassName(): string {
    if (this.config?.textTransform) return ` qd-data-facets-text-${this.config.textTransform}`;

    return '';
  }

  get isList(): boolean {
    return Array.isArray(this.data);
  }

  get shouldTranslate(): boolean {
    return !!this.config?.isTranslated && this.data !== undefined;
  }

  getI18n(text: string): string {
    if (text.indexOf('i18n') === 0) return text;

    return this.i18n + '.' + text;
  }
}
