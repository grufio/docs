/**
 * @description Type definitions for the 'text' options.
 */
export type QdDataFacetsTextConfig = {
  /**
   * @description If "true", the value is used as i18n key segment.
   *
   *  * @default: false
   */
  isTranslated?: boolean;

  /**
   * @description Defines the text transform operation of the value.
   *
   *  * @default: 'none'
   */
  textTransform?: 'capitalize' | 'uppercase' | 'lowercase' | 'full-width' | 'full-size-kana' | 'none';
};
