import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { QdMockTranslatePipe } from '../../../core/__mocks__/mock-translate.pipe';
import { QdDataFacetsTextConfig } from './data-facets-text.interfaces';
import { QdDataFacetsTextComponent } from './data-facets-text.component';

@Component({
  selector: 'data-facets-text-test',
  template: `<qd-data-facets-text [config]="config" [data]="data" [testId]="testId"></qd-data-facets-text>`
})
class TestComponent {
  config: QdDataFacetsTextConfig = {};
  data = 'Evian Mineralwasser ohne Kohlensäure, 0,75 Liter Glasflaschen - 2200-1000';
  testId = 'myTestId';
}

@Component({
  selector: 'data-facets-text-transform',
  template: `<qd-data-facets-text [data]="data" [config]="config"></qd-data-facets-text>`
})
class TextTransformTestComponent {
  config: QdDataFacetsTextConfig = { textTransform: 'uppercase' };
  data = 'Evian Mineralwasser ohne Kohlensäure, 0,75 Liter Glasflaschen - 2200-1000';
}

@Component({
  selector: 'data-facets-text-test-translate',
  template: `<qd-data-facets-text [data]="data" [config]="config" [i18n]="'i18n.translations'"></qd-data-facets-text>`
})
class ContentTranslateTestComponent {
  config: QdDataFacetsTextConfig = { isTranslated: true };
  data = 'TEXT_TO_TRANSLATE';
}

@Component({
  selector: 'data-facets-text-test-translate-with-complete-i18n-key',
  template: `<qd-data-facets-text [data]="data" [config]="config" [i18n]="'i18n.translations'"></qd-data-facets-text>`
})
class ContentTranslateWithCompleteI18nKeyTestComponent {
  config: QdDataFacetsTextConfig = { isTranslated: true };
  data = 'i18n.translations.TEXT_TO_TRANSLATE';
}

@Component({
  selector: 'data-facets-text-test-list',
  template: `<qd-data-facets-text [data]="data"></qd-data-facets-text>`
})
class ListContentComponent {
  data = ['Hinweis A', 'Hinweis B'];
}

@Component({
  selector: 'data-facets-text-list-translate',
  template: `<qd-data-facets-text [data]="data" [config]="config" [i18n]="'i18n.translations'"></qd-data-facets-text>`
})
class TranslatedListContentComponent {
  config: QdDataFacetsTextConfig = { isTranslated: true };
  data = ['TEXT_TO_TRANSLATE', 'MORE_TEXT_TO_TRANSLATE'];
}

describe(`Testing ${QdDataFacetsTextComponent.name} |`, () => {
  let fixture: ComponentFixture<any>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        QdDataFacetsTextComponent,
        QdMockTranslatePipe,
        TestComponent,
        TextTransformTestComponent,
        ContentTranslateTestComponent,
        ContentTranslateWithCompleteI18nKeyTestComponent,
        ListContentComponent,
        TranslatedListContentComponent
      ]
    }).compileComponents();
  }));

  function createComponent(componentClass: any): void {
    fixture = TestBed.createComponent(componentClass);
    fixture.detectChanges();
  }

  test('matches the snapshot with default settings', () => {
    createComponent(TestComponent);
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches the snapshot with uppercase text transform', () => {
    createComponent(TextTransformTestComponent);
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches the snapshot with translated content', () => {
    createComponent(ContentTranslateTestComponent);
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches the snapshot with translated content (with complete i18n key)', () => {
    createComponent(ContentTranslateWithCompleteI18nKeyTestComponent);
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches the snapshot with list content', () => {
    createComponent(ListContentComponent);
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('matches the snapshot with translated list content', () => {
    createComponent(TranslatedListContentComponent);
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('handles undefined data correctly without translation', () => {
    createComponent(TestComponent);

    fixture.componentInstance.data = undefined;
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('does not translate when isTranslated is false', () => {
    createComponent(ContentTranslateTestComponent);

    fixture.componentInstance.config.isTranslated = false;
    fixture.detectChanges();

    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('does not translate when data is undefined and isTranslated is true', () => {
    createComponent(ContentTranslateTestComponent);

    fixture.componentInstance.config.isTranslated = true;
    fixture.componentInstance.data = undefined;

    fixture.detectChanges();
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
