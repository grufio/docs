import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

import { QdDataFacetsBlankComponent } from './blank/data-facets-blank.component';
import { QdDataFacetsBooleanComponent } from './boolean/data-facets-boolean.component';
import { QdDataFacetsChipComponent } from './chip/data-facets-chip.component';
import { QdDataFacetsCurrencyComponent } from './currency/data-facets-currency.component';
import { QdDataFacetsDateComponent } from './date/data-facets-date.component';
import { QdDataFacetsIconComponent } from './icon/data-facets-icon.component';
import { QdDataFacetsIntegerComponent } from './integer/data-facets-integer.component';
import { QdDataFacetsLinkComponent } from './link/data-facets-link.component';
import { QdDataFacetsProgressComponent } from './progress/data-facets-progress.component';
import { QdDataFacetsStatusComponent } from './status/data-facets-status.component';
import { QdDataFacetsTextComponent } from './text/data-facets-text.component';

// TODO: Inherit QdIcon from QdDataFacetsIconComponent.
import { QdChipModule } from '../../chips/chips.module';
import { QdIconModule } from '../../icon/icon.module';

import { QdStatusIndicatorModule } from '../../status-indicator/status-indicator.module';
import { QdDataFacetsChipConfig } from './chip/data-facets-chip.interfaces';
import { QdDataFacetsChipTruncatedIndicatorComponent } from './chip/truncated-indicator/data-facets-chip-truncated-indicator.component';
import { QdDataFacetsChipTruncatedTooltipComponent } from './chip/truncated-tooltip/data-facets-chip-truncated-tooltip.component';
import { QdDataFacetsCurrencyConfig } from './currency/data-facets-currency.interfaces';
import { QdDataFacetsDateConfig } from './date/data-facets-date.interfaces';
import { QdDataFacetsLinkConfig } from './link/data-facets-link.interfaces';
import { QdDataFacetsStatusData } from './status/data-facets-status.interfaces';
import { QdDataFacetsTextConfig } from './text/data-facets-text.interfaces';

export { COMPONENT_MAP } from './data-facets.model';

export {
  QdDataFacetsChipConfig,
  QdDataFacetsCurrencyConfig,
  QdDataFacetsDateConfig,
  QdDataFacetsLinkConfig,
  QdDataFacetsStatusData,
  QdDataFacetsTextConfig
};

@NgModule({
  imports: [CommonModule, TranslateModule, QdIconModule, QdChipModule, QdStatusIndicatorModule],
  declarations: [
    QdDataFacetsBlankComponent,
    QdDataFacetsBooleanComponent,
    QdDataFacetsChipComponent,
    QdDataFacetsCurrencyComponent,
    QdDataFacetsDateComponent,
    QdDataFacetsIconComponent,
    QdDataFacetsIntegerComponent,
    QdDataFacetsLinkComponent,
    QdDataFacetsProgressComponent,
    QdDataFacetsStatusComponent,
    QdDataFacetsTextComponent,
    QdDataFacetsChipTruncatedTooltipComponent,
    QdDataFacetsChipTruncatedIndicatorComponent
  ],
  exports: []
})
export class QdDataFacetsModule {}
