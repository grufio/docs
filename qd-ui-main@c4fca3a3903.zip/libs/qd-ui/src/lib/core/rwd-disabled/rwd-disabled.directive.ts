import { Directive } from '@angular/core';

@Directive({
  selector: '[qdRwdDisabled]',
  host: { class: 'qd-rwd-disabled' }
})
export class QdRwdDisabledDirective {}
