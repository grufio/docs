// @ts-strict-ignore
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { QdRwdDisabledDirective } from './rwd-disabled.directive';

@Component({
  template: `<test-component qdRwdDisabled></test-component> `
})
class RwdDisabledTestComponent {}

@Component({
  selector: 'test-component',
  template: ''
})
class TestComponent {}

describe(QdRwdDisabledDirective.name, () => {
  let component: RwdDisabledTestComponent;
  let fixture: ComponentFixture<RwdDisabledTestComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [RwdDisabledTestComponent, TestComponent, QdRwdDisabledDirective]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RwdDisabledTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  test('the component matches the snapshot.', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });
});
