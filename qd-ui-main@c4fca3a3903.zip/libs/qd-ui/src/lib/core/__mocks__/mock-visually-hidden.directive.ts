import { Directive } from '@angular/core';

@Directive({
  selector: '[qdVisuallyHidden]',
  host: { class: 'qd-mock-visually-hidden' }
})
export class QdMockVisuallyHiddenDirective {}
