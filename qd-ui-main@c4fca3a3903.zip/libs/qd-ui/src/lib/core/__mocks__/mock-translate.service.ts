import { Injectable } from '@angular/core';
import { of, ReplaySubject } from 'rxjs';
import { QdTranslatable } from '../model/translation.interface';

@Injectable()
export class QdMockTranslateService {
  instant(value: string): string {
    return 'Fake translation: ' + value;
  }

  get = jest.fn((value: string) => {
    return of('Fake translation: ' + value);
  });

  translate = jest.fn((translatable: QdTranslatable) => {
    if (translatable.i18n) return this.instant(translatable.i18n);

    return 'Fake translation: ' + JSON.stringify(translatable.translation);
  });

  onLangChange = new ReplaySubject<string>();
  onTranslationChange = new ReplaySubject<string>();
  onDefaultLangChange = new ReplaySubject<string>();
  currentLang = 'de';

  use = jest.fn();
  getTranslation = jest.fn();
}
