import { NgModule } from '@angular/core';
import { QdMockBreakpointService } from './mock-breakpoint.service';
import { QdMockDisabledDirective } from './mock-disabled.directive';
import { QdMockRwdDisabledDirective } from './mock-rwd-disabled.directive';
import { QdMockTranslatePipe } from './mock-translate.pipe';
import { QdMockVisuallyHiddenDirective } from './mock-visually-hidden.directive';
import { QdMockPopoverOnClickDirective } from './mock-popover-on-click.directive';

export {
  QdMockDisabledDirective,
  QdMockRwdDisabledDirective,
  QdMockVisuallyHiddenDirective,
  QdMockTranslatePipe,
  QdMockBreakpointService,
  QdMockPopoverOnClickDirective
};

@NgModule({
  declarations: [
    QdMockDisabledDirective,
    QdMockRwdDisabledDirective,
    QdMockVisuallyHiddenDirective,
    QdMockTranslatePipe,
    QdMockPopoverOnClickDirective
  ],
  exports: [
    QdMockDisabledDirective,
    QdMockRwdDisabledDirective,
    QdMockVisuallyHiddenDirective,
    QdMockTranslatePipe,
    QdMockPopoverOnClickDirective
  ]
})
export class QdMockCoreModule {}
