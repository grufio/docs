import { Directive } from '@angular/core';

@Directive({
  selector: '[qdDisabled]',
  host: { class: 'qd-mock-disabled' }
})
export class QdMockDisabledDirective {}
