// @ts-strict-ignore
import {
  Directive,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  Output,
  TemplateRef,
  ViewContainerRef
} from '@angular/core';

@Directive({
  selector: '[qdPopoverOnClick]',
  exportAs: 'qdPopoverOnClick'
})
export class QdMockPopoverOnClickDirective {
  @Input() qdPopoverOnClick: TemplateRef<unknown>;
  @Input() qdPopoverWidth;
  @Input() qdPopoverMinWidth;
  @Input() qdPopoverMaxWidth;
  @Input() qdPopoverHeight;
  @Input() qdPopoverMinHeight;
  @Input() qdPopoverMaxHeight;
  @Input() positionStrategy;
  @Input() qdPopoverCloseStrategy;
  @Input() qdPopoverDisabled;
  @Input() qdPopoverStopPropagation = true;

  @Output() readonly opened = new EventEmitter();
  @Output() readonly closed = new EventEmitter();

  private _open: boolean = false;
  private _embeddedView;

  constructor(private viewContainerRef: ViewContainerRef, private hostRef: ElementRef) {}

  ngOnInit(): void {}
  ngOnDestroy(): void {}

  @HostListener('click', ['$event'])
  show(event): void {
    if (this.qdPopoverStopPropagation) event.stopPropagation();

    if (!this._open) {
      this._open = true;
      this.opened.emit('Overlay has opened!');

      this._embeddedView = this.viewContainerRef.createEmbeddedView(this.qdPopoverOnClick);
    } else {
      this.close();
    }
  }

  @HostListener('document:click', ['$event'])
  clickedOutside(event: PointerEvent) {
    if (this.isHostElementClicked(event) || this.isElementInTemplateClicked(event)) return;

    this.close();
  }

  close() {
    this._open = false;
    this.closed.emit('Overlay closed!');
    this.viewContainerRef.clear();
  }

  open(): void {
    this.opened.emit();
  }

  private isHostElementClicked(event: PointerEvent): boolean {
    return event.target === this.hostRef.nativeElement;
  }

  private isElementInTemplateClicked(event: PointerEvent): boolean {
    const templateRootNode = this.getTemplateRootNode();
    if (!templateRootNode) return false;

    return Array.prototype.some.call(
      [templateRootNode, ...(templateRootNode?.getElementsByTagName((event.target as HTMLElement).tagName) || [])],
      element => element === event.target
    );
  }

  private getTemplateRootNode(): any {
    return this._embeddedView?.rootNodes?.[0];
  }
}
