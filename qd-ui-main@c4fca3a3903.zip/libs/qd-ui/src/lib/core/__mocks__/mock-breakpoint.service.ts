import { BehaviorSubject } from 'rxjs';

export class QdMockBreakpointService {
  public breakpoint$ = new BehaviorSubject<string>('xxl');

  public getMatchingBreakpoint(): BehaviorSubject<string> {
    return this.breakpoint$;
  }
}
