import { Directive } from '@angular/core';

@Directive({
  selector: '[qdRwdDisabled]',
  host: { class: 'qd-mock-rwd-disabled' }
})
export class QdMockRwdDisabledDirective {}
