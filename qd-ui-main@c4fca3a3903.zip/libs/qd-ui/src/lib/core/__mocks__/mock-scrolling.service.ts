export class QdMockScrollingService {
  scrollIntoViewIfNeeded = jest.fn();
  scrollIntoView = jest.fn();
  getBorderDistances = jest.fn();
}
