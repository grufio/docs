import globalVars from '../../../global-vars.json';

export const convertPxToRem = (pixel: number): string =>
  `${parseFloat((pixel / globalVars.base.fontsize).toFixed(3))}rem`;
