// @ts-strict-ignore
import { convertPxToRem } from './convertPxToRem.tools';

jest.mock('../../../global-vars.json', () => ({ base: { fontsize: 16 } }));

describe('Testing convertPxToRem |', () => {
  test('The tool can convert pixel numbers to rem string.', () => {
    expect(convertPxToRem(1)).toBe('0.063rem');
    expect(convertPxToRem(2)).toBe('0.125rem');
    expect(convertPxToRem(16)).toBe('1rem');
    expect(convertPxToRem(42.4711)).toBe('2.654rem');
    expect(convertPxToRem(720)).toBe('45rem');
  });
});
