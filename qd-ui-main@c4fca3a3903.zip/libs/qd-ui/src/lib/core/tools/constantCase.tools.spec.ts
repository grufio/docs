// @ts-strict-ignore
import { constantCase } from './constantCase.tools';

describe('Testing constantCase |', () => {
  test('The tool can convert strings to CONSTANT_CASE.', () => {
    expect(constantCase('i-like-kebab')).toBe('I_LIKE_KEBAB');
    expect(constantCase('flyingCamels')).toBe('FLYING_CAMELS');
    expect(constantCase('CamelsAreAwesome')).toBe('CAMELS_ARE_AWESOME');
    expect(constantCase('It works!')).toBe('IT_WORKS');
  });
});
