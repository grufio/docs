import { upperCase } from 'lodash';

export const constantCase = (str: string): string => upperCase(str).replace(/ /g, '_');
