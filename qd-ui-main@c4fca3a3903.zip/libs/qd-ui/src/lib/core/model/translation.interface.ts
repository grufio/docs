export type i18n = string;

export interface QdTranslatable {
  /**
   * @description Defines the translation key
   */
  i18n: i18n;

  /**
   * @description Alternative to i18n translations, used when translations are provided from the backend
   */
  translation?: QdTranslation;
}

/**
 * @description Translations originating from the backend
 */
export interface QdTranslation {
  de: string;
  fr: string;
  it: string;
  en: string;
}
