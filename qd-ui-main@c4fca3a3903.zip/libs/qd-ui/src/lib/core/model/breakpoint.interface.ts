import globalVars from '../../../global-vars.json';

export const breakpoints = globalVars.breakpoints;
export type QdBreakpoint = keyof typeof breakpoints;
