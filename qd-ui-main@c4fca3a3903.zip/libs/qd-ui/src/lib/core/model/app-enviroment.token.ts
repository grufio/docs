import { InjectionToken } from '@angular/core';

import { Environment } from '../../master-layout/master-layout-banner/master-layout-banner.component';
import { QdAppEnvironment } from './app-enviroment.interface';

export const APP_ENVIRONMENT = new InjectionToken<QdAppEnvironment | Environment>('APP_ENVIRONMENT');
