/**
 * Represents the QdAppEnvironment configuration.
 */
export type QdAppEnvironment = {
  /**
   * Indicates whether the application is running in production mode.
   */
  production: boolean;

  /**
   * The API endpoint for the backend service.
   */
  BACKEND_SERVICE_API?: string;

  /**
   * The path to the configuration file.
   */
  CONFIGURATION_PATH?: string;

  /**
   * Indicates whether backend notifications should be enabled.
   *
   * * @default false
   */
  disableBackendNotifications?: boolean;
};

/**
 * Represents the QdPamsConfig configuration.
 */
export type QdPamsConfig = {
  /**
   * The PAMS environment.
   */
  pamsEnvironment: string;
};
