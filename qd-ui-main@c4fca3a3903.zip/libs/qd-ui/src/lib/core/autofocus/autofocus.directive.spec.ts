// @ts-strict-ignore
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { QdAutofocusDirective } from './autofocus.directive';

@Component({
  selector: 'input-with-autofocus',
  template: `
    <div class="first-view" *ngIf="renderFirstView">
      <input [qdAutofocus]="autofocusFirst" />
      <input [qdAutofocus]="autofocusSecond" />
    </div>
    <div class="second-view" *ngIf="renderSecondView">
      <input [qdAutofocus]="autofocusFirst" />
      <input [qdAutofocus]="autofocusSecond" />
    </div>
  `
})
class TestComponent {
  renderFirstView = true;
  renderSecondView = false;
  autofocusFirst = false;
  autofocusSecond = false;
}

describe(QdAutofocusDirective.name, () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let inputs: DebugElement[];
  let focusFirst: jest.SpyInstance;
  let focusSecond: jest.SpyInstance;
  let consoleWarn: jest.SpyInstance;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, QdAutofocusDirective]
    }).compileComponents();
  }));

  function createFixtureAndComponent(autofocusFirst, autofocusSecond): void {
    beforeEach(() => {
      fixture = TestBed.createComponent(TestComponent);
      component = fixture.componentInstance;

      component.autofocusFirst = autofocusFirst;
      component.autofocusSecond = autofocusSecond;

      fixture.detectChanges();

      inputs = fixture.debugElement.queryAll(By.css('input'));
      focusFirst = jest.spyOn(inputs[0].nativeElement, 'focus');
      focusSecond = jest.spyOn(inputs[1].nativeElement, 'focus');
    });
  }

  afterEach(() => jest.clearAllMocks());

  const autofocusDataProvider = [
    {
      description: 'if nothing is set',
      autofocusFirst: false,
      autofocusSecond: false,
      hasFocusFirst: false,
      hasFocusSecond: false,
      hasWarning: false
    },
    {
      description: 'if set once',
      autofocusFirst: true,
      autofocusSecond: false,
      hasFocusFirst: true,
      hasFocusSecond: false,
      hasWarning: false
    },
    {
      description: 'if set twice or more',
      autofocusFirst: true,
      autofocusSecond: true,
      hasFocusFirst: true,
      hasFocusSecond: false,
      hasWarning: true
    }
  ];

  autofocusDataProvider.forEach(
    ({ description, autofocusFirst, autofocusSecond, hasFocusFirst, hasFocusSecond, hasWarning }) => {
      describe(description + ',', () => {
        consoleWarn = jest.spyOn(console, 'warn').mockImplementation(() => {});

        createFixtureAndComponent(autofocusFirst, autofocusSecond);

        test(`${hasFocusFirst ? 'auto-focuses' : "doesn't auto-focus"} first element after timeout.`, done => {
          expect(focusFirst).not.toHaveBeenCalled();

          setTimeout(() => {
            expect(focusFirst).toHaveBeenCalledTimes(hasFocusFirst ? 1 : 0);
            done();
          }, 0);
        });

        test(`${hasFocusSecond ? 'auto-focuses' : "doesn't auto-focus"} second element after timeout.`, done => {
          expect(focusSecond).not.toHaveBeenCalled();

          setTimeout(() => {
            expect(focusSecond).toHaveBeenCalledTimes(hasFocusSecond ? 1 : 0);
            done();
          }, 0);
        });

        test(`${hasWarning ? 'triggers' : "doesn't trigger"}  warning.`, () => {
          expect(consoleWarn).toHaveBeenCalledTimes(hasWarning ? 1 : 0);
          if (hasWarning)
            expect(consoleWarn).toHaveBeenCalledWith('QD-UI | QdAutofocus - "hasAutofocus" can be used only once!');
        });
      });
    }
  );

  describe('if view is changed,', () => {
    createFixtureAndComponent(false, true);

    beforeEach(() => {
      component.renderFirstView = false;
      component.renderSecondView = true;

      fixture.detectChanges();

      inputs = fixture.debugElement.queryAll(By.css('input'));
      focusFirst = jest.spyOn(inputs[0].nativeElement, 'focus');
      focusSecond = jest.spyOn(inputs[1].nativeElement, 'focus');
    });

    test('auto-focuses element in new view after timeout.', done => {
      expect(focusFirst).not.toHaveBeenCalled();
      expect(focusSecond).not.toHaveBeenCalled();

      setTimeout(() => {
        expect(focusFirst).toHaveBeenCalledTimes(0);
        expect(focusSecond).toHaveBeenCalledTimes(1);
        done();
      }, 0);
    });
  });

  describe('if another view is opened,', () => {
    createFixtureAndComponent(false, true);

    beforeEach(async () => {
      await new Promise(resolve => setTimeout(resolve, 0));
      inputs[1].nativeElement.dispatchEvent(new Event('blur'));

      component.renderFirstView = true;
      component.renderSecondView = true;

      fixture.detectChanges();

      inputs = fixture.debugElement.queryAll(By.css('.second-view input'));
      focusFirst = jest.spyOn(inputs[0].nativeElement, 'focus');
      focusSecond = jest.spyOn(inputs[1].nativeElement, 'focus');
    });

    test('auto-focuses element in new view after timeout.', done => {
      expect(focusFirst).not.toHaveBeenCalled();
      expect(focusSecond).not.toHaveBeenCalled();

      setTimeout(() => {
        expect(focusFirst).toHaveBeenCalledTimes(0);
        expect(focusSecond).toHaveBeenCalledTimes(1);
        done();
      }, 0);
    });
  });
});
