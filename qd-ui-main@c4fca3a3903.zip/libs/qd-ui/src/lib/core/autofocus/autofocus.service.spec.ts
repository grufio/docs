// @ts-strict-ignore
import { TestBed } from '@angular/core/testing';
import { QdAutofocusService } from './autofocus.service';

describe(QdAutofocusService.name, () => {
  let service: QdAutofocusService;

  beforeEach(() => {
    service = TestBed.inject(QdAutofocusService);
  });

  test('Service can set & get "isAutofocusActivated" property.', () => {
    expect(service.isAutofocusActivated).toBe(false);
    service.isAutofocusActivated = true;
    expect(service.isAutofocusActivated).toBe(true);
  });
});
