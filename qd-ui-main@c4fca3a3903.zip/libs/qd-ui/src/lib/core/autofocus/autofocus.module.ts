import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { QdAutofocusDirective } from './autofocus.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [QdAutofocusDirective],
  exports: [QdAutofocusDirective]
})
export class QdAutofocusModule {}
