import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QdMockAutofocusDirective } from './mock-autofocus.directive';
import { QdMockAutofocusService } from './mock-autofocus.service';

@NgModule({
  imports: [CommonModule],
  declarations: [QdMockAutofocusDirective],
  exports: [QdMockAutofocusDirective],
  providers: [QdMockAutofocusService]
})
export class QdMockAutofocusModule {}
