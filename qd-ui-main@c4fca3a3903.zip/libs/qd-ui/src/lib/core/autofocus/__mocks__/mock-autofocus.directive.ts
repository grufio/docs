import { Directive, Input } from '@angular/core';

@Directive({
  selector: '[qdAutofocus]'
})
export class QdMockAutofocusDirective {
  @Input() qdAutofocus = false;
}
