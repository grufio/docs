// @ts-strict-ignore
import { Injectable } from '@angular/core';

@Injectable()
export class QdMockAutofocusService {
  isAutofocusActivated;
}
