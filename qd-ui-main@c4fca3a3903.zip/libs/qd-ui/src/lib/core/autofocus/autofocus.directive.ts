import { AfterViewInit, Directive, ElementRef, Input, OnDestroy } from '@angular/core';
import { QdAutofocusService } from './autofocus.service';

@Directive({
  selector: '[qdAutofocus]'
})
export class QdAutofocusDirective implements AfterViewInit, OnDestroy {
  @Input() qdAutofocus = false;

  constructor(
    private readonly autofocusService: QdAutofocusService,
    private readonly elementRef: ElementRef<HTMLElement>
  ) {}

  ngAfterViewInit(): void {
    if (!this.qdAutofocus) return;

    if (this.autofocusService.isAutofocusActivated) {
      console.warn('QD-UI | QdAutofocus - "hasAutofocus" can be used only once!');

      return;
    }

    this.autofocusService.isAutofocusActivated = true;

    setTimeout(() => {
      this.elementRef.nativeElement.focus();

      this.elementRef.nativeElement.addEventListener('blur', () => {
        this.autofocusService.isAutofocusActivated = false;
      });
    }, 0);
  }

  ngOnDestroy(): void {
    this.autofocusService.isAutofocusActivated = false;
  }
}
