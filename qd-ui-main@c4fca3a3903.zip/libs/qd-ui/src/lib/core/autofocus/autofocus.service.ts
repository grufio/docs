import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class QdAutofocusService {
  private _isAutofocusActivated = false;

  set isAutofocusActivated(hasInstance) {
    this._isAutofocusActivated = hasInstance;
  }

  get isAutofocusActivated(): boolean {
    return this._isAutofocusActivated;
  }
}
