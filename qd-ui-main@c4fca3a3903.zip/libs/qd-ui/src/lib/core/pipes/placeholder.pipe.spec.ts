// @ts-strict-ignore
import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { QdPlaceholderPipe } from './placeholder.pipe';

@Component({
  selector: 'test',
  template: '{{ translation | placeholder:"maxFileSize":maxFileSize }}'
})
class TestComponent {
  translation = 'The maximum file size is {{maxFileSize}}.';
  maxFileSize = '10 MB';
  size = 894;
}

@Component({
  selector: 'test-undefined-value',
  template: '{{ translation | placeholder:"maxFileSize":maxFileSize }}'
})
class TestComponentUndefinedValue {
  translation = undefined;
  maxFileSize = '10 MB';
  size = 894;
}

@Component({
  selector: 'test-multiple-replacements',
  template: '{{ translation | placeholder:"supportName":"David" }}'
})
class TestComponentMultipleReplacements {
  translation =
    'If you need help please contact {{supportName}}. You can contact {{supportName}} under the number 058 123 456.';
}

describe(`Testing ${QdPlaceholderPipe.name} |`, () => {
  let component;
  let fixture;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, TestComponentUndefinedValue, TestComponentMultipleReplacements, QdPlaceholderPipe]
    });
  });

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  test('placeholder is replaced correctly', () => {
    createComponent(TestComponent);

    expect(fixture.nativeElement.innerHTML).toBe('The maximum file size is 10 MB.');
  });

  test('undefined value does not cause error', () => {
    createComponent(TestComponentUndefinedValue);

    expect(fixture.nativeElement.innerHTML).toBe('');
  });

  test('replaces multiple occurrences', () => {
    createComponent(TestComponentMultipleReplacements);

    expect(fixture.nativeElement.innerHTML).toBe(
      'If you need help please contact David. ' + 'You can contact David under the number 058 123 456.'
    );
  });
});
