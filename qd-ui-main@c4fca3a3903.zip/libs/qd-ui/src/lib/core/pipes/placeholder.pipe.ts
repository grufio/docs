import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'placeholder' })
export class QdPlaceholderPipe implements PipeTransform {
  transform(value: string, placeholderName: string, replacementStr: string): string {
    if (!value) return value;

    const strToReplace = '{{' + placeholderName + '}}';
    return value.replace(new RegExp(strToReplace, 'g'), replacementStr);
  }
}
