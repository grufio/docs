import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'placeholders' })
export class QdPlaceholdersPipe implements PipeTransform {
  transform(value: string, parameters: { [key: string]: string }): string {
    if (!value) return value;

    Object.entries(parameters).forEach(([parameterKey, parameterValue]) => {
      const strToReplace = '{{' + parameterKey + '}}';
      value = value.replace(new RegExp(strToReplace, 'g'), parameterValue);
    });

    return value;
  }
}
