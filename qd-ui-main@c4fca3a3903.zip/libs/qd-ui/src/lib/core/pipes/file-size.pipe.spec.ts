import { QdFileSizePipe } from './file-size.pipe';
import { TranslateService } from '@ngx-translate/core';

describe(`Testing ${QdFileSizePipe.name} |`, () => {
  let pipe: QdFileSizePipe;

  describe('without TranslateService', () => {
    beforeEach(() => {
      pipe = new QdFileSizePipe();
    });

    test('returns empty string for null', () => {
      expect(pipe.transform(null)).toBe('');
    });

    test('formats bytes less than 1024 correctly', () => {
      expect(pipe.transform(512)).toBe('512b');
    });

    test('formats megabytes fallback en-US', () => {
      expect(pipe.transform(1_572_864)).toBe('1.5mb');
    });
  });

  describe('with TranslateService (de-DE)', () => {
    beforeEach(() => {
      const mockTranslate = { currentLang: 'de-DE' } as TranslateService;
      pipe = new QdFileSizePipe(mockTranslate);
    });

    test('formats megabytes with comma for de-DE', () => {
      expect(pipe.transform(1_572_864)).toBe('1,5mb');
    });
  });
});
