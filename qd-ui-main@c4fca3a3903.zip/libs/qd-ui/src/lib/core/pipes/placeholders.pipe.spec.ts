import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { QdPlaceholdersPipe } from './placeholders.pipe';

@Component({
  selector: 'test',
  template: '{{ translation | placeholders:parameters }}'
})
class TestComponent {
  translation = 'The maximum file size is {{maxFileSize}}.';
  parameters = {
    maxFileSize: '10 MB'
  };
}

@Component({
  selector: 'test-undefined-value',
  template: '{{ translation | placeholders:parameters }}'
})
class TestComponentUndefinedValue {
  translation = undefined;
  parameters = {
    maxFileSize: '10 MB'
  };
}

@Component({
  selector: 'test-undefined-value',
  template: '{{ translation | placeholders:parameters }}'
})
class TestComponentMultipleValues {
  translation = 'The state of the {{orderNumber}} has been changed to ';
  parameters = {
    maxFileSize: '10 MB'
  };
}

describe(`Testing ${QdPlaceholdersPipe.name} |`, () => {
  let component;
  let fixture;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, TestComponentUndefinedValue, QdPlaceholdersPipe]
    });
  });

  function createComponent(componentClass): void {
    fixture = TestBed.createComponent(componentClass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  test('placeholders are replaced correctly', () => {
    createComponent(TestComponent);

    expect(fixture.nativeElement.innerHTML).toBe('The maximum file size is 10 MB.');
  });

  test('undefined value does not cause error', () => {
    createComponent(TestComponentUndefinedValue);

    expect(fixture.nativeElement.innerHTML).toBe('');
  });
});
