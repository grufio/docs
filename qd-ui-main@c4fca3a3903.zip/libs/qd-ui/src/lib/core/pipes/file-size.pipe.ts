import { Optional, Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Pipe({
  name: 'qdFileSize',
  pure: true
})
export class QdFileSizePipe implements PipeTransform {
  constructor(@Optional() private translate?: TranslateService) {}

  transform(bytes: number | null | undefined): string {
    if (bytes == null || isNaN(bytes)) return '';

    const thresh = 1024;
    const units = ['kb', 'mb', 'gb', 'tb', 'pb'];

    if (bytes < thresh) return `${bytes}b`;

    let size = bytes;
    let unitIndex = -1;

    do {
      size /= thresh;
      unitIndex++;
    } while (size >= thresh && unitIndex < units.length - 1);

    const locale = this.translate?.currentLang || 'en-US';

    const formatted = new Intl.NumberFormat(locale, {
      maximumFractionDigits: 1
    }).format(size);

    return `${formatted}${units[unitIndex]}`;
  }
}
