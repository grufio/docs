// @ts-strict-ignore
import { QdPopoverService } from './popover.service';
import { TestBed } from '@angular/core/testing';
import { QdPopoverComponent } from './popover/popover.component';

describe(QdPopoverService.name, () => {
  let service: QdPopoverService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdPopoverService]
    });
  });

  beforeEach(() => {
    service = TestBed.inject(QdPopoverService);
  });

  test('yields callback on close', done => {
    service.subscribe(excludedPopovers => {
      expect(excludedPopovers).toEqual([]);
      done();
    });

    service.closeAllOverlays();
  });

  test('yields callback on close with given excludedPopovers', done => {
    const mockPopover1 = new QdPopoverComponent(null, { parentPopovers: [] }, null);
    const mockPopover2 = new QdPopoverComponent(null, { parentPopovers: [] }, null);

    service.subscribe(excludedPopovers => {
      expect(excludedPopovers).toEqual([mockPopover1, mockPopover2]);
      done();
    });

    service.closeAllOverlays([mockPopover1, mockPopover2]);
  });
});
