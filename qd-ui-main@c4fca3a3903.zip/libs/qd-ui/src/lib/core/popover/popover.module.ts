import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { QdPopoverOnClickDirective } from './popover-on-click/popover-on-click.directive';
import { QdPopoverOnHoverDirective } from './popover-on-hover/popover-on-hover.directive';
import { QdPopoverService } from './popover.service';
import { QdPopoverComponent } from './popover/popover.component';

@NgModule({
  imports: [CommonModule],
  declarations: [QdPopoverComponent, QdPopoverOnClickDirective, QdPopoverOnHoverDirective],
  exports: [QdPopoverOnClickDirective, QdPopoverOnHoverDirective],
  providers: [QdPopoverService]
})
export class QdPopoverModule {}
