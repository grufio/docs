import { Injectable } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { QdPopoverComponent } from './popover/popover.component';

export type PopoverCloseCallback = (excludedPopovers: QdPopoverComponent[]) => void;

@Injectable()
export class QdPopoverService {
  private closeHandler = new Subject<QdPopoverComponent[]>();

  closeAllOverlays(excludedPopovers: QdPopoverComponent[] = []): void {
    this.closeHandler.next(excludedPopovers);
  }

  subscribe(callback: PopoverCloseCallback): Subscription {
    return this.closeHandler.subscribe(callback);
  }
}
