// @ts-strict-ignore
import { Component, ElementRef, Injector, Input, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { QdPopoverParentService } from '../popover-parent.service';

export type QdPopoverBackgroundColor = 'white' | 'transparent';

@Component({
  selector: 'qd-popover',
  templateUrl: './popover.component.html',
  providers: [QdPopoverParentService],
  styleUrls: ['./popover.component.scss']
})
export class QdPopoverComponent implements OnChanges {
  @Input() content: TemplateRef<unknown>;
  @Input() backgroundColor: QdPopoverBackgroundColor = 'white';

  direction: 'up' | 'down' = 'down';

  constructor(
    private elementRef: ElementRef,
    private popoverParentService: QdPopoverParentService,
    public injector: Injector
  ) {
    this.popoverParentService.parentPopovers.push(this);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['backgroundColor']) this.updateClassName();
  }

  setDirection(direction: 'up' | 'down'): void {
    this.direction = direction;
    this.updateClassName();
  }

  private updateClassName(): void {
    this.elementRef.nativeElement.className = `${this.direction} ${this.backgroundColor}`;
  }

  addParentPopovers(popovers: QdPopoverComponent[] = []): void {
    popovers.forEach(popover => this.popoverParentService.parentPopovers.push(popover));
  }
}
