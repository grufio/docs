// @ts-strict-ignore
import { QdPopoverBackgroundColor, QdPopoverComponent } from './popover.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { By } from '@angular/platform-browser';
import { QdPopoverParentService } from '../popover-parent.service';
import { MockProvider } from 'ng-mocks';

@Component({
  selector: 'test-component',
  template: `
    <qd-popover [content]="template" [backgroundColor]="backgroundColor"></qd-popover>
    <ng-template #template><p>One day, I am open source.</p></ng-template>
  `
})
class TestComponent {
  @Input() backgroundColor: QdPopoverBackgroundColor = 'white';
}

describe(QdPopoverComponent.name, () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let popoverComponent;
  let popoverParentService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule],
      declarations: [TestComponent, QdPopoverComponent],
      providers: [MockProvider(QdPopoverParentService, { parentPopovers: [] })]
    }).overrideComponent(QdPopoverComponent, {
      set: { providers: [] }
    });
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    popoverComponent = fixture.debugElement.query(By.directive(QdPopoverComponent)).componentInstance;
    popoverParentService = TestBed.inject(QdPopoverParentService);
  });

  test('matches snapshot', () => {
    expect(fixture.nativeElement).toMatchSnapshot();
  });

  test('setDirection sets the correct class', () => {
    popoverComponent.setDirection('up');
    expect(popoverComponent.elementRef.nativeElement.className).toBe('up white');

    popoverComponent.setDirection('down');
    expect(popoverComponent.elementRef.nativeElement.className).toBe('down white');
  });

  test('backgroundColor input sets the correct class', () => {
    component.backgroundColor = 'transparent';
    fixture.detectChanges();

    expect(popoverComponent.elementRef.nativeElement.className).toBe('down transparent');
  });

  test(`sets component instance in ${QdPopoverParentService.name}`, () => {
    expect(popoverParentService.parentPopovers).toEqual([
      fixture.debugElement.query(By.directive(QdPopoverComponent)).componentInstance
    ]);
  });

  test(`addParentPopovers passes popovers to ${QdPopoverParentService.name}`, () => {
    const mockPopover1 = {};
    const mockPopover2 = {};
    const mockPopover3 = {};

    popoverComponent.addParentPopovers([mockPopover1, mockPopover2]);
    popoverComponent.addParentPopovers([mockPopover3]);
    popoverComponent.addParentPopovers();

    expect(popoverParentService.parentPopovers).toEqual([
      fixture.debugElement.query(By.directive(QdPopoverComponent)).componentInstance,
      mockPopover1,
      mockPopover2,
      mockPopover3
    ]);
  });
});
