// @ts-strict-ignore
import { TestBed } from '@angular/core/testing';
import { QdPopoverParentService } from './popover-parent.service';
import { QdPopoverComponent } from './popover/popover.component';

describe(QdPopoverParentService.name, () => {
  let service: QdPopoverParentService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QdPopoverParentService]
    });
  });

  beforeEach(() => {
    service = TestBed.inject(QdPopoverParentService);
  });

  test('can get parentPopovers', () => {
    expect(service.parentPopovers).toEqual([]);
  });

  test('can set parentPopovers', () => {
    const mockPopover1 = new QdPopoverComponent(null, { parentPopovers: [] }, null);
    const mockPopover2 = new QdPopoverComponent(null, { parentPopovers: [] }, null);

    service.parentPopovers = [mockPopover1, mockPopover2];

    expect(service.parentPopovers).toEqual([mockPopover1, mockPopover2]);
  });
});
