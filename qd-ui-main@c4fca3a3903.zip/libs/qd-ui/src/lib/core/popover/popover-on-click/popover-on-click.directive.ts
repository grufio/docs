// @ts-strict-ignore
import {
  ConnectedPosition,
  FlexibleConnectedPositionStrategy,
  Overlay,
  OverlayPositionBuilder,
  OverlayRef
} from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import {
  Directive,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
  Optional,
  Output,
  TemplateRef
} from '@angular/core';
import isNumber from 'lodash/isNumber';
import { Subscription } from 'rxjs';
import { distinctUntilChanged, map } from 'rxjs/operators';
import { convertPxToRem } from '../../tools/convertPxToRem.tools';
import { QdPopoverParentService } from '../popover-parent.service';
import { QdPopoverService } from '../popover.service';
import { QdPopoverBackgroundColor, QdPopoverComponent } from '../popover/popover.component';

@Directive({
  selector: '[qdPopoverOnClick]',
  exportAs: 'qdPopoverOnClick'
})
export class QdPopoverOnClickDirective implements OnInit, OnDestroy {
  @Input() qdPopoverOnClick: TemplateRef<unknown>;
  @Input() positionStrategy: ConnectedPosition | ConnectedPosition[];
  @Input() qdPopoverCloseStrategy: 'onOutsideClick' | 'onEveryClick' = 'onEveryClick';
  @Input() qdPopoverDisabled = false;
  @Input() qdPopoverStopPropagation = true;
  @Input() qdPopoverBackgroundColor: QdPopoverBackgroundColor;

  @Input() set qdPopoverWidth(qdPopoverWidth: number | string | 'auto') {
    if (isNumber(qdPopoverWidth)) qdPopoverWidth = qdPopoverWidth + 'px';
    this._qdPopoverWidth = qdPopoverWidth;

    if (this._overlayRef?.hasAttached()) {
      this._overlayRef.updateSize({ width: this._qdPopoverWidth });
      this.updatePosition();
    }
  }

  get qdPopoverWidth(): string | 'auto' {
    return this._qdPopoverWidth;
  }

  @Input() set qdPopoverMinWidth(qdPopoverMinWidth: number | string | 'none') {
    if (isNumber(qdPopoverMinWidth)) qdPopoverMinWidth = qdPopoverMinWidth + 'px';
    this._qdPopoverMinWidth = qdPopoverMinWidth;

    if (this._overlayRef?.hasAttached()) {
      this._overlayRef.updateSize({ minWidth: this._qdPopoverMinWidth });
      this.updatePosition();
    }
  }

  get qdPopoverMinWidth(): string | 'none' {
    return this._qdPopoverMinWidth;
  }

  @Input() set qdPopoverMaxWidth(qdPopoverMaxWidth: number | string | 'none') {
    if (isNumber(qdPopoverMaxWidth)) qdPopoverMaxWidth = qdPopoverMaxWidth + 'px';
    this._qdPopoverMaxWidth = qdPopoverMaxWidth;

    if (this._overlayRef?.hasAttached()) {
      this._overlayRef.updateSize({ maxWidth: this._qdPopoverMaxWidth });
      this.updatePosition();
    }
  }

  get qdPopoverMaxWidth(): string | 'none' {
    return this._qdPopoverMaxWidth;
  }

  @Input() set qdPopoverHeight(qdPopoverHeight: number | string | 'auto') {
    if (isNumber(qdPopoverHeight)) qdPopoverHeight = qdPopoverHeight + 'px';
    this._qdPopoverHeight = qdPopoverHeight;

    if (this._overlayRef?.hasAttached()) {
      this._overlayRef.updateSize({ height: this._qdPopoverHeight });
      this.updatePosition();
    }
  }

  get qdPopoverHeight(): string | 'auto' {
    return this._qdPopoverHeight;
  }

  @Input() set qdPopoverMinHeight(qdPopoverMinHeight: number | string | 'none') {
    if (isNumber(qdPopoverMinHeight)) qdPopoverMinHeight = qdPopoverMinHeight + 'px';
    this._qdPopoverMinHeight = qdPopoverMinHeight;

    if (this._overlayRef?.hasAttached()) {
      this._overlayRef.updateSize({ minHeight: this._qdPopoverMinHeight });
      this.updatePosition();
    }
  }

  get qdPopoverMinHeight(): string | 'none' {
    return this._qdPopoverMinHeight;
  }

  @Input() set qdPopoverMaxHeight(qdPopoverMaxHeight: number | string | 'none') {
    if (isNumber(qdPopoverMaxHeight)) qdPopoverMaxHeight = qdPopoverMaxHeight + 'px';
    this._qdPopoverMaxHeight = qdPopoverMaxHeight;

    if (this._overlayRef?.hasAttached()) {
      this._overlayRef.updateSize({ maxHeight: this._qdPopoverMaxHeight });
      this.updatePosition();
    }
  }

  get qdPopoverMaxHeight(): string | 'none' {
    return this._qdPopoverMaxHeight;
  }

  @Output() readonly opened = new EventEmitter();
  @Output() readonly closed = new EventEmitter();

  private _qdPopoverWidth: string | 'auto' = convertPxToRem(204);
  private _qdPopoverMinWidth: string | 'none' = 'none';
  private _qdPopoverMaxWidth: string | 'none' = 'none';
  private _qdPopoverHeight: string | 'auto' = 'auto';
  private _qdPopoverMinHeight: string | 'none' = 'none';
  private _qdPopoverMaxHeight: string | 'none' = 'none';
  private _host: HTMLElement;
  private _overlayRef: OverlayRef;
  private _flexibleConnectedPositionStrategy: FlexibleConnectedPositionStrategy;
  private _closeSubscription: Subscription;
  private _positionChangesSubscription: Subscription;

  constructor(
    protected hostRef: ElementRef<HTMLElement>,
    protected overlayPositionBuilder: OverlayPositionBuilder,
    protected overlay: Overlay,
    protected popoverService: QdPopoverService,
    @Optional() protected popoverParentService: QdPopoverParentService
  ) {
    this._host = this.hostRef.nativeElement;
  }

  ngOnInit(): void {
    this._flexibleConnectedPositionStrategy = this.overlayPositionBuilder
      .flexibleConnectedTo(this._host)
      .withPositions([
        ...(this.positionStrategy
          ? Array.isArray(this.positionStrategy)
            ? this.positionStrategy
            : [this.positionStrategy]
          : []),
        {
          originX: 'end',
          originY: 'bottom',
          overlayX: 'end',
          overlayY: 'top'
        }
      ]);

    this._overlayRef = this.overlay.create({
      positionStrategy: this._flexibleConnectedPositionStrategy,
      disposeOnNavigation: true,
      scrollStrategy: this.overlay.scrollStrategies.reposition()
    });
  }

  ngOnDestroy(): void {
    this.close();
  }

  @HostListener('click', ['$event'])
  show(event: any): void {
    if (this.qdPopoverStopPropagation) event.stopPropagation();
    if (this.qdPopoverDisabled) return;

    if (!this._overlayRef.hasAttached()) {
      this.open();
    } else {
      this.close();
    }
  }

  @HostListener('document:click', ['$event'])
  clickedOutside(event: PointerEvent): void {
    if (this._overlayRef.hasAttached() && this.shouldClose(event)) this.close();
  }

  open(): void {
    if (this._overlayRef.hasAttached()) return;

    this.updateOverlayRefSize();

    const popoverPortal = new ComponentPortal(QdPopoverComponent);
    const popoverRef = this._overlayRef.attach(popoverPortal);

    popoverRef.instance.content = this.qdPopoverOnClick;

    if (this.qdPopoverBackgroundColor) popoverRef.instance.backgroundColor = this.qdPopoverBackgroundColor;

    popoverRef.instance.addParentPopovers(this.popoverParentService?.parentPopovers);
    this.opened.emit();

    this.popoverService.closeAllOverlays(this.popoverParentService?.parentPopovers);

    this._closeSubscription = this.popoverService.subscribe(excludedPopovers => {
      if (excludedPopovers.includes(popoverRef.instance)) return;
      this.close();
    });

    this._positionChangesSubscription = this._flexibleConnectedPositionStrategy.positionChanges
      .pipe(
        map(positionChange => positionChange.connectionPair.overlayY),
        distinctUntilChanged()
      )
      .subscribe(overlayY => {
        popoverRef.instance.setDirection(overlayY === 'top' ? 'down' : 'up');
      });
  }

  close(): void {
    if (!this._overlayRef.hasAttached()) return;

    this.resetOverlayRefSize();
    this._overlayRef?.detach();
    this._closeSubscription?.unsubscribe();
    this._positionChangesSubscription?.unsubscribe();
    this.closed.emit();
  }

  updatePosition(): void {
    if (!this._overlayRef.hasAttached()) return;

    this._overlayRef.updatePosition();
  }

  private updateOverlayRefSize(): void {
    this._overlayRef.updateSize({
      width: this.qdPopoverWidth,
      minWidth: this.qdPopoverMinWidth,
      maxWidth: this.qdPopoverMaxWidth,
      height: this.qdPopoverHeight,
      minHeight: this.qdPopoverMinHeight,
      maxHeight: this.qdPopoverMaxHeight
    });
  }

  private resetOverlayRefSize(): void {
    this._overlayRef.updateSize({
      width: 'auto',
      minWidth: 'auto',
      maxWidth: 'auto',
      height: 'auto',
      minHeight: 'auto',
      maxHeight: 'auto'
    });
  }

  private shouldClose(event: PointerEvent): boolean {
    if (!this._overlayRef.hasAttached() || event.target === this._host) return false;

    const target = event.target as any;

    if (this.qdPopoverCloseStrategy === 'onEveryClick')
      return !((target?.classList as DOMTokenList)?.contains('disabled') || target?.disabled);

    if (this.qdPopoverCloseStrategy === 'onOutsideClick') {
      const hostElementHovered = this._host.parentElement.querySelector(':hover');
      const overlayElementHovered = this._overlayRef.overlayElement.querySelector(':hover');
      const elementInPopoverClicked = !!target.closest('qd-popover');

      return !hostElementHovered && !overlayElementHovered && !elementInPopoverClicked;
    }
  }
}
