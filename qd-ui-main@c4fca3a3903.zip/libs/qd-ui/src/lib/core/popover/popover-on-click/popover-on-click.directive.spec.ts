// @ts-strict-ignore
import { QdPopoverOnClickDirective } from './popover-on-click.directive';
import { TestBed } from '@angular/core/testing';
import { Component, ElementRef, Injectable, ViewChild } from '@angular/core';
import { Overlay } from '@angular/cdk/overlay';
import { QdPopoverService } from '../popover.service';
import { Subject } from 'rxjs';
import { MockProvider } from 'ng-mocks';
import { QdPopoverParentService } from '../popover-parent.service';

@Injectable()
class MockElementRef {
  nativeElement = {};
}

@Component({
  selector: 'test-component',
  template: `
    <button [qdPopoverOnClick]="menu" (opened)="opened()" (closed)="closed()" data-test="menu" #button>menu</button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponent {
  @ViewChild(QdPopoverOnClickDirective) directive;

  opened = jest.fn();
  closed = jest.fn();
}

@Component({
  selector: 'test-component-disabled',
  template: `
    <button
      [qdPopoverOnClick]="menu"
      [qdPopoverDisabled]="true"
      (opened)="opened()"
      (closed)="closed()"
      data-test="menu"
      #button
    >
      menu
    </button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponentDisabled {
  opened = jest.fn();
  closed = jest.fn();
}

@Component({
  selector: 'test-component',
  template: `
    <button [qdPopoverOnClick]="menu" [qdPopoverStopPropagation]="false" data-test="menu" #button>menu</button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponentStopPropagationFalse {}

@Component({
  selector: 'test-component',
  template: `
    <button
      [qdPopoverOnClick]="menu"
      [qdPopoverStopPropagation]="false"
      [qdPopoverBackgroundColor]="'transparent'"
      data-test="menu"
      #button
    >
      menu
    </button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponentBackgroundColorTransparent {}

@Component({
  selector: 'test-component-with-width',
  template: `
    <button
      [qdPopoverOnClick]="menu"
      [qdPopoverWidth]="qdPopoverWidth"
      [qdPopoverMinWidth]="qdPopoverMinWidth"
      [qdPopoverMaxWidth]="qdPopoverMaxWidth"
      [qdPopoverHeight]="qdPopoverHeight"
      [qdPopoverMinHeight]="qdPopoverMinHeight"
      [qdPopoverMaxHeight]="qdPopoverMaxHeight"
      data-test="menu"
    >
      menu
    </button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponentWithWidthAndHeight {
  qdPopoverWidth = 'auto';
  qdPopoverHeight = 'auto';
  qdPopoverMinWidth = '200px';
  qdPopoverMaxWidth = '300px';
  qdPopoverMinHeight = '200px';
  qdPopoverMaxHeight = '300px';
}

@Component({
  selector: 'test-component-with-width-number-format',
  template: `
    <button
      [qdPopoverOnClick]="menu"
      [qdPopoverWidth]="qdPopoverWidth"
      [qdPopoverMinWidth]="qdPopoverMinWidth"
      [qdPopoverMaxWidth]="qdPopoverMaxWidth"
      [qdPopoverHeight]="qdPopoverHeight"
      [qdPopoverMinHeight]="qdPopoverMinHeight"
      [qdPopoverMaxHeight]="qdPopoverMaxHeight"
      data-test="menu"
    >
      menu
    </button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponentWithWidthAndHeightInNumberFormat {
  qdPopoverWidth = 'auto';
  qdPopoverHeight = 'auto';
  qdPopoverMinWidth = 200;
  qdPopoverMaxWidth = 300;
  qdPopoverMinHeight = 200;
  qdPopoverMaxHeight = 300;
}

@Component({
  selector: 'test-component-with-position-strategy',
  template: `
    <button
      [qdPopoverOnClick]="menu"
      [positionStrategy]="{
        originX: 'start',
        originY: 'bottom',
        overlayX: 'start',
        overlayY: 'top'
      }"
      data-test="menu"
    >
      menu
    </button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponentWithPositionStrategy {}

@Component({
  selector: 'test-component-with-position-strategy-array',
  template: `
    <button
      [qdPopoverOnClick]="menu"
      [positionStrategy]="[
        {
          originX: 'start',
          originY: 'bottom',
          overlayX: 'start',
          overlayY: 'top'
        },
        {
          originX: 'start',
          originY: 'top',
          overlayX: 'start',
          overlayY: 'bottom'
        }
      ]"
      data-test="menu"
    >
      menu
    </button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponentWithPositionStrategyArray {
  @ViewChild(QdPopoverOnClickDirective) directive;
}

describe(QdPopoverOnClickDirective.name, () => {
  let fixture;
  let component;

  let popoverRef;
  let mockOverlayRef;
  let mockOverlay;
  let mockPopoverService;
  let mockParentPopovers;

  beforeEach(() => {
    popoverRef = {
      instance: {
        setDirection: jest.fn(),
        addParentPopovers: jest.fn()
      }
    };

    mockOverlayRef = {
      detach: jest.fn(),
      hasAttached: jest.fn(),
      attach: jest.fn(() => popoverRef),
      updateSize: jest.fn(),
      updatePosition: jest.fn()
    };

    mockOverlay = {
      create: jest.fn(() => mockOverlayRef),
      scrollStrategies: { reposition: jest.fn() }
    };

    const mockCloseHandler = new Subject<boolean>();
    mockPopoverService = {
      closeAllOverlays: jest.fn(),
      subscribe: mockCloseHandler.subscribe.bind(mockCloseHandler),
      emitCloseHandler: mockCloseHandler.next.bind(mockCloseHandler)
    };

    mockParentPopovers = [{}, {}];
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        TestComponentDisabled,
        TestComponentStopPropagationFalse,
        TestComponentBackgroundColorTransparent,
        TestComponentWithWidthAndHeight,
        TestComponentWithWidthAndHeightInNumberFormat,
        TestComponentWithPositionStrategy,
        TestComponentWithPositionStrategyArray,
        QdPopoverOnClickDirective
      ],
      providers: [
        {
          provide: ElementRef,
          useClass: MockElementRef
        },
        {
          provide: Overlay,
          useValue: mockOverlay
        },
        MockProvider(QdPopoverParentService, { parentPopovers: mockParentPopovers })
      ]
    })
      .overrideDirective(QdPopoverOnClickDirective, {
        set: { providers: [{ provide: QdPopoverService, useValue: mockPopoverService }] }
      })
      .compileComponents();

    mockOverlayRef.hasAttached.mockReturnValue(false);
    mockOverlayRef.detach.mockClear();
  });

  afterEach(jest.clearAllMocks);

  function createComponent(testComponent): void {
    fixture = TestBed.createComponent(testComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }

  test('yields created overlay', () => {
    createComponent(TestComponent);

    expect(mockOverlay.create).toHaveBeenCalled();
    expect(mockOverlay.scrollStrategies.reposition).toHaveBeenCalledTimes(1);
  });

  test('yields attached popover on show', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(mockOverlayRef.attach).toHaveBeenCalled();
    expect(popoverRef.instance.content).toBe(component.directive.qdPopoverOnClick);
    expect(popoverRef.instance.addParentPopovers).toHaveBeenCalledWith(mockParentPopovers);
  });

  test('yields no attached popover and no events on show if disabled', () => {
    createComponent(TestComponentDisabled);

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(mockOverlayRef.attach).not.toHaveBeenCalled();
    expect(mockOverlayRef.detach).not.toHaveBeenCalled();
    expect(component.opened).not.toHaveBeenCalled();
    expect(component.closed).not.toHaveBeenCalled();
  });

  test('yields opened output event on show', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(fixture.componentInstance.opened).toHaveBeenCalledTimes(1);
  });

  test('yields no propagated event', () => {
    createComponent(TestComponent);

    const event = new Event('click');
    jest.spyOn(event, 'stopPropagation');

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.dispatchEvent(event);

    expect(event.stopPropagation).toHaveBeenCalled();
  });

  test('yields propagated event with qdPopoverStopPropagation false', () => {
    createComponent(TestComponentStopPropagationFalse);

    const event = new Event('click');
    jest.spyOn(event, 'stopPropagation');

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.dispatchEvent(event);

    expect(event.stopPropagation).not.toHaveBeenCalled();
  });

  test('yields attached popover on show with qdPopoverStopPropagation false', () => {
    createComponent(TestComponentStopPropagationFalse);

    mockOverlayRef.attach.mockImplementation(function () {
      this.hasAttached.mockReturnValue(true);
      return popoverRef;
    });

    const event = new Event('click', { bubbles: true });
    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.dispatchEvent(event);

    expect(mockOverlayRef.attach).toHaveBeenCalled();
    expect(mockOverlayRef.detach).not.toHaveBeenCalled();
  });

  test('yields popover with given backgroundColor', () => {
    createComponent(TestComponentBackgroundColorTransparent);

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(popoverRef.instance.backgroundColor).toBe('transparent');
  });

  test('yields closed popover on show if an overlay is already attached', () => {
    createComponent(TestComponent);

    mockOverlayRef.hasAttached.mockReturnValue(true);

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(mockOverlayRef.detach).toHaveBeenCalled();
  });

  test('yields closed overlays when showing', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();

    expect(mockPopoverService.closeAllOverlays).toHaveBeenCalledWith(mockParentPopovers);
  });

  test('yields detached overlay on destroy', () => {
    createComponent(TestComponent);

    mockOverlayRef.hasAttached.mockReturnValue(true);
    fixture.destroy();
    fixture.detectChanges();

    expect(mockOverlayRef.detach).toHaveBeenCalled();
  });

  test('yields closed popover on click if overlay is attached', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();
    fixture.detectChanges();
    mockOverlayRef.hasAttached.mockReturnValue(true);

    fixture.componentInstance.directive.clickedOutside({
      target: {
        className: 'something'
      }
    } as any);
    fixture.detectChanges();

    expect(mockOverlayRef.detach).toHaveBeenCalledTimes(1);
    expect(fixture.componentInstance.closed).toHaveBeenCalledTimes(1);
  });

  test('yields no closed popover on click if overlay is not attached', () => {
    createComponent(TestComponent);

    fixture.componentInstance.directive.clickedOutside({
      target: {
        className: 'something'
      }
    } as any);
    fixture.detectChanges();

    expect(mockOverlayRef.detach).not.toHaveBeenCalled();
    expect(fixture.componentInstance.closed).not.toHaveBeenCalled();
  });

  test('yields no closed popover for click on elements with class disabled', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();
    fixture.detectChanges();

    fixture.componentInstance.directive.clickedOutside({
      target: {
        className: 'something--disabled'
      }
    } as any);
    fixture.detectChanges();

    expect(mockOverlayRef.detach).not.toHaveBeenCalled();
    expect(fixture.componentInstance.closed).not.toHaveBeenCalled();
  });

  test('yields no closed popover for click on disabled elements', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();
    fixture.detectChanges();

    fixture.componentInstance.directive.clickedOutside({
      target: {
        disabled: true,
        className: 'something'
      }
    } as any);
    fixture.detectChanges();

    expect(mockOverlayRef.detach).not.toHaveBeenCalled();
    expect(fixture.componentInstance.closed).not.toHaveBeenCalled();
  });

  test('yields closed popover on emission of popoverService', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();
    fixture.detectChanges();
    mockOverlayRef.hasAttached.mockReturnValue(true);

    mockPopoverService.emitCloseHandler([]);

    expect(mockOverlayRef.detach).toHaveBeenCalledTimes(1);
    expect(fixture.componentInstance.closed).toHaveBeenCalledTimes(1);
  });

  test('yields not closed popover on emission of popoverService if popover in exclude list', () => {
    createComponent(TestComponent);

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();
    fixture.detectChanges();

    mockPopoverService.emitCloseHandler([popoverRef.instance]);

    expect(mockOverlayRef.detach).not.toHaveBeenCalled();
    expect(fixture.componentInstance.closed).not.toHaveBeenCalled();
  });

  test('yields created overlay without width and height before shown', () => {
    createComponent(TestComponentWithWidthAndHeight);

    expect(mockOverlay.create).not.toHaveBeenCalledWith(expect.objectContaining({ width: expect.any(String) }));
    expect(mockOverlay.create).not.toHaveBeenCalledWith(expect.objectContaining({ minWidth: expect.any(String) }));
    expect(mockOverlay.create).not.toHaveBeenCalledWith(expect.objectContaining({ maxWidth: expect.any(String) }));
    expect(mockOverlay.create).not.toHaveBeenCalledWith(expect.objectContaining({ height: expect.any(String) }));
    expect(mockOverlay.create).not.toHaveBeenCalledWith(expect.objectContaining({ minHeight: expect.any(String) }));
    expect(mockOverlay.create).not.toHaveBeenCalledWith(expect.objectContaining({ maxHeight: expect.any(String) }));
    expect(mockOverlayRef.updateSize).not.toHaveBeenCalled();
    expect(mockOverlayRef.updatePosition).not.toHaveBeenCalled();
  });

  test('yields created overlay with width and height after shown', () => {
    createComponent(TestComponentWithWidthAndHeight);

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith(
      expect.objectContaining({
        width: 'auto',
        minWidth: '200px',
        maxWidth: '300px',
        height: 'auto',
        minHeight: '200px',
        maxHeight: '300px'
      })
    );
  });

  test('yields created overlay with width and height after shown (number format)', () => {
    createComponent(TestComponentWithWidthAndHeightInNumberFormat);

    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();

    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith(
      expect.objectContaining({
        width: 'auto',
        minWidth: '200px',
        maxWidth: '300px',
        height: 'auto',
        minHeight: '200px',
        maxHeight: '300px'
      })
    );
  });

  test('yields created overlay with updated width', () => {
    createComponent(TestComponentWithWidthAndHeight);

    mockOverlayRef.hasAttached.mockReturnValue(true);

    component.qdPopoverWidth = '300px';
    fixture.detectChanges();
    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith({ width: '300px' });
    expect(mockOverlayRef.updatePosition).toHaveBeenCalled();

    jest.clearAllMocks();

    component.qdPopoverMinWidth = '100px';
    fixture.detectChanges();
    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith({ minWidth: '100px' });
    expect(mockOverlayRef.updatePosition).toHaveBeenCalled();

    jest.clearAllMocks();

    component.qdPopoverMaxWidth = 500; // number is also supported
    fixture.detectChanges();
    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith({ maxWidth: '500px' });
    expect(mockOverlayRef.updatePosition).toHaveBeenCalled();
  });

  test('yields created overlay with updated height', () => {
    createComponent(TestComponentWithWidthAndHeight);

    mockOverlayRef.hasAttached.mockReturnValue(true);

    component.qdPopoverHeight = '250px';
    fixture.detectChanges();
    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith({ height: '250px' });
    expect(mockOverlayRef.updatePosition).toHaveBeenCalled();

    jest.clearAllMocks();

    component.qdPopoverMinHeight = '100px';
    fixture.detectChanges();
    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith({ minHeight: '100px' });
    expect(mockOverlayRef.updatePosition).toHaveBeenCalled();

    jest.clearAllMocks();

    component.qdPopoverMaxHeight = 500; // number is also supported
    fixture.detectChanges();
    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith({ maxHeight: '500px' });
    expect(mockOverlayRef.updatePosition).toHaveBeenCalled();
  });

  test('yields overlay with resetted width and height on close', () => {
    createComponent(TestComponentWithWidthAndHeight);

    mockOverlayRef.hasAttached.mockReturnValue(true);

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();

    expect(mockOverlayRef.updateSize).toHaveBeenCalledWith({
      width: 'auto',
      minWidth: 'auto',
      maxWidth: 'auto',
      height: 'auto',
      minHeight: 'auto',
      maxHeight: 'auto'
    });
  });

  test('yields created overlay with custom positionStrategy', () => {
    createComponent(TestComponentWithPositionStrategy);

    expect(mockOverlay.create).toHaveBeenCalledWith(
      expect.objectContaining({
        positionStrategy: expect.objectContaining({
          _preferredPositions: [
            {
              originX: 'start',
              originY: 'bottom',
              overlayX: 'start',
              overlayY: 'top'
            },
            {
              originX: 'end',
              originY: 'bottom',
              overlayX: 'end',
              overlayY: 'top'
            }
          ]
        })
      })
    );
  });

  test('yields created overlay with custom positionStrategy array', () => {
    createComponent(TestComponentWithPositionStrategyArray);

    expect(mockOverlay.create).toHaveBeenCalledWith(
      expect.objectContaining({
        positionStrategy: expect.objectContaining({
          _preferredPositions: [
            {
              originX: 'start',
              originY: 'bottom',
              overlayX: 'start',
              overlayY: 'top'
            },
            {
              originX: 'start',
              originY: 'top',
              overlayX: 'start',
              overlayY: 'bottom'
            },
            {
              originX: 'end',
              originY: 'bottom',
              overlayX: 'end',
              overlayY: 'top'
            }
          ]
        })
      })
    );
  });

  test('yields created overlay with correct direction after position strategy becomes effective', () => {
    createComponent(TestComponentWithPositionStrategyArray);

    // @ts-ignore
    const flexibleConnectedPositionStrategy = component.directive._flexibleConnectedPositionStrategy;
    flexibleConnectedPositionStrategy.positionChanges = new Subject();

    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.click();
    fixture.detectChanges();

    (flexibleConnectedPositionStrategy.positionChanges as Subject<any>).next({
      connectionPair: {
        overlayY: 'bottom'
      }
    });
    expect(popoverRef.instance.setDirection).toHaveBeenNthCalledWith(1, 'up');

    (flexibleConnectedPositionStrategy.positionChanges as Subject<any>).next({
      connectionPair: {
        overlayY: 'top'
      }
    });
    expect(popoverRef.instance.setDirection).toHaveBeenNthCalledWith(2, 'down');
  });
});
