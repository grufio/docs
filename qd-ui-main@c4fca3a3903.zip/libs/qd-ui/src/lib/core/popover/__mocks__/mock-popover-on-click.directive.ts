// @ts-strict-ignore
import {
  Component,
  Directive,
  EventEmitter,
  HostListener,
  Input,
  Optional,
  Output,
  TemplateRef,
  ViewContainerRef
} from '@angular/core';
import { DomPortalOutlet, TemplatePortal } from '@angular/cdk/portal';
import { ConnectedPosition } from '@angular/cdk/overlay';
import { QdPopoverBackgroundColor } from '../popover/popover.component';
import { QdPopoverService } from '../popover.service';
import { QdPopoverParentService } from '../popover-parent.service';

@Component({
  selector: 'qd-mock-popover',
  template: ''
})
export class QdMockPopoverComponent {}

@Directive({
  selector: '[qdPopoverOnClick]'
})
export class QdMockPopoverOnClickDirective {
  @Input() qdPopoverOnClick: TemplateRef<unknown>;
  @Input() qdPopoverWidth: string | 'auto';
  @Input() qdPopoverMinWidth: string | 'none';
  @Input() qdPopoverMaxWidth: string | 'none';
  @Input() qdPopoverHeight: string | 'auto' = 'auto';
  @Input() qdPopoverMinHeight: string | 'none' = 'none';
  @Input() qdPopoverMaxHeight: string | 'none' = 'none';
  @Input() positionStrategy: ConnectedPosition | ConnectedPosition[];
  @Input() qdPopoverCloseStrategy: 'onOutsideClick' | 'onEveryClick' = 'onEveryClick';
  @Input() qdPopoverDisabled = false;
  @Input() qdPopoverStopPropagation = true;
  @Input() qdPopoverBackgroundColor: QdPopoverBackgroundColor;

  @Output() readonly opened = new EventEmitter();
  @Output() readonly closed = new EventEmitter();

  constructor(
    private viewContainerRef: ViewContainerRef,
    @Optional() protected popoverService: QdPopoverService,
    @Optional() protected popoverParentService: QdPopoverParentService
  ) {}

  ngOnInit(): void {}
  ngOnDestroy(): void {}
  updatePosition(): void {}

  private popoverMockPortal: DomPortalOutlet;

  @HostListener('click', ['$event'])
  show(event: any): void {
    if (this.qdPopoverStopPropagation) event.stopPropagation();

    this.open();
  }

  open = jest.fn(() => {
    if (!this.popoverMockPortal) {
      this.viewContainerRef.createComponent(QdMockPopoverComponent);
      this.popoverMockPortal = new DomPortalOutlet(document.querySelector('qd-mock-popover'));
    }

    if (this.popoverService) {
      this.popoverService.closeAllOverlays(this.popoverParentService?.parentPopovers);
      this.popoverService.subscribe(() => this.detach());
    }

    this.detach();

    this.popoverMockPortal.attach(new TemplatePortal(this.qdPopoverOnClick, this.viewContainerRef));

    this.opened.emit();
  });

  private detach(): void {
    if (this.popoverMockPortal?.hasAttached()) this.popoverMockPortal.detach();
  }

  close = jest.fn(() => {
    this.closed.emit();
  });
}
