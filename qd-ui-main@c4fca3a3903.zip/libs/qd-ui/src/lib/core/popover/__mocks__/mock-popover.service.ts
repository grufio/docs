// @ts-strict-ignore
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { PopoverCloseCallback } from '../popover.service';
import { QdPopoverComponent } from '../popover/popover.component';

@Injectable()
export class QdMockPopoverService {
  closeAllOverlays() {}

  subscribe(callback: PopoverCloseCallback) {
    return of([new QdPopoverComponent(null, null, null)]).subscribe(callback);
  }
}
