import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QdMockPopoverComponent } from './mock-popover.component';
import { QdMockPopoverOnClickDirective } from './mock-popover-on-click.directive';
import { QdMockPopoverService } from './mock-popover.service';

@NgModule({
  imports: [CommonModule],
  declarations: [QdMockPopoverComponent, QdMockPopoverOnClickDirective],
  exports: [QdMockPopoverOnClickDirective],
  providers: [QdMockPopoverService]
})
export class QdMockPopoverModule {}
