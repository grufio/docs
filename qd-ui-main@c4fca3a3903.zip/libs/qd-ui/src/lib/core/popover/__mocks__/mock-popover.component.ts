// @ts-strict-ignore
import { Component, Input, TemplateRef } from '@angular/core';

@Component({
  selector: 'qd-popover',
  template: 'content: <ng-container *ngTemplateOutlet="content"></ng-container>'
})
export class QdMockPopoverComponent {
  @Input()
  content: TemplateRef<unknown>;
}
