// @ts-strict-ignore
import { ConnectedPosition, Overlay, OverlayPositionBuilder, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import {
  Directive,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
  Output,
  TemplateRef
} from '@angular/core';
import { Subscription } from 'rxjs';
import { convertPxToRem } from '../../tools/convertPxToRem.tools';
import { QdPopoverService } from '../popover.service';
import { QdPopoverComponent } from '../popover/popover.component';

@Directive({
  selector: '[qdPopoverOnHover]'
})
export class QdPopoverOnHoverDirective implements OnInit, OnDestroy {
  private host: HTMLElement;
  private overlayRef: OverlayRef;
  private closeSubscription: Subscription;

  @Input() qdPopoverOnHover: TemplateRef<unknown>;
  @Input() qdPopoverWidth: string | 'auto' = convertPxToRem(204);
  @Input() positionStrategy: ConnectedPosition;

  @Output() readonly opened = new EventEmitter();
  @Output() readonly closed = new EventEmitter();

  constructor(
    private hostRef: ElementRef<HTMLElement>,
    private overlayPositionBuilder: OverlayPositionBuilder,
    private overlay: Overlay,
    private popoverService: QdPopoverService
  ) {
    this.host = this.hostRef.nativeElement;
  }

  ngOnInit(): void {
    const positionStrategy = this.overlayPositionBuilder.flexibleConnectedTo(this.host).withPositions([
      ...(this.positionStrategy ? [this.positionStrategy] : []),
      {
        originX: 'end',
        originY: 'bottom',
        overlayX: 'end',
        overlayY: 'top'
      }
    ]);

    this.overlayRef = this.overlay.create({ positionStrategy, width: this.qdPopoverWidth, disposeOnNavigation: true });
  }

  ngOnDestroy(): void {
    this.close();
  }

  @HostListener('mouseover', ['$event'])
  show(event: any): void {
    event.stopPropagation();
    if (!this.overlayRef.hasAttached()) {
      const popoverPortal = new ComponentPortal(QdPopoverComponent);
      const popoverRef = this.overlayRef.attach(popoverPortal);

      popoverRef.instance.content = this.qdPopoverOnHover;
      this.opened.emit();

      this.popoverService.closeAllOverlays();

      this.closeSubscription = this.popoverService.subscribe(() => this.close());
    }
  }

  @HostListener('document:mouseout', ['$event'])
  hoveredOutside(): void {
    if (this.overlayRef.hasAttached() && !this.overlayRef.overlayElement.querySelector(':hover')) this.close();
  }

  close(): void {
    this.overlayRef?.detach();
    this.closeSubscription?.unsubscribe();
    this.closed.emit();
  }
}
