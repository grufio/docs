// @ts-strict-ignore
import { QdPopoverOnHoverDirective } from './popover-on-hover.directive';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, ElementRef, Injectable, ViewChild } from '@angular/core';
import { FlexibleConnectedPositionStrategy, Overlay } from '@angular/cdk/overlay';
import { QdPopoverService } from '../popover.service';
import { Subject } from 'rxjs';

jest.mock('../popover.service', () => ({ QdPopoverService: class {} }));

@Injectable()
class MockElementRef {
  nativeElement = {};
}

@Component({
  selector: 'test-component',
  template: `
    <button [qdPopoverOnHover]="menu" data-test="menu" #button>menu</button>
    <ng-template #menu>
      <p>Hello, folks!</p>
    </ng-template>
  `
})
class TestComponent {
  @ViewChild(QdPopoverOnHoverDirective) directive;
}

const popoverRef = {
  instance: {}
};

const mockOverlayRef = {
  detach: jest.fn(),
  hasAttached: jest.fn(),
  overlayElement: {
    querySelector: jest.fn()
  },
  attach: jest.fn(() => popoverRef)
};

const mockOverlay = {
  create: jest.fn(() => mockOverlayRef)
};

const mockCloseHandler = new Subject<boolean>();
const mockPopoverService = {
  closeAllOverlays: jest.fn(),
  subscribe: mockCloseHandler.subscribe.bind(mockCloseHandler),
  emitCloseHandler: mockCloseHandler.next.bind(mockCloseHandler)
};

describe(QdPopoverOnHoverDirective.name, () => {
  let fixture: ComponentFixture<TestComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestComponent, QdPopoverOnHoverDirective],
      providers: [
        {
          provide: ElementRef,
          useClass: MockElementRef
        },
        {
          provide: Overlay,
          useValue: mockOverlay
        },
        {
          provide: QdPopoverService,
          useValue: mockPopoverService
        }
      ]
    });

    TestBed.compileComponents().then(() => {
      fixture = TestBed.createComponent(TestComponent);
      fixture.detectChanges();

      jest.spyOn(fixture.componentInstance.directive.closed, 'emit');
      jest.spyOn(fixture.componentInstance.directive.opened, 'emit');
    });

    mockOverlayRef.hasAttached.mockReturnValue(false);
    mockOverlayRef.detach.mockClear();
  });

  test('yields created overlay', () => {
    expect(mockOverlay.create).toHaveBeenCalledWith({
      positionStrategy: expect.any(FlexibleConnectedPositionStrategy),
      width: '12.75rem',
      disposeOnNavigation: true
    });
  });

  test('yields created overlay with custom position strategy', () => {
    fixture.componentInstance.directive.positionStrategy = {
      originX: 'start',
      originY: 'top',
      overlayX: 'start',
      overlayY: 'bottom'
    };
    fixture.componentInstance.directive.ngOnInit();

    expect(mockOverlay.create).toHaveBeenCalledWith({
      positionStrategy: expect.objectContaining({
        _preferredPositions: [
          {
            originX: 'start',
            originY: 'top',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'end',
            originY: 'bottom',
            overlayX: 'end',
            overlayY: 'top'
          }
        ]
      }),
      width: '12.75rem',
      disposeOnNavigation: true
    });
  });

  test('yields attached popover on hover', () => {
    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.dispatchEvent(new Event('mouseover'));

    expect(mockOverlayRef.attach).toHaveBeenCalled();
  });

  test('yields opened output event on hover', () => {
    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.dispatchEvent(new Event('mouseover'));

    expect(fixture.componentInstance.directive.opened.emit).toHaveBeenCalledTimes(1);
  });

  test('yields closed overlays when mouse is moved out', () => {
    mockOverlayRef.hasAttached.mockReturnValue(true);
    mockOverlayRef.overlayElement.querySelector.mockReturnValue(false);

    document.dispatchEvent(new Event('mouseout'));

    expect(mockOverlayRef.overlayElement.querySelector).toHaveBeenCalledWith(':hover');
    expect(mockOverlayRef.detach).toHaveBeenCalled();
    expect(fixture.componentInstance.directive.closed.emit).toHaveBeenCalledTimes(1);
  });

  test('yields no closed popover when mouse is moved out if no overlay is attached', () => {
    mockOverlayRef.hasAttached.mockReturnValue(false);

    document.dispatchEvent(new Event('mouseout'));

    expect(mockOverlayRef.detach).not.toHaveBeenCalled();
    expect(fixture.componentInstance.directive.closed.emit).not.toHaveBeenCalled();
  });

  test('yields closed popover on emission of popoverService', () => {
    let button = fixture.debugElement.nativeElement.querySelector('button[data-test="menu"]');
    button.dispatchEvent(new Event('mouseover'));
    fixture.detectChanges();

    mockPopoverService.emitCloseHandler(true);

    expect(mockOverlayRef.detach).toHaveBeenCalledTimes(1);
    expect(fixture.componentInstance.directive.closed.emit).toHaveBeenCalledTimes(1);
  });

  test('yields detached overlay on destroy', () => {
    fixture.destroy();
    fixture.detectChanges();

    expect(mockOverlayRef.detach).toHaveBeenCalled();
    expect(fixture.componentInstance.directive.closed.emit).toHaveBeenCalledTimes(1);
  });

  test('yields no error on destroy with detached overlay', () => {
    fixture.componentInstance.directive.overlayRef = null;

    expect(() => fixture.destroy()).not.toThrow();
  });
});
