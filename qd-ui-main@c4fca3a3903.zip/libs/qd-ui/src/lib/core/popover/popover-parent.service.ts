import { Injectable } from '@angular/core';
import { QdPopoverComponent } from './popover/popover.component';

@Injectable()
export class QdPopoverParentService {
  parentPopovers: QdPopoverComponent[] = [];
}
