import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

import { QdAppEnvironment } from './model/app-enviroment.interface';
import { QdBreadcrumbsModule } from './breadcrumbs/breadcrumbs.module';
import { QdDataFacetsModule } from './data-facets/data-facets.module';
import { QdDisabledDirective } from './disabled/disabled.directive';
import { QdFileSizePipe } from './pipes/file-size.pipe';
import { QdPlaceholderPipe } from './pipes/placeholder.pipe';
import { QdProjectionGuardComponent } from './projection-guard/projection-guard.component';
import { QdRwdDisabledDirective } from './rwd-disabled/rwd-disabled.directive';
import { QdTooltipAtIntersectionDirective } from './tooltip/tooltip-at-intersection/tooltip-at-intersection.directive';
import { QdTranslatable, QdTranslation } from './model/translation.interface';
import { QdVisuallyHiddenDirective } from './visually-hidden/visually-hidden.directive';
import { QdPushEventsService } from './services/push-events.service';

export {
  QdAppEnvironment,
  QdDisabledDirective,
  QdFileSizePipe,
  QdPlaceholderPipe,
  QdProjectionGuardComponent,
  QdRwdDisabledDirective,
  QdTooltipAtIntersectionDirective,
  QdTranslatable,
  QdTranslation,
  QdVisuallyHiddenDirective,
  QdPushEventsService
};

@NgModule({
  imports: [CommonModule, TranslateModule, QdDataFacetsModule, QdBreadcrumbsModule],
  declarations: [
    QdDisabledDirective,
    QdFileSizePipe,
    QdPlaceholderPipe,
    QdProjectionGuardComponent,
    QdRwdDisabledDirective,
    QdVisuallyHiddenDirective
  ],
  exports: [
    QdDisabledDirective,
    QdFileSizePipe,
    QdPlaceholderPipe,
    QdProjectionGuardComponent,
    QdRwdDisabledDirective,
    QdVisuallyHiddenDirective
  ]
})
export class QdCoreModule {}
