import { Component, Type } from '@angular/core';
import { TestBed } from '@angular/core/testing';

import { QdProjectionGuardComponent } from './projection-guard.component';

@Component({
  template: `<qd-projection-guard></qd-projection-guard>`
})
class TestHostBasicComponent {}

@Component({
  template: `
    <qd-projection-guard>
      <div id="child1"></div>
      <span id="child2"></span>
    </qd-projection-guard>
  `
})
class TestHostWithChildrenComponent {}

@Component({
  template: `<qd-projection-guard [isDisabled]="true"><div></div></qd-projection-guard>`
})
class TestHostDisabledComponent {}

@Component({
  template: `<qd-projection-guard><div></div></qd-projection-guard>`
})
class TestHostDefaultWarningComponent {}

@Component({
  template: `
    <qd-projection-guard warningMessage="Custom Warning">
      <div></div>
    </qd-projection-guard>
  `
})
class TestHostCustomWarningComponent {}

@Component({
  template: `<qd-projection-guard [isDisabled]="false"></qd-projection-guard>`
})
class TestHostExplicitEnabledComponent {}

describe(`Testing ${QdProjectionGuardComponent.name} |`, () => {
  const configureTestBed = (hostComponent: Type<unknown>) => {
    TestBed.configureTestingModule({
      declarations: [QdProjectionGuardComponent, hostComponent]
    });
  };

  const createComponent = <T>(component: Type<T>) => TestBed.createComponent(component);

  afterEach(() => jest.restoreAllMocks());

  describe('basic functionality', () => {
    beforeEach(() => configureTestBed(TestHostBasicComponent));

    test('removes host element from DOM', () => {
      const fixture = createComponent(TestHostBasicComponent);

      fixture.detectChanges();

      expect(fixture.nativeElement.querySelector('qd-projection-guard')).toBeNull();
    });
  });

  describe('child content projection', () => {
    beforeEach(() => configureTestBed(TestHostWithChildrenComponent));

    test('logs warnings for all child elements', () => {
      const warnSpy = jest.spyOn(console, 'warn').mockImplementation();
      const expectedMessage = 'QD-UI | QdProjectionGuard - This content is not supported and cannot be displayed:';
      const expectedFirstElement = expect.objectContaining({ id: 'child1' });
      const expectedSecondElement = expect.objectContaining({ id: 'child2' });

      createComponent(TestHostWithChildrenComponent).detectChanges();

      expect(warnSpy).toHaveBeenCalledTimes(2);
      expect(warnSpy).toHaveBeenNthCalledWith(1, expectedMessage, expectedFirstElement);
      expect(warnSpy).toHaveBeenNthCalledWith(2, expectedMessage, expectedSecondElement);
    });

    test('logs element-specific warnings', () => {
      const warnSpy = jest.spyOn(console, 'warn').mockImplementation();

      createComponent(TestHostWithChildrenComponent).detectChanges();

      expect(warnSpy).toHaveBeenCalledTimes(2);
      expect(warnSpy).toHaveBeenNthCalledWith(1, expect.any(String), expect.objectContaining({ id: 'child1' }));
      expect(warnSpy).toHaveBeenNthCalledWith(2, expect.any(String), expect.objectContaining({ id: 'child2' }));
    });
  });

  describe('disabled state handling', () => {
    beforeEach(() => configureTestBed(TestHostDisabledComponent));

    test('prevents warning logging when disabled', () => {
      const warnSpy = jest.spyOn(console, 'warn').mockImplementation();

      createComponent(TestHostDisabledComponent).detectChanges();

      expect(warnSpy).not.toHaveBeenCalled();
    });

    test('still removes host element when disabled', () => {
      const fixture = createComponent(TestHostDisabledComponent);

      fixture.detectChanges();

      expect(fixture.nativeElement.querySelector('qd-projection-guard')).toBeNull();
    });
  });

  describe('warning message configuration', () => {
    test('uses default warning template', () => {
      configureTestBed(TestHostDefaultWarningComponent);
      const warnSpy = jest.spyOn(console, 'warn').mockImplementation();

      createComponent(TestHostDefaultWarningComponent).detectChanges();

      expect(warnSpy).toHaveBeenCalledWith(
        'QD-UI | QdProjectionGuard - This content is not supported and cannot be displayed:',
        expect.any(HTMLElement)
      );
    });

    test('accepts custom warning messages', () => {
      configureTestBed(TestHostCustomWarningComponent);
      const warnSpy = jest.spyOn(console, 'warn').mockImplementation();

      createComponent(TestHostCustomWarningComponent).detectChanges();

      expect(warnSpy).toHaveBeenCalledWith('Custom Warning', expect.any(HTMLElement));
    });
  });
});
