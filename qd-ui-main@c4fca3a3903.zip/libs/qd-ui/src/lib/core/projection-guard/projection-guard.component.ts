import { AfterContentInit, AfterViewInit, Component, ElementRef, Input } from '@angular/core';

@Component({
  selector: 'qd-projection-guard',
  template: '<ng-content></ng-content>',
  styles: [':host { display: none !important; position: absolute }']
})
export class QdProjectionGuardComponent implements AfterContentInit, AfterViewInit {
  @Input() isDisabled = false;
  @Input() warningMessage = 'QD-UI | QdProjectionGuard - This content is not supported and cannot be displayed:';

  wildcardSlot!: Element;

  constructor(private elementRef: ElementRef) {}

  ngAfterContentInit(): void {
    if (this.isDisabled) return;

    this.wildcardSlot = this.elementRef.nativeElement;

    if (!this.wildcardSlot.children.length) return;

    Array.from(this.wildcardSlot.children).forEach(el => console.warn(this.warningMessage, el));
  }

  ngAfterViewInit(): void {
    this.elementRef.nativeElement.remove();
  }
}
