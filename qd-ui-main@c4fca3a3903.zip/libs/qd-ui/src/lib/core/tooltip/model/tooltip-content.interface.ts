/**
 * @description Defines the content.
 */
export interface QdTooltipContent {
  /**
   * @description Defines the translation key for headline.
   */
  headline?: { i18n: string };

  /**
   * @description Defines the translation keys for paragraph.
   */
  paragraphs: { i18n: string }[];
}
