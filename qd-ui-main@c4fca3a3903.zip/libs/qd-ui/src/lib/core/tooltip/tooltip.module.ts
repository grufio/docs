import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

import { QdTooltipAtIntersectionDirective } from './tooltip-at-intersection/tooltip-at-intersection.directive';
import { QdTooltipComponent } from './tooltip/tooltip.component';
import { QdTooltipOnClickDirective } from './tooltip-on-tap-hover/tooltip-on-click.directive';

@NgModule({
  imports: [CommonModule, TranslateModule],
  declarations: [QdTooltipComponent, QdTooltipOnClickDirective, QdTooltipAtIntersectionDirective],
  exports: [QdTooltipOnClickDirective, QdTooltipAtIntersectionDirective]
})
export class QdTooltipModule {}
