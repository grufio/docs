import { Directive, ElementRef, HostListener, Input, OnDestroy } from '@angular/core';
import { ConnectedPosition, Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { TranslateService } from '@ngx-translate/core';

import { QdTooltipComponent } from '../tooltip/tooltip.component';
import { QdTooltipContent } from '../model/tooltip-content.interface';

const MAX_TOOLTIP_CHARACTER = 512;
const TOOLTIP_POSITIONS: ConnectedPosition[] = [
  { originX: 'center', originY: 'top', overlayX: 'center', overlayY: 'bottom' },
  { originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'top' },
  { originX: 'start', originY: 'center', overlayX: 'end', overlayY: 'center' },
  { originX: 'end', originY: 'center', overlayX: 'start', overlayY: 'center' }
];

@Directive({
  selector: '[qdTooltipOnClick]'
})
export class QdTooltipOnClickDirective implements OnDestroy {
  @Input() qdTooltipContent?: QdTooltipContent;

  private _overlayRef?: OverlayRef | null;

  @HostListener('click')
  onClickToggle(): void {
    this._overlayRef ? this.close() : this.show();
  }

  @HostListener('document:click', ['$event.target'])
  onOutsideClickClose(target: HTMLElement): void {
    if (!this.elementRef.nativeElement.contains(target)) this.close();
  }

  constructor(private overlay: Overlay, private elementRef: ElementRef, private translateService: TranslateService) {}

  ngOnDestroy(): void {
    this.close();
  }

  show(): void {
    const positionStrategy = this.overlay
      .position()
      .flexibleConnectedTo(this.elementRef)
      .withFlexibleDimensions(false)
      .withPush(false)
      .withPositions(TOOLTIP_POSITIONS);

    this._overlayRef = this.overlay.create({ positionStrategy });

    const tooltipRef = this._overlayRef.attach(new ComponentPortal(QdTooltipComponent));
    tooltipRef.instance.content = this.getContent();
  }

  close(): void {
    if (this._overlayRef) {
      this._overlayRef.dispose();
      this._overlayRef = null;
    }
  }

  private getContent(): { headline?: string; paragraphs: string[] } {
    const content: { headline?: string; paragraphs: string[] } = { paragraphs: [] };

    let fullText = '';

    const headline = this.qdTooltipContent?.headline?.i18n;

    if (headline) {
      const translatedHeadline = this.translate(headline);
      content.headline = translatedHeadline;
      fullText += translatedHeadline;
    }

    const paragraphs = this.qdTooltipContent?.paragraphs || [];
    const translatedParagraphs = paragraphs.map(p => this.translate(p.i18n));

    if (translatedParagraphs.length) {
      content.paragraphs.push(...translatedParagraphs);
      fullText += translatedParagraphs.join('');
    }

    const truncatedText = this.truncateText(fullText);

    return {
      headline: content.headline,
      paragraphs: content.paragraphs.map(p =>
        truncatedText.includes(p) ? p : `${p.substring(0, MAX_TOOLTIP_CHARACTER)}...`
      )
    };
  }

  private truncateText(text: string): string {
    if (text.length <= MAX_TOOLTIP_CHARACTER) return text.trim();

    console.warn(
      `QdUi | QdTooltip - Tooltip content exceeds ${MAX_TOOLTIP_CHARACTER} characters. It will be truncated.`
    );

    return `${text.substring(0, MAX_TOOLTIP_CHARACTER).trim()}...`;
  }

  private translate(key: string): string {
    return this.translateService.instant(key);
  }
}
