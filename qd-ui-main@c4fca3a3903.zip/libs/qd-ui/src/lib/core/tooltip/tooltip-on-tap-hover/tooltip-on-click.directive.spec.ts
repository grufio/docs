import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Overlay } from '@angular/cdk/overlay';
import { TranslateService } from '@ngx-translate/core';
import { MockComponent, MockProvider } from 'ng-mocks';

import { QdTooltipOnClickDirective } from './tooltip-on-click.directive';
import { QdTooltipComponent } from '../tooltip/tooltip.component';
import { QdTooltipContent } from '../model/tooltip-content.interface';

@Component({
  template: `<button [qdTooltipContent]="content" qdTooltipOnClick></button>`
})
class HostComponent {
  content?: QdTooltipContent;
}

describe(`Testing ${QdTooltipOnClickDirective.name} |`, () => {
  let fixture: ComponentFixture<HostComponent>;
  let host: HostComponent;
  let directive: QdTooltipOnClickDirective;
  let overlay: Overlay;
  let translateService: TranslateService;

  const createOverlayMock = jest.fn(() => ({
    dispose: jest.fn(),
    attach: jest.fn(() => ({ instance: { content: {} } })),
    hasAttached: jest.fn(() => true)
  }));

  const positionMock = jest.fn(() => ({
    flexibleConnectedTo: jest.fn(() => ({
      withFlexibleDimensions: jest.fn(() => ({
        withPush: jest.fn(() => ({
          withPositions: jest.fn(() => [])
        }))
      }))
    }))
  }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HostComponent, QdTooltipOnClickDirective, MockComponent(QdTooltipComponent)],
      providers: [
        MockProvider(TranslateService, {
          instant: jest.fn((key: string) => key)
        }),
        MockProvider(Overlay, {
          create: createOverlayMock,
          position: positionMock
        } as any)
      ]
    });

    fixture = TestBed.createComponent(HostComponent);
    host = fixture.componentInstance;
    directive = fixture.debugElement
      .query(By.directive(QdTooltipOnClickDirective))
      .injector.get(QdTooltipOnClickDirective);

    overlay = TestBed.inject(Overlay);
    translateService = TestBed.inject(TranslateService);

    jest.spyOn(console, 'warn').mockImplementation();
  });

  test('toggles overlay on host click', () => {
    const button = fixture.debugElement.query(By.css('button'));

    button.nativeElement.click();

    expect((directive as any)._overlayRef).toBeTruthy();

    button.nativeElement.click();

    expect((directive as any)._overlayRef).toBeNull();
  });

  test('creates overlay with correct position strategy', () => {
    const mockWithPositions = jest.fn();
    const mockWithPush = jest.fn(() => ({ withPositions: mockWithPositions }));
    const mockWithFlexibleDimensions = jest.fn(() => ({ withPush: mockWithPush }));
    const mockFlexibleConnectedTo = jest.fn(() => ({ withFlexibleDimensions: mockWithFlexibleDimensions }));

    (overlay.position as jest.Mock).mockReturnValueOnce({ flexibleConnectedTo: mockFlexibleConnectedTo });

    directive.show();

    expect(overlay.position).toHaveBeenCalled();
    expect(mockFlexibleConnectedTo).toHaveBeenCalledWith(directive['elementRef']);
    expect(mockWithFlexibleDimensions).toHaveBeenCalledWith(false);
    expect(mockWithPush).toHaveBeenCalledWith(false);

    const expectedPositions = [
      { originX: 'center', originY: 'top', overlayX: 'center', overlayY: 'bottom' },
      { originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'top' },
      { originX: 'start', originY: 'center', overlayX: 'end', overlayY: 'center' },
      { originX: 'end', originY: 'center', overlayX: 'start', overlayY: 'center' }
    ];

    expect(mockWithPositions).toHaveBeenCalledWith(expectedPositions);
  });

  test('closes overlay on external click', () => {
    const button = fixture.debugElement.query(By.css('button'));

    button.nativeElement.click();
    expect((directive as any)._overlayRef).toBeTruthy();

    document.dispatchEvent(new MouseEvent('click'));
    expect((directive as any)._overlayRef).toBeNull();
  });

  test('dispose overlay when closed', () => {
    const button = fixture.debugElement.query(By.css('button'));
    button.nativeElement.click();

    const overlayRef = (directive as any)._overlayRef;

    directive.close();

    expect(overlayRef.dispose).toHaveBeenCalledWith();
  });

  test('ngOnDestroy closes overlay', () => {
    directive.show();
    directive.ngOnDestroy();

    expect((directive as any)._overlayRef).toBeNull();
  });

  test('generates translated content', () => {
    host.content = {
      headline: { i18n: 'test.headline' },
      paragraphs: [{ i18n: 'test.para1' }, { i18n: 'test.para2' }]
    };

    fixture.detectChanges();
    const content = (directive as any).getContent();

    expect(content).toEqual({
      headline: 'test.headline',
      paragraphs: ['test.para1', 'test.para2']
    });
  });

  test('truncates content over 512 chars', () => {
    const longText = 'x'.repeat(600);
    host.content = { paragraphs: [{ i18n: longText }] };

    fixture.detectChanges();
    const content = (directive as any).getContent();

    expect(content.paragraphs[0].length).toBe(512 + 3);
    expect(content.paragraphs[0].endsWith('...')).toBe(true);

    expect(console.warn).toHaveBeenCalledWith(
      'QdUi | QdTooltip - Tooltip content exceeds 512 characters. It will be truncated.'
    );
  });

  test('uses translation service', () => {
    host.content = {
      headline: { i18n: 'test.header' },
      paragraphs: [{ i18n: 'test.content' }]
    };

    fixture.detectChanges();
    (directive as any).getContent();

    expect(translateService.instant).toHaveBeenCalledWith('test.header');
    expect(translateService.instant).toHaveBeenCalledWith('test.content');
  });

  test('handles undefined content', () => {
    host.content = undefined;
    fixture.detectChanges();

    const content = (directive as any).getContent();

    expect(content).toEqual({ paragraphs: [] });
  });
});
