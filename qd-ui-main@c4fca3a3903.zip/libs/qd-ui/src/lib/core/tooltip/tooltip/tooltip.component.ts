import { Component, Input } from '@angular/core';

@Component({
  selector: 'qd-tooltip',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.scss']
})
export class QdTooltipComponent {
  @Input() content?: { headline?: string; paragraphs: string[] };
}
