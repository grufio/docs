import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QdMockTranslatePipe } from '../../__mocks__/mock-translate.pipe';
import { QdTooltipComponent } from './tooltip.component';

@Component({
  selector: 'minimal-test-component',
  template: ` <qd-tooltip [content]="content"></qd-tooltip> `
})
class MinimalTestComponent {
  content = {
    paragraphs: ['SwissInnovate GmbH, headquartered in Zurstein']
  };
}

@Component({
  selector: 'full-test-component',
  template: ` <qd-tooltip [content]="content"></qd-tooltip> `
})
class FullTestComponent {
  content = {
    headline: 'About SwissInnovate',
    paragraphs: [
      'SwissInnovate GmbH, headquartered in Zurstein, Switzerland, excels in technology consulting and innovation development.',
      'With a strong presence in Helvetia City, Lugesta, and Villeciel, the company supports businesses in adopting cutting-edge solutions tailored to their unique needs.'
    ]
  };
}

describe(`Testing ${QdTooltipComponent.name} |`, () => {
  function createComponent(): void {
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [CommonModule],
        declarations: [QdTooltipComponent, QdMockTranslatePipe, MinimalTestComponent, FullTestComponent]
      });
    });
  }

  describe('One paragraph only', () => {
    let fixture: ComponentFixture<MinimalTestComponent>;
    createComponent();

    test('matches snapshot', () => {
      fixture = TestBed.createComponent(MinimalTestComponent);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });

  describe('Full filled component', () => {
    let fixture: ComponentFixture<FullTestComponent>;
    createComponent();

    test('matches snapshot', () => {
      fixture = TestBed.createComponent(FullTestComponent);
      fixture.detectChanges();

      expect(fixture.nativeElement).toMatchSnapshot();
    });
  });
});
