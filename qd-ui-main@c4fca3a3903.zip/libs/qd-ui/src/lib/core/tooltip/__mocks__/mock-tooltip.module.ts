// @ts-strict-ignore
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QdMockPopoverOnClickDirective } from './mock-popover-on-click.directive';
import { QdMockTooltipComponent } from './mock-tooltip.component';
import { QdMockTooltipAtIntersectionDirective } from './mock-tooltip-at-intersection.directive';
import { QdMockTooltipOnClickDirective } from './mock-tooltip-on-click.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [QdMockTooltipComponent, QdMockTooltipOnClickDirective, QdMockTooltipAtIntersectionDirective],
  exports: [QdMockPopoverOnClickDirective, QdMockTooltipOnClickDirective]
})
export class QdMockTooltipModule {}
