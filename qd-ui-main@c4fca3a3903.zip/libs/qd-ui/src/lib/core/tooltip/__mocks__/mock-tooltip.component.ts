// @ts-strict-ignore
import { Component, Input } from '@angular/core';

@Component({
  selector: 'qd-tooltip',
  template: 'content: {{ content | json }}'
})
export class QdMockTooltipComponent {
  @Input() content;
}
