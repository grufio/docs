import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[qdTooltipAtIntersection]'
})
export class QdMockTooltipAtIntersectionDirective {
  @HostListener('mouseenter', ['$event'])
  @HostListener('mousemove', ['$event'])
  show = jest.fn();

  @HostListener('mouseleave', ['$event'])
  hide = jest.fn();
}
