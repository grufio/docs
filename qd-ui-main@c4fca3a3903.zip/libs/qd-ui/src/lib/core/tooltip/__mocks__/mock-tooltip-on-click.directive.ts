// @ts-strict-ignore
import { Directive, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[qdTooltipOnClick]'
})
export class QdMockTooltipOnClickDirective {
  @Input() qdTooltipContent;

  @HostListener('mouseenter', ['$event'])
  @HostListener('mousemove', ['$event'])
  show = jest.fn();

  @HostListener('mouseleave', ['$event'])
  hide = jest.fn();
}
