import { TranslateModule } from '@ngx-translate/core';
import { StoreModule } from '@ngrx/store';
import { OverlayModule } from '@angular/cdk/overlay';

import { QdTooltipModule } from './tooltip.module';

const template = `
<div style="margin: 50px">
  <button qdTooltipOnClick [qdTooltipContent]="tooltipContent">
    Click me
  </button>
</div>

`;

const tooltipContent = {
  headline: { i18n: 'tooltip.headline' },
  paragraphs: [{ i18n: 'tooltip.paragraph1' }, { i18n: 'tooltip.paragraph2' }]
};

context('QdTooltipOnClickDirective', () => {
  beforeEach(() => {
    cy.mount(template, {
      imports: [QdTooltipModule, TranslateModule.forRoot(), StoreModule.forRoot({}), OverlayModule],
      componentProperties: {
        tooltipContent
      }
    });
  });

  it('shows tooltip on click and hides it when clicking outside', () => {
    cy.get('button').click();
    cy.get('qd-tooltip').should('exist');
    cy.matchImage();

    cy.get('body').click();
    cy.get('qd-tooltip').should('not.exist');
  });
});
