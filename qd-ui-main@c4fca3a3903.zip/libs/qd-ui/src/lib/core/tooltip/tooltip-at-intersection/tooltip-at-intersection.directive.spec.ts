import { Overlay } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { Component, ElementRef, Injectable, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { QdMockTooltipComponent } from '../__mocks__/mock-tooltip.component';
import { QdTooltipAtIntersectionDirective } from './tooltip-at-intersection.directive';

@Injectable()
class MockElementRef {
  nativeElement = {};
}

const tooltipRef = {
  instance: { content: {} }
};

let mockHasAttached = false;
const mockOverlayRef = {
  attach: jest.fn(() => tooltipRef),
  hasAttached: jest.fn(() => mockHasAttached),
  detach: jest.fn()
};

const mockOverlay = {
  create: jest.fn(() => mockOverlayRef)
};

let mockObserve = jest.fn();
let mockUnobserve = jest.fn();

@Component({
  template: `
    <div class="intersection" qdTooltipAtIntersection>
      Get deeeeeep into the DOM
      <section>
        <div>
          <p class="qd-intersection-target">Loooooong content</p>
        </div>
      </section>
    </div>
  `
})
class TestComponent {
  @ViewChild(QdTooltipAtIntersectionDirective) directive;
}

describe(`Testing ${QdTooltipAtIntersectionDirective.name} |`, () => {
  let mockIntersectionObserver;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule],
      declarations: [QdTooltipAtIntersectionDirective, QdMockTooltipComponent, TestComponent],
      providers: [
        { provide: ElementRef, useClass: MockElementRef },
        { provide: Overlay, useValue: mockOverlay }
      ]
    });
  }));

  function dispatchEvent(element, eventType): void {
    element.dispatchEvent(
      new MouseEvent(eventType, {
        view: window,
        bubbles: true,
        cancelable: true
      })
    );
  }

  function setMockIntersectionObserver(intersectionRatio): void {
    mockIntersectionObserver = class {
      private readonly _handler;

      constructor(handler) {
        this._handler = handler;
      }

      observe(element): void {
        mockObserve();
        this._handler([{ intersectionRatio, target: element }]);
      }

      unobserve(): void {
        mockUnobserve();
      }
    };

    window.IntersectionObserver = mockIntersectionObserver;
  }

  afterEach(() => jest.clearAllMocks());

  const showEventTypeProvider = ['mouseenter', 'mousemove'];

  showEventTypeProvider.forEach(eventType => {
    describe(`Show: on eventType "${eventType}" with NO intersections:`, () => {
      let fixture: ComponentFixture<TestComponent>;

      test('overlay dont attached', () => {
        fixture = TestBed.createComponent(TestComponent);
        setMockIntersectionObserver(1);
        fixture.detectChanges();

        expect(mockOverlayRef.attach).toHaveBeenCalledTimes(0);
      });
    });
  });

  showEventTypeProvider.forEach(eventType => {
    describe(`Show: on eventType "${eventType}" with intersections:`, () => {
      let fixture: ComponentFixture<TestComponent>;
      let element: HTMLElement;

      test('overlay attaches', () => {
        fixture = TestBed.createComponent(TestComponent);
        setMockIntersectionObserver(0);
        fixture.detectChanges();

        expect(mockOverlay.create).toHaveBeenCalledTimes(1);
        expect(mockOverlayRef.hasAttached).toHaveBeenCalledTimes(0);

        element = fixture.debugElement.query(By.css('.intersection')).nativeElement;
        dispatchEvent(element, eventType);

        fixture.detectChanges();

        expect(mockOverlayRef.hasAttached).toHaveBeenCalledTimes(1);
        expect(mockOverlayRef.attach).toHaveBeenCalledTimes(1);
        expect(tooltipRef.instance.content).toStrictEqual({ headline: undefined, paragraphs: ['Loooooong content'] });
      });
    });
  });

  const hideEventTypeProvider = ['mouseleave', 'click'];

  hideEventTypeProvider.forEach(eventType => {
    describe(`Hide: on eventType "${eventType}"`, () => {
      beforeEach(() => {
        mockHasAttached = true;
        jest.useFakeTimers();
      });

      afterEach(jest.useRealTimers);

      let fixture: ComponentFixture<TestComponent>;
      let element: HTMLElement;

      test('overlay detached after 300 ms debounce time', () => {
        fixture = TestBed.createComponent(TestComponent);
        setMockIntersectionObserver(0);
        fixture.detectChanges();

        expect(mockOverlay.create).toHaveBeenCalledTimes(1);
        expect(mockOverlayRef.hasAttached).toHaveBeenCalledTimes(0);

        element = fixture.debugElement.query(By.css('.intersection')).nativeElement;
        dispatchEvent(element, 'mouseleave');

        expect(mockOverlayRef.detach).toHaveBeenCalledTimes(0);

        jest.advanceTimersByTime(300);

        expect(mockOverlayRef.detach).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('getContent:', () => {
    let fixture: ComponentFixture<TestComponent>;
    let element: HTMLElement;

    beforeEach(() => {
      fixture = TestBed.createComponent(TestComponent);
      fixture.detectChanges();
      element = fixture.debugElement.query(By.css('.intersection')).nativeElement;
    });

    test('returns content with headline and paragraphs when data-tooltip-headline is set', () => {
      element.querySelector('.qd-intersection-target').setAttribute('data-tooltip-headline', 'Test Headline');
      element.querySelector('.qd-intersection-target').textContent = 'Test content';

      const content = fixture.componentInstance.directive.getContent();

      expect(content.headline).toBe('Test Headline');
      expect(content.paragraphs).toEqual(['Test content']);
    });

    test('returns content with undefined headline when data-tooltip-headline is not set', () => {
      element.querySelector('.qd-intersection-target').removeAttribute('data-tooltip-headline');
      element.querySelector('.qd-intersection-target').textContent = 'Test content';

      const content = fixture.componentInstance.directive.getContent();

      expect(content.headline).toBeUndefined();
      expect(content.paragraphs).toEqual(['Test content']);
    });

    test('returns empty string in paragraphs if textContent is empty', () => {
      element.querySelector('.qd-intersection-target').setAttribute('data-tooltip-headline', 'Test Headline');
      element.querySelector('.qd-intersection-target').textContent = '';

      const content = fixture.componentInstance.directive.getContent();

      expect(content.headline).toBe('Test Headline');
      expect(content.paragraphs).toEqual(['']);
    });

    test('returns empty string in paragraphs and undefined headline when both are empty', () => {
      element.querySelector('.qd-intersection-target').removeAttribute('data-tooltip-headline');
      element.querySelector('.qd-intersection-target').textContent = '';

      const content = fixture.componentInstance.directive.getContent();

      expect(content.headline).toBeUndefined();
      expect(content.paragraphs).toEqual(['']);
    });
  });

  describe('On destroy:', () => {
    let component: TestComponent;
    let fixture: ComponentFixture<TestComponent>;
    let element: HTMLElement;
    let unobserveSpy;
    let destroyedNextSpy;
    let destroyedCompleteSpy;

    beforeEach(() => {
      fixture = TestBed.createComponent(TestComponent);
      setMockIntersectionObserver(0);
      component = fixture.componentInstance;

      fixture.detectChanges();

      unobserveSpy = jest.spyOn(component.directive._observer$, 'unobserve');
      destroyedNextSpy = jest.spyOn(component.directive._destroyed$, 'next');
      destroyedCompleteSpy = jest.spyOn(component.directive._destroyed$, 'complete');
    });

    test('unsubscribes from all subscriptions', () => {
      element = fixture.debugElement.query(By.css('.intersection')).nativeElement;
      component.directive.ngOnDestroy();

      expect(unobserveSpy).toHaveBeenNthCalledWith(1, element.querySelector('.qd-intersection-target'));
      expect(destroyedNextSpy).toHaveBeenCalledTimes(1);
      expect(destroyedCompleteSpy).toHaveBeenCalledTimes(1);
    });
  });
});
