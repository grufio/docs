import { Overlay, OverlayPositionBuilder, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { AfterViewInit, Directive, ElementRef, OnDestroy } from '@angular/core';
import { fromEvent, merge, Subject } from 'rxjs';
import { debounceTime, filter, takeUntil } from 'rxjs/operators';

import { convertPxToRem } from '../../tools/convertPxToRem.tools';
import { QdTooltipComponent } from '../tooltip/tooltip.component';

const TARGET_SELECTOR = '.qd-intersection-target';
const SHOW_EVENTS = ['mouseenter', 'mousemove'];
const HIDE_EVENTS = ['mouseleave', 'click'];
const HIDE_DELAY = 300;
const OVERLAY_WIDTH = 280;
const UNSUBSCRIBE_IMMEDIATELY = true;
const THRESHOLD = 1;

/**
 * QdTooltipAtIntersectionDirective provides a tooltip. This will be triggered if the content is intersected.
 *
 * * Selector: [qdTooltipAtIntersection]
 * * Target Selector: .qd-intersection-target
 *
 * The IntersectionObserver API is used for the implementation.
 * * @see https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver
 *
 * * Note: The intersection of the target is calculated by the IntersectionObserver only once, initially (can be extended later if required). After that it will be unsubscribed immediately.
 * */
@Directive({
  selector: '[qdTooltipAtIntersection]'
})
export class QdTooltipAtIntersectionDirective implements AfterViewInit, OnDestroy {
  private _overlayRef!: OverlayRef;
  private _target!: HTMLElement;
  private _observer$!: IntersectionObserver;
  private _isIntersected = false;
  private _destroyed$ = new Subject<void>();

  constructor(private _host: ElementRef, private _positionBuilder: OverlayPositionBuilder, private _overlay: Overlay) {}

  ngAfterViewInit(): void {
    this.setTarget();
    this.observeTarget();
    this.createOverlay();
    this.subscribeShow();
    this.subscribeHide();
  }

  ngOnDestroy(): void {
    this._observer$.unobserve(this._target);

    this._destroyed$.next();
    this._destroyed$.complete();
  }

  private setTarget(): void {
    this._target = this._host.nativeElement.querySelector(TARGET_SELECTOR);
  }

  private observeTarget(): void {
    const options = {
      root: this._host.nativeElement,
      threshold: THRESHOLD
    };

    this._observer$ = new IntersectionObserver(entries => {
      this._isIntersected = entries[0].intersectionRatio < 1;
      if (this._isIntersected) {
        this._setStyles();
        if (UNSUBSCRIBE_IMMEDIATELY) this._observer$.unobserve(this._target);
      }
    }, options);

    this._observer$.observe(this._target);
  }

  private _setStyles(): void {
    this._target.style.overflow = 'hidden';
    this._target.style.textOverflow = 'ellipsis';
    this._target.style.cursor = 'help';
  }

  private createOverlay(): void {
    this._overlayRef = this._overlay.create({
      positionStrategy: this._positionBuilder
        .flexibleConnectedTo(this._host)
        .withPositions([{ originX: 'start', originY: 'bottom', overlayX: 'start', overlayY: 'top' }]),
      width: convertPxToRem(OVERLAY_WIDTH)
    });
  }

  private subscribeShow(): void {
    merge(...SHOW_EVENTS.map(event => fromEvent(this._host.nativeElement, event)))
      .pipe(
        takeUntil(this._destroyed$),
        filter(() => !this._overlayRef.hasAttached() && this._isIntersected)
      )
      .subscribe(() => {
        const content: { headline?: string; paragraphs: string[] } = this.getContent();
        const tooltipPortal = new ComponentPortal(QdTooltipComponent);
        const tooltipRef = this._overlayRef.attach(tooltipPortal);

        tooltipRef.instance.content = content;
      });
  }

  private subscribeHide(): void {
    merge(...HIDE_EVENTS.map(event => fromEvent(this._host.nativeElement, event)))
      .pipe(
        takeUntil(this._destroyed$),
        filter(() => this._overlayRef.hasAttached()),
        debounceTime(HIDE_DELAY)
      )
      .subscribe(() => this._overlayRef.detach());
  }

  private getContent(): { headline?: string; paragraphs: string[] } {
    return {
      headline: this._target.getAttribute('data-tooltip-headline') || undefined,
      paragraphs: [this._target.textContent?.trim() || '']
    };
  }
}
