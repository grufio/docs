import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { QdFocusable } from './focusable';
import { QdFocusableDirective } from './focusable.directive';
import { QD_FOCUSABLE_TOKEN } from './focusable.token';

// Mock QdFocusable implementation
class MockFocusable implements QdFocusable {
  focus = jest.fn();
}

@Component({
  template: '<div qdFocusable></div>'
})
class TestComponent {}

describe('QdFocusableDirective', () => {
  let mockFocusable: MockFocusable;

  beforeEach(() => {
    mockFocusable = new MockFocusable();

    TestBed.configureTestingModule({
      declarations: [QdFocusableDirective, TestComponent],
      providers: [{ provide: QD_FOCUSABLE_TOKEN, useValue: mockFocusable }]
    });
  });

  it('should create the directive instance', () => {
    const fixture = TestBed.createComponent(TestComponent);
    const element = fixture.debugElement.query(el => el.attributes['qdFocusable'] != null);
    const directive = element.injector.get(QdFocusableDirective);

    expect(directive).toBeTruthy();
  });

  it('should call focus on the injected focusable object', () => {
    const fixture = TestBed.createComponent(TestComponent);
    const element = fixture.debugElement.query(el => el.attributes['qdFocusable'] != null);
    const directive = element.injector.get(QdFocusableDirective);

    directive.focus();

    expect(mockFocusable.focus).toHaveBeenCalled();
  });

  it('should do nothing if no focusable object is provided', () => {
    TestBed.overrideProvider(QD_FOCUSABLE_TOKEN, { useValue: null });
    const fixture = TestBed.createComponent(TestComponent);
    const element = fixture.debugElement.query(el => el.attributes['qdFocusable'] != null);
    const directive = element.injector.get(QdFocusableDirective);

    expect(() => directive.focus()).not.toThrow();
  });
});
