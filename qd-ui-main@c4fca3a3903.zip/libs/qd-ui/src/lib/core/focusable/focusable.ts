/**
 * Implement this interface to make your component focusable.
 */
export interface QdFocusable {
  /**
   * Focus the component
   */
  focus();
}
