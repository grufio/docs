import { Directive, Inject, Optional } from '@angular/core';
import { QdFocusable } from './focusable';
import { QD_FOCUSABLE_TOKEN } from './focusable.token';

@Directive({
  selector: '[qdFocusable]'
})
export class QdFocusableDirective {
  constructor(@Optional() @Inject(QD_FOCUSABLE_TOKEN) private focusable: QdFocusable) {}

  focus(): void {
    if (this.focusable) this.focusable.focus();
  }
}
