import { NgModule } from '@angular/core';
import { QdFocusableDirective } from './focusable.directive';

@NgModule({
  declarations: [QdFocusableDirective],
  exports: [QdFocusableDirective]
})
export class QdFocusableModule {}
