import { InjectionToken } from '@angular/core';

/**
 * Provide focusable components by this token.
 */
export const QD_FOCUSABLE_TOKEN = new InjectionToken<string>('QD_FOCUSABLE_TOKEN');
