<img src="https://confluence.bit.admin.ch/download/attachments/268095262/image2020-9-11_14-33-29.png" width="320">

---

# Quadrel UI

> Quadrel UI is a low-code framework for quickly building enterprise user interfaces.
> It was originally developed as part of the DaziT digital transformation program for the Federal Office for Customs and Border Security (FOCBS). Quadrel is now also used in other contexts and welcomes new applications and use cases.

---

## Overview

This README gives you a quick introduction to the project. For full documentation, refer to these chapters:

- [Code Conventions](./docs/code-conventions)
- [API Style Guide](./docs/api-styleguide)
- [Testing Guidelines](./docs/testing)
- [Commit Message Guidelines](./docs/code-of-conduct)

---

## Getting Started

**Installation**:

```bash
npm ci
```

**Start Storybook**:

```bash
npm run sb

# Open the development environment in your browser: http://localhost:6006
```

**Run Component Tests**:

```bash
npm run comp-test
```

**Run Unit Tests**:

```bash
npm run test:qd-ui
```

---

## Additional Notes

- The project uses NX for monorepo management
- Compodoc is used to generate component documentation
- Storybook is used for interactive documentation and live previews of UI patterns and components
- Unit and component tests are part of the development workflow
- Please follow the [Commit Message Guidelines](./docs/code-of-conduct), which are essential for CI/CD
