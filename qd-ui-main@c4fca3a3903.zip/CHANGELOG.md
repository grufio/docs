# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [18.1.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv18.0.3&sourceBranch=refs%2Ftags%2Fv18.1.0) (2025-06-13)


### Features

* DAZUIC-2734 - contact card menu ([9fcd232](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9fcd2327dd6ffa4c82f7b6cf89b1ce0982f70484))

### [18.0.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv18.0.2&sourceBranch=refs%2Ftags%2Fv18.0.3) (2025-06-06)


### Bug Fixes

* DAZUIC-3780 - update tree data ([21c1dbe](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/21c1dbe9ebe927dd5cdfa3c796ec2652f52cfed0))
* stories with validators ([b04bc8b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b04bc8bdc3021e1779e3545cdf70cc9f31888119))

### [18.0.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv18.0.1&sourceBranch=refs%2Ftags%2Fv18.0.2) (2025-06-06)

### [18.0.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv18.0.0&sourceBranch=refs%2Ftags%2Fv18.0.1) (2025-05-26)

## [18.0.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.46.1&sourceBranch=refs%2Ftags%2Fv18.0.0) (2025-05-26)


### Features

* DAZUIC-3704 - info banner documentation for dialog ([0994b17](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0994b17ac32b76e4e92cf49c43dd8a10d5fb2a98))
* DAZUIC-3744 - nx update 18 to 19 ([c95c824](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c95c8242488c0354900fced4dbf4786ce3833db0))
* DAZUIC-3764 update to angular 18 BREAKING CHANGE ([4c5c280](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4c5c280eda50271df0ddde067a0fd02f137fb8ff))


### Bug Fixes

* multiInput component test ([61d41e9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/61d41e91120933db7b826719c6a072e0aa7d93eb))


### [17.46.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.46.0&sourceBranch=refs%2Ftags%2Fv17.46.1) (2025-06-06)


### Bug Fixes

* DAZUIC-3858 - make context changed handler trigger ([351f38b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/351f38b2852982ef7c202ae6d093e085effdf4ea))

## [17.46.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.45.0&sourceBranch=refs%2Ftags%2Fv17.46.0) (2025-06-05)


### Features

* DAZUIC-3812 - increase z-index of dialogs ([7b95bbf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7b95bbff45d3ad7e78f2c6e6cc79cba613ef7672))
* DAZUIC-3812 - increase z-index of shell left, shell right and backdrop ([5020622](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5020622b6a835a510655a06b8a8180126ed687a1))

## [17.45.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.44.0&sourceBranch=refs%2Ftags%2Fv17.45.0) (2025-06-05)


### Features

* DAZUIC-3853 - shell header appIcon ([fcfe2cd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fcfe2cdabecf08b33395a15950d195c5bed47f72))

## [17.44.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.43.4&sourceBranch=refs%2Ftags%2Fv17.44.0) (2025-06-04)


### Features

* **quick-edit:** operation mode integration, support for outer FormArray, minor fixes and cleanup ([47b5739](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/47b5739478e15e993010f871cd1f5082b02b07de))

### [17.43.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.43.3&sourceBranch=refs%2Ftags%2Fv17.43.4) (2025-06-04)


### Bug Fixes

* DAZUIC-3852 - update section toolbar actions ([b099f59](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b099f592baf11d122038147c86249b75a1fce66d))
* french translation context ([941de32](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/941de320cae24f37416517d23b6f532aa2f7b794))

### [17.43.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.43.2&sourceBranch=refs%2Ftags%2Fv17.43.3) (2025-06-02)


### Bug Fixes

* DAZUIC-3837 - show translation string but emit value ([64840b0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/64840b02d8fb40c2c75a604b4d9c8d1cd540e22b))

### [17.43.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.43.1&sourceBranch=refs%2Ftags%2Fv17.43.2) (2025-06-02)


### Bug Fixes

* DAZUIC-3812 - increase z-index of shell left ([db16d23](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/db16d23747b7a054871a771534f54492d14c5850))

### [17.43.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.43.0&sourceBranch=refs%2Ftags%2Fv17.43.1) (2025-06-02)


### Bug Fixes

* DAZUIC-3841 - filter should always be in focus when opening dropdown ([b4d9e26](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b4d9e2654612908beaa970135f85b66c746cab9b))

## [17.43.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.42.1&sourceBranch=refs%2Ftags%2Fv17.43.0) (2025-05-28)


### Features

* DAZUIC-3841 - dropdown focus on active item or filter ([0987f42](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0987f42121c5c1bba0926ed24717ea3ecf769bc8))


### Bug Fixes

* multiInput cypress test ([ad2e8b0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ad2e8b03bad9a40b08c68708d1a68c2081dfea13))

### [17.42.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.42.0&sourceBranch=refs%2Ftags%2Fv17.42.1) (2025-05-28)


### Bug Fixes

* DAZUIC-3816 - input with units scrollbar and validation ([d4286f7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d4286f7fff99a225f5078d21627c1f9850b7e638))

## [17.42.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.41.0&sourceBranch=refs%2Ftags%2Fv17.42.0) (2025-05-27)


### Features

* DAZUIC-3704 - info banner documentation for dialog ([0994b17](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0994b17ac32b76e4e92cf49c43dd8a10d5fb2a98))


### Bug Fixes

* multiInput component test ([61d41e9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/61d41e91120933db7b826719c6a072e0aa7d93eb))

## [17.41.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.40.0&sourceBranch=refs%2Ftags%2Fv17.41.0) (2025-05-26)


### Features

* DAZUIC-3704 - info banner for dialog ([1b81e87](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1b81e87ce5f887e785eb9eaf038965db2d09cfff))
* DAZUIC-3824 - operationMode component tests ([e933c41](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e933c4167dae917524d5a923d90a0fd2a118f914))
* DAZUIC-3824 - Use operationMode in functional patterns ([7a369b7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7a369b72fef37e6599fae5ea8cbbcedbcddf5379))


### Bug Fixes

* cypress screenshots ([fedfbc4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fedfbc4c8cb0637d2d561981d61fd424a345440a))

## [17.40.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.39.0&sourceBranch=refs%2Ftags%2Fv17.40.0) (2025-05-23)


### Features

* DAZUIC-3711 - add new Form: FileUpload ([d68ab17](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d68ab1707135b86616999fcc4d31f3609580706c))
* DAZUIC-3711 - cypress tests for fileUpload ([450a7df](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/450a7df15edfa68226b705501951a2bce3390b4a))
* DAZUIC-3711 - update cypress screenshots with new threshhold ([5d6dff9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5d6dff999bc51e8e2f6acbc197fbd8d4f3f76fd3))


### Bug Fixes

* DAZUIC-3711 - add missing action events ([a632d37](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a632d37a7b465e18098c0eb2f632863d35435695))
* DAZUIC-3711 - fix styles ([00a0847](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/00a0847d6cd536783c8a62542cda76095c6063af))
* DAZUIC-3711 - fix styles ([4124c1e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4124c1edfb68ee44d702cc1f75e6f0db22ac5dbb))
* DAZUIC-3800 - adopt viewonly value from datepicker for timepicker ([15f6be0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/15f6be08709dc5de39b60da78beb7ed9a978722f))

## [17.39.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.38.0&sourceBranch=refs%2Ftags%2Fv17.39.0) (2025-05-15)


### Features

* DAZUIC-2731 - QdTree inline actions ([924501a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/924501af7dfe6973cb445a1ef0632a9f2d520614))
* DAZUIC-2731 - update QdTree expand icon ([79d736a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/79d736a5288f830e5129b01e31dd2d5e8ec592e2))


### Bug Fixes

* update ngrx store ([aa20e46](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/aa20e46c718f084d384f7ef602c32e250e2cf043))

## [17.38.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.37.0&sourceBranch=refs%2Ftags%2Fv17.38.0) (2025-05-14)


### Features

* DAZUIC-3785 - table filling width mode "harmonized" ([82ebfa5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/82ebfa5ca3c8bb194b0203506ac740246fbef163))

## [17.37.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.36.2&sourceBranch=refs%2Ftags%2Fv17.37.0) (2025-05-14)


### Features

* DAZUIC-3813 - control panel broad width ([5ec728d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5ec728d57dbc8bb0b3c7bcdd986643c9e586b5df))

### [17.36.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.36.1&sourceBranch=refs%2Ftags%2Fv17.36.2) (2025-05-13)


### Bug Fixes

* DAZUIC-3795 - fix disabled property in QdCheckboxes ([5fd5a06](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5fd5a067d2beee9e158b61e827489b4476db46bb))
* **quick-edit:** null check for progress values ([cb83ee5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cb83ee54fb9c4779a1eacf61d65c2cabee16d4f8))

### [17.36.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.36.0&sourceBranch=refs%2Ftags%2Fv17.36.1) (2025-05-13)


### Bug Fixes

* DAZUIC-3808 - update input value for datetime correctly ([eff115d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/eff115d9b047f601cbaa2c44bea91f6ecaa55e88))

## [17.36.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.35.0&sourceBranch=refs%2Ftags%2Fv17.36.0) (2025-05-12)


### Features

* feat: DAZUIC-3815 - add async refresh via config ([ce83660](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ce83660d112b6872e59c5a99bbff93e0bb25aad5))

## [17.35.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.34.1&sourceBranch=refs%2Ftags%2Fv17.35.0) (2025-05-06)


### Features

* DAZUIC-3760 - Connect table to server side events ([f940917](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f940917ceac13c345454bbcfe56b5f6230080ade))

### [17.34.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.34.0&sourceBranch=refs%2Ftags%2Fv17.34.1) (2025-05-06)


### Bug Fixes

* apply missing tooltip config to all labels ([5cb0148](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5cb0148afde73c9a27fdf7c804a50842d1ce4288))
* DAZUIC-3737 - emit value instead of translation when selecting QdInput options ([6c5cd56](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6c5cd56be2714f7e533a3b8ee21a3f93b6392359))

## [17.34.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.33.0&sourceBranch=refs%2Ftags%2Fv17.34.0) (2025-05-05)


### Features

* DAZUIC-3689 - extend expand API with access of full record ([91c914c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/91c914c9fbe961976143095aaff8228a1f25847a))


### Bug Fixes

* fixes after refactoring ([0c5f912](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0c5f91253fc74bdf824d1b314cf773fdd65c5a67))

## [17.33.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.32.0&sourceBranch=refs%2Ftags%2Fv17.33.0) (2025-04-29)


### Features

* DAZUIC-3746 - PageInfoBanner: Support correct rendering inside Stepper and Tabs ([d15efb8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d15efb854c023c767ab858ffc839da3600a1b1f7))
* DAZUIC-3786 - Use Table Refresh for link action ([65a170a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/65a170a46bd95477d2f0c0c9baffb392ce03467b))

## [17.32.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.31.0&sourceBranch=refs%2Ftags%2Fv17.32.0) (2025-04-23)


### Features

* DAZUIC-3759 - push events service for server side events created ([dce92ec](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/dce92ecb34f25e5bea66e9c042af91aa1e1d4e55))
* **page:** data-test-ids for page ([21ad4cf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/21ad4cf3ab057ddfc4631abb1736d876fb2d69ad))
* provide further test ids ([bb32d89](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bb32d89a5a4007899721ea67ee85775b88630006))

## [17.31.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.30.1&sourceBranch=refs%2Ftags%2Fv17.31.0) (2025-04-23)


### Features

* DAZUIC-3783 - QdQuickEdit Integration in QdPage ([46d66f8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/46d66f84bf3fc83dc5a354ec43edfec755a9aba4))

### [17.30.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.30.0&sourceBranch=refs%2Ftags%2Fv17.30.1) (2025-04-22)


### Bug Fixes

* DAZUIC-3784 service navigation fix handleLogout default (true) ([4bb2651](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4bb26512358fe73d73dc8e91aa57b68de0fd9740))

## [17.30.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.29.0&sourceBranch=refs%2Ftags%2Fv17.30.0) (2025-04-17)


### Features

* avoid spam clicks ([82b910d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/82b910ddd794c7660d670c3e10c46bdc858f9ef5))
* DAZUIC-3547 - allow asynchronous operations before moving to next step ([3fa2dfc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3fa2dfcfa9219fb8f6a2d8fcc2a540552eb9da19))

## [17.29.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.28.0&sourceBranch=refs%2Ftags%2Fv17.29.0) (2025-04-14)


### Features

* DAZUIC-3735 - hoist filterValueChange event to section ([9d429a3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9d429a3a28b1fcc2431dfd4b03c7c768167a7440))

## [17.28.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.27.4&sourceBranch=refs%2Ftags%2Fv17.28.0) (2025-04-10)


### Features

* DAZUIC-3747 too much padding fixed in dialog with qd-sections ([a3e9364](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a3e93647fca458b8fa594e1b1c7222fb8eed24e2))

### [17.27.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.27.3&sourceBranch=refs%2Ftags%2Fv17.27.4) (2025-04-07)


### Bug Fixes

* **qd-tile:** add vertical spacing ([1284ec0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1284ec0097b1f28656430d0ffc54852f250f34a1))

### [17.27.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.27.2&sourceBranch=refs%2Ftags%2Fv17.27.3) (2025-04-07)


### Bug Fixes

* DAZUIC-3768 - use ResizeObserver for popup ([d3c719a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d3c719a52069c64b5e1c630dd25187b635bcbf0e))

### [17.27.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.27.1&sourceBranch=refs%2Ftags%2Fv17.27.2) (2025-04-03)


### Bug Fixes

* datepicker default state not being applied properly in inspect page ([b78db74](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b78db7439c1cb3ccb317ca1dfcb3f9caab0d71cb))

### [17.27.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.27.0&sourceBranch=refs%2Ftags%2Fv17.27.1) (2025-04-03)


### Bug Fixes

* DAZUIC-3762 set service navigation pamsAppId by input binding, make pamsAppId mandatory ([f75c567](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f75c567bbee9922f40d13844fe3c19cae67217f6))

## [17.27.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.7&sourceBranch=refs%2Ftags%2Fv17.27.0) (2025-04-03)


### Features

* DAZUIC-3367 - remove unneeded initial resolver call without parameters ([1611f2b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1611f2b0216095bd061a4936bd004407ba509469))

### [17.26.7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.6&sourceBranch=refs%2Ftags%2Fv17.26.7) (2025-03-31)

### [17.26.6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.5&sourceBranch=refs%2Ftags%2Fv17.26.6) (2025-03-31)


### Bug Fixes

* DAZUIC-3707 - completely hide empty chips instead of blue line ([fb8c2c0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fb8c2c0091009bb351d6c4d760761009d5c766d1))

### [17.26.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.4&sourceBranch=refs%2Ftags%2Fv17.26.5) (2025-03-31)


### Documentation

* Add new Tab for Implementation details ([f8d7d68](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f8d7d685b7533c848baec5aea38f60b1e6896a14))

### [17.26.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.3&sourceBranch=refs%2Ftags%2Fv17.26.4) (2025-03-27)

### [17.26.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.2&sourceBranch=refs%2Ftags%2Fv17.26.3) (2025-03-27)


### Bug Fixes

* asset path for service navigation storybook example fixed ([f89eac3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f89eac317ad756ecb641b787d6dff05b98b415ff))

### [17.26.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.1&sourceBranch=refs%2Ftags%2Fv17.26.2) (2025-03-27)


### Documentation

* DAZUIC-3626 - Add docs and artefacts for EMBAG ([cf03a64](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cf03a64fae630d527a3a03c11022b3e9e694fcd3))

### [17.26.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.26.0&sourceBranch=refs%2Ftags%2Fv17.26.1) (2025-03-26)

## [17.26.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.25.1&sourceBranch=refs%2Ftags%2Fv17.26.0) (2025-03-26)


### Features

* enable service navigation widgets by default ([b828e23](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b828e2366809fdc14f940dac4f624348443ecd24))

### [17.25.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.25.0&sourceBranch=refs%2Ftags%2Fv17.25.1) (2025-03-26)


### Documentation

* info banner docu component fixed ([7a1c1ef](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7a1c1ef13c2af8ef0e6de16fefb8efd85d3ad134))

## [17.25.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.24.0&sourceBranch=refs%2Ftags%2Fv17.25.0) (2025-03-25)


### Features

* DAZUIC-3695 - service navigation integration switched to npm ([e2a3c06](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e2a3c06a7cd316cc3e8294d0eb2096e8c871d780))

## [17.24.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.23.0&sourceBranch=refs%2Ftags%2Fv17.24.0) (2025-03-25)


### Features

* DAZUIC-3576 - datepicker: times can be disabled, date time range selection storybook example ([ec79ea8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ec79ea8801b5c5c15876d06c8811d31452fd7cbc))

## [17.23.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.22.1&sourceBranch=refs%2Ftags%2Fv17.23.0) (2025-03-24)


### Features

* DAZUIC-3708 - New SectionAdapter & ProjectionGuard for more dev usability ([7654e9e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7654e9e72492dc82b4914900f539e2fd62314fe8))


### Bug Fixes

* DAZUIC-3738 - Context:  make filter case-insensitive ([20968e4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/20968e4c7c62f989c4e3d89084b5808b68fd68f0))
* DAZUIC-3739 – QdFilter now works in view-only environment ([5350ceb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5350ceb53ee1c8fb3478992dcd09ed53dcf946b3))

### [17.22.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.22.0&sourceBranch=refs%2Ftags%2Fv17.22.1) (2025-03-24)


### Bug Fixes

* tile margins ([bef4744](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bef4744b5ef33a9314cfe638f8cdc4d018a966a0))

## [17.22.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.21.0&sourceBranch=refs%2Ftags%2Fv17.22.0) (2025-03-20)


### Features

* finalize feature ([7d1a3c0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7d1a3c039be81b04a25bca2b4030ddbfe10105ba))
* implementation ([05c888f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/05c888fdd6c258448469d363155b88d4652eaf37))


### Bug Fixes

* DAZUIC-3725 - date picker: issue with date selection and language switch fixed ([bd01f97](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bd01f979448c95ea9bb2d631d97db4c4a64a365d))

## [17.21.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.20.0&sourceBranch=refs%2Ftags%2Fv17.21.0) (2025-03-14)


### Features

* DAZUIC-3726 - QdTable: Add config key for refresh on language change ([ce82322](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ce82322a0b5d7fb561687900180906126fdfb88c))

## [17.20.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.19.0&sourceBranch=refs%2Ftags%2Fv17.20.0) (2025-03-13)


### Features

* DAZUIC-3695 - service navigation integration switched backed to cdn (wait for test) ([da2db37](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/da2db3779536c684db0e7efafe3b021332286734))

## [17.19.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.18.0&sourceBranch=refs%2Ftags%2Fv17.19.0) (2025-03-12)


### Features

* Make Value Facet translatable ([3ef9375](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3ef93756e47a61bd689600291640c21381e0ef59))

## [17.18.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.17.0&sourceBranch=refs%2Ftags%2Fv17.18.0) (2025-03-12)


### Features

* DAZUIC-3675 - Collabsible Section ([f6d773c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f6d773c357d571c18840bbcebf95f769decade25))

## [17.17.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.16.3&sourceBranch=refs%2Ftags%2Fv17.17.0) (2025-03-12)


### Features

* DAZUIC-3695 - load service navigation asset with npm ([e7fa11b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e7fa11be639354bfd8b8ffc31f2e93927ef5f452))

### [17.16.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.16.2&sourceBranch=refs%2Ftags%2Fv17.16.3) (2025-03-11)


### Bug Fixes

* undefined ref for no provided config ([ab5829c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ab5829c2f4615c482a08626cc2bef4800102c6d1))

### [17.16.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.16.1&sourceBranch=refs%2Ftags%2Fv17.16.2) (2025-03-11)

### [17.16.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.16.0&sourceBranch=refs%2Ftags%2Fv17.16.1) (2025-03-07)


### Bug Fixes

* Form Label - vertical alignment ([43464dc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/43464dc972bf2b4cfbc28c807386ac094a2db65e))

## [17.16.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.15.2&sourceBranch=refs%2Ftags%2Fv17.16.0) (2025-03-07)


### Features

* DAZUIC-3650 - bring back TilesContainer to wrap QdGrid ([2388095](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/23880957a748f88bcdaaf954083740fc146a983b))
* DAZUIC-3650 - finalize implementation ([4bcd1de](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4bcd1de39750815cbf8199207aa9476012e6ba2c))
* DAZUIC-3650 - QdTile rework with illustration and disabled state ([9a8a8ea](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9a8a8eab334909d53200632cbf2d7c09c055c648))


### Bug Fixes

* DAZUIC-3650 - Impovements ([dd7831b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/dd7831b333ebd6c68a3d4b9bfa8c4eb186d0996f))
* missing gap with margins ([3e7e923](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3e7e923e2073e336604eba7964d470a0f5941eda))

### [17.15.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.15.1&sourceBranch=refs%2Ftags%2Fv17.15.2) (2025-03-07)


### Bug Fixes

* DAZUIC-3659 | Datepicker validation - switch to DD.MM.YYYY for all languages ([8761273](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/876127360980fa4f67027a35cd1d315f9fb24c5c))
* TAPAS-1351 html tags in comments ([7d3d976](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7d3d97600ef983388ccdf32eea390efb6dd0e471))

### [17.15.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.15.0&sourceBranch=refs%2Ftags%2Fv17.15.1) (2025-03-07)

## [17.15.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.14.0&sourceBranch=refs%2Ftags%2Fv17.15.0) (2025-03-06)


### Features

* DAZUIC-3632 - page tabs selectedIndex config ([0b2a913](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0b2a9134d56c5feda672da5fbd88cc4685dd3115))

## [17.14.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.13.0&sourceBranch=refs%2Ftags%2Fv17.14.0) (2025-03-04)


### Features

* DAZUIC-3618 - new panel section component ([a7719d1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a7719d169fe796d08e916e3934bdd82c650609bd))
* DAZUIC-3618 - shell right toolbar title ([663bd73](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/663bd73108eb45afbb2747d7a7d63e84cfc87ecd))
* DAZUIC-3646 - control panel status title component ([f6ce1a6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f6ce1a6a3838ead9461ea669b6e54c0a8cb22f57))
* DAZUIC-3646 - integrate status pairs into panel section (control panel) ([bb39ce6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bb39ce605d9c740fd84355eb6f367b3166bc3246))


### Bug Fixes

* DAZUIC-3618 - shell right scrollbar fixed (commentary, notifications) ([126cc39](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/126cc39ed1db21b5559a7fbc3d4dc66f28da0496))

## [17.13.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.12.0&sourceBranch=refs%2Ftags%2Fv17.13.0) (2025-03-04)


### Features

* DAZUIC-3623 - oblique service navigation mobile view adaptions ([7d1d558](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7d1d558e4b387f70cca0499de5514c38bb11cf6a))
* DAZUIC-3623 - oblique service navigation mobile view adaptions ([1cabb8d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1cabb8d65f214810a2267f347d32fdbcbc434501))
* DAZUIC-3623 - oblique service navigation mobile view adaptions ([f77ed30](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f77ed30d3af8967061e0a633ec3085f4852da9c9))

## [17.12.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.11.1&sourceBranch=refs%2Ftags%2Fv17.12.0) (2025-03-04)


### Features

* DAZUIC-3644 - embed notifications into page ([6b29acb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6b29acbccd5cf14fbeb2258ff37e0352d148889e))
* DAZUIC-3645 - notification redesign, custom title and custom link ([3aee0a9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3aee0a9e7fe790edb4969d1a4f090767a49e48ff))

### [17.11.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.11.0&sourceBranch=refs%2Ftags%2Fv17.11.1) (2025-03-03)


### Bug Fixes

* DAZUIC-3691 | Context - Fix translations ([4d784e2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4d784e2749fb73e00f23c4c41cb5209067f5abad))

## [17.11.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.10.0&sourceBranch=refs%2Ftags%2Fv17.11.0) (2025-02-26)


### Features

* DAZUIC-3534, DAZUIC-3597 - Minor styling tweaks in section & tooltip ([824610d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/824610d4b40285b1e3d8533da3399dccefa12720))


### Documentation

* use QdValidators.date() in qd-datepicker examples ([76d096f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/76d096f77dd81c9d425551398864e03104d2b4e7))

## [17.10.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.9.0&sourceBranch=refs%2Ftags%2Fv17.10.0) (2025-02-24)


### Features

* DAZUIC-3530 - Page Tabs with counters ([85eec0b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/85eec0b1b00135f054acdeacbdd5bbc38df44c09))
* DAZUIC-3684 - integrate service navigation into master layout ([f8c1254](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f8c1254025926b65f2f716cf0684dd1d9f1d005a))

## [17.9.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.8.0&sourceBranch=refs%2Ftags%2Fv17.9.0) (2025-02-24)


### Features

* DAZUIC-3667 - allow providing date for breadcrumb dialogs ([7fdadf5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7fdadf5360464a15ec5e8904aafb396dc85ccf43))

## [17.8.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.7.2&sourceBranch=refs%2Ftags%2Fv17.8.0) (2025-02-19)


### Features

* DAZUIC-3661 - close shell right if comments disappear (e.g. after navigation) ([ab218fe](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ab218fe44cf4a978ec36c6b9cdb53831f4b92158))


### Documentation

* describe qdColumn value (colspan) ([3859683](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3859683df90fa62095427b891dfd0a4fb24c28a5))

### [17.7.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.7.1&sourceBranch=refs%2Ftags%2Fv17.7.2) (2025-02-18)


### Bug Fixes

* DAZUIC-3668 - DAZUIC-3668 - Correct link mapping in service navigation ([ce09e99](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ce09e99063aad5890d180c9b9d30283f30afe88b))
* DAZUIC-3668 - Stringify contactInfo in service navigation ([b05f1e3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b05f1e380d9ce53f741db183b0d0da806c78f044))

### [17.7.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.7.0&sourceBranch=refs%2Ftags%2Fv17.7.1) (2025-02-17)


### Bug Fixes

* DAZUIC-3676 - js error in disabledDates validator fixed with not-date values ([3051374](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3051374def52355146562af8e57c3361bb886ea7))

## [17.7.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.6.1&sourceBranch=refs%2Ftags%2Fv17.7.0) (2025-02-17)


### Features

* DAZUIC-3574 - QdForms: ViewOnly, Design Adjustments ([202e851](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/202e851ba9a7909056b3cf3d9d4881a1ced38470))

### [17.6.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.6.0&sourceBranch=refs%2Ftags%2Fv17.6.1) (2025-02-10)

## [17.6.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.5.1&sourceBranch=refs%2Ftags%2Fv17.6.0) (2025-02-10)


### Features

* DAZUIC-3662 - isHidden flag for page submit button ([78dbf91](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/78dbf91af08a2be46a301b519522dcd34da981a7))

### [17.5.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.5.0&sourceBranch=refs%2Ftags%2Fv17.5.1) (2025-02-10)


### Bug Fixes

* TAPAS-1351 Rich text character counter, translations ([67e7af6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/67e7af64601f1792b4832c086b6896c2e999e154))

## [17.5.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.4.1&sourceBranch=refs%2Ftags%2Fv17.5.0) (2025-02-07)


### Features

* DAZUIC-3660 - hide submit button on view only inspect page ([02785d9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/02785d935f2f9e3493f664f27e4d641bb7d967b4))

### [17.4.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.4.0&sourceBranch=refs%2Ftags%2Fv17.4.1) (2025-01-31)

## [17.4.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.3.3&sourceBranch=refs%2Ftags%2Fv17.4.0) (2025-01-30)


### Features

* **DAZUIC-3555:** fix shell docs ([f2d23a5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f2d23a5c4641bdde96afa75de8539c6dd62030ce))

### [17.3.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.3.2&sourceBranch=refs%2Ftags%2Fv17.3.3) (2025-01-29)


### Bug Fixes

* DAZUIC-3656 - selected data was not displayed in calendar for date picker in form group ([0777a6e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0777a6ef634266a3d18f10d80208fbdf8de211c6))

### [17.3.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.3.1&sourceBranch=refs%2Ftags%2Fv17.3.2) (2025-01-29)


### Bug Fixes

* table resolver type ([4f20880](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4f208806aed83218f17976447b217a633b88efa4))

### [17.3.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.3.0&sourceBranch=refs%2Ftags%2Fv17.3.1) (2025-01-29)


### Bug Fixes

* TAPAS-1351 Make comment dropdown editable, language asset, date fixes ([391bb56](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/391bb56e7ec89f3cc8f2369fa6769e46b73aa2b9))

## [17.3.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.2.5&sourceBranch=refs%2Ftags%2Fv17.3.0) (2025-01-28)


### Features

* DAZUIC-3651 - improve email validator (new regex) ([64da036](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/64da03635e3a15fcacf3f1b6dd4b4f8fd69303c6))


### Bug Fixes

* DAZUIC-3587 positioning and styling of dialog closer button ([e0896a3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e0896a391ee7a8f230bbebb8f759bd2249234e65))

### [17.2.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.2.4&sourceBranch=refs%2Ftags%2Fv17.2.5) (2025-01-27)


### Bug Fixes

* DAZUIC-3549 reset behaviour for freeText filter fixed ([6cea705](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6cea705608b1e94426383cc959b0aacc98dacd2c))

### [17.2.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.2.3&sourceBranch=refs%2Ftags%2Fv17.2.4) (2025-01-27)

### [17.2.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.2.2&sourceBranch=refs%2Ftags%2Fv17.2.3) (2025-01-23)


### Bug Fixes

* DAZUIC-3648 - remove undefined overwrite for background color ([140a09f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/140a09fffb1b7b59131e63a1a747a910fc25c324))

### [17.2.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.2.1&sourceBranch=refs%2Ftags%2Fv17.2.2) (2025-01-17)


### Bug Fixes

* TAPAS-1351 Fix comment value, customs display, tests ([9afc7c5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9afc7c5d01e68f3790f4273619b0d1147354cd3a))

### [17.2.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.2.0&sourceBranch=refs%2Ftags%2Fv17.2.1) (2025-01-17)

## [17.2.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.1.0&sourceBranch=refs%2Ftags%2Fv17.2.0) (2025-01-16)


### Features

* DAZUIC-3555 - extend docs for Shell with route flags ([b93af3f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b93af3f801b4c2d43cef3f1c0a1e5a5aeb39fcf4))

## [17.1.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.0.2&sourceBranch=refs%2Ftags%2Fv17.1.0) (2025-01-16)


### Features

* DAZUIC-2868 - implementation of multi input flyout with qdPopoverOnClick directive ([54716f8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/54716f862c84d3e3647c1375e9c28da55527b8ad))
* DAZUIC-3422 - QdTable: Enables a refresh as a side effect through Action Results ([f5c666b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f5c666b13d136d57b62994682ff093481eba1e15))

### [17.0.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv18.0.1&sourceBranch=refs%2Ftags%2Fv17.0.2) (2025-01-16)


### Bug Fixes

* versions ([2ebd882](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2ebd882bdd5042010716f3a44d84ddbe013219c4))

### [18.0.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv18.0.0&sourceBranch=refs%2Ftags%2Fv18.0.1) (2025-01-15)

### Features

* DAZUIC-3522 - breadcrumbs for page dialog ([0a42067](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0a42067d40f540c020bc99b261cb728c39233792))
* update to angular 17 BREAKING CHANGE ([54d7442](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/54d7442bdc188534bd73baa6b67c7806839c62b1))

### [17.0.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv17.0.0&sourceBranch=refs%2Ftags%2Fv17.0.1) (2025-01-08)


### Bug Fixes

* DAZUIC-3594 - consider connector params for manuel table refresh (refreshPage method) ([6b874bf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6b874bfa4e6c975235485878a74c94392b39508a))

## [17.0.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.34.0&sourceBranch=refs%2Ftags%2Fv17.0.0) (2025-01-08)


### Features

* DAZUIC-3579 - allow tabs in overview page ([6789b3f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6789b3f12473f05bda7307604dc31206a8c7e928))
* update to angular 17 BREAKING CHANGE ([a4dc8ae](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a4dc8ae5ca56af91927311ab0bbf889de70d5e13))


### [16.38.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.38.0&sourceBranch=refs%2Ftags%2Fv16.38.1) (2025-01-08)


### Bug Fixes

* TAPAS-1351 Change time format for comments ([f60e476](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f60e47637d171dfe3fedf033b79c685957d85de1))
* TAPAS-1351 Update snapshot ([79fb624](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/79fb6242c484092b38a6ef52583e1ff7f109cd01))

## [16.38.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.37.0&sourceBranch=refs%2Ftags%2Fv16.38.0) (2025-01-08)


### Features

* DAZUIC-3573 - new viewonly mode (copied from readonly mode), inspect page uses viewonly mode now ([d03e496](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d03e496bba1cd2273619f6086aad9e3f94438f2d))

## [16.37.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.36.0&sourceBranch=refs%2Ftags%2Fv16.37.0) (2025-01-08)


### Features

* DAZUIC-3500 - fixes after review ([9385321](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/938532101a1914bbbe167cf0839b34b211accf87))
* DAZUIC-3500 -extend quick edit with add functionality ([f1ceb7e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f1ceb7e664689cafd61624eb0f855ed2823ef102))


### Bug Fixes

* when data not provided ([134b73b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/134b73b1c25fca3b1c9fe0778253e3e06cb3cd42))

## [16.36.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.35.0&sourceBranch=refs%2Ftags%2Fv16.36.0) (2025-01-08)


### Features

* DAZUIC-3586 - Margin Bottom fehlt ([3fc7703](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3fc7703f868f6da9182ac010b9a8a79f936cb7bd))
* DAZUIC-3586 - Multiinput Margin Fix ([979ab06](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/979ab0660481b9b4352c19c929051e3d1c7ea950))


### Bug Fixes

* DAZUIC-3594 - consider connector params for manuel table refresh (refreshPage method) ([aca3661](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/aca3661bad0aae9ec01d893e46e02bdd04457e6e))

## [16.35.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.34.0&sourceBranch=refs%2Ftags%2Fv16.35.0) (2025-01-07)


### Features

* DAZUIC-3579 - allow tabs in overview page ([6789b3f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6789b3f12473f05bda7307604dc31206a8c7e928))
* DAZUIC-3585 - Multiinput Refactoring ([732ca1e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/732ca1ede385bda94848c79fc7c02d49271254e8))

## [16.34.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.33.1&sourceBranch=refs%2Ftags%2Fv16.34.0) (2025-01-07)


### Features

* DAZUIC-3585 - Multiinput Refactoring ([18ea9eb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/18ea9eb154a7c888103763af42a042caadf67747))

### [16.33.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.33.0&sourceBranch=refs%2Ftags%2Fv16.33.1) (2024-12-18)


### Bug Fixes

* export QdTreeRowExpanderService ([5fd24a2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5fd24a267eb52a6cf89c5a5d7026a02d0b5f7f76))

## [16.33.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.32.0&sourceBranch=refs%2Ftags%2Fv16.33.0) (2024-12-12)


### Features

* DAZUIC-3564 Anzeiger falsy 0 Wert im Dropdown ([c92d34b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c92d34b0e0937b7712ce1b5c6ab33b44ec35e8a5))

## [16.32.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.31.0&sourceBranch=refs%2Ftags%2Fv16.32.0) (2024-12-11)


### Features

* DAZUIC-3413 - Collapse API for Tree ([5900158](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5900158e5f55daaf9ae759b1c4b69ed4b8356ecb))
* DAZUIC-3563 - Initiale Minutenanzeige Datepicker ([a761a58](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a761a58d6db4998508347764dc06647fdbc31082))

## [16.31.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.30.0&sourceBranch=refs%2Ftags%2Fv16.31.0) (2024-12-10)


### Features

* add test attribute ([17cba7b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/17cba7b8a165c15c607c259b428c37afcb42ccec))
* DAZUIC-3461 - allow further dropdown options in quickedit type ([2cb8aca](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2cb8aca7ee35879b07db2f0b967fabf237b95cda))
* DAZUIC-3461 - dropdown type for quick edit ([1032fbc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1032fbcb0c03bfd946bd1dba6e07b62eb11e4b0b))
* rename type to enum ([404f6bf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/404f6bf1d34e7fea629fc93ece0ac98dba8062d1))

## [16.30.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.29.1&sourceBranch=refs%2Ftags%2Fv16.30.0) (2024-12-10)


### Features

* DAZUIC-3324 - page object resolver updateMetadata can be implemented ([cc24724](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cc2472434b632f69112225a9009b7881405da023))
* DAZUIC-3324 - table text column: use complete i18n if given in data ([3c7cc6c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3c7cc6c083c595cc80faffeeb6d6bf7a7414ab48))


### Bug Fixes

* DAZUIC-3324 - take form group snapshot when switching to edit mode ([eb85919](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/eb85919c985c3b6fa018d2e55bfcc80e96fb7e87))

### [16.29.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.29.0&sourceBranch=refs%2Ftags%2Fv16.29.1) (2024-12-05)


### Bug Fixes

* table connectors emissions and page reset fixed ([f9b5edd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f9b5edd2f7202e3789be5e3353bb65f422a1a42a))

## [16.29.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.28.3&sourceBranch=refs%2Ftags%2Fv16.29.0) (2024-12-05)


### Features

* DAZUIC-3499 - allow additionalInfo in footer actions ([60c658f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/60c658f1b845fa5626d406f6c61b08d3694d593d))
* DAZUIC-3499 - button additional info flap ([4c2520c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4c2520cae6e27b220864910c2ec81b416b51c319))
* DAZUIC-3499 - finalize feature ([398b55e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/398b55e4d7000b6185dfee4ba8a60413f7753153))


### Bug Fixes

* undefined ref for optional property ([1b86aca](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1b86aca6c77f3724237748220f304efc25c93acc))

### [16.28.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.28.2&sourceBranch=refs%2Ftags%2Fv16.28.3) (2024-12-03)


### Bug Fixes

* consider filter type 'dateTimeRange' for setFilterSelection ([bae5837](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bae58376e2a4e4a86911d5d9bd5bfddaab025b34))

### [16.28.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.28.1&sourceBranch=refs%2Ftags%2Fv16.28.2) (2024-11-29)


### Bug Fixes

* DAZUIC-3548 - show falsy values ([4927664](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/492766422563fe57a1aa8ad18ecc84b416a5f5b9))

### [16.28.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.28.0&sourceBranch=refs%2Ftags%2Fv16.28.1) (2024-11-28)

## [16.28.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.27.4&sourceBranch=refs%2Ftags%2Fv16.28.0) (2024-11-28)


### Features

* DAZUIC-2290 - connect search to router, fix filter router connection ([fc9d548](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fc9d5489d8bfcebd72514eb2c2468cfe1bbe52b6))
* DAZUIC-3541 - Commentari - Added missing customData and some improvements ([5e1c018](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5e1c018253e31a0a82f9384ec56de88c17027d67))
* DAZUIC-3544 - add showAuthentication config to service navigation (for login/logout button) ([92dbdd3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/92dbdd3657be1b4e09d4e1e7218dbb869770d212))
* DAZUIC-3544 - map login/logout properties for service navigation ([768530c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/768530c232e0919913f125443266848783da9f0d))


### Bug Fixes

* DAZUIC-2290 - allow url serialization symbols in filter values ([4cf1b7d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4cf1b7d61e5282f56fcbcb14b637adc84d25c539))
* DAZUIC-3528 - Fix page Object Resolver Issue ([422724c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/422724c37e1168de3e7c49be388769d807f20f2f))
* DAZUIC-3553 - only use eportal language/language from url if it is contained in the languageList (for header widget/service navigation) ([b4cedb8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b4cedb888d36315f363c9fd0af38660dc1c3047a))


### Documentation

* DAZUIC-3553 - document e-portal language adoption behaviour ([3b800d0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3b800d05e508b0b290e2882e5b29bd2b9ce23b6e))
* fix storybook search examples ([9a63375](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9a63375767ecef36c89e0ddffdb399b1fb29051b))

### [16.27.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.27.3&sourceBranch=refs%2Ftags%2Fv16.27.4) (2024-11-27)


### Bug Fixes

* DAZUIC-3554 - prevent rerendering of radio buttons ([95e5fcb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/95e5fcbdf162d0972715fea27b8116bb2b040c84))

### [16.27.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.27.2&sourceBranch=refs%2Ftags%2Fv16.27.3) (2024-11-25)


### Bug Fixes

* DAZUIC-3539 - translation mapping for header widget and service navigation config fixed ([0fc5d74](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0fc5d74c7cc86d46729a80faff1a268602b798b8))

### [16.27.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.27.1&sourceBranch=refs%2Ftags%2Fv16.27.2) (2024-11-25)


### Bug Fixes

* DAZUIC-3546 - don't set undefined language for service navigation ([4e827df](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4e827df5c08a0fed16720c795045e7cf3dcae2ca))

### [16.27.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.27.0&sourceBranch=refs%2Ftags%2Fv16.27.1) (2024-11-24)


### Bug Fixes

* DAZUIC-33536 - max char validations for textarea and inputs ([ca32f24](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ca32f24b96d477602eea30df24365d406ddd593b))

## [16.27.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.26.2&sourceBranch=refs%2Ftags%2Fv16.27.0) (2024-11-21)


### Features

* DAZUIC-3347 - Secondary MultiButton for QdSection ([f5cf5cd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f5cf5cdd16212051a07f119882076402dc693f82))

### [16.26.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.26.1&sourceBranch=refs%2Ftags%2Fv16.26.2) (2024-11-15)


### Bug Fixes

* DAZUIC-3458 - do not show info content as fallback for error state ([c5bec21](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c5bec21f8a3154f21b583b0b155e5a788d43821c))
* DAZUIC-3509 - also set language parameter in service navigation to update the language ([e1418a2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e1418a2bec4cf11e4a9df04b1e9be2df5dc25e51))
* DAZUIC-3528 - Re-add take(1) in page object resolver ([02f31ce](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/02f31cef3fc7a6329ed04c0e71bfd7ae4f3d2b20))
* make header widget not execute when no config provided ([aed2cd7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/aed2cd7fde678d644fde7dc70cb8ea56d1e2a00a))

### [16.26.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.26.0&sourceBranch=refs%2Ftags%2Fv16.26.1) (2024-11-13)


### Bug Fixes

* DAZUIC-3528 - Remove take(1) from page object resolver ([93e2932](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/93e29328ef06ac8ec5aa5d29e5e60b0295378bb1))

## [16.26.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.25.0&sourceBranch=refs%2Ftags%2Fv16.26.0) (2024-11-12)


### Features

* DAZUIC-3478 - Integrate QdImageComponent within QLS ([1ab84c7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1ab84c7c32a8a7c405928920bee045fa4fbfab50))

## [16.25.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.24.3&sourceBranch=refs%2Ftags%2Fv16.25.0) (2024-11-12)


### Features

* DAZUIC-3204 - Make FileCollector usable in standalone mode ([0adb280](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0adb2800ec536ac4f8a02ab760d198cad38c450c))

### [16.24.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.24.2&sourceBranch=refs%2Ftags%2Fv16.24.3) (2024-11-11)


### Bug Fixes

* do not throw on outside clicks without className ([c62de9c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c62de9c4fdafddd079314b9c44ec4768d602320e))
* override version for prosemirror-model ([93ae958](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/93ae958b8f3de0746beff7e16a079fd533016de2))

### [16.24.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.24.1&sourceBranch=refs%2Ftags%2Fv16.24.2) (2024-11-11)


### Bug Fixes

* DAZUIC-3509 - use environment specific api url for eportal language request ([24499ff](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/24499ffcc17988ddfe7df0559fb6c8ea9c736e52))

### [16.24.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.24.0&sourceBranch=refs%2Ftags%2Fv16.24.1) (2024-11-11)


### Bug Fixes

* DAZUIC-3251 - typing issue pamsEnvironment ([82dbf39](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/82dbf3968894e322a9433398fa117655f1dbed72))
* DAZUIC-3515 - Parameter for link content type in QdTree ([41e2111](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/41e2111f151ef3439b2468c980522fdf65b1a715))

## [16.24.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.23.3&sourceBranch=refs%2Ftags%2Fv16.24.0) (2024-11-08)


### Features

* DAZUIC-3520 Link Columns clicks do not trigger primary actions ([2edb082](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2edb08237925a5ccef305f040be7924e742de3c2))

### [16.23.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.23.2&sourceBranch=refs%2Ftags%2Fv16.23.3) (2024-11-07)


### Bug Fixes

* DAZUIC-3483 - Inspect view creates side effect in create ([838b3ca](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/838b3ca395392e53ef3c5bbb9945c2c99fe705c1))

### [16.23.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.23.1&sourceBranch=refs%2Ftags%2Fv16.23.2) (2024-11-06)


### Bug Fixes

* missing exports ([32c6908](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/32c69082ffbabd338626a859a65195ff2ec2ae06))

### [16.23.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.23.0&sourceBranch=refs%2Ftags%2Fv16.23.1) (2024-11-05)


### Bug Fixes

* DAZUIC-3378 - never be clearable when disabled ([20de1ec](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/20de1ec4832d913b78c1837d857404af850ddb99))
* DAZUIC-3458 - pause notifications on dialog open, fix config typing issues ([49a8355](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/49a8355f530fddca01fef785fa8bac4e94514010))

## [16.23.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.22.1&sourceBranch=refs%2Ftags%2Fv16.23.0) (2024-11-04)


### Features

* DAZUIC-3504 - make context labels multilang ([449c52f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/449c52f73b8a14d73adc86b394cb0ec5e6e58366))


### Bug Fixes

* DAZUIC-3483 - Fix safeDraft Action in Create ([c30049e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c30049e9484df0b747ad3b87a928846a8b8d0ca9))
* DAZUIC-3483 - MultiInput is  empty in readonly mode ([855a561](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/855a561b79e7f41bd9ae76549800740a7ff39d8c))
* DAZUIC-3483 - typing issue control PageStep ([aa5375c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/aa5375c948aab7d74bf727b688692db5823b05d8))


### Documentation

* DAZUIC-3483 - Trigger change detection for archive/delete actions ([e161900](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e161900bf5e8b1f3f186bfba2959e70996ef8d9c))

### [16.22.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.22.0&sourceBranch=refs%2Ftags%2Fv16.22.1) (2024-11-04)


### Bug Fixes

* DAZUIC-3484 - Fix scrollbar on criticality click at 150% zoom ([2ad800d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2ad800db554881f4fd7c61ff28f60c67824e54d9))

## [16.22.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.21.3&sourceBranch=refs%2Ftags%2Fv16.22.0) (2024-10-30)


### Features

* DAZUIC-3487 - multi staging filter example ([0b952b8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0b952b8bbf6da35fe72f02b55d13f06fe01b12a5))


### Bug Fixes

* DAZUIC-3487 - update behaviour in filter components fixed ([e1ddbbc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e1ddbbcf47aa3c484f45b38a580d24f902dd42c3))

### [16.21.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.21.2&sourceBranch=refs%2Ftags%2Fv16.21.3) (2024-10-28)


### Documentation

* update page Docs ([fa92540](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fa9254000dc75470809819a20347e8b033841f23))

### [16.21.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.21.1&sourceBranch=refs%2Ftags%2Fv16.21.2) (2024-10-28)


### Bug Fixes

* conditional border in POH ([e24ad08](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e24ad086e31cb57276269aba3cfb7d2775a69efe))

### [16.21.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.21.0&sourceBranch=refs%2Ftags%2Fv16.21.1) (2024-10-28)


### Bug Fixes

* showcase page validation ([ef06f57](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ef06f57a9dcf39c50080c4bf48b3b50558688e1e))

## [16.21.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.20.0&sourceBranch=refs%2Ftags%2Fv16.21.0) (2024-10-25)


### Features

* DAZUIC-3446 - Add Docs, Save Validation, Fixes ([c5f5821](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c5f5821050d13784974a8f90a5d68d53145fc09a))

## [16.20.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.19.1&sourceBranch=refs%2Ftags%2Fv16.20.0) (2024-10-25)


### Features

* DAZUIC-3488 - simplify determination of environment in banner service ([6f62866](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6f62866b1a4ff35e57c5f33564a4d3fcfd3072af))

### [16.19.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.19.0&sourceBranch=refs%2Ftags%2Fv16.19.1) (2024-10-23)


### Bug Fixes

* DAZUIC-3477 - make facet registration static and remove decorator approach ([421080a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/421080ac9b7fb0ff2fbc0e618c9e041ac0013c89))

## [16.19.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.18.0&sourceBranch=refs%2Ftags%2Fv16.19.0) (2024-10-23)


### Features

* DAZUIC-3446 - Add more Documentation for QdPage ([d863890](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d863890820fd329944ddcc4fe5e8ca68fd2e59af))

## [16.18.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.17.0&sourceBranch=refs%2Ftags%2Fv16.18.0) (2024-10-22)


### Features

* DAZUIC-3446 - More Page Adjustments ([d92c932](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d92c9326cfaa595605268d944f179700a09c016e))
* DAZUIC-3446 - Page Adjustments ([8805cbd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8805cbdc5ebc0326adc90eee6605e5667e5e86d2))

## [16.17.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.9&sourceBranch=refs%2Ftags%2Fv16.17.0) (2024-10-22)


### Features

* DAZUIC-3423 - header widget uses eportal language from autologin endpoint if no default language is set ([b0441ee](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b0441eed73a756df87160ef06b37453c104cb9b2))

### [16.16.9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.8&sourceBranch=refs%2Ftags%2Fv16.16.9) (2024-10-22)

### [16.16.8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.7&sourceBranch=refs%2Ftags%2Fv16.16.8) (2024-10-16)


### Bug Fixes

* DAZUIC-3462 - next button disabled state validation updates fixed ([124af87](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/124af8747c5d7f389beed3583e519fcd858f5ed6))

### [16.16.7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.6&sourceBranch=refs%2Ftags%2Fv16.16.7) (2024-10-15)


### Bug Fixes

* DAZUIC-3467 - allow navigating back when current step is invalid ([4d5ac31](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4d5ac31a7ce32a6423dee6ef5fafd906cf4ecd94))

### [16.16.6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.5&sourceBranch=refs%2Ftags%2Fv16.16.6) (2024-10-15)

### [16.16.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.4&sourceBranch=refs%2Ftags%2Fv16.16.5) (2024-10-14)

### [16.16.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.3&sourceBranch=refs%2Ftags%2Fv16.16.4) (2024-10-10)


### Bug Fixes

* async behaviour selected step validation ([d60adb0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d60adb0ab76debb95193f2812acd90604dabe952))
* DAZUIC-3459 - Create Page Validation and Dynamic Step issues ([81403d0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/81403d09e973db56a8712b6d9cdab997494b5f96))

### [16.16.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.2&sourceBranch=refs%2Ftags%2Fv16.16.3) (2024-10-10)


### Bug Fixes

* minor validator issues ([7541593](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/75415937b675a41ac079066ee61e66e2db0c5437))

### [16.16.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.1&sourceBranch=refs%2Ftags%2Fv16.16.2) (2024-10-07)


### Bug Fixes

* export QdContextService ([68d73a7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/68d73a703fe3f6a5aec2044babeafb2f7623b860))

### [16.16.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.16.0&sourceBranch=refs%2Ftags%2Fv16.16.1) (2024-10-02)


### Bug Fixes

* DAZUIC-3438 - allow async validators for create page ([894b060](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/894b0602d64a9ab94ebb010da15015f9604d9c2d))

## [16.16.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.15.0&sourceBranch=refs%2Ftags%2Fv16.16.0) (2024-10-01)


### Features

* DAZUIC-3285 - API design ([1e00e2e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1e00e2e41cf41ed89474d4529f530e6453c9e445))
* DAZUIC-3285 - business context ([d9d8a24](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d9d8a246941504bd865c3b81368815687427b68d))
* DAZUIC-3285 - finalize feature ([dcebf83](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/dcebf83b4ba32056b4ecb10caf521bb01e49045a))
* DAZUIC-3285 - finalize feature, docs and implementation ([2e809f5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2e809f508223ba4aa4010269486672381d92a08d))


### Bug Fixes

* build issues ([c690357](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c690357d0737132468c87f2c948cc5e899487e49))
* fixes after design review ([80b6770](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/80b67700a5311f87b7d8dae9febd8367b782b4ba))
* provide context at root level and extend story with custom selection ([498220a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/498220a00d59d0a6b5e70b643eea1d69101ed53c))
* remove italic style for not selected contexts ([e88e9dc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e88e9dce46fb2a5e548858b59f932647a0445a09))
* undefined ref ([616c207](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/616c207527afea82fe6bb827844b4fa739a60b29))


### Documentation

* extend page docs with contexts ([520583e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/520583e393f6c3e4651c966a3b9b227ba09e487d))

## [16.15.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.14.3&sourceBranch=refs%2Ftags%2Fv16.15.0) (2024-10-01)


### Features

* DAZUIC-3401 - Use Data Facets in Tree ([a055dc0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a055dc0eae40e0834d9798cff681a12bb4f1f9ad))

### [16.14.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.14.2&sourceBranch=refs%2Ftags%2Fv16.14.3) (2024-10-01)


### Bug Fixes

* inspect page readonly fixes ([f465e0d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f465e0d0ae9b8270a3c1dcc237912ee8bd5b8de8))

### [16.14.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.14.1&sourceBranch=refs%2Ftags%2Fv16.14.2) (2024-09-26)

### [16.14.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.14.0&sourceBranch=refs%2Ftags%2Fv16.14.1) (2024-09-25)


### Bug Fixes

* DAZUIC-3302 add exports for QdFormOptionsResolver ([1066d70](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1066d705ee44fe5871b524972097642efb24ac27))

## [16.14.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.13.0&sourceBranch=refs%2Ftags%2Fv16.14.0) (2024-09-25)


### Features

* DAZUIC-3302 resolver for input options with loading and error hints ([4c1c90e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4c1c90eb8e0a9b106386e842bd141bcecca43d2b))

## [16.13.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.12.2&sourceBranch=refs%2Ftags%2Fv16.13.0) (2024-09-23)


### Features

* DAZUIC-3401 - Add Data Facets ([9653f30](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9653f30b199691e11fe0d301e494b38e108333aa))


### Bug Fixes

* DAZUIC-3433 - respect readonly toggle in multi input ([424533c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/424533c38de679c67a456861a976135c332231b6))
* translate richtext label in add comment dialog ([cdb8163](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cdb8163fae14b04e7fb77011e70871a1e0759ced))

### [16.12.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.12.1&sourceBranch=refs%2Ftags%2Fv16.12.2) (2024-09-23)


### Bug Fixes

* mock section component id collisions ([5d7e88d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5d7e88da573760a4e62bbd9b01a4a961fa0012f5))

### [16.12.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.12.0&sourceBranch=refs%2Ftags%2Fv16.12.1) (2024-09-18)


### Bug Fixes

* ExpressionChangedAfterItHasBeenChecked Errors ([b5f25a6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b5f25a6796be0250706c8a6928cb083dd548691f))
* ExpressionChangedAfterItHasBeenChecked Errors ([a6a0e8a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a6a0e8a565978d1e12e9c8df7fb4382c02fe497c))

## [16.12.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.11.3&sourceBranch=refs%2Ftags%2Fv16.12.0) (2024-09-17)


### Features

* DAZUIC-3020 table: truncate multiple chips with small truncation indicator chip ([43ce030](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/43ce03013bc5a9a5161f7e19af09a6fdb5657259))


### Bug Fixes

* DAZUIC-3412 - word break and width in commentari add new button fixed ([fd58e48](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fd58e48f49848f25349f0fdd336c1688053fbba1))


### Documentation

* inline and multiline notifications documentation ([24489bd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/24489bdb1e95422eb6c25d6d647f605c97f71e7e))

### [16.11.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.11.2&sourceBranch=refs%2Ftags%2Fv16.11.3) (2024-09-16)

### [16.11.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.11.1&sourceBranch=refs%2Ftags%2Fv16.11.2) (2024-09-16)

### [16.11.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.11.0&sourceBranch=refs%2Ftags%2Fv16.11.1) (2024-09-11)

## [16.11.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.10.0&sourceBranch=refs%2Ftags%2Fv16.11.0) (2024-09-11)


### Features

* DAZUIC-3376 page-tabs - replace selectionChange output by tabSelection output ([f9f4050](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f9f405041edf429c50ae90768117809fd8eb6df0))

## [16.10.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.9.1&sourceBranch=refs%2Ftags%2Fv16.10.0) (2024-09-11)


### Features

* DAZUIC-3372 QdPageFooter Anpassungen ([2996071](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/29960714afe736ee480c620a52f210d23c78a6be))

### [16.9.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.9.0&sourceBranch=refs%2Ftags%2Fv16.9.1) (2024-09-09)


### Bug Fixes

* filter - emit valueChange only once per change ([b6b31dc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b6b31dc03fe879273baf5e59695edbf58e567c94))

## [16.9.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.8.0&sourceBranch=refs%2Ftags%2Fv16.9.0) (2024-09-09)


### Features

* DAZUIC-3299 - Add ControlPanel ([fbbf3c1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fbbf3c146644a9eefc68bc1afea5344f354bcacc))

## [16.8.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.7.2&sourceBranch=refs%2Ftags%2Fv16.8.0) (2024-09-06)


### Features

* DAZUIC-3390 ProgressBar max-height for tables ([764878a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/764878af66eb8e8cde14bcf19fac10f45ab25720))

### [16.7.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.7.1&sourceBranch=refs%2Ftags%2Fv16.7.2) (2024-09-04)


### Bug Fixes

* make commentary standalone components module components again and add to public api ([125c202](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/125c2027a56f5b0e5c681b151238269a2bc5d875))

### [16.7.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.7.0&sourceBranch=refs%2Ftags%2Fv16.7.1) (2024-09-03)

## [16.7.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.6.2&sourceBranch=refs%2Ftags%2Fv16.7.0) (2024-09-02)


### Features

* DAZUIC-3376 - page stepper additional properties and methods to enable connection to router ([0f851be](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0f851be1a8f398f1c067be30cb0663f20e65baae))

### [16.6.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.6.1&sourceBranch=refs%2Ftags%2Fv16.6.2) (2024-09-02)

### [16.6.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.6.0&sourceBranch=refs%2Ftags%2Fv16.6.1) (2024-09-02)

## [16.6.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.5.5&sourceBranch=refs%2Ftags%2Fv16.6.0) (2024-08-30)


### Features

* DAZUIC-3344 - neutral status chip ("none") ([e9e2446](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e9e244692f5fb37778732f3c7df6ec29040039dc))


### Bug Fixes

* DAZUIC-3377 - support currency column for tree table ([d8a44a0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d8a44a0444a4aed8b8b0a564726bf432bfd96101))

### [16.5.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.5.4&sourceBranch=refs%2Ftags%2Fv16.5.5) (2024-08-29)


### Bug Fixes

* inspect page readonly toggling with tabs ([83e6e14](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/83e6e14dc3ca2a8fc5bde056c7196f55ef1ddd3b))

### [16.5.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.5.3&sourceBranch=refs%2Ftags%2Fv16.5.4) (2024-08-29)


### Documentation

* add docs for QdPage and QdShell ([6163787](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6163787e1ead22afaa0bbffbd14e55926158b4e9))

### [16.5.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.5.2&sourceBranch=refs%2Ftags%2Fv16.5.3) (2024-08-28)


### Bug Fixes

* DAZUIC-3373 - table: handle config changes ([ba9491a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ba9491ac8c7c101337b1be29239dc462c1ec36c3))

### [16.5.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.5.0&sourceBranch=refs%2Ftags%2Fv16.5.2) (2024-08-27)


### Bug Fixes

* Inspect - hide submit button in view mode ([1b7187b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1b7187b7ce8eacfb79f4a366c07ded76b08ace5a))

### [16.5.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.5.0&sourceBranch=refs%2Ftags%2Fv16.5.1) (2024-08-27)


### Bug Fixes

* Inspect - hide submit button in view mode ([1b7187b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1b7187b7ce8eacfb79f4a366c07ded76b08ace5a))

## [16.5.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.4.1&sourceBranch=refs%2Ftags%2Fv16.5.0) (2024-08-27)


### Features

* update page button handling ([11e7287](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/11e728776d7307f47f1026a60d32a52eb35eafdc))


### Bug Fixes

* DAZUIC-3295 - styling fixes for page object header facets ([6fa5805](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6fa5805ed6206cf0a1662454ddd7a1805b943cf4))
* facet async issues ([5758dd9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5758dd974c6659aa98a60bdd0b36d2af5d9eb35c))
* resolve review comments ([6a94c1e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6a94c1e31bd4b1ecd4ca419f8e969004fd657604))
* resolve review comments ([e20638a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e20638a2396b530d9aace5b9d6bee387422ebe04))

### [16.4.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.4.0&sourceBranch=refs%2Ftags%2Fv16.4.1) (2024-08-27)


### Bug Fixes

* DAZUIC-3365 - reset emission ReplaySubjects when filter is destroyed to prevent initial emission when the filer is reinitialized ([7de7076](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7de7076b8a0b98503ec3280c07b1413c41d05d1f))

## [16.4.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.3.3&sourceBranch=refs%2Ftags%2Fv16.4.0) (2024-08-26)


### Features

* DAZUIC-3183 - new icons certificateReview and certificateWait ([81a6f30](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/81a6f30894a6e4a18116c8323281004648482db8))

### [16.3.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.3.2&sourceBranch=refs%2Ftags%2Fv16.3.3) (2024-08-23)


### Bug Fixes

* DAZUIC-3365 - return result of last call if refresh is called multiple times in quick succession even if first call is resolved later ([bad46ff](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bad46ff027e8b761f0e21048475afb413b1f8460))

### [16.3.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.3.1&sourceBranch=refs%2Ftags%2Fv16.3.2) (2024-08-22)


### Bug Fixes

* DAZUIC-3293 - move currentLang to last position for translateService.getTranslation calls because of an issue in the getTranslation method ([24cf235](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/24cf2354d1301c42d7d4f705c2a17a03483aea25))

### [16.3.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.3.0&sourceBranch=refs%2Ftags%2Fv16.3.1) (2024-08-22)


### Bug Fixes

* DAZUIC-3345 - fix input dropdown bugs and scroll into view with arrow keys ([5e42fd3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5e42fd3612e14850d4a8e89b5403b373e2e852cf))

## [16.3.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.2.2&sourceBranch=refs%2Ftags%2Fv16.3.0) (2024-08-20)


### Features

* cleanup storybook ([9a7500b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9a7500bd7e499086a00cff45724fa0f5937b1a04))
* DAZUIC-3095 - add doku ([7eceb2f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7eceb2fd59ef8100bc8a325c044a542eb3943099))
* DAZUIC-3095 - further content types for POH ([9856f6f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9856f6ff470a46e3861a09cabc5bdd453465da43))
* DAZUIC-3252 - actions for overview and custom pages ([727ded8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/727ded8291badcc95746e6ce2bd974dbe540467f))
* DAZUIC-3260 - remove page levels in favor of isHome ([e6c4615](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e6c46154d75794b53ca19c1156d8d5f3ea09f557))
* inspect mode readonly  controlling ([60c25de](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/60c25de41fd02fd763dcde41d87bada10c82ad01))
* readonly controlling - respect config values over inspect controlling ([a8cc7b1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a8cc7b18e7558a4e2149903954dfbe854079ca80))


### Bug Fixes

* add property to providers ([42d59d6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/42d59d66b63ee926d7f1c19e59d2ec717a536524))
* build ([ac0d1b8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ac0d1b8d17a46aa3b371a26388536c9103cdaf2e))
* dialog injection ([f6ccc80](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f6ccc8078fd99f2de2c2d9e1ee9bb817798fda5f))
* fix pipeline ([52b086e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/52b086ec1f5dcc1f44ae4c275a479dcde6b2cc4c))
* fix some issues before release ([83a40ff](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/83a40ff650140f061d1bb80970891e876bb47dc2))
* isHome declaration position ([5c7ee52](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5c7ee52c3d4d48fd0c0708e4e3107ac9195ebfcb))
* multiple ng-contents not allowed ([8491111](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/84911115ce95fba15a6c72e474df7f95b9801980))
* readonly toggling only for inspect ([125a517](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/125a51781ad0083cff11ca8efc6ab61104eb0797))
* remove blabla ([4868733](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4868733e70d85461670f403ee2058167c8d70bd3))


### Documentation

* add Storybook use Cases ([076643b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/076643b6c6751a4b7fbe8c2d89f93cdfe3ced26b))

### [16.2.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.2.1&sourceBranch=refs%2Ftags%2Fv16.2.2) (2024-08-16)


### Bug Fixes

* build issue with import fixed ([220c90e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/220c90e3dcd51849b50e1daa9a882959e5f5c833))

### [16.2.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.2.0&sourceBranch=refs%2Ftags%2Fv16.2.1) (2024-08-16)


### Bug Fixes

* DAZUIC-3312 - table clean up behaviour fixed ([b6d9881](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b6d9881ef75c4d59a5d13d85c2ff6d499ac48270))

## [16.2.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.1.0&sourceBranch=refs%2Ftags%2Fv16.2.0) (2024-08-15)


### Features

* DAZUIC-3259 - change section toolbar button to ghost button ([ff84e62](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ff84e62110b22c49488f10e766452c613b7fad9f))


### Bug Fixes

* DAZUIC-3239 - table filter bug ([8e60e0b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8e60e0b7098dabdd05c87e6987359b199a9e5a99))

## [16.1.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.0.1&sourceBranch=refs%2Ftags%2Fv16.1.0) (2024-08-09)


### Features

* DAZUIC-3287 - search debounceTime removed; search emits only on enter or icon click and not when typing ([0c359a9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0c359a96332d43f75258458d5af5640bccb064bc))

### [16.0.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv16.0.0&sourceBranch=refs%2Ftags%2Fv16.0.1) (2024-08-06)


### Bug Fixes

* DAZUIC-3286 - filter reset button behavior fixed when data from store is used; handling of category changes simplified ([53d3f7b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/53d3f7bbe8f2c765bf800e87136e268716f4274d))

## [16.0.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.46.2&sourceBranch=refs%2Ftags%2Fv16.0.0) (2024-08-06)


### Features

* DAZUIC-2712 - migration of confirmation-dialog ([92017c8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/92017c8a096e959bdc12db52dd84093d610ab749))
* DAZUIC-3110 - BREAKING CHANGE - upgrade to v16 ([5495d65](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5495d65ae15329f56d2a7a326dc83c203508ef24))
* DAZUIC-3120 - qd-date-tree removed ([a15205f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a15205fbba72f72edf7e261bc938174af7981604))
* DAZUIC-3123 - Remove Zombies: QdModal ([77e04af](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/77e04aff079a6622f6aa1da70d46add9e8257483))
* DAZUIC-3124 - Remove Zombies: QdException ([4cc86da](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4cc86da0712854343f3f526ae68904f930877788))


### Bug Fixes

* DAZUIC-3263 - fix change detection loop in filter (remove async ngOnChanges); also emit filter url for changes from connector directive ([ce16ea6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ce16ea6321aaba7540ad7444be4c7fab1ef68727))

### [15.46.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.46.1&sourceBranch=refs%2Ftags%2Fv15.46.2) (2024-07-30)


### Bug Fixes

* DAZUIC-3249 - Fix container toolbar when multiple actions are in use ([d7f67cd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d7f67cd0a02d275c25f4ca12873e6b040c952052))

### [15.46.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.46.0&sourceBranch=refs%2Ftags%2Fv15.46.1) (2024-07-29)


### Bug Fixes

* DAZUIC-3239 - make table store type safe ([18b7973](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/18b79737ebaa7c75dfaa03979be7bfd79b4e6081))

## [15.46.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.45.1&sourceBranch=refs%2Ftags%2Fv15.46.0) (2024-07-23)


### Features

* DAZUIC-3118 - qdColumns responsive colspans; qdColumnBreakBefore, qdColumnFullGridWidth, qdColumnNextInSameRow, qdColumnAutoFill, qdColumnsDisableAutoFill and qdColumnsMax directive ([d0d607f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d0d607f3e959c3425f79b011f52b66ed3acc1aaf))

### [15.45.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.45.0&sourceBranch=refs%2Ftags%2Fv15.45.1) (2024-07-22)

## [15.45.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.44.2&sourceBranch=refs%2Ftags%2Fv15.45.0) (2024-07-19)


### Features

* DAZUIC-3190 - input dropdown ([73cda4d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/73cda4dfe4dcb637a26a8a8443f35861503210b3))

### [15.44.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.44.1&sourceBranch=refs%2Ftags%2Fv15.44.2) (2024-07-17)


### Bug Fixes

* QD Table - unsubscribe fixed for columnSortDirection$ subscription ([acc9fa7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/acc9fa714bcdcfd549ee174feb43a2823769005f))

### [15.44.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.44.0&sourceBranch=refs%2Ftags%2Fv15.44.1) (2024-07-16)

## [15.44.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.43.0&sourceBranch=refs%2Ftags%2Fv15.44.0) (2024-07-16)


### Features

* DAZUIC-3094 - POH status and value facets ([9d698da](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9d698dad063ec36b31e253deb9f4788e7a5c0cab))

## [15.43.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.42.0&sourceBranch=refs%2Ftags%2Fv15.43.0) (2024-07-15)


### Features

* DAZUIC-3107 - POH initial creation ([55f2e5b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/55f2e5b32b07993a5c3f526e5425fc57b6e351ab))

## [15.42.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.41.1&sourceBranch=refs%2Ftags%2Fv15.42.0) (2024-07-05)


### Features

* DAZUIC-3180 - Makes sure that the highest break point in the edge is reached ([2b7d867](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2b7d867c33b3e221354124b14b1dd83c00d4080c))

### [15.41.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.41.0&sourceBranch=refs%2Ftags%2Fv15.41.1) (2024-07-04)


### Bug Fixes

* DAZUIC-3226 - Cleanup of table state in ngrx-store when UID has been auto-generated ([61ea331](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/61ea331286fa3a7a7a86579b5ddf043712e252f3))
* DAZUIC-3227 - change detection issue in file collector fixed ([48123a6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/48123a68cd9d8afdfa0d4078fc50e75a6703a2aa))

## [15.41.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.40.2&sourceBranch=refs%2Ftags%2Fv15.41.0) (2024-07-04)


### Features

* DAZUIC-3191 - Added New Comment and Readonly Dialog ([200fe2f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/200fe2fc0696dd60bb07c4597861f9e1174d697d))


### Bug Fixes

* DAZUIC-3061 - More highlighting for Storysource Button ([fdc070b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fdc070bf3845384a24128b44cf31f57f14b4be4b))
* DAZUIC-3181 - shell left and right scrolling ([b0c1a02](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b0c1a027e19be374e67efcb71a88d0428dc4e422))
* DAZUIC-3221 icon active fix ([6d423dd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6d423dd196f2e03c66f6fe034f8da6af6553cffc))

### [15.40.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.40.1&sourceBranch=refs%2Ftags%2Fv15.40.2) (2024-07-01)


### Bug Fixes

* service navigation - eportal language request error handling ([8cdcaeb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8cdcaeb1480ae8e6bdab8394091a2c9abe7328aa))

### [15.40.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.40.0&sourceBranch=refs%2Ftags%2Fv15.40.1) (2024-07-01)


### Bug Fixes

* add page tabs module to qd ui module ([f83df49](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f83df49d027fcd56ea39a11ce51b34e0bd1a4006))

## [15.40.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.39.2&sourceBranch=refs%2Ftags%2Fv15.40.0) (2024-07-01)


### Features

* DAZUIC-3210 - allow query parameters in route data previousHref url (my-url?param=value) ([208e094](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/208e0946c8cce0e0f0e1fafbaa21c2df1edbaf6c))

### [15.39.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.39.1&sourceBranch=refs%2Ftags%2Fv15.39.2) (2024-07-01)


### Bug Fixes

* add ngx-editor dependency to fix build issue ([daa1836](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/daa1836bf38cac82801f70aef9b2fc8ab3c283c1))
* add page tabs module to public api ([0e0c751](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0e0c751933139636897971f3607fc778d3f354b1))
* fixes cut of big CH logo ([0c61834](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0c61834491aa727d341c7b4cff0a0dd003c31d32))

### [15.39.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.39.0&sourceBranch=refs%2Ftags%2Fv15.39.1) (2024-06-28)


### Bug Fixes

* make config in service-navigation.service.ts public instead of getter/setter without logic ([3cc0e31](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3cc0e31f1f21933a2111340e2f76e2c57a902691))

## [15.39.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.38.2&sourceBranch=refs%2Ftags%2Fv15.39.0) (2024-06-27)


### Features

* DAZUIC-2958 file collector - handle async file list changes ([ab006e2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ab006e2d8f7321e6ac4c44d8626508965aeab3eb))

### [15.38.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.38.1&sourceBranch=refs%2Ftags%2Fv15.38.2) (2024-06-26)


### Documentation

* DAZUIC-3206 - extend search config docs ([1945f41](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1945f410f44e6232716bf6dfebb70ab07e8bdc89))

### [15.38.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.38.0&sourceBranch=refs%2Ftags%2Fv15.38.1) (2024-06-26)


### Documentation

* filter - preserve state with uid ([bc6c47d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bc6c47d1755ebbde7bb078bd008d46cd34995ffb))

## [15.38.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.37.2&sourceBranch=refs%2Ftags%2Fv15.38.0) (2024-06-26)

### Features

- DAZUIC-3109 - richtext editor ([8b6f084](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8b6f084221402b6c49fbe31a9fbcec5c3be95309))

### [15.37.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.37.1&sourceBranch=refs%2Ftags%2Fv15.37.2) (2024-06-26)

### Bug Fixes

- DAZUIC-3182 - fix previousHref issue ([529944b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/529944b45130ee95e2fb8892eefb3cf6a75e5591))
- DAZUIC-3187 - Make table-filter-connection more reactive ([a33727e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a33727eb1ba0717d116f0c42aa172df59919ecd0))
- DAZUIC-3187 - Remove the warnings in the unit tests ([bfba341](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bfba3414812683d5d73f8f9f7e280c150a3e4dd0))

### [15.37.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.37.0&sourceBranch=refs%2Ftags%2Fv15.37.1) (2024-06-25)

### Bug Fixes

- DAZUIC-3174 - added new icons ([c0ced7b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c0ced7b285df3aac85153db1133c4c9b4fb748cc))

## [15.37.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.7&sourceBranch=refs%2Ftags%2Fv15.37.0) (2024-06-24)

### Features

- DAZUIC-3119 - integrate comments in shell ([e24a8b7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e24a8b72f384ef2f21e8d9cd9f8501d71365814e))
- DAZUIC-3119 - pr corrections ([f505454](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f50545475272880ded55567b210c6aabde79a2f9))
- DAZUIC-3119 - Use correkt input value for shell header ([3f09fd3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3f09fd3b08ac6644d05556b3e47fc682d4688503))
- DAZUIC-3126 - comments unit tests ([b577678](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b5776780bdb1c2cdc4b79f3c5e0bfcec48395c72))
- DAZUIC-3126 - create comments list ([ac7f1ee](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ac7f1eec5efd5164cd9c557e8284f654bdfb797f))
- DAZUIC-3126 - remove cypress file ([42ff799](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/42ff799232fdc767d618f4d384909d874eb9902e))

### Documentation

- DAZUIC-3119 - add story for comments ([4dc310a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4dc310a2a604599f5ff056f38844fad5b806ee9d))

### [15.36.7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.6&sourceBranch=refs%2Ftags%2Fv15.36.7) (2024-06-24)

### Bug Fixes

- DAZUIC-3112 - remove entry components ([9ccba94](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9ccba94682094077d0922557ef599b08dded6c31))

### [15.36.6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.5&sourceBranch=refs%2Ftags%2Fv15.36.6) (2024-06-20)

### [15.36.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.4&sourceBranch=refs%2Ftags%2Fv15.36.5) (2024-06-20)

### Bug Fixes

- DAZUIC-3130 - Correct reset of form array ([44889d5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/44889d52b4687f2c843dfb14367ca53f90bc1182))

### [15.36.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.3&sourceBranch=refs%2Ftags%2Fv15.36.4) (2024-06-17)

### Bug Fixes

- modal fullscreen issues ([71885a5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/71885a5fd9837db419eb84b62dde5923615a7b9d))
- remove record stepper stuff ([aa8c3b3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/aa8c3b3cfd62b71d1569649782f5656abc7d12fb))

### [15.36.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.2&sourceBranch=refs%2Ftags%2Fv15.36.3) (2024-06-12)

### Bug Fixes

- DAZUIC-2929 - get pams environment from backend config in QdShellServiceNavigationComponent ([c294571](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c2945712237d161bfd884994dd15b7d307b8f019))

### [15.36.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.1&sourceBranch=refs%2Ftags%2Fv15.36.2) (2024-06-10)

### Bug Fixes

- DAZUIC-3147 - determination of toolbar components in table integration fixed ([28688e7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/28688e7205cf7ebe9c968f4e5c41b5253052fb1f))

### [15.36.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.36.0&sourceBranch=refs%2Ftags%2Fv15.36.1) (2024-06-10)

### Documentation

- DAZUIC-3087 - logout value changes in filter ([2c39784](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2c397848d0b1475588729b26196b797a95ec4f55))

## [15.36.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.35.0&sourceBranch=refs%2Ftags%2Fv15.36.0) (2024-06-05)

### Features

- DAZUIC-3067 - New Output Event for Navigation on Tabs ([ff9eaaf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ff9eaafe9ceed54bfe8bcebaae9b55210fa44035))

## [15.35.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.34.2&sourceBranch=refs%2Ftags%2Fv15.35.0) (2024-06-04)

### Features

- DAZUIC-3078 - isHidden flag for addNew button ([f1138f4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f1138f4d373bb46348048e912eadae1ff8025fb0))

### [15.34.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.34.1&sourceBranch=refs%2Ftags%2Fv15.34.2) (2024-06-04)

### Bug Fixes

- pamsEnvironment binding in Service Navigation ([778c00c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/778c00cee1e59b63551d0f5835f794a8006e9cd4))

### [15.34.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.34.0&sourceBranch=refs%2Ftags%2Fv15.34.1) (2024-06-03)

### Bug Fixes

- DAZUIC-3052 - fix previousHref route parameter for sub module routes ([7400769](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/74007697755b35d9c9360d33dd71bb2ec938756b))

## [15.34.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.33.1&sourceBranch=refs%2Ftags%2Fv15.34.0) (2024-05-30)

### Features

- DAZUIC-2771 - key navigation for dropdown component ([650beae](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/650beae50239c1fb7ab412449185987392c20eef))
- DAZUIC-2771 - use form-input component for multiInput key navigation ([325a2bb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/325a2bb612be0e9acbd27e6498674ab5bb890ed9))

### [15.33.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.33.0&sourceBranch=refs%2Ftags%2Fv15.33.1) (2024-05-30)

### Bug Fixes

- fix race condition issues in Service Navigation ([534b5f1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/534b5f18f613d8f3dc4df3d5642723911eea1f86))

## [15.33.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.32.1&sourceBranch=refs%2Ftags%2Fv15.33.0) (2024-05-29)

### Features

- DAZUIC-2921 ff - Release for page navigation ([e66b6f8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e66b6f8a5b7195c8983bbc6453833e270ae1e3bb))

### [15.32.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.32.0&sourceBranch=refs%2Ftags%2Fv15.32.1) (2024-05-29)

### Bug Fixes

- DAZUIC-3064 - hide checkbox button if config not set; fix dialogRef closed handler ([4cf8441](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4cf8441f813260fdc4a78877300c7240f5748bac))

## [15.32.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.31.3&sourceBranch=refs%2Ftags%2Fv15.32.0) (2024-05-29)

### Features

- DAZUIC-2918 - service navigation integration ([03df884](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/03df884654a1f7b9d299ccb96b94eb1c32000a75))
- DAZUIC-2957 - fetch default language from eportal ([7783bb2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7783bb2dae9e67870874059d84ac9496d084189b))
- **service-navigation:** rework implementation with CDN reference ([d0ea28e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d0ea28ea75d800016f6258374bc0ee80e2fc60b0))

### Bug Fixes

- DAZUIC-3052 - fix previousHref route parameter for sub module routes ([541d2b7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/541d2b7aeb17690b43452824058cba0adf5dc81d))
- DAZUIC-3054 - wait for config by table[qdConnectToFilter] before initializing filter ([bf402ad](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bf402adc95c4d1d906c1dfa806340c74ddc3da1d))
- minor fixes in service navigation config ([c632945](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c6329459c1be7934b557de54c19bcebb21e03433))

### [15.31.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.31.2&sourceBranch=refs%2Ftags%2Fv15.31.3) (2024-05-28)

### Bug Fixes

- DAZUIC-3050 - handling of search component debounce time fixed ([a1781bf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a1781bf3ecdb4fc8420a68654e6e074a91470bc1))

### [15.31.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.31.1&sourceBranch=refs%2Ftags%2Fv15.31.2) (2024-05-24)

### Documentation

- qd-table pagination docs ([584abe0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/584abe0dc7d102b8a8344f8a5ea288aeffd7ba02))

### [15.31.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.31.0&sourceBranch=refs%2Ftags%2Fv15.31.1) (2024-05-24)

### Bug Fixes

- DAZUIC-3029 - Allow null values for read-only form values ([8366929](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8366929b320a50d7da0630540cc47e1fdb891724))

## [15.31.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.30.0&sourceBranch=refs%2Ftags%2Fv15.31.0) (2024-05-23)

### Features

- DAZUIC-2921 - Tabs integration: Page footer ([93d809b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/93d809bc1119df4b5347cede2f004a423681c377))

## [15.30.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.29.0&sourceBranch=refs%2Ftags%2Fv15.30.0) (2024-05-22)

### Features

- DAZUIC-3033 page tabs - isDisabled config to disable a single tab ([bdec18d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bdec18d3a6530d2a7d4e594b22f2330de6f1be27))

### Documentation

- DAZUIC-2996 - documentation for snackbarOptions and osNotificationOptions ([52eb6f8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/52eb6f814901e4585e4b2d961d3ade6158c6ac28))

## [15.29.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.28.0&sourceBranch=refs%2Ftags%2Fv15.29.0) (2024-05-22)

### Features

- DAZUIC-3011 - QdPageFooter API und integration Stepper ([82f031a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/82f031aefb97a130974acaa09c0f11f2aa312d21))

### Bug Fixes

- add readonly actions in multiInput, fix checkbox bug in service ([e95ef4d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e95ef4d431be3b5f7457cf825f40c93ac1e3d974))
- no more errors if page title is not given ([9ddfbe0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9ddfbe05b353f49f31df64b67ec4043d8da02a54))
- re-add close container ([14b35d3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/14b35d39d00b8392d99f12a6c4423db6257026f8))

## [15.28.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.27.1&sourceBranch=refs%2Ftags%2Fv15.28.0) (2024-05-15)

### Features

- DAZUIC-2925 - page navigation tabs redesign ([b140e6c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b140e6c354687ab8cf21bf0fdbbc292345c2766b))

### [15.27.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.27.0&sourceBranch=refs%2Ftags%2Fv15.27.1) (2024-05-15)

## [15.27.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.26.1&sourceBranch=refs%2Ftags%2Fv15.27.0) (2024-05-15)

### Features

- DAZUIC-2996 snackbar notifications onClose callback ([fc319cf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fc319cf6af5e219cfafd63415d43c7565998710c))

### [15.26.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.26.0&sourceBranch=refs%2Ftags%2Fv15.26.1) (2024-05-15)

### Bug Fixes

- DAZUIC-3022 - fix container in legacy layout ([ff786f1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ff786f105210ad6c74c4a55a629fb3fce221aad0))

## [15.26.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.25.0&sourceBranch=refs%2Ftags%2Fv15.26.0) (2024-05-14)

### Features

- **datepicker:** validate date and time for model binding usage ([48f085e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/48f085e2be612673f00c8bc7f7e737a2a0e11bdb))

### Bug Fixes

- **datepicker:** allow model binding with initial value ([13d3532](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/13d3532eddc30fc92104408f5be32314e463d6a0))
- **datepicker:** initial value ([8b5f6ee](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8b5f6ee779fe7d5089fec89f97de669eb39dcc00))
- **datetime-picker:** validation user input ([1ff4f5d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1ff4f5deb9a76cb0327f9d46d35b16620645d71c))
- DAZUIC-2795 - datepicker invalid user input ([ecb3d37](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ecb3d37de5e4ead12eaafe36997cd95622dd6180))

## [15.25.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.24.1&sourceBranch=refs%2Ftags%2Fv15.25.0) (2024-05-14)

### Features

- DAZUIC-2996 desktop notifications ([1c1d06a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1c1d06acebb5d72de0de1db74d31647bc1fb1b46))

### [15.24.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.24.0&sourceBranch=refs%2Ftags%2Fv15.24.1) (2024-05-13)

### Bug Fixes

- DAZUIC-3006 - datepicker handle edge case when first of month is a sunday ([ad04847](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ad048472ac187c6319ff345c7b546d4fa5205722))

## [15.24.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.23.0&sourceBranch=refs%2Ftags%2Fv15.24.0) (2024-05-10)

### Features

- DAZUIC-2920 - Cancel Button and Dialog ([04a680d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/04a680d26e7a86d88605ad9557853eb91cc850e2))

## [15.23.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.22.1&sourceBranch=refs%2Ftags%2Fv15.23.0) (2024-05-07)

### Features

- DAZUIC-2617 - add valueChange to filter ([32b3966](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/32b3966d201552d6f7cfe380124db7d7c76f0bb9))

### [15.22.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.22.0&sourceBranch=refs%2Ftags%2Fv15.22.1) (2024-05-06)

### Documentation

- document filter config uid ([11b29a8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/11b29a84c49966cf49b1226abb85c4d996407178))

## [15.22.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.21.1&sourceBranch=refs%2Ftags%2Fv15.22.0) (2024-05-06)

### Features

- DAZUIC-2924 - page navigation stepper redesign ([f47dfda](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f47dfda331d2dc474e325c2cd976be16f076e6a2))

### [15.21.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.21.0&sourceBranch=refs%2Ftags%2Fv15.21.1) (2024-05-03)

## [15.21.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.20.1&sourceBranch=refs%2Ftags%2Fv15.21.0) (2024-05-02)

### Features

- DAZUIC-2978 - table on push strategy ([1ae51b8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1ae51b8a6a9f704b96e450cfc853a85486e4dae6))

### [15.20.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.20.0&sourceBranch=refs%2Ftags%2Fv15.20.1) (2024-05-02)

### Bug Fixes

- DAZUIC-2861 - multi input disabled with form controls ([c35855d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c35855d235dc518bc69f980c9fa32ef8a2d342a8))
- DAZUIC-2861 - multi input values and valueChange ([35b501a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/35b501a12333c8cdafe67f75089ec7996f7ddd0e))

## [15.20.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.19.0&sourceBranch=refs%2Ftags%2Fv15.20.0) (2024-05-01)

### Features

- DAZUIC-2927 - page navigation tabs ([71b339b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/71b339b569b7c9a622697c7313b3fef188565f94))

## [15.19.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.18.0&sourceBranch=refs%2Ftags%2Fv15.19.0) (2024-05-01)

### Features

- Stepper: DAZUIC-2922 - Completion of the API, encapsulation CDK ([0a9e4ba](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0a9e4ba62bd23c74c13e93cd29be8e94701c8ef8))

## [15.18.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.17.0&sourceBranch=refs%2Ftags%2Fv15.18.0) (2024-05-01)

### Features

- DAZUIC-2974 - upload timestamp for collected files ([607efd1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/607efd1aa700fd17cf91620c3aff14accaf22429))

### Bug Fixes

- design issue upload timestamp ([2416075](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2416075d18eef605b5d6d450de1af25a0ae7ca7e))
- file name ([c44dfb2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c44dfb2486b1b0277363ebfd5b6ce77b2e1f76d7))

## [15.17.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.16.6&sourceBranch=refs%2Ftags%2Fv15.17.0) (2024-05-01)

### Features

- Stepper: DAZUIC-2922 - Completion of the API, encapsulation CDK ([b4daef5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b4daef52c45bcde206e8d346ce5d9fa0d0ebdf60))

### [15.16.6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.16.5&sourceBranch=refs%2Ftags%2Fv15.16.6) (2024-04-30)

### Bug Fixes

- DAZUIC-2997 dropdown opens with a higher priority down than up ([bd486be](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bd486be38337aabd6cbf9f5fd74f43c0a0b4c9bd))

### [15.16.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.16.4&sourceBranch=refs%2Ftags%2Fv15.16.5) (2024-04-26)

### Bug Fixes

- DAZUIC-2990 - don't close parent popover if nested popover is opened ([00b890d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/00b890de6677887f823d8d6e351f879e95cc51b4))

### [15.16.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.16.3&sourceBranch=refs%2Ftags%2Fv15.16.4) (2024-04-26)

### [15.16.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.16.2&sourceBranch=refs%2Ftags%2Fv15.16.3) (2024-04-25)

### Bug Fixes

- DAZUIC-2989 - closes secondary action menu on every click ([9d9fd1d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9d9fd1d815056ea68b0d4bb90c00b27cf29dcbd0))
- DAZUIC-2989 - do not fire primary action when clicking secondary actions menu ([2832a31](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2832a316ebca83912c9ebec170aa1eafef760017))
- DAZUIC-2989 - provide QdPopoverService in module ([6039162](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6039162bfb6f9617b0f2b4795d9ed14a44aa622b))
- Draggable banner in QdShell ([7728b85](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7728b850ba824615330aee894e0ebe0fd79a1f76))

### [15.16.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.16.1&sourceBranch=refs%2Ftags%2Fv15.16.2) (2024-04-22)

### Bug Fixes

- Connector Table Filter directive does not work if filter is preselected ([f4354d5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f4354d5533361658aadf104259d37add0526c0db))
- DAZUIC-2965 type of checkbox values for readonly ([9b19001](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9b1900154b50b0410530c55740bc2f701edfa1c9))
- Show translated values for readonly switches ([b3c7bc9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b3c7bc9460d60b175fdd2e85741028124613c7a8))

### [15.16.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.16.0&sourceBranch=refs%2Ftags%2Fv15.16.1) (2024-04-22)

### Bug Fixes

- file size pipe - fixes display of empty value ([c6e81fc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c6e81fc07afcb7905d65a0f143971b0e84bff3a1))

## [15.16.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.15.0&sourceBranch=refs%2Ftags%2Fv15.16.0) (2024-04-22)

### Features

- DAZUIC-2979 - notifications service onRemove method ([c611672](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c611672bfb91438ae33f1bbf85963a388e5855e7))

## [15.15.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.14.0&sourceBranch=refs%2Ftags%2Fv15.15.0) (2024-04-19)

### Features

- DAZUIC-2978 - integrate closer and stepper into QdModalFullscreenContainerComponent ([5096403](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5096403f4549cd8fb3b01684b159bbc5d463d8ba))

### Bug Fixes

- currency and date display in table ([badf530](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/badf530066a865c4a7915f3599969a0a28cbaf0c))

## [15.14.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.13.4&sourceBranch=refs%2Ftags%2Fv15.14.0) (2024-04-18)

### Features

- DAZUIC-2930 - shell right with notifications ([cbae0c7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cbae0c782b6754d1e43c17aaf0d2c789ff14c660))

### [15.13.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.13.3&sourceBranch=refs%2Ftags%2Fv15.13.4) (2024-04-18)

### Bug Fixes

- DAZUIC-2863 - active option for radio buttons ([4298b1a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4298b1a13381e30ee5a81301c3be7e231807695b))
- DAZUIC-2863 - active options for checkboxes ([d114719](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d11471945c002178660a13286ebf281eba22c15a))
- DAZUIC-2863 - checkbox chips: add option to disable one chip ([6c23445](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6c23445b09fc4aaed838af9a632aa92a49d7c820))
- DAZUIC-2863 - pincode component: change input type to password when codeHidden ([edcc1c6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/edcc1c6be474f900254a017577de64c7b8e729c5))
- DAZUIC-2863 - set checkboxes height to min-height to not hide hint ([e1258c2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e1258c2c3590c59e2a4e5296c8d40dd4ccf7e8eb))
- DAZUIC-2863 - show validation errors for checkbox-chips component ([bcbccc2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bcbccc202746de28a6e4a28730bd1efb22849c34))

### [15.13.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.13.2&sourceBranch=refs%2Ftags%2Fv15.13.3) (2024-04-18)

### Bug Fixes

- DAZUIC-2827 - use readonly component for all forms ([48d83e2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/48d83e286c3c3dd26f887f174a8dc644fef2b556))

### [15.13.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.13.1&sourceBranch=refs%2Ftags%2Fv15.13.2) (2024-04-18)

### Bug Fixes

- width of form type container within the shell ([77022dc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/77022dca3937f8ff7bb8a2810e3212795123f4fd))

### [15.13.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.13.0&sourceBranch=refs%2Ftags%2Fv15.13.1) (2024-04-17)

### Bug Fixes

- Connector Table Filter directive does not work if filter is not preselected ([cac66dd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cac66ddb012451575496ba7747a8a3ad9b879607))

## [15.13.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.12.0&sourceBranch=refs%2Ftags%2Fv15.13.0) (2024-04-17)

### Features

- DAZUIC-2980 - file collector downloadFilesWithHttpClient flag ([b1087c2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b1087c2bdd920c0920000f829466462d2d1575e2))

### Bug Fixes

- filter - connect with router fixed when already navigated ([7941ce8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7941ce8f62618fdb3f80e2aa2de4f0f27ad6c3ea))

## [15.12.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.11.0&sourceBranch=refs%2Ftags%2Fv15.12.0) (2024-04-17)

### Features

- export QdUploadError and QdUploadErrorType ([22e9e88](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/22e9e88bf53ad3bed4b9a688bb10d91967e48b3a))
- file collector - hide allowed files description in readonly mode ([21531b0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/21531b0e41bdb1e34f6e59f46f100de3d9614fdd))
- file collector - log error if readonly is set and add new is present ([8c633fc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8c633fcf21505ba83759c0852bd85a5d410d3d4a))

## [15.11.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.10.1&sourceBranch=refs%2Ftags%2Fv15.11.0) (2024-04-17)

### Features

- filter - methods to get current values (postBody, queryString, filterUrlParameterString) ([91a209a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/91a209a2755b0a49b435e1e4ba6d63dee56a82c4))

### Documentation

- filter - document filter component query methods ([0c54d39](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0c54d393cbd95658cd75adf18e2e9c531e9df1d9))

### [15.10.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.10.0&sourceBranch=refs%2Ftags%2Fv15.10.1) (2024-04-17)

### Bug Fixes

- DAZUIC-2972 - qd-datepicker: handle form control changes ([e251548](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e251548e777ca91b77ce70890564f047e4088693))

### Documentation

- fix shell pams environment example ([f733bc6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f733bc6f2f3472f0972f366027b207e46780ddc9))

## [15.10.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.9.1&sourceBranch=refs%2Ftags%2Fv15.10.0) (2024-04-16)

### Features

- DAZUIC-2913 - Design: Align QdContainer with QdSection ([5690125](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/569012553e925ac7347979df26b7ac55573597d1))

### [15.9.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.8.1&sourceBranch=refs%2Ftags%2Fv15.9.1) (2024-04-15)

### [15.8.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.8.0&sourceBranch=refs%2Ftags%2Fv15.8.1) (2024-04-14)

### Bug Fixes

- ModalService Dialog usage ([8d636bf](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8d636bfc7a82efeb542dae6d02fc53158311fb56))

## [15.8.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.7.0&sourceBranch=refs%2Ftags%2Fv15.8.0) (2024-04-12)

### Features

- DAZUIC-2971 - qd-datepicker: disabled dates validation ([496c259](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/496c259c299453c21cfff7d01b4e057cf021ce95))

## [15.7.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.6.0&sourceBranch=refs%2Ftags%2Fv15.7.0) (2024-04-12)

### Features

- DAZUIC-2926 - Implemented QdPageStepper ([782a064](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/782a064c26fd632aebe0a5aa9d19f6765175b2d8))

### Bug Fixes

- lint return types - exclude cypress tests ([9c0a4c0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9c0a4c02c9420957f5444f004718ca63375227db))

### Documentation

- DAZUIC-2926 - Add JsDocs ([73324d1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/73324d187cb1639b586821d79b56607a8189de93))

## [15.6.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.5.0&sourceBranch=refs%2Ftags%2Fv15.6.0) (2024-04-10)

### Features

- DAZUIC-2914 - Container ready for RDW inside the shell ([84394d6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/84394d65d11b93c232cde6c6bb1f94e050c36fdb))

## [15.5.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.4.3&sourceBranch=refs%2Ftags%2Fv15.5.0) (2024-04-10)

### Features

- DAZUIC-2966 - qd-shell: handle asynchronous config changes ([a37e20c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a37e20cec0797ba5ac6a6161e2491a33988ca8db))

### [15.4.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.4.2&sourceBranch=refs%2Ftags%2Fv15.4.3) (2024-04-09)

### [15.4.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.4.1&sourceBranch=refs%2Ftags%2Fv15.4.2) (2024-04-08)

### Bug Fixes

- table status mobile positioning fixed ([1bb54d9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1bb54d9b47081cf131dbef26cfff0d025ef91fa6))
- table text mobile positioning fixed ([f3941af](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f3941aff6b41e8f083403ebd80891fde497c721d))

### [15.4.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.4.0&sourceBranch=refs%2Ftags%2Fv15.4.1) (2024-03-28)

### Bug Fixes

- console error in story book resolver example ([e4a46da](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e4a46dac551396d5bb6194ab042f67d9a40a9289))

## [15.4.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.3.6&sourceBranch=refs%2Ftags%2Fv15.4.0) (2024-03-28)

### Features

- DAZUIC-2940 include table row uid in tree table events ([6690563](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6690563207286c797178b2d4361b36c81d574ac8))

### [15.3.6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.3.5&sourceBranch=refs%2Ftags%2Fv15.3.6) (2024-03-22)

### [15.3.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.3.4&sourceBranch=refs%2Ftags%2Fv15.3.5) (2024-03-22)

### Documentation

- update status in SB ([12ac1ed](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/12ac1ed39a2f9efc76da5ba965d80856a91be285))

### [15.3.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.3.3&sourceBranch=refs%2Ftags%2Fv15.3.4) (2024-03-21)

### Bug Fixes

- DAZUIC-2928 - length for nullish values ([1682b39](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1682b39a947b27efee1fee20f6c2853fb80a7f56))

### [15.3.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.3.2&sourceBranch=refs%2Ftags%2Fv15.3.3) (2024-03-20)

### Bug Fixes

- pre-commit-hook ([8b5c268](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8b5c2682641f4edbef7bba18743a0b207d2c2ff1))

### [15.3.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.3.1&sourceBranch=refs%2Ftags%2Fv15.3.2) (2024-03-20)

### [15.3.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.3.0&sourceBranch=refs%2Ftags%2Fv15.3.1) (2024-03-20)

## [15.3.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.2.2&sourceBranch=refs%2Ftags%2Fv15.3.0) (2024-03-20)

### Features

- DAZUIC-2872 - adjustments for integrations ([24a47d5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/24a47d56ae5c632d2cd65fe74566cafb65b13af2))

### [15.2.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.2.1&sourceBranch=refs%2Ftags%2Fv15.2.2) (2024-03-20)

### Bug Fixes

- DAZUIC-2919 - translate navigation links ([a29df48](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a29df484e0938e9ac81f0990b12a59b47c5ff158))

### [15.2.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.2.0&sourceBranch=refs%2Ftags%2Fv15.2.1) (2024-03-19)

### Documentation

- Code Conventions - Data Handling in Angular Templates ([1dbee40](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1dbee40ac13a6dca952e5514713029e7b5fcba95))

## [15.2.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.1.0&sourceBranch=refs%2Ftags%2Fv15.2.0) (2024-03-19)

### [14.42.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.3&sourceBranch=refs%2Ftags%2Fv14.42.4) (2024-03-15)

### Bug Fixes

- DAZUIC-2911 - display of account icon menu in header widget fixed; prevent exceeding of borders for draggable header banner ([24d05a3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/24d05a3b6c9a38d8d380a35c731be32bb5d0bf3f))

### [14.42.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.2&sourceBranch=refs%2Ftags%2Fv14.42.3) (2024-03-15)

### Bug Fixes

- DAZUIC-2910 - height of layout inside shell fixed to prevent scrollbars ([3276944](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/32769442470ac6f2a008437d4c357abfe04fe263))

### [14.42.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.1&sourceBranch=refs%2Ftags%2Fv14.42.2) (2024-03-14)

### Bug Fixes

- DAZUIC-2909 - close table action menu if another is opened ([1ad058f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1ad058fa163a29408f743509626cc4f634639a29))

### [14.42.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.0&sourceBranch=refs%2Ftags%2Fv14.42.1) (2024-03-13)

## [13.52.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.7.0&sourceBranch=refs%2Ftags%2Fv13.52.0) (2023-11-23)

### Features

- DAZUIC-2613 - allow multiline notification messages ([b024143](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b0241431dcbacf2301b79da30554a14a5e253417))

## [13.51.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.3.0&sourceBranch=refs%2Ftags%2Fv13.51.0) (2023-11-21)

### Features

- DAZUIC-2608 - add "uuid" as dependency in published package.json ([e983042](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e9830423cdd3e38fc083ceeabe607e67510776bf))

### [13.50.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.50.4&sourceBranch=refs%2Ftags%2Fv13.50.5) (2023-11-15)

### [13.50.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.1.1&sourceBranch=refs%2Ftags%2Fv13.50.4) (2023-11-14)

### Bug Fixes

- DAZUIC-2541 - disable page process header submit button if enableSubmit input is false ([1d80831](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1d808315afb0cfa30c279b4d3f609b8424854643))
- DAZUIC-2602 fix for header widget bug with language list parameter ([6ded629](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6ded629f49b258cda420a4cab0fa567f8b8ecb5b))

## [15.1.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.0&sourceBranch=refs%2Ftags%2Fv15.1.0) (2024-03-19)

### Features

- **toolbar-action:** DAZUIC-2756 - provide generic action ([6c73afc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6c73afce063459f2f007830ef635f9cb83bdb671))

### Bug Fixes

- resolve merge conflicts ([5d7a8f0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5d7a8f0071a64cdd8f0343a1f7fb72e5c8a0c2a9))

### Documentation

- Add Guard Clause for type parsing ([228a112](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/228a112e6cb7f29dea42d00a66f0b6abb99cd728))
- Add Guard Clause for type parsing ([a4b46c2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a4b46c20bc3b7dbb0c5d7ccd266cf03c93fd5450))
- add layout chapter in storybook ([7713889](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7713889bc1ee0d77e69ed8fe6ca63eb61a2400f4))
- DAZUIC-2570 - rename Container Header ([feb0354](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/feb03540c351567219aa857eb4502d443655a25b))

### [14.42.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.3&sourceBranch=refs%2Ftags%2Fv14.42.4) (2024-03-15)

### Bug Fixes

- DAZUIC-2911 - display of account icon menu in header widget fixed; prevent exceeding of borders for draggable header banner ([24d05a3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/24d05a3b6c9a38d8d380a35c731be32bb5d0bf3f))

### [14.42.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.2&sourceBranch=refs%2Ftags%2Fv14.42.3) (2024-03-15)

### Bug Fixes

- DAZUIC-2910 - height of layout inside shell fixed to prevent scrollbars ([3276944](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/32769442470ac6f2a008437d4c357abfe04fe263))

### [14.42.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.1&sourceBranch=refs%2Ftags%2Fv14.42.2) (2024-03-14)

### Bug Fixes

- DAZUIC-2909 - close table action menu if another is opened ([1ad058f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1ad058fa163a29408f743509626cc4f634639a29))

### [14.42.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.42.0&sourceBranch=refs%2Ftags%2Fv14.42.1) (2024-03-13)

## [14.42.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.41.0&sourceBranch=refs%2Ftags%2Fv14.42.0) (2024-03-13)

### Features

- DAZUIC-2906 Anpassung Fiter Textinput Style ([aeffb2f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/aeffb2fad06f898aa7a62aebf364526efafb3cab))

## [14.41.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.40.6&sourceBranch=refs%2Ftags%2Fv14.41.0) (2024-03-13)

### Features

- DAZUIC-2605 Input Erweiterung Step Attribut ([8978ae0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8978ae03c8c2e04e0c84df62b742438a2899a383))
- DAZUIC-2825 - story source link ([76cd480](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/76cd480ccfa50f9c3bf8c1c271787c1f18980a7f))

### Bug Fixes

- DAZUIC-2824 - fix overlapping of cdk overlay in qdPopoverOnClick used by qd-dropdown ([8cd6b92](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8cd6b9222b7740c89a3d1731494da837d16f7cc8))

### [14.40.6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.40.5&sourceBranch=refs%2Ftags%2Fv14.40.6) (2024-03-12)

### Bug Fixes

- DAZUIC-2883 - empty string for empty date or currency cells ([b66e04c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b66e04c6ace1fea2d02579e06343370c16591a2e))

### [14.40.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.40.4&sourceBranch=refs%2Ftags%2Fv14.40.5) (2024-03-12)

### [14.40.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.40.3&sourceBranch=refs%2Ftags%2Fv14.40.4) (2024-03-12)

### Bug Fixes

- DAZUIC-2883 - show "-" for empty values in currency and date content types ([9ec817e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9ec817eeb080030f5e709213c25c9b42181d160c))

### [14.40.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.40.2&sourceBranch=refs%2Ftags%2Fv14.40.3) (2024-03-11)

### Bug Fixes

- Remove adding a chip, if input flield is blurring ([3304d7f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3304d7fd99f9a307156ad6a7189b1292bcb58300))

### [14.40.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.40.1&sourceBranch=refs%2Ftags%2Fv14.40.2) (2024-03-11)

### Bug Fixes

- fix readonlyAction for radio buttons ([0b7c3e5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0b7c3e5e8286f975d1370041ffb7b0731ec43d59))

### [14.40.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.40.0&sourceBranch=refs%2Ftags%2Fv14.40.1) (2024-03-08)

### Bug Fixes

- DAZUIC-2866 - set language from url also for redirects ([cc39fa6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cc39fa674e0bd0f0a86981a554298a3b081b36b6))

## [14.40.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.39.0&sourceBranch=refs%2Ftags%2Fv14.40.0) (2024-03-07)

### Features

- DAZUIC-2839 - Add tableFilter & tableSearch connector (still WIP!) ([5639c31](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5639c3116521bc5d729a9a99fd7d6d6d24f6692f))

## [14.39.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.38.2&sourceBranch=refs%2Ftags%2Fv14.39.0) (2024-03-07)

### Features

- DAZUIC-2813 - Add tag info to ContactCard ([3408bee](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3408bee232357d34b72d47f7dd53a2e37b9e17e5))

### [14.38.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.38.1&sourceBranch=refs%2Ftags%2Fv14.38.2) (2024-03-06)

### Bug Fixes

- DAZUIC-2866 - delay to fix getting of language from url ([2e08773](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2e08773d67deca8dfa7d6962894f680d0af61fcb))

### [14.38.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.38.0&sourceBranch=refs%2Ftags%2Fv14.38.1) (2024-03-05)

### Bug Fixes

- DAZUIC-2866 - don't block while waiting for language from url ([57f30b1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/57f30b119904c70761ad431e7182d2fe6cde6f09))

## [14.38.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.37.1&sourceBranch=refs%2Ftags%2Fv14.38.0) (2024-03-05)

### Features

- DAZUIC-2867 Zusammenfuhrung Dialog und PageDialog ([07de192](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/07de19232801b3ed3a6dfb7ed86dedda4e1e912b))

### Bug Fixes

- Remove useless form configs ([c1ef9f8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c1ef9f8bed9ff0810598c185146f238aef12bdc5))

## [15.0.0-beta.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.37.1&sourceBranch=refs%2Ftags%2Fv15.0.0-beta.2) (2024-03-06)

### Features

- **toolbar-action:** DAZUIC-2756 - provide generic action ([6c73afc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6c73afce063459f2f007830ef635f9cb83bdb671))

### Documentation

- Add Guard Clause for type parsing ([228a112](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/228a112e6cb7f29dea42d00a66f0b6abb99cd728))

## [15.0.0-beta.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv15.0.0-beta.0&sourceBranch=refs%2Ftags%2Fv15.0.0-beta.1) (2023-12-12)

### Documentation

- Add Guard Clause for type parsing ([bd1da6c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bd1da6c457bc571027ce4e1a5d8b40d27508219e))

## [15.0.0-beta.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.13.5&sourceBranch=refs%2Ftags%2Fv15.0.0-beta.0) (2023-12-08)

### [14.37.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.37.0&sourceBranch=refs%2Ftags%2Fv14.37.1) (2024-03-01)

## [14.37.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.36.0&sourceBranch=refs%2Ftags%2Fv14.37.0) (2024-02-29)

### Features

- DAZUIC-2866 - read lang parameter from url (e.g. for redirects from ePortal) ([7ef0ff0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7ef0ff0c75bd17c0031467a056644c738e50a7eb))

## [14.36.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.35.1&sourceBranch=refs%2Ftags%2Fv14.36.0) (2024-02-27)

### Features

- DAZUIC-2866 - read lang parameter from url (e.g. for redirects from ePortal) ([1185b30](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1185b3050777bb41576b6c56bf26edeb8a3166b0))

### [14.35.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.35.0&sourceBranch=refs%2Ftags%2Fv14.35.1) (2024-02-27)

### Bug Fixes

- emit filter outputs initially with preselection or emitOutputsInitially config (also if router is not present) ([d0baadb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d0baadbec93ee492be6717063f441c6af6d69ed3))

## [14.35.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.34.1&sourceBranch=refs%2Ftags%2Fv14.35.0) (2024-02-22)

### Features

- DAZUIC-2802 Removed Tooltip and changed items width ([f5622af](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f5622afe7b5f85703d460f9d6f450bc1bea64b1b))
- DAZUIC-2860 - qd-stepper currentIndex output ([a904473](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a90447359121e3fa21b97d8f38fd6e5e78c706fc))

### [14.34.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.34.0&sourceBranch=refs%2Ftags%2Fv14.34.1) (2024-02-22)

### Bug Fixes

- DAZUIC-2858 - resolver service refresh method pageIndex param handling fixed for table component refreshPage method ([8f20f21](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8f20f21ff3c1dd8cd95e6ae3a62fc54543c34c0a))

## [14.34.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.33.0&sourceBranch=refs%2Ftags%2Fv14.34.0) (2024-02-22)

### Features

- adjust dialog margins and paddings ([fdde3c7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fdde3c7e7f3345a09699d03a8823b029fe9395a6))
- container toolbar - smaller header, margin and padding adaptions ([912d46a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/912d46a55ddd7ca9f547e997d120ef2a7a1ca95f))
- DAZUIC-2191 - always use dot as separator for file size in file collector ([23462ef](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/23462ef5ade3311dbcc4454e002773b6f49954dc))
- DAZUIC-2779 - file collector redesign ([ceee306](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ceee3068d878933b602a3063d889b5bb1f3eaffc))

### Bug Fixes

- navigation with shell and legacy layout ([79f90b0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/79f90b019b613de7b2a87c6dbfc29e057ace1c2a))

### Documentation

- Add Guard Clause for type parsing ([bd1da6c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bd1da6c457bc571027ce4e1a5d8b40d27508219e))

## [15.0.0-beta.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.13.5&sourceBranch=refs%2Ftags%2Fv15.0.0-beta.0) (2023-12-08)

### [14.13.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.13.4&sourceBranch=refs%2Ftags%2Fv14.13.5) (2023-12-07)

### Documentation

- DAZUIC-2654 - add missing disabled states for form elements ([8976514](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/897651460fb6c4f00868977af7bbec4ca3c32440))

### [14.13.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.13.3&sourceBranch=refs%2Ftags%2Fv14.13.4) (2023-12-07)

### Bug Fixes

- fix import in mock component ([3d79766](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3d79766221607e034316de5b1adcc364c09aadcc))

### [14.13.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.13.2&sourceBranch=refs%2Ftags%2Fv14.13.3) (2023-12-07)

### Bug Fixes

- adjust mock components to match current component structure ([44cfbc2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/44cfbc245d6ddea2a82b3a1dbd7e2a888ff74304))

### [14.13.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.13.1&sourceBranch=refs%2Ftags%2Fv14.13.2) (2023-12-07)

### Documentation

- DAZUIC-2654 - add some docs for forms ([633b7d7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/633b7d77ff780de1880704eb67bddab01c509ada))

### [14.13.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.13.0&sourceBranch=refs%2Ftags%2Fv14.13.1) (2023-12-06)

### Bug Fixes

- DAZUIC-2654 - Activate disable states via reactive forms ([f6fee90](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f6fee90af55fc96a961d7cd93fdd7dd55274b11f))

## [14.13.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.12.0&sourceBranch=refs%2Ftags%2Fv14.13.0) (2023-12-05)

### Features

- DAZUIC-2533 - nestedRows in tree table data ([78bd88d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/78bd88d1d8920bd9c2bf2569e5629450d067027b))
- DAZUIC-2578 - Add Button Anpassung ([1ff6740](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1ff67407e4cb98d601346a37ed22438c9a6f370a))

## [14.12.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.11.0&sourceBranch=refs%2Ftags%2Fv14.12.0) (2023-11-30)

### Features

- QdTree docs fix ([eee3803](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/eee3803ebed3a3359a4353c36f9beb1a34ada085))

## [14.11.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.10.0&sourceBranch=refs%2Ftags%2Fv14.11.0) (2023-11-30)

### Features

- DAZUIC-2624 - datepicker migration in filter ([31bab6c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/31bab6c7f1a3e729ea480f4ce52a3ee6e66a4690))

## [14.10.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.9.0&sourceBranch=refs%2Ftags%2Fv14.10.0) (2023-11-29)

### Features

- DAZUIC-2577 - separate concerns with QdTable and QdTree ([ea5c7a2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ea5c7a234b8345eb95970cfc4fd3824446b8910d))

## [14.9.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.8.0&sourceBranch=refs%2Ftags%2Fv14.9.0) (2023-11-29)

### Features

- DAZUIC-2575 - Erweiterung Datepicker mit Jahres/Monatspicker ([f5504c1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f5504c12704f395a61423468b524c545a1bec33c))

## [14.8.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.7.0&sourceBranch=refs%2Ftags%2Fv14.8.0) (2023-11-23)

### Features

- DAZUIC-2522 - New global config key: QdNotificationsHttpInterceptorService can be disabled ([9546160](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/95461605684da949f168686b72f0fa90c75b1640))

## [14.7.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.6.1&sourceBranch=refs%2Ftags%2Fv14.7.0) (2023-11-23)

### Features

- DAZUIC-2613 - allow multiline notification messages ([7e221c2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7e221c2342e687627be8dcca3c8b8e693d2d9780))

### Documentation

- DAZUIC-2609 display inherited properties of extended interfaces in config modal ([a5ae746](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a5ae746e7a15138d9d88662add9894c745b4a7c0))

### [14.6.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.6.0&sourceBranch=refs%2Ftags%2Fv14.6.1) (2023-11-23)

### Bug Fixes

- DAZUIC-2576 - bugfix for date parser ([3e9035f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3e9035f5d449213e5ea2c95bf24d3b6a38e46da6))

## [14.6.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.5.0&sourceBranch=refs%2Ftags%2Fv14.6.0) (2023-11-23)

### Features

- DAZUIC-2524 - new showConfirmCheckbox input property in QdModalConfirmComponent alows to hide confirm checkbox ([5bebc6b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5bebc6bfae7d819d6bc151eb2ab081fd96d1fd0b))

### Documentation

- DAZUIC-2524 - documentation for QdModalConfirmComponent ([bc7fc37](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bc7fc3720a757b11eb8882459979768ef52e25fa))

## [14.5.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.4.1&sourceBranch=refs%2Ftags%2Fv14.5.0) (2023-11-22)

### Features

- DAZUIC-2525 - add confirmProcess to QdModalConfirmComponent afterClose result, typify modal afterClose results ([fec571e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fec571e4b01c077ea47954e2106a4c18edf1d546))

### Documentation

- DAZUIC-2525 - documentation for QdModalConfirmComponent ([ec55080](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ec5508037d538a630f9a59b827e7f23008652b96))

### [14.4.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.4.0&sourceBranch=refs%2Ftags%2Fv14.4.1) (2023-11-22)

### Bug Fixes

- DAZUIC-2576 - calender table styles, date selection, activate validation ([d9848e7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d9848e73401ed7af6a18ecb572313cfaca3c09e6))

## [14.4.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.3.0&sourceBranch=refs%2Ftags%2Fv14.4.0) (2023-11-21)

### Features

- DAZUIC-2574 - Add Date Adapter ([e5fb7a4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e5fb7a41e67af34425ff0d613fc9a7c85980852d))
- DAZUIC-2574 - Add full functionality to the datepicker ([c3b8b0c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c3b8b0c057f358da6b97b8b219112340c54b3a45))
- DAZUIC-2574 - Add full functionality to the datepicker ([84a9994](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/84a999471c5622a4147f996478cbf2826d7e7df8))
- DAZUIC-2574 - Conversion of calendar component to string I/O ([7bd8b40](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7bd8b4015534673b76f354559e8a974c7c31c5cf))

## [14.3.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.2.1&sourceBranch=refs%2Ftags%2Fv14.3.0) (2023-11-21)

### Features

- DAZUIC-2608 - add "uuid" and "moment" as dependency in published package.json ([8f1db6b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8f1db6bb3793dcf015ee49daccdafd452bb4322b))

### [14.2.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.2.0&sourceBranch=refs%2Ftags%2Fv14.2.1) (2023-11-21)

### Bug Fixes

- DAZUIC-2614 - table inline menu rerendering loop fix ([10110c7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/10110c720fa8972ccfeb9d4eae812bbd48db51a6))

## [14.2.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.1.1&sourceBranch=refs%2Ftags%2Fv14.2.0) (2023-11-16)

### Features

- DAZUIC-2574 - implementation of custom calendar ([2e0804e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2e0804e4c55766ff2ab356b1099c9dc39d3f31be))

### Bug Fixes

- DAZUIC-2602 fix for header widget bug with language list parameter ([13a0e84](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/13a0e84fc0bec09cd1492c1833224f33619b2c79))

### [14.1.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.1.0&sourceBranch=refs%2Ftags%2Fv14.1.1) (2023-11-06)

## [14.1.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.0.3&sourceBranch=refs%2Ftags%2Fv14.1.0) (2023-10-30)

### Features

- DAZUIC-2540 - first and last pagination buttons ([fb182a6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fb182a6527e854c577612c75c7cc693592dec7d9))

### [14.0.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.0.2&sourceBranch=refs%2Ftags%2Fv14.0.3) (2023-10-25)

### Documentation

- update documention for stepper ([9a2cfcd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9a2cfcd8a096bcca402c05d0c1c0fcd63ac8da74))

### [14.0.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.0.1&sourceBranch=refs%2Ftags%2Fv14.0.2) (2023-10-25)

### Bug Fixes

- DAZUIC-2541 - disable page process header submit button if enableSubmit input is false ([99c3d58](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/99c3d581ad81754a04a2ecc459ede8064687d7a1))
- DAZUIC-2563 - docu config modal validation and rawtypes fixed ([48ac6b4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/48ac6b42dcc441b1b870d8a133989f98cd89d072))

### [14.0.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.0.0&sourceBranch=refs%2Ftags%2Fv14.0.1) (2023-10-23)

## [14.0.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv14.0.0-beta.0&sourceBranch=refs%2Ftags%2Fv14.0.0) (2023-10-20)

## [14.0.0-beta.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.50.0&sourceBranch=refs%2Ftags%2Fv14.0.0-beta.0) (2023-10-18)

### Features

- DAZUIC-2460 configuration modal for Qd types ([c228796](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c228796485d80814984db6a957ae3204119bf18d))
- DAZUIC-2492 - add parser for component overview, add JSDocs for each component ([dbf9b65](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/dbf9b6502c3c3ff02780fc2fda894cf095da8b1c))
- DAZUIC-2505 - improve determination of controls for type options in config modal; save maximized state in session storage ([a41c133](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a41c1337edfc01ea279e8a843e9f335e6616e5df))
- **docs:** consolidate form stories ([dbd8ed4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/dbd8ed4e2ce6e0fd7df8f9d4d98b285f792a99da))
- **input-stories:** remove wrapper component ([d19b379](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d19b3794dc7f0aaca19da3ba6ff08a31529f9561))

### Bug Fixes

- array uuids fixed in docu config modal ([0c7684b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0c7684be46208299627c50e22d0964a3887300a1))
- DAZUIC-1595 - table stories to csf 3 format; fix asset path mapping ([b39228f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b39228f1b7203e615360a6f7cd10b2aca9e1e7fc))
- DAZUIC-1595 - table stories to csf 3 format; rename #root selector to #storybook-root ([e2e189d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e2e189da12e562ca9478e24d04626c2423da20fb))
- DAZUIC-2505 - change types to interfaces so that properties are parsed by compodoc ([7b31163](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/7b3116327e433e3405a3846053e48139c051c096))
- DAZUIC-2505 - fixes complex raw types in compodoc documentation.json ([3410f40](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3410f4075fccb93a8f1af7ae9b5ff55dccfb8e77))
- DAZUIC-2505 display config type detail modal for generic types ([d9eb5be](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d9eb5be553a9f2f4ed0c6f0828e2193cd007c3f2))
- e2e tests paths ([622d4aa](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/622d4aa0532063ad305c689f7c58cc4997a50392))
- e2e tests paths ([66f7e3d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/66f7e3d4a50dd579202b6eab50d37d5cc7e5a10a))
- e2e tests paths ([dcd71d6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/dcd71d6c85740a34e67019093a5314bb1c6f2eb3))

### Documentation

- add code samples ([6ac5e98](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6ac5e98683ffb4d3bfaac791262044639a2be186))
- add example @ return value types ([97c2fd2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/97c2fd2d134904db0e34a2888e67f846db9981c7))
- DAZUIC-2459 - add docsJson Parser ([44fde8a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/44fde8a43886294056488b7d654e5bd2d11cfe40))
- DAZUIC-2490 - add input descriptions ([5081235](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/50812353e7a4ce8738863d6ddaf51296d5d37922))
- DAZUIC-2491 - add output descriptions ([1f0025a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1f0025a98e66a10581e1558484ac94303986df7b))
- DAZUIC-2491 - fix code review comments ([e946c76](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e946c7651d6236ae89cebfb49d1e11fb26b79a79))
- DAZUIC-2492 - resolve code review comments ([68e5bed](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/68e5beddfbab2d09d71e5a8e2457cc786a383454))
- hide unused outputs input fields ([c8c1062](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c8c1062157b2f439d2383aaf361b077fcf4a1bcf))
- Merge with Components JSDocs ([148f3d5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/148f3d5f9af36f6fccff8f09dfae74e74a0a78d9))
- Merge with Type modal ([fea3452](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fea345283fa493eaf8b186c63cd8cf3ae0ebfa80))

## [13.52.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.51.0&sourceBranch=refs%2Ftags%2Fv13.52.0) (2023-11-23)

### Features

- DAZUIC-2613 - allow multiline notification messages ([b024143](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b0241431dcbacf2301b79da30554a14a5e253417))

## [13.51.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.50.5&sourceBranch=refs%2Ftags%2Fv13.51.0) (2023-11-21)

### Features

- DAZUIC-2608 - add "uuid" as dependency in published package.json ([e983042](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e9830423cdd3e38fc083ceeabe607e67510776bf))

### [13.50.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.50.4&sourceBranch=refs%2Ftags%2Fv13.50.5) (2023-11-15)

### [13.50.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.50.0&sourceBranch=refs%2Ftags%2Fv13.50.4) (2023-11-14)

### Bug Fixes

- DAZUIC-2541 - disable page process header submit button if enableSubmit input is false ([1d80831](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1d808315afb0cfa30c279b4d3f609b8424854643))
- DAZUIC-2602 fix for header widget bug with language list parameter ([6ded629](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6ded629f49b258cda420a4cab0fa567f8b8ecb5b))

## [13.50.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.49.4&sourceBranch=refs%2Ftags%2Fv13.50.0) (2023-10-16)

### Features

- DAZUIC-2518 - hide save button in stepper when (stepSave) output is not set on the current step ([5f6dc65](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5f6dc65fd8e466a7ec8253394e7c000d2a5ff5f3))

### [13.49.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.49.3&sourceBranch=refs%2Ftags%2Fv13.49.4) (2023-10-09)

### Documentation

- DAZUIC-2469 - validator docu adjusted ([9d1c1e5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9d1c1e5a5712a898337ce2a01ed7eca92b73dc58))

### [13.49.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.49.2&sourceBranch=refs%2Ftags%2Fv13.49.3) (2023-10-09)

### Bug Fixes

- DAZUIC-2500 - dropdown closing behaviour fixed (click on another dropdown closes the dropdown now) ([d71b955](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d71b9552c12f60bb32fba71cdcc0097c7f9830d5))

### [13.49.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.49.1&sourceBranch=refs%2Ftags%2Fv13.49.2) (2023-10-06)

### Bug Fixes

- DAZUIC-2501 - fix italian translation for maxlength validation ([b1f823d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b1f823d02656e20c32b923f4b92283688accce09))
- DAZUIC-2501 - fix italian translation for minlength validation ([5b1e189](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5b1e18911feed562b4208c4b63d72c91b568d783))

### [13.49.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.49.0&sourceBranch=refs%2Ftags%2Fv13.49.1) (2023-10-03)

### Bug Fixes

- DAZUIC-2497 - Multi Input: Add chip on blur ([2ac4d25](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2ac4d25cec785ff0ed499241215a1fd9fc3f9890))

## [13.49.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.48.3&sourceBranch=refs%2Ftags%2Fv13.49.0) (2023-09-29)

### Features

- DAZUIC-2498 new icons "emailIn" and "emailOut" ([3b3c317](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3b3c317077724ac6978b3a342ff9f1be069746de))

### [13.48.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.48.2&sourceBranch=refs%2Ftags%2Fv13.48.3) (2023-09-08)

### Bug Fixes

- DAZUIC-2376 - fix reset button disabled behaviour to be fully reactive ([3439e26](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3439e2664c8341f0ce7bed83ce956e6632e33c4c))
- filter out empty items ([4d79de9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4d79de94b770ad9e62bde1cacfd6bb39a412b332))

### [13.48.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.48.1&sourceBranch=refs%2Ftags%2Fv13.48.2) (2023-09-05)

### Bug Fixes

- DAZUIC-2467 - Export Filter Types ([0836bd2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0836bd26b8076ed2148754575e6f747f42d60a0b))

### [13.48.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.48.0&sourceBranch=refs%2Ftags%2Fv13.48.1) (2023-09-04)

### Bug Fixes

- DAZUIC-2445 - Fix Tree Table ([931175f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/931175ffcfc736d54f450d2ff15b85cad5f3f0c8))
- DAZUIC-2445 - Fix Tree Table ([97d3c48](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/97d3c4887551dab830d71ffae99cb95df4c41468))

## [13.48.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.47.2&sourceBranch=refs%2Ftags%2Fv13.48.0) (2023-09-01)

### Features

- DAZUC-2414 - Remove the placeholder, X icon logic ([4e3d73d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4e3d73d6737e7d3f850292bbd95a0a75f6f63568))

### [13.47.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.47.1&sourceBranch=refs%2Ftags%2Fv13.47.2) (2023-08-21)

### Bug Fixes

- DAZUIC-2376 - Remove the second emit of EventEmitter by click reset button. ([cf64284](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cf6428475083358eadb6662f444ae28c7be9b3ea))

### [13.47.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.47.0&sourceBranch=refs%2Ftags%2Fv13.47.1) (2023-08-17)

### Bug Fixes

- DICS2R2 - fix some small issues for QdTable Date content type ([d08f0e6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d08f0e6bdfd01185cb306d67a692e9a3acfc3b0b))

## [13.47.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.46.2&sourceBranch=refs%2Ftags%2Fv13.47.0) (2023-08-16)

### Features

- DICS2R2-2243 enable date cells with formatting in QdTable ([d9bab19](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d9bab190e89194ca5be7d922a62a3e0c45c1bfa7))

### [13.46.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.46.1&sourceBranch=refs%2Ftags%2Fv13.46.2) (2023-08-16)

### Bug Fixes

- DAZUIC-2397 - change scroll behavior in-click-popover ([c075ca1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c075ca1379f396acff4554a538fcfe22e192e6ae))
- DAZUIC-2397 - remove useless assertion in unit tests ([fd1897d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fd1897dafae8a951c5b69a118b52cc21110fd730))

### [13.46.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.46.0&sourceBranch=refs%2Ftags%2Fv13.46.1) (2023-08-15)

### Bug Fixes

- DMBA-5259 mark input and textarea as invalid if max length is exceeded directly after typing and not only after blur ([cf96405](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cf96405a347d64f8f10ddb15661bcc6366b0e648))

## [13.46.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.45.1&sourceBranch=refs%2Ftags%2Fv13.46.0) (2023-08-15)

### Features

- table content type chip - chip level can be defined by label with levelMapping option ([d22a5e1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d22a5e19c810ba5540c3e659382c7ee3fc85747b))

### [13.45.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.45.0&sourceBranch=refs%2Ftags%2Fv13.45.1) (2023-08-08)

### Bug Fixes

- DAZUIC-2344 - fix "undefined" output in contact card with empty countryCode ([4d394a3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4d394a33e66d170bc26da0c2163f7de174ec5ec8))

## [13.45.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.44.0&sourceBranch=refs%2Ftags%2Fv13.45.0) (2023-08-02)

### Features

- DAZUIC-2373 - Use new readonly action component for Input, Checkboxes & Radiobuttons ([abb0412](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/abb04124314850e78f0c39053dd4d91197c60d2a))

## [13.44.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.43.1&sourceBranch=refs%2Ftags%2Fv13.44.0) (2023-07-24)

### Features

- DAZWVS-8017 - consider notification uuid to be able to remove specific notification ([b4d1c7f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b4d1c7fd0839ead5c97a5c451f1208dcda48624b))
- DAZWVS-8017 - QD menu button min width and max width with truncated text with tooltip ([23ce1cb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/23ce1cbc784d4d2e7b8e68869ef661e43a6522bb))

### [13.43.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.43.0&sourceBranch=refs%2Ftags%2Fv13.43.1) (2023-07-24)

### Bug Fixes

- DAZUIC-2359 - QdButton - no underline when using anchor tag ([b5f0cd4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b5f0cd48e4d5ec1424592624cb070113fed6e228))

## [13.43.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.42.0&sourceBranch=refs%2Ftags%2Fv13.43.0) (2023-07-24)

### Features

- DAZUIC-2359 - QdButton - Button component and directive can be bound to a-tag ([fe0de5e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fe0de5e3b2033d7dcc07ba70c87f2fc8bc9edd4b))

## [13.42.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.41.0&sourceBranch=refs%2Ftags%2Fv13.42.0) (2023-07-21)

### Features

- DAZUIC-2358 - QdTable - Add build-in-translation-feature for content types 'chip' & 'text' ([390ab5c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/390ab5cd4940b576cb189a2c1ae383e8df8cf478))

## [13.41.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.40.4&sourceBranch=refs%2Ftags%2Fv13.41.0) (2023-07-20)

### Features

- DICS2R2-2241 enable setting text-transform on text cells in QdTable ([762f4c2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/762f4c2e87b6e2d9e55c6aaaf329a27a15b8ee36))

### [13.40.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.40.3&sourceBranch=refs%2Ftags%2Fv13.40.4) (2023-07-19)

### Bug Fixes

- DAZUIC-2357 handle step input changes in stepper component ([f654a09](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f654a0966c2f6beae524138374c34e13eaf5c821))

### [13.40.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.40.2&sourceBranch=refs%2Ftags%2Fv13.40.3) (2023-07-12)

### Bug Fixes

- DAZUIC-2353 - contact card height issues ([00376a1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/00376a187280894436057f1cb6581bb317fa05b7))

### [13.40.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.40.1&sourceBranch=refs%2Ftags%2Fv13.40.2) (2023-07-12)

### Bug Fixes

- add export for QdContactData in public API ([4574594](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/45745944649650897673861f7e24a35eefeea886))
- add further exports to public API ([46068b6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/46068b6986e458f93dce5057eb617d0cede4bed2))

### [13.40.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.40.0&sourceBranch=refs%2Ftags%2Fv13.40.1) (2023-07-11)

### Bug Fixes

- DAZWVS-7861 add type to isHidden button config property ([35eaece](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/35eaece999e4c64f856bdb6b6adb318832e6c60b))

## [13.40.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.39.0&sourceBranch=refs%2Ftags%2Fv13.40.0) (2023-07-10)

### Features

- DAZUIC-2340 enforce header or toolbar in qd-container (error log) ([f262def](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f262defe95552983544d6d6934c1842026630ae6))

### Bug Fixes

- DAZUIC-2320 fix loop in table wrapping service if main column is not filling column ([1bda262](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1bda262fde407f139678cfaca135cb267c6dd385))

## [13.39.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.38.0&sourceBranch=refs%2Ftags%2Fv13.39.0) (2023-07-07)

### Features

- DMBA-5521 - make c/o optional ([86a770c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/86a770cc97d8bff88ed300b0e8ec8337b2ac3dde))

## [13.38.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.37.0&sourceBranch=refs%2Ftags%2Fv13.38.0) (2023-06-30)

### Features

- DAZUIC-2339 change qd columns full width breakpoint threshold to sm (600px) ([e4ce238](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e4ce23878b2c6a9ce8d89a744cb557b4a2139f88))

## [13.37.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.36.0&sourceBranch=refs%2Ftags%2Fv13.37.0) (2023-06-29)

### Features

- DAZUIC-2338 - data-test-ids for qd-table and its elements ([c5a55d3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c5a55d3eafcdba8c2b852d371e1e762a67914d86))

## [13.36.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.35.0&sourceBranch=refs%2Ftags%2Fv13.36.0) (2023-06-19)

### Features

- DAZUIC-2325 - Add hidden property for QdMenuButton ([97d12a3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/97d12a3dc4e0a33a12eeddabf4602df458c8649f))
- DMBA-5336 - add page index data resolver parameter to table refresh method ([cf309ba](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/cf309bab32e83b358f8311756db85c10283d8b5b))

### Bug Fixes

- DAZUIC-2325 - fix minor styling bug in QdMenuButton ([59d68bd](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/59d68bd9743b014e17caa7079e9a958e96364775))
- sonar issues in QdFormControl and QdFormBuilder ([73ea574](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/73ea574461fa7d27e229de9bb79d7550b7e42fd7))

## [13.35.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.34.0&sourceBranch=refs%2Ftags%2Fv13.35.0) (2023-06-19)

### Features

- DAZUIC-2325 - Labels are translated within the QdMenuButton component ([1d732be](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1d732be3167f583b5a6a307ad7863042d46f58e8))

## [13.34.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.33.0&sourceBranch=refs%2Ftags%2Fv13.34.0) (2023-06-16)

### Features

- DAZUIC-1005 - input/textarea character counter with max length validator ([3fea319](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3fea319c60c38905b8f958e2ed00461be196b069))

## [13.33.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.32.0&sourceBranch=refs%2Ftags%2Fv13.33.0) (2023-06-15)

### Features

- DAZUIC-2158 - contact card placeholders configurable (hasPlaceholders) ([d11bdb8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d11bdb8bb13a96de77bb18e95bec4afc8166a1df))

## [13.32.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.6&sourceBranch=refs%2Ftags%2Fv13.32.0) (2023-06-15)

### Features

- DAZUIC-2149 - Create core module & intersection tooltip directive, use it in filter ([52397bc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/52397bc86302419dbcc17aeb159b464df9ea7694))

### [13.31.6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.5&sourceBranch=refs%2Ftags%2Fv13.31.6) (2023-06-09)

### Bug Fixes

- DAZUIC-2307 - multi input can now be used with [formArrayName] directive ([83e90cc](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/83e90cc86f5eecbddae297ff3876d0c692c2f019))

### [13.31.5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.4&sourceBranch=refs%2Ftags%2Fv13.31.5) (2023-06-06)

### Bug Fixes

- DAZUIC-2300 - breaking change in multi input fixed: use with FormControl still possible (instead of new QdFormArray) ([99d0c2d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/99d0c2d7b360b78983c70b9ad62cf8a7bcdbbc82))

### [14.0.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.4&sourceBranch=refs%2Ftags%2Fv14.0.1) (2023-06-06)

### Bug Fixes

- DAZUIC-2300 - breaking change in multi input fixed: use with FormControl still possible (instead of new QdFormArray) ([99d0c2d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/99d0c2d7b360b78983c70b9ad62cf8a7bcdbbc82))

## [14.0.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.4&sourceBranch=refs%2Ftags%2Fv14.0.0) (2023-06-06)

### Bug Fixes

- DAZUIC-2300 - breaking change in multi input fixed: use with FormControl still possible (instead of new QdFormArray) ([99d0c2d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/99d0c2d7b360b78983c70b9ad62cf8a7bcdbbc82))

### [13.31.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.3&sourceBranch=refs%2Ftags%2Fv13.31.4) (2023-06-01)

### Bug Fixes

- DAZUIC-631 - fix initial triggering of filter outputs ([a9039c4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a9039c485b61151295493b072253949a0244db0b))

### [13.31.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.2&sourceBranch=refs%2Ftags%2Fv13.31.3) (2023-06-01)

### Bug Fixes

- DAZUIC-2286 - some fixes for Sonar ([a34c3f0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a34c3f035c988963b20c5b83da54b9e0b2326655))

### Documentation

- DAZUIC-2286 - Fix for incorrect column specification ([a53c7a9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a53c7a9d33d7e1ce777ae6e43c890329c77cd62f))

### [13.31.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.1&sourceBranch=refs%2Ftags%2Fv13.31.2) (2023-05-31)

### Bug Fixes

- DAZUIC-2286 - Sonar, ignore false positive for tables ([e2eb5b6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e2eb5b6a4edbb0321b023cda76c65ca7bc1bf36e))
- DAZUIC-631 - wait for pending navigations when setting filter query parameter ([3273de6](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/3273de684930fd000d8b61f09346db66c5f99b9d))

### [13.31.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.31.0&sourceBranch=refs%2Ftags%2Fv13.31.1) (2023-05-30)

### Bug Fixes

- DAZUIC-631 - fix waiting for navigation end before filter query parameter is checked ([23aef94](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/23aef9445caf21b4d04e4b0570c79e50844623f5))

## [13.31.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.30.1&sourceBranch=refs%2Ftags%2Fv13.31.0) (2023-05-30)

### Features

- DAZUIC-631 - persist filter selection in url ([ef3fe17](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ef3fe17763617ef2774efb590a5c3fa80f63302f))

### [13.30.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.30.0&sourceBranch=refs%2Ftags%2Fv13.30.1) (2023-05-30)

### Bug Fixes

- DAZUIC-2263 - remove unused property in column config ([ea980fb](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ea980fb3fe6ee68e49a90e33241a82afdc0633f8))

## [13.30.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.29.0&sourceBranch=refs%2Ftags%2Fv13.30.0) (2023-05-30)

### Features

- DAZUIC-2276 - search phrase configurable; handle search config updates ([6ee1df7](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/6ee1df784e889963b02487e2b8c1bb272c642470))

## [13.29.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.28.0&sourceBranch=refs%2Ftags%2Fv13.29.0) (2023-05-26)

### Features

- DAZITSUV-5101 - qd-multi-input_mit-backend-validierung-erweitern ([0ac3e82](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0ac3e8250075c0ed6811a92a58e1434e23970e9b))

## [13.28.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.27.4&sourceBranch=refs%2Ftags%2Fv13.28.0) (2023-05-25)

### Features

- DAZUIC-2253 - extend column system to 6 columns ([5bfc169](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5bfc169d4c92d685b4ac036dd2c3c52b624b2d5a))

### [13.27.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.27.3&sourceBranch=refs%2Ftags%2Fv13.27.4) (2023-05-25)

### Bug Fixes

- DAZUIC-2275 - export interfaces ([af86d3e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/af86d3e961051b9f36271853be7f35cd0b1b3c78))

### [13.27.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.27.2&sourceBranch=refs%2Ftags%2Fv13.27.3) (2023-05-25)

### Bug Fixes

- DAZUIC-2273 - make ngOnDestroy hooks with unsubscribe robust ([d85459b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d85459b5106b9e3fa47c607b601fbc2ba8409fc0))

### [13.27.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.27.1&sourceBranch=refs%2Ftags%2Fv13.27.2) (2023-05-24)

### Bug Fixes

- DAZUIC-2265 - provide SearchService at component level ([4c04455](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4c044558d41c15773fc07620cdb100d4db10a4e8))

### [13.27.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.27.0&sourceBranch=refs%2Ftags%2Fv13.27.1) (2023-05-17)

### Bug Fixes

- DAZUIC-2254 - handle updated options in checkboxes component ([4259a35](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4259a354a7df7749882f593246c899606839fbf3))

## [13.27.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.26.2&sourceBranch=refs%2Ftags%2Fv13.27.0) (2023-05-16)

### Features

- DAZUIC-1964 - QdMenuButton ([876e0a0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/876e0a013e61734034f725eda67ab599b90ac14b))

### [13.26.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.26.1&sourceBranch=refs%2Ftags%2Fv13.26.2) (2023-05-16)

### Bug Fixes

- DAZUIC-2250 - remove buggy leftover code of removed feature ([0a98206](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0a9820662c2e33af2b27c355a4e832cb7c85b488))

### [13.26.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.26.0&sourceBranch=refs%2Ftags%2Fv13.26.1) (2023-05-05)

### Bug Fixes

- DAZUIC-2234 - handle updated options in dropdown component ([5011c64](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5011c64088e5e955a0fc09b59803974107357895))

## [13.26.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.25.0&sourceBranch=refs%2Ftags%2Fv13.26.0) (2023-05-04)

### Features

- DAZUIC-2161 - QdTable: replace lastColumnFillingWidth property ([dacb05b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/dacb05b7f487eb7d268434db54d58eb39870c065))

### Documentation

- DAZUIC-2206 - update sone documentations for components ([0cd10b0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0cd10b01899810c06824c2252d866b904aecb748))
- DAZUIC-2229 - Fix broken image snapshot ([e46a197](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e46a19725cfc8969895023273cc228a83bcba7f5))

## [13.25.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.24.1&sourceBranch=refs%2Ftags%2Fv13.25.0) (2023-05-01)

### Features

- DAZUIC-663 - default notification error messages for several HTTP error status codes ([0ffa34c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0ffa34c2988892dc3263e901b0aeae4623dfff50))

### [13.24.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.24.0&sourceBranch=refs%2Ftags%2Fv13.24.1) (2023-04-25)

### Bug Fixes

- DAZUIC-1537 - add document name in english translation of upload delete confirmation ([0908e2e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0908e2e21513fbad465d9fa4007de738563b2ea9))

## [13.24.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.23.0&sourceBranch=refs%2Ftags%2Fv13.24.0) (2023-04-25)

### Features

- DAZUIC-1272 - QdTable: one single point of truth for tableId's ([52bb027](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/52bb027be08a1dae7c07c77c7d0e7b35cdc5486a))

## [13.23.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.22.0&sourceBranch=refs%2Ftags%2Fv13.23.0) (2023-04-24)

### Features

- DAZUIC-1272 - add scenario ([b7bcef5](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b7bcef55dd20f02464156ba0508d79e9d4370e63))

### Bug Fixes

- DAZUIC-2200 - always trigger table selection event on change of table data ([143c598](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/143c5988810350daffaae49f12c3c08a3baea117))

## [13.22.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.21.0&sourceBranch=refs%2Ftags%2Fv13.22.0) (2023-04-18)

### Features

- DAZUIC-2135 - Extend the container section to include chips ([0b07d50](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/0b07d50e8e2bb6b48f947c8e9673012857b52621))

## [13.21.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.20.0&sourceBranch=refs%2Ftags%2Fv13.21.0) (2023-04-17)

### Features

- DAZUIC-2021 - pagination alignment to width of the associated table ([50ac32a](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/50ac32a50cb062faeac164c3c630ae807a6526df))

### Documentation

- multi input config documentation ([bf6ff1c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/bf6ff1c8f29379a4a7077575533884dcf44a59a9))

## [13.20.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.19.1&sourceBranch=refs%2Ftags%2Fv13.20.0) (2023-04-13)

### Features

- DAZUIC-2192 - extend notifications interceptor, to show them as a snackbar ([a9364b4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/a9364b49df8dc4db2adb112cfd85b71d70b62095))

### [13.19.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.19.0&sourceBranch=refs%2Ftags%2Fv13.19.1) (2023-04-12)

### Bug Fixes

- DMBA-4515 - update snackbar overlay position when notifications are added or window is resized ([c193760](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c193760c493e436a45eb52ec5c3a2f9316fc6a83))
- ensure resizeSubscription is defined before unsubscribing ([35434c1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/35434c1831e103596ff56ab6a789d4d2046ab176))

## [13.19.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.18.1&sourceBranch=refs%2Ftags%2Fv13.19.0) (2023-03-31)

### Features

- DAZITSUV-4984 - multi input frontend validation and input splitting ([796941c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/796941c76d2405f752d029112696d7e78cb03d47))

### [13.18.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.18.0&sourceBranch=refs%2Ftags%2Fv13.18.1) (2023-03-30)

### Bug Fixes

- allow up to 14 columns in QdTable ([c814d23](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/c814d2396c07158cc8895d0d2c1d8cdf27861ffe))

## [13.18.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.17.1&sourceBranch=refs%2Ftags%2Fv13.18.0) (2023-03-29)

### Features

- DAZUIC-2134 - table content type "icon" ([5308e33](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/5308e33de6ac839fe292b95cde08faa239e007f8))

### [13.17.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.17.0&sourceBranch=refs%2Ftags%2Fv13.17.1) (2023-03-28)

### Bug Fixes

- export QdTableConfigColumn type ([86833d9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/86833d96f5fa0b4a82b617f6b72540ab2da8699b))

## [13.17.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.16.3&sourceBranch=refs%2Ftags%2Fv13.17.0) (2023-03-28)

### Features

- DAZUIC-1577 - Update HeaderWidget V2.8+ in QdShell ([13a4f3c](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/13a4f3c362b695ce078edc133a6f9aeafab6f980))
- DAZUIC-2146 - sticky shell header (config: isHeaderSticky) ([e526095](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/e526095bfe464ac73da623ff40e1546d934155a3))

### Bug Fixes

- DAZUIC-1577 - Calling "useLanguage" on each HeaderWidget configuration update ([23d1852](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/23d1852456552a6d2ed817421c23c96f18c3e679))

### Documentation

- DAZUIC-1577 - Rename table link show case in Storybook ([fe2deb0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/fe2deb0616fdd57a824bb0c3339a1bd00ae9ff30))

### [13.16.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.16.2&sourceBranch=refs%2Ftags%2Fv13.16.3) (2023-03-27)

### Bug Fixes

- export QdFilterService for combination of table, pagination and filter ([d84428f](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d84428ffdc7a071ab6319db91b37136d00e6d3f0))

### [13.16.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.16.1&sourceBranch=refs%2Ftags%2Fv13.16.2) (2023-03-27)

### Bug Fixes

- DAZUIC-2142 - remove overlay on destroy of snackbar listener ([b3da335](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/b3da3354734e5123bf55791baf36bd0e05197e4b))

### Documentation

- page sizes [25, 50, 100] in examples ([2cef5d9](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2cef5d971c112af78928a27ef4c8f47379756e56))

### [13.16.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.16.0&sourceBranch=refs%2Ftags%2Fv13.16.1) (2023-03-24)

### Documentation

- example for table with pagination and filter ([d12588e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d12588eb23540fb9b3c7eb616d581a5ebffda762))

## [13.16.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.15.0&sourceBranch=refs%2Ftags%2Fv13.16.0) (2023-03-24)

### Features

- DAZUIC-2137 - remove column type 'chips'; 'chip' accepts single and multiple chips ([4db0238](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4db0238b60d2bb2912998d9dc56d7efae285a540))

### Documentation

- DAZUIC-2137 - remove column types from config that are not implemented yet ([78ea583](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/78ea58364a1af6023cd8f51c3abec72364f11fd5))

## [13.15.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.14.0&sourceBranch=refs%2Ftags%2Fv13.15.0) (2023-03-24)

### Features

- DAZUIC-2138 - Merge table content types LinkSinge & LinkMulti to link ([8b0551e](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/8b0551e5452cf8210cd3a6aae54392c01983a3b8))

## [13.14.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.13.0&sourceBranch=refs%2Ftags%2Fv13.14.0) (2023-03-23)

### Features

- DAZUIC-2066 - Add contentTypes linkSingle & linkMulti for QdTable ([87b3282](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/87b3282d0515e4ccc7b7c76c4e25c66c3f976b4d))

## [13.13.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.12.0&sourceBranch=refs%2Ftags%2Fv13.13.0) (2023-03-22)

### Features

- DAZUIC-1965 - Content Type Status for QdTable ([1d835f1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/1d835f17f18ec6d75af162df845a905907fc7328))

## [13.12.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.11.0&sourceBranch=refs%2Ftags%2Fv13.12.0) (2023-03-21)

### Features

- DAZUIC-1966 - QdTable: Add chip content type ([2d5e11d](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2d5e11dccdec79c369e0f05c23a157724274fad3))
- QdTable: fix some typos and minor issues in docs ([4c9636b](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/4c9636bd2c9cd979d9cfa3c2521250561d065f2d))

### Bug Fixes

- DAZUIC-2113 - fix container type in filter/table show cases ([2af28c8](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2af28c82e7cfe92aa3473a2b977908d1d59bb79d))
- DAZUIC-2113 fix paddings for container type 'table' ([d4f27c0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/d4f27c02fde13d78af26accd37831c72ac12cefc))

## [13.11.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.10.0&sourceBranch=refs%2Ftags%2Fv13.11.0) (2023-03-21)

### Features

- DAZUIC-1956 - pagination styling and scrolling behavior ([2403a27](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2403a2721453b5e6a1996bacd8fba6c5b205ab95))

## [13.10.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.9.0&sourceBranch=refs%2Ftags%2Fv13.10.0) (2023-03-16)

### Features

- DAZUIC-1724 - Chips Content Type QdTable ([58104ba](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/58104ba6dc778204e55c3c56821dd4cec89711e0))

## [13.9.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.8.2&sourceBranch=refs%2Ftags%2Fv13.9.0) (2023-03-15)

### Features

- DAZUIC-1977 - new multi input component ([ac8a4d3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/ac8a4d3a96b4500fda8333daacf281860520a4ba))

### [13.8.2](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.8.1&sourceBranch=refs%2Ftags%2Fv13.8.2) (2023-03-10)

### [13.8.1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.8.0&sourceBranch=refs%2Ftags%2Fv13.8.1) (2023-03-09)

## [13.8.0](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.8.0-beta.4&sourceBranch=refs%2Ftags%2Fv13.8.0) (2023-03-06)

### Features

- DAZUIC-1955 - QdTable Refresh API for pagination ([798e374](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/798e3748cbbf1c71444fe3d1a0540167ae494e2f))
- translate qd-search placeholder "Search" ([53628c1](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/53628c17d05a460c97f89c85e33b6e873293d6a0))

### Bug Fixes

- DAZUIC-2035 - remove whitespace in folder name ([f7c3dad](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/f7c3dadf01868491eba68e32aa3e9464ddefd1bd))
- DAZUIC-2035 - remove whitespace in mapped folder names ([9132a59](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/9132a5975dbf8f321080de1c144ea5e0d88fc624))
- DAZUIC-2066 - fix triggering of table selection event ([eae4bb4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/eae4bb4b3749725083d57bb39ef8bb8e1ad6331a))

## [13.8.0-beta.4](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.8.0-beta.3-193&sourceBranch=refs%2Ftags%2Fv13.8.0-beta.4) (2023-02-28)

## [13.8.0-beta.3](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/compare/diff?targetBranch=refs%2Ftags%2Fv13.7.2-beta.0&sourceBranch=refs%2Ftags%2Fv13.8.0-beta.3) (2023-02-24)

### Features

- DAZUIC-1728 - extend jenkins to create Blogpost after release & publish ([2049dab](https://bitbucket.bit.admin.ch/projects/EZQD/repos/qd-ui/commits/2049dab07b02ee3bc0b5f32387c0d61fd7261653))

### [13.7.2-beta.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.7.1...v13.7.2-beta.0) (2023-02-17)

### Bug Fixes

- DAZUIC-2019 - back link parameter replacement (consider child route events) ([006c13f](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/006c13f49ed40f2ca3d6af603b77a8185767d8a3))

### [13.7.1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.7.0...v13.7.1) (2023-02-14)

### Bug Fixes

- DAZUIC-2001 - Handling QdContainerToolbarAction without QdContainer ([d9248c0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d9248c031f6fc3800c797abffe683f7e0a550e84))
- mobile view of checkboxes and radiobuttons in filter ([4431ef7](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4431ef7c2c6c5680fe2ffe8068bbffca178f6ff0))

## [13.7.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.6.1-beta.0...v13.7.0) (2023-02-08)

### Features

- DAZUIC-1487 - Make QdButtons usable ([2ddfa85](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2ddfa85a9f431f36c9e9969fde9c0f9a885c92b4))
- DAZUIC-1961 - qd-table new config: mainColumnNotFillingWidth ([1885d16](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1885d1632e8873209e6fac8ef4ece7c47f961022))
- DAZUIC-1961 - qd-table new config: mainColumnNotFillingWidth ([32a9e15](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/32a9e155e6514158f0162af5eec07819f7fb8209))
- DAZUIC-1962 - dynamic previousHref in master layout ([3d01aad](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d01aad4bac387eb6b00d05bc04a7d13d0b1402c))
- DAZUIC-1963 - add generic QdAutofocusDirective, use these in QdSearch & QdInput ([c69846f](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c69846fedd230f01233be06c5b5885c0ea5f0ffb))

### [13.6.1-beta.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.6.0...v13.6.1-beta.0) (2023-01-26)

### Features

- DAZUIC-1783 - Add components for QdFileCollector ([ea298aa](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ea298aaff03c517a3ead7b13a84e0d17ffffaea2))
- DAZUIC-1784 - QdFileCollector file handling ([b604484](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b604484f519413084e1a9bcc009dbe93f0e6bd89))
- DAZUIC-1979 - qd-input inputmode attribute ([7542170](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/754217005e01393bab84a03e52cbad9d0881bd8c))

### Bug Fixes

- qd-table pagination font, button size, empty state with pagination ([67892db](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/67892dbc90dd0180db5cc4d56ec873f5d1d6e4da))
- qd-table pagination font, button size, empty state with pagination ([1cbee56](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1cbee565411dc1f9ba79f389ac4447030b355f4e))

## [13.6.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.3...v13.6.0) (2022-12-21)

### Features

- DAZUIC-1762 - QdTabs reacts dynamically to changes in content projection ([e3e42ac](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e3e42ac04fa000e6ab622a9111e754cf7c21cd52))
- DAZUIC-221 - QdTable: add empty state view ([def3cf0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/def3cf05cad4f676eafcbbe2dce9bc3f3732854c))

### [13.5.3](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.2...v13.5.3) (2022-12-14)

### [13.5.2-beta.3-183](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.2-beta.3...v13.5.2-beta.3-183) (2022-11-30)

### [13.5.2-beta.3](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.2-beta.2-182...v13.5.2-beta.3) (2022-11-30)

### Features

- DAZUIC-1762 - QdTable - add verification: has data changed? ([5f83f15](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5f83f158ef8fd28b8360aafb86ea29291863c2c3))

### [13.5.2-beta.2-182](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.2-beta.2...v13.5.2-beta.2-182) (2022-11-29)

### [13.5.2-beta.2](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.2-beta.1...v13.5.2-beta.2) (2022-11-29)

### Bug Fixes

- DAZUIC-1762 - remove drawer ([e5e61d2](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e5e61d2f6aeeb1e072dee65b93cb787a41b65d2e))

### [13.5.2-beta.1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.2-beta.0...v13.5.2-beta.1) (2022-11-29)

### Bug Fixes

- DAZUIC-1762 - remove drawer ([442ab21](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/442ab21016d8f7e8e0ef2af600a11b2ba16f281e))

### [13.5.2-beta.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.1...v13.5.2-beta.0) (2022-11-29)

### [13.5.2](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.1...v13.5.2) (2022-12-14)

### Features

- DAZUIC-1552 - QD-UI - Convert to nx monorepo ([739a079](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/739a079b0c3e366e4c471a51a7b467d6bc3e38a9))
- DAZUIC-1762 - QdTable - add verification: has data changed? ([6050289](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6050289b6dc2901046406651305d904ce0816aaa))
- DAZUIC-1762 - QdTable - Update data when view changed ([fddfacf](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fddfacfa05f254ee9cc75c5e906a467073951d60))

### Bug Fixes

- DAZUIC-1762 - QdTable - implement new update strategy ([e28c201](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e28c201dd0af6fd14eb8c5c70669449c558a6e15))
- DAZUIC-1865 - pph data section margin with navigation ([90e8642](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/90e86424bcaa3d636dd5cd61783862d262df9146))

### [13.5.1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.5.0...v13.5.1) (2022-11-20)

### Bug Fixes

- export QD_DATA_RESOLVER_TOKEN and QdDataResolver ([0e0d730](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0e0d7309adc7220e3c138b408bd13f1579ac6a73))

## [13.5.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.4.5...v13.5.0) (2022-11-17)

### Features

- DAZUIC-1510 - Add QdDrawer ([9185497](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/918549791749221f45e037a03c941fc6f355c97f))
- DAZUIC-1751 - add QdTooltip & use it in QdSearch ([fca50d9](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fca50d9531d896560aa7bac4014a1fac29c70947))
- DAZUIC-1751 - reduce padding in tooltip overlay ([523bb89](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/523bb89d4caa0bc277b0758ed0a71b7fd6ded4a0))
- DAZUIC-1752 - contact card component ([9cb774b](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9cb774b73f125be578d06b02f7da150d3445b120))
- DAZUIC-1752 - contact card placeholders ([e585373](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e585373ac61a3a4412743c197a246154ff9bb093))
- DAZUIC-1757 - inline notifications redesign, pph integration ([9853b83](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9853b83d5491fbfac4f90486af15b5bef4d6932b))
- DAZUIC-1758 - add data section to PPH ([c40c404](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c40c40463f2a9ef18f49f455b6251ed6c60c5394))
- DAZUIC-770 - pagination implementation ([437eb67](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/437eb67eaa2fbd7588c6b84247c1691a7c5760ed))
- DAZUIC-770 - tests for pagination clicks ([818394b](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/818394b523eca2ee4b223d4600e171158698284a))
- DAZUIC-773 - table 100% width (main column), table styling ([493af6f](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/493af6f724762344b3a8a0506631aa3cb62a6e2f))
- MAPP-9384, DAZUIC-1804 - Add QdShellToolbar ([399a270](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/399a2703089621936b40e919977880dde3e2deb8))

### Bug Fixes

- allow empty string pamsEnvironment initially for async use case ([6ed92f7](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6ed92f781cd7aded4eb368bcd6102fd473fbbec9))
- DAZUIC-1533 - fix build ([877f612](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/877f6128d523bee239a958512ddbcf6afdfdb202))
- DAZUIC-1533 - fix default preselect in QdSearch ([d6d4e1c](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d6d4e1c1c633e8335d7b3c0fbd3af7254e540064))
- DAZUIC-1676 - scrolling input units ([da9f2de](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/da9f2de12bddf10251c7b21bd7f20d4792bdec28))
- handling of null values in config ([52e14e0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/52e14e03f574ac680529db22628d0dfce25a6cc5))

### [13.4.5](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.4.4...v13.4.5) (2022-10-19)

### Bug Fixes

- DAZUIC-1529 - fix linting error ([91f8031](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/91f80312097c8d87a4f13403a7e6779f21e11dcc))
- DAZUIC-1670 - fix footer issues ([6f51b35](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6f51b35914673d1d4a0bf61ec1d8a63dd6dff605))
- DAZUIC-1670 - fix radio buttons & checkboxes in mobile ([d9ae8ca](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d9ae8cac9be95a42c605249579f918c321c675d9))
- DAZUIC-1677 - fix changeDetection for PamsStatus in Header Wigdet ([99958a8](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/99958a857ef49709eca446120926588027529ebe))

### [13.4.4](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.4.3...v13.4.4) (2022-10-12)

### Features

- DAZUIC-1082 - add E2E-Tests for QdButtons ([5323f3f](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5323f3f665a057d61be6ea45f6315ea5c0574fa5))
- DAZUIC-1646 - add E2E-Tests for QdPercentageProgressBar ([c83c1f1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c83c1f14458ae94f18163393730c81d5a86913d8))
- DAZUIC-1648 - Add batch for tested E2E stories in SB ([07c8db8](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/07c8db8b77be03dbf570f837d5c83e6ee0da9872))
- DAZUIC-1648 - Add Dropdown E2E-Tests ([9cb00f4](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9cb00f46a40e0c0439ecaaa5d0de91343a6a9abf))
- DAZUIC-1649 - add E2E-Tests for QdFilter ([30effe2](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/30effe241d19181834b3ca07b28c0e0760f3fa92))

### Bug Fixes

- DAZUIC-1528 - Jenkins: clean-up before each build ([580701e](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/580701e8ffeeba914889d299323785e66b665dc6))
- DAZUIC-1528 - Jenkins: clean-up before each build ([effa21d](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/effa21dcde82cfd6da863340ccabf6225d23cba0))
- DAZUIC-1717 - Updating styles when inputs change ([f690ec0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f690ec0f25c10e23c1ae8dd592614bb3d8477204))
- dropdown default value ([b23cd7d](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b23cd7db1a06361abdebd3c03a9b6e49ee49ae16))

### [13.4.3](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.4.2...v13.4.3) (2022-09-27)

### Bug Fixes

- fix undefined property type to allow TS strict mode ([055635e](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/055635e7dc3844b510103ccee1278454a22ca572))

### [13.4.2](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.4.1...v13.4.2) (2022-09-26)

### Bug Fixes

- DAZUIC-1528 - reduce memory for prod enviroment ([642a331](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/642a3319ff62a8eb65cfc5df6a8987e962893f25))

### [13.4.1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.4.0...v13.4.1) (2022-09-23)

### Bug Fixes

- import fixed in navigation tiles module ([a3eabb1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a3eabb107bdab5aeb351e3cc244b83cf6def461c))

## [13.4.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.3.0...v13.4.0) (2022-09-23)

### Features

- DAZITTPE-6601 - added docs and tests ([ed6eb6f](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ed6eb6fad4f97c695dcfe9a1454bb33f9d5c11ae))
- DAZITTPE-6601 - added new percentage-progress-bar ([9dce52e](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9dce52e36a308d5b15ec923fa2b78dd96985208e))
- DAZUIC-1192 - Connect QdPage to State Management ([a83704e](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a83704ed0f67fd1dd7d27617985fd550303196ef))
- DAZUIC-1458 - Add QdCheckboxChip component ([9f12e6d](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9f12e6df04e1f8330b8a082d02b6894c764b59cd))
- DAZUIC-1493 - Deployment: Features Branches ([eb1f3ba](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/eb1f3ba568daf5fa78f479da07bc52b04447028f))
- DAZUIC-1500 - qd-input units ([79744ed](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/79744ed18a5359660eb0b1ad495d9d2d85cacb58))
- DAZUIC-1501 - Design checkbox chips ([66ff03e](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/66ff03eb0d85a7a8638a20f2e670e8751af40c67))
- DAZUIC-1501 - QdCheckboxes, QdRadioButtons: mobile Design ([6ce907e](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6ce907ebe8f21f8bc56eda87fe03cc34078c9300))
- DAZUIC-1502 - code scaffolding ([f26d086](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f26d086357d7cabbc9dbe6d572da40c750ad8167))
- DAZUIC-1502 - datepicker component ([8275883](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/827588300266cf88ac3ee39754611178328919fa))
- DAZUIC-1505 - navigation tiles ([b8fd979](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b8fd979daa4f55b365bb2ffa398b430d7d4db451))
- DAZUIC-1506 - Update HeaderWidget in QdMasterLayout ([4118f27](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4118f270a1e4639f53cb61703c238a20fc0d97e7))
- DAZUIC-1589 - remove qd-auth ([7b0f347](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7b0f347b5581a618f3f927bb62df241cc90d5507))
- DAZUIC-1602 - new icons ([69a20f5](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/69a20f516615620290218b28202ece941fc5ada2))

### Bug Fixes

- data tree states ([d371f49](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d371f4999b63973665266736c14784b0377b772a))
- required validator ([5402051](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5402051d1894d438b0656c9cfd622a5e4588bc8b))

## [13.3.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.2.0...v13.3.0) (2022-08-25)

### Features

- DAZUIC-1361 - update QdTable: selection handler ([427e792](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/427e79231903f10b9cfb2e8e69747f58436db707))
- DAZUIC-453 - actions instead of console logs ([a0ca85f](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a0ca85f20b5631a3752d8793c61c8f3af4e1ba32))
- DAZUIC-482 - table inline menu implementation ([a653084](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a653084d3b869af80218ca7298ed6dacf7809498))

### Bug Fixes

- clear and regenerate cypress snapshots ([47013d6](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/47013d664fc13dbed61e384ae04ee165d03d6451))
- cypress config fix for tests ([45da401](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/45da401472a4bb5fda8179b1fb8ad5880031051a))
- DAZUIC-1463 - fix reading selected rows from store ([808ff91](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/808ff91192a242c03d152779635a644fed9de2c2))

### [13.2.2](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.2.0...v13.2.2) (2022-07-29)

### Features

- DAZUIC-1361 - update QdTable: selection handler ([427e792](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/427e79231903f10b9cfb2e8e69747f58436db707))

### Bug Fixes

- DAZUIC-1463 - fix reading selected rows from store ([72daf76](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/72daf76babce8772ce5d02866f0006e45dcabc12))

### [13.2.1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.2.0...v13.2.1) (2022-07-28)

### Bug Fixes

- DAZUIC-1463 - fix reading selected rows from store ([72daf76](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/72daf76babce8772ce5d02866f0006e45dcabc12))

## [13.2.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.1.1...v13.2.0) (2022-07-27)

### Features

- DAZUIC-1329 - aside option for vertical pairs ([adfddb8](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/adfddb8997300baf55932ed5879bf039e2d6d0de))
- DAZUIC-1349 - use QdTable in Modal ([e1d430c](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e1d430cb2167e991689e4a7a9321482fb19fe8fa))
- DAZUIC-1463 - save table selection in store ([e83b411](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e83b41186fe1d397327c5254c7216e4377e30b96))
- DAZUIC-961 - put table data into state ([e001165](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e001165cd72dd8ecddce49a6dc2a45152b07de21))
- DAZUIC-961 - read filter data from state ([a513099](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a513099a243e7ef4d908b89fb9e10d41e529e632))
- DAZUIC-961 - read table data from state ([6bc2335](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6bc2335c4b3f2553799bcad8cc6eb158b16f44cb))
- DAZUIC-961 - search data in state ([fa7c06b](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fa7c06b4d834296a45ab828007d4f2a4d3fd4ce3))

### Bug Fixes

- DAZUIC-1330 - no selection event when order changed ([e62cfa5](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e62cfa5dd4b5f481cac09feefe6e01648f6a1021))
- DAZUIC-1457 - fix cut inputs in safari ([7089cb9](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7089cb9773909a51a73c56d03ea370e7b743d3a0))
- DAZUIC-1461 - QdForms: ValueChange event will no longer emitted initially ([b9fb4bc](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b9fb4bc36f1782497e2ef1ab0396da268de4076b))
- test ([8e6acf8](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e6acf803a3714ce03e8ff0def7dd29b6511c0b0))

### [13.1.1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.1.1-beta.1...v13.1.1) (2022-07-20)

### Bug Fixes

- DAZUIC-1454 - fix cut input field error message ([a4ab5fc](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a4ab5fc13074c576ac3f298a60d5d4d9ee7d4994))

### [13.1.1-beta.1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.1.1-beta.0...v13.1.1-beta.1) (2022-07-19)

### Bug Fixes

- DAZUIC-1453 - fix dependency ([b0353ac](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b0353ac64653f2e6a1913cb3a1666c64e22e384d))

### [13.1.1-beta.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.1.0...v13.1.1-beta.0) (2022-07-19)

### Bug Fixes

- DAZUIC-1448 - fix dropdown positioning ([d9ab47b](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d9ab47bf8d25314c68d183e5ff181ed6f49109b1))
- DAZUIC-1451 - fix row selection service types ([487df02](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/487df02575b225d2ea5b6855c580d4c2b4c75630))
- DAZUIC-1453 - fix pear dependency ([c012c43](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c012c43b5192aad981aae07c671f89577913813f))

## [13.1.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v13.0.1...v13.1.0) (2022-07-12)

### Features

- DAZIUC-1354 - Add RWD approved badges ([97e56c6](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/97e56c6397bf6cd1b71d9bae1d3c64add628c99d))
- DAZUIC-1037 - build cypress PoC ([f17fdee](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f17fdeeae46233b41ae9a4cfbde06f6cca71b9b5))
- DAZUIC-1157 - add search field, add banner ([049846c](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/049846cc6ffa0335b57c9e1222bda01499692ae5))
- DAZUIC-1165 - test fix ([c0d64b1](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0d64b14578bd1c4d7596cc2584390847c1e0ad8))
- DAZUIC-1202 - footer implementation ([bb73442](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bb73442055994ab30b2b1aae666ff8313f223579))
- DAZUIC-1206 - section toolbar ([8a69275](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8a692752a02cadeacdadd81fc7eb2c9d164f8275))
- DAZUIC-1213 - aggregation in qd-table tree view ([9874182](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/98741825058c525688912392e0d4148a94235657))
- DAZUIC-1265 - add edge case for rwd table handling ([f030829](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f03082909b0e8f737a12c2ec3e76f48ff459eddd))
- DAZUIC-1265 - RWD for plain table ([5c88229](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5c88229a616aca1ec76e2ba3ec46900622f1de81))
- DAZUIC-1283 - shell header widget and back link ([603add7](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/603add7c32f8fe4a56bb4f73d8b45cae263209b5))
- DAZUIC-1315 - scaffold page ([360bb27](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/360bb2708ad171bd07eeb76a198ef73d0fad6527))
- DAZUIC-1315 - scaffold page component and create storybook ([cbdd834](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cbdd8344659eebdb9d896cee1bf251463b2b1406))
- DAZUIC-1330 - table radio button selection ([63c389f](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/63c389fa5a617cc00d85e56ffef55c5ae51d52c8))
- DAZUIC-1330 - table radio button selection ([e0220ec](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e0220ecf37ccea208ceab5061c0a1b55843f9ecb))
- DAZUIC-1355 - add basic page process header ([1758346](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1758346558a86a00bfee0bb27bb840ee8d1a7ae7))
- DAZUIC-680 - page sections ([684a323](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/684a323cbc83565455238575554670dbbb973b33))
- DAZUIC-680 - page sections ([07f72c8](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/07f72c8c589e75458a4df7bb5ef3db227764d4be))

### Bug Fixes

- auth module integration after update to 13 ([553f165](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/553f16590a3dad88cd47c8cf59ed94c0829ac093))
- DAZUIC-1112 - bahavior filter EventEmittter ([2ea3f1c](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2ea3f1c2f2f8c24814d37cf04cd751ac3e76ed48))
- DAZUIC-1112 - dropdown z-index bug ([271d8c2](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/271d8c2bac089aee6a72db52d70542b7eba8b46b))
- DAZUIC-1113 - repair nested view in QdDataTree ([6ee091c](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6ee091c2f79870409c02908c5e3cb4c6df9c26ef))
- DAZUIC-1113 - resolve sotorybook build issues ([7f21f50](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7f21f50e5e16b564ffd7e5d64b50775eb8faf810))
- DAZUIC-1213 - fix tree view example data ([6860fd6](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6860fd67dcb7cddb5fe1f4968d750717374746a8))
- DAZUIC-1259 - back link fix ([d7fd429](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d7fd4299ae06268e18be44e99e2ccd38473020ed))
- DAZUIC-1440 - fix container scrollability ([092c75e](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/092c75e35f78cc13ad0ac0c1eac8b403157925fe))
- merge conflicts ([5a567a8](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5a567a89ba68c8fe14cbf8e0d25dc0293baa304e))
- shell layout ([9c4332d](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9c4332df901a3bf69c58b7aaf6fb98b8bfb249b5))
- switch between mobile and desktop header widget ([418ee80](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/418ee8003910cc13abdad3a5c5c0381079e18dad))
- unit test snapshots root ID problems ([9044c39](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9044c397b98216bf206c33f8283e23894ad65de4))

### [13.0.1](https://bitbucket.bit.admin.ch/scm/ezqd/qd-ui/compare/v13.0.0...v13.0.1) (2022-05-27)

### Bug Fixes

- test ([384e5c4](https://bitbucket.bit.admin.ch/scm/ezqd/qd-ui/commit/384e5c4e483c18dc83ef2c3e8c140c8147b18c21))

## [13.0.0](https://bitbucket.bit.admin.ch/scm/ezqd/qd-ui/compare/v13.0.0-beta.1...v13.0.0) (2022-05-23)

### Features

- DAZUIC-1116 - Angular 13 Upgrade

## [2.3.0](https://bitbucket.bit.admin.ch///compare/v2.1.2...v2.3.0) (2022-05-18)

### Features

- DAZUIC-1069 - add table tree view ([c8a134d](https://bitbucket.bit.admin.ch///commit/c8a134d9d72afb2b497e721cc72c8180a98da563))
- DAZUIC-1118 - implement notifications as snackbar ([b50a3d3](https://bitbucket.bit.admin.ch///commit/b50a3d3bf80ca0cf98083b94eba53cc93327d413))
- DAZUIC-1122 - add icons for via webshop ([316bdb4](https://bitbucket.bit.admin.ch///commit/316bdb48eeb686e31beeb02a4e6941dce591e3ce))
- DAZUIC-697 - application component basis ([5f6e595](https://bitbucket.bit.admin.ch///commit/5f6e59516fd6df390e15a9ba1b33b39911a8453b))
- DAZUIC-697 - example content for qd-application ([7f14f51](https://bitbucket.bit.admin.ch///commit/7f14f51021645e69b6d77a576329b935af6b93b0))

### Bug Fixes

- DAZUIC-1038 - stepper name was not changed properly ([fee1b59](https://bitbucket.bit.admin.ch///commit/fee1b59735aded31d7c476eae94a230622ec7b71))

## [2.2.0](https://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v2.1.2...v2.2.0) (2022-04-08)

### Features

- DAZUIC-1122 - add icons for via webshop ([316bdb4](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/316bdb48eeb686e31beeb02a4e6941dce591e3ce))

### Bug Fixes

- DAZUIC-1038 - stepper name was not changed properly ([fee1b59](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fee1b59735aded31d7c476eae94a230622ec7b71))
- test code was broken due to changed API of step item component ([194fa29](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/194fa29565627a258a29b1917be261b1b972eaa6))
- Whitespace: spaces, no tabs in Jenkinsfile ([ba78c70](https://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ba78c706466c87b0ae88665f2f9f68acb697368d))

## [2.1.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v2.1.1...v2.1.2) (2022-03-11)

### Bug Fixes

- add deep-object-diff as dep and remove peer deps ([fd1e53d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fd1e53db91b63775cff2fe75d31c0c176dff714f))

## [2.1.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.11.0...v2.1.1) (2022-03-10)

### Bug Fixes

- Add missing dependencies
- Logo Icon Fix
- Pincode Fix: uppercase values

## [2.1.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.11.0...v2.1.0) (2022-03-09)

### Features

- DAZUIC-1017 - Connex features for pinCode component" ([432bf39](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/432bf39a55905586ff9f9959c89d24ae71d269e4))
- DAZUIC-1017 - updates after code review ([ba51ce5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ba51ce5c0fa785db825ca2d09c538fece423c9fb))
- DAZUIC-673 - Qd-Table: add basic implementation ([7ed15a5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7ed15a562796985db9ecb73186be1180208e7ee3))
- DAZUIC-842 - resolve console warnings while storybook building ([c08b76b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c08b76b9d0582253aa3dd7ce8fe043717116ac15))
- DAZUIC-842 - update browsers list ([0afb879](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0afb8791d8a4fd375bdb681cf4a8d3b3f2e2bcb5))

### Bug Fixes

- DAZUIC-1027 - fix style side effects, optional unsubscriptions ([e5ff56c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e5ff56c7edbfa958e18935abaa86a9d4772b820b))
- DAZUIC-928 resolve sonar messages ([8ddd1dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8ddd1ddce8853fd9f4d622ad0d74f4d07f29e7f8))

## [2.0.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.12.0...v2.0.0) (2022-02-21)

### Features

- DAZUIC-972 - add as ngrx-store as devDependency ([b982381](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b9823811a2d86f8bfa94c0744c48baa73db61446))

## [1.12.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.11.0...v1.12.0) (2022-02-18)

### Features

- DAZUIC-673 - Qd-Table: add basic implementation ([7ed15a5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7ed15a562796985db9ecb73186be1180208e7ee3))
- DAZUIC-842 - resolve console warnings while storybook building ([c08b76b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c08b76b9d0582253aa3dd7ce8fe043717116ac15))
- DAZUIC-842 - update browsers list ([0afb879](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0afb8791d8a4fd375bdb681cf4a8d3b3f2e2bcb5))

### Bug Fixes

- DAZUIC-928 resolve sonar messages ([8ddd1dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8ddd1ddce8853fd9f4d622ad0d74f4d07f29e7f8))
- DAZUIC-929 - house keeping part 2 ([03112af](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/03112af280b3c2d6dfff5d307e4c6892207bfb8d))
- DAZUIC-965 - clean-up imports ([83644e7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/83644e7728fec96cfe60a12697469ef71e310810))

## [1.10.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.10.2...v1.10.3) (2021-12-03)

### Bug Fixes

- DAZUIC-895 - empty filter state event emitter, alternative content for upload ([d2b1b1c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2b1b1cfe780632fda937954ce685edd4f54a38e))
- trigger event emitter by clicking reset filter button ([1028c2a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1028c2a24613ac82ded986ef0cb236a9bf612fde))

## [1.10.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.10.1...v1.10.2) (2021-12-02)

## [1.10.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.10.0...v1.10.1) (2021-12-02)

### Features

- DAZUIC-6645 - Model Design for Qd-Forms ([31dd29f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/31dd29fba7796c9c10155ee6086ed646cf26f9d3))
- DAZUIC-858 disable filter / reset function when no filter is selected ([6aacba1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6aacba163041649ddde5c52af6801072504df37d))
- DAZUIC-873 - add changelog ([d98d134](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d98d1346b0c09b15da825c21abfeafc41ed579fe))
- DAZUIC-873 - clean-up code ([cf01ec3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cf01ec3703ea3515052e2db4696e04a9387b2e64))
- DAZUIC-885 add custom validators ([684237b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/684237b899e5c2ceaea1964105a88afd676bab9b))
- DAZUIC-885 fix build in QdValidators ([5133af3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5133af3cde71b4fb06b4a73cbe88ef6a70afb45e))

### Bug Fixes

- DAZUIC-873 fix date range filter ([66e1a75](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/66e1a754619104122262b4e9d4d968008ec981b5))
- DAZUIC-885 update error message ([4961f0e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4961f0e7db7de2fe7924542ca73a222415d06d72))
- merge conflicts ([6dc00a6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6dc00a66590c9c9cccbd54ffbe92b9baf2494b0a))
- revert jeap-pipelinelibrary@v2 ([867acf6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/867acf6d3a46d78a45d896e27ce859f184c1d97a))

## [1.10.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.6...v1.10.0) (2021-11-29)

### Features

- DAZUIC-785 add locale date pipe and use in filter ([4834636](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4834636074175038181c407241e31ff5bb60b376))
- DAZUIC-786 add restriction to date range filter ([7275622](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7275622f41f7c9e25d91a62c4796eeccd9aa305b))
- DAZUIC-793 - update related unit tests ([383130b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/383130bc603ce1d7431c65a66fe6ec8a1bd804e1))
- DAZUIC-808 add custom error component ([57083e6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/57083e67c18f55c50b779071fd005be03a42c0e4))
- DAZUIC-808 using qd form error in all input components ([ce75b01](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ce75b0128e0daa23685f5f5f5dc7a39549cbd60b))
- DAZUIC-824 - extend search with dropdown ([9824a2b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9824a2bb25d71bf59e6de364e650e0f3382ac964))
- DAZUIC-867 Adapt Local date format ([a47ef2b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a47ef2b6c7b522a70bb0c4b96596c1a274b95739))
- DAZUIC-867 add test to filterState$ ([31cc383](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/31cc383e7629616ace12bb676dfd14ea6725872b))
- DAZUIC-867 change date format ([74ff6a7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/74ff6a7bfe38ba083cb836b70e5c5fc3ff976dc6))
- DAZUIC-873 - clean-up code ([9751e6d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9751e6db1f482783c6ebeb774a37d42c41a2caac))
- DAZUIC-873 - filter: async input handling ([66b5d8f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/66b5d8f9b51f16453800f8944e37cd685d3b606b))

### Bug Fixes

- DAZUIC-873 refactor filter service to single filterState ([16f6a31](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/16f6a31d25cf378bc34de3dade12808b0c4e4fe6))
- merge conflicts ([53a8026](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/53a8026473deacd8a305431cbfc2994bb127a38a))

## [1.9.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.2...v1.9.3) (2021-10-26)

### Features

- DAZUIC-793 - update QdUiMockModule ([2a769a3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2a769a36b6e3f605598bddd2d015255a3732f93d))

## [1.9.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.1...v1.9.2) (2021-10-25)

### Features

- DAZUIC-703 - update master layout test ([0d021e4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0d021e4be778d19ccf18dbe99c683ed6e30fdc6e))
- DAZUIC-703 - update tabs test module ([956f9bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/956f9bd87aeb948eae7778ec869113e57d694ea5))
- DAZUIC-793 - export QdMockModalService ([35306da](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/35306da6474d95dd81fcc1479d3b56d335c59848))

## [1.9.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.0...v1.9.1) (2021-10-22)

### Features

- DAZUIC-703 - update master layout mock ([ae91cb9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ae91cb95465c7416e7350a37a3c637483e594206))

## [1.9.7-beta.0](https://bitbucket.bit.admin.ch///compare/v1.9.6...v1.9.7-beta.0) (2021-11-17)

### Features

- DAZUIC-785 add locale date pipe and use in filter ([4834636](https://bitbucket.bit.admin.ch///commit/4834636074175038181c407241e31ff5bb60b376))
- DAZUIC-786 add restriction to date range filter ([7275622](https://bitbucket.bit.admin.ch///commit/7275622f41f7c9e25d91a62c4796eeccd9aa305b))
- DAZUIC-793 - update related unit tests ([383130b](https://bitbucket.bit.admin.ch///commit/383130bc603ce1d7431c65a66fe6ec8a1bd804e1))
- DAZUIC-824 - extend search with dropdown ([9824a2b](https://bitbucket.bit.admin.ch///commit/9824a2bb25d71bf59e6de364e650e0f3382ac964))
- DAZUIC-867 Adapt Local date format ([a47ef2b](https://bitbucket.bit.admin.ch///commit/a47ef2b6c7b522a70bb0c4b96596c1a274b95739))
- DAZUIC-867 add test to filterState$ ([31cc383](https://bitbucket.bit.admin.ch///commit/31cc383e7629616ace12bb676dfd14ea6725872b))
- DAZUIC-867 change date format ([74ff6a7](https://bitbucket.bit.admin.ch///commit/74ff6a7bfe38ba083cb836b70e5c5fc3ff976dc6))

## [1.9.6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.5...v1.9.6) (2021-11-03)

### Features

- DAZUIC-703 - add backStep EventEmitter in stepper ([4a17b1b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4a17b1b6f5e753ce9398116955eedc5459fea5dc))
- DAZUIC-831 - add currentIndex key in dialog data model ([56f79aa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/56f79aa657c28070b466c98d838472e10c73e442))

## [1.9.5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.4...v1.9.5) (2021-10-29)

## [1.9.4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.0...v1.9.4) (2021-10-27)

### Bug Fixes

- DAZUIC-702 - clean-up changelog ([92a7be7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/92a7be7cef426bcfbc0ca7f846675ac5228fb9ca))
- DAZUIC-793 - update QdUiMockModule ([89184a2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/89184a209e8e7bc8693dc3c90afaaa3dd89a1dfa))
- DAZUIC-848 - fix error, when using qd-forms in tests ([55b4d2e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/55b4d2ea88d23c3b7f73d4d537005ce6ccdbef43))

## [1.9.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.2...v1.9.3) (2021-10-26)

### Features

- DAZUIC-793 - update QdUiMockModule ([2a769a3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2a769a36b6e3f605598bddd2d015255a3732f93d))

## [1.9.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.1...v1.9.2) (2021-10-25)

### Features

- DAZUIC-703 - update master layout test ([0d021e4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0d021e4be778d19ccf18dbe99c683ed6e30fdc6e))
- DAZUIC-703 - update tabs test module ([956f9bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/956f9bd87aeb948eae7778ec869113e57d694ea5))
- DAZUIC-793 - export QdMockModalService ([35306da](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/35306da6474d95dd81fcc1479d3b56d335c59848))

## [1.9.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.0...v1.9.1) (2021-10-22)

### Features

- DAZUIC-703 - update master layout mock ([ae91cb9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ae91cb95465c7416e7350a37a3c637483e594206))

### Bug Fixes

- DAZUIC-702 - clean-up changelog ([92a7be7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/92a7be7cef426bcfbc0ca7f846675ac5228fb9ca))

## [1.9.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.0-beta.0...v1.9.0) (2021-10-19)

### Features

- DAZUIC-589 - clean-up exports ([75d1de8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/75d1de8dbfad5d68efa66942e046ff23c6d13c42))
- DAZUIC-766 - export module for applications ([c18cd31](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c18cd31225a423eb1796586e4540e73eb3e74617))
- DAZUIC-766 - export module for applications ([0f38f47](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0f38f47ca0097815a9b6e16d79a07e48b81bb3c6))
- DAZUIC-766 - update modules after test ([9efdd1a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9efdd1a0173ed34833b57eb3f65796b54eeb3da0))
- DAZUIC-766 - update modules after test ([c23754b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c23754bb8c89392d980859c8c66ddeceb607a11e))

### Bug Fixes

- DAZUIC-688 - add mock module ([973e57f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/973e57f288fb9194c5ac720b972588d396d1dc79))
- DAZUIC-688 - bump version ([bc17d8a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bc17d8a757060c56d87acc35fbd2f446e2fdb926))
- DAZUIC-688 - delete unsused badge ([2dc8128](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2dc8128424dc3e1cd66b8b3b52cdd3dc8d902094))
- DAZUIC-688 - update pupblic api ([056944c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/056944c4bde65c08ee3cddb5713102d871a18f5b))
- DAZUIC-702 - set test-id optinal ([c0f17d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0f17d5f39a893aea7c77f45fe04f8d4f08512eb))

## [1.9.0-beta.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.8.0...v1.9.0-beta.0) (2021-10-11)

### Features

- DAZUIC-702 - add-spectator-for-easy-tests ([d3924ac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d3924acac07477e122f35db7bb9e8f056d52e638))
- DAZUIC-702 - fix icon button alignment in tables ([f3b4cb1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f3b4cb1d6fbd99a82355f43d808c3e7c102ef7d2))

### Bug Fixes

- DAZUIC-688 - add mock module ([a64db67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a64db67310cb8a03f0f2d4914b2fa2dd82dfbe17))
- DAZUIC-688 - update mocks ([53b190a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/53b190a88b18a6c024cc4d9838571e48f6fffc52))
- DAZUIC-702 - fix spectator test ([c59ef94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c59ef941f4fd34a1644ee7b4417103757476cb51))
- DQMS-107 - title autocomplete form ([3cf06ca](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3cf06ca1420f4de8d3bda9291661df872bd69242))

## [1.8.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.3...v1.8.0) (2021-10-07)

### Features

- add changelog ([c77000f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c77000f87ee3ff73811eaeb7d7eafd1510e17eac))
- add changelog ([cea95ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cea95ab538272e371513c75f8ed348202317fe64))
- add versions button ([fe1cb0f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fe1cb0f2aeee5a1b9f9a927ae94077334e136fa5))
- DAZUIC-651 add attribute data-test-id for child component in Page Process Header ([9a6ff38](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9a6ff3871dc25530d9f002fded6172f32da6cd4e))
- DAZUIC-762 add attribute data-test-id for checkbox component ([b410ff1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b410ff1ab54fc244379482b7f5f9906d43406fde))
- DAZUIC-762 add attribute data-test-id for child component in Chip component ([b9db2c9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b9db2c96098368778ca3d0a91104ec2f67b33aaf))
- DAZUIC-762 add attribute data-test-id for child component in Dropdown ([bc34f63](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bc34f63bca403c78bc6d5b9b22ab4a9db5189260))
- DAZUIC-762 add attribute data-test-id for child component in Image component ([372a42c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/372a42c6fd428942145dc0090ab6c5a31b0d0402))
- DAZUIC-762 add attribute data-test-id for child component in radio button ([abffc71](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/abffc71441ea6d02643d981fe40a26cd9f7b5ccb))
- DAZUIC-762 add attribute data-test-id for child component in Status indicator ([f0baed5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f0baed5a4af9d3387040e0cde6b5760caa4dbb65))
- DAZUIC-762 add attribute data-test-id for container component ([3d57210](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d5721068b58e1d1524130e3a389ac50b7a23100))
- DAZUIC-762 add attribute data-test-id for Filter component ([ef7161e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ef7161ed16cfab90e434260c88e7ef46eb36b3e4))
- DAZUIC-762 add attribute data-test-id for Stepper ([7d39d44](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7d39d444ce963964d9fa7bc0943aea153c63aa90))
- DAZUIC-762 add attribute data-test-id for Tab ([216c5ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/216c5ab0f8df83c54d5887bc13c55dd7c8cc2712))
- DAZUIC-762 add example of attribute data-test-id for icon component ([8cbb726](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8cbb72616d02549e893ed28e9101df643b84aef7))
- DAZUIC-762 add example of attribute data-test-id for Layout system ([63f6398](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/63f6398927324066a666bd25364d44093032e0e1))
- DAZUIC-762 add example of attribute data-test-id for list component ([4b38ef5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4b38ef50e19956310f88781e7597f7f646c78539))
- DAZUIC-762 add example of attribute data-test-id for text section ([881c6cf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/881c6cfc2e34c9ff04f0124410c756a20a27dbc9))
- DAZUIC-762 add example of data-test-id for alert component ([c0d52f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0d52f04218efb4ce5de283716dd451baa16ec4e))
- DAZUIC-762 add example of data-test-id for button component ([d74ad29](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d74ad29c0aebb09c8b7fc6b23044ae66ab97d93b))
- DAZUIC-762 add example of data-test-id for data-tree component ([02b7cf9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02b7cf94b6f4219082661b5efc77ff00f68a8e80))
- DAZUIC-762 fix data-test-id ([8a1d266](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8a1d266afddb8527cce5dd0ea058784733646bcf))
- DAZUIC-765 add attribute data-test-id for child component in form input ([839619d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839619d3f7264a9d5059128d33c9fea09b0072fb))
- Display version in welcome page ([91cc029](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/91cc029efeb155944994ccc3ddc93ae5377dbd01))

## [1.7.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.1...v1.7.3) (2021-09-29)

### Features

- DAZUIC-793 - add free text filter ([4ec3733](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4ec3733812006c66b8a4f2fba23fc536fe3038a8))

## [1.7.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.0...v1.7.1) (2021-09-16)

### Features

- DAZUIC-736 - add date type filter ([3208cc5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3208cc5ee9c91e2ff6c32666cf46daab044b8fb1))
- DAZUIC-781 - add dateRange type filter ([033cbb4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/033cbb415d86f17749aa59b5f31ff74ee67120b0))

### Bug Fixes

- some fixes for the realease ([de98731](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/de987311fe3014e078c5a8eab3d958c9798e660d))

## [1.7.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2...v1.7.0) (2021-09-09)

### Features

- DAZUIC-429 - add document for input and textarea ([7631b50](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7631b50f6e1a48d31d505ed780f2dd3397b5b849))
- DAZUIC-429 - Add FormGroup to input component ([bf75029](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf7502913426dcdf64e759d936edf4b88dc9f2e2))
- DAZUIC-542 - Create custom input component ([e373822](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e37382291b4a60c21dec4dfa0a0ff72bb91ac757))
- DAZUIC-542 - refactor icon to use font instead of svg ([d4f3807](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d4f380736424f0436415dda7288e4e4cf42763cf))
- DAZUIC-542 - update component with outdated icon ([ccf43e5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ccf43e5904fd94fe677ed2f056d1bedb818d15dd))
- DAZUIC-542 - update icon font to newest design ([81b13dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/81b13dd5b9afc457695dbb6955b6a23030bcaab8))
- DAZUIC-649 add error state to checkbox ([0189b8b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0189b8b72b7e79bb7fe6e2c98b2a7e1045a20629))
- DAZUIC-649 add error state to radio buttons ([08605b6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08605b667786a867a7cfcba284f753fb0cae8372))
- DAZUIC-649 Fix style of radio button ([42c19c7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/42c19c72bf77ef0b354cdd488b04e44c69501c6a))
- DAZUIC-656 adapt design of filter ([08a224c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08a224c43d59abfe6979351b1da5c7e0541d0858))
- DAZUIC-656 update filter design ([bf3f1cc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf3f1ccad17d6776a57ab7d0c1f990a9620d7f52))
- DAZUIC-656 Update single select filter ([9cb4602](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9cb4602d2f787ea3cfcefe4c478922973bb0b523))
- DAZUIC-674 - Create Custom Textarea component ([3967191](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3967191f1d63f6b8aba74b67d6539d39a5916fc6))
- DAZUIC-676 add type to input component ([05a2f7e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/05a2f7ede7c9690d739701a01008bb9a956fd267))
- DAZUIC-677 fix design detail in input component ([605d9f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/605d9f536e2e6945e3cddbb33e7e8e8180424d8d))
- DAZUIC-677 fix error state to all input component ([4e75f14](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4e75f141ce9c036718f5c5e6f64c0cf9c8111ec7))
- DAZUIC-722 - add error state to dropdown ([173caa0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/173caa07bf5449e71d25e179e0d5e6638dd22cd0))
- DAZUIC-722 fix error state of dropdown ([ab5b6bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ab5b6bdb8f858302af7675b52eaafe79cec2c838))
- DAZUIC-723 fix checkbox icon ([a6daf87](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a6daf87de1bf2aa43f12927c8b56d493df6e3e3f))
- DAZUIC-723 update icon set for checkbox ([99a8a8e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/99a8a8e403b63c645d045aae18adbe4a27ca7b8b))
- DAZUIC-736 Add date filter component ([1177d67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1177d67ded19a18ff81db34adc8cea0bf92bc3fa))
- DAZUIC-737 Add input filter component ([374309f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/374309f4133ff0490a503767beee5ad0319bd5ef))
- DAZUIC-738 - filtering items in Qd-Forms and Qd-Filter ([a4faa30](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a4faa3066f0fcade054dc4d9027696d158a5a7c8))
- DAZUIC-738 - update documentation ([f3010f8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f3010f8d1dedc7d90f976b921e499d76562c321d))
- DAZUIC-740 - design qd filter ([d2a348c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2a348c54f6eb46ca89385536895cd206eb13cd9))
- DAZUIC-741 - optimize filter service, new filter interfaces ([e486837](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e48683788fd9e6efa2444bad6afdec957543e4be))
- DAZUIC-744 - update Tabs, pending tasks ([5444fed](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5444fed921289a7e9ee21562d5c480bf047cb807))
- DAZUIC-776 - finalising filter for use as a beta ([4b7c49a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4b7c49a8e1995e2eb039fd285108e31d82734195))
- DAZUIC-776 - remove comment ([24da726](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/24da726a294828110bf215be2bb8c135bb339e6c))

### Bug Fixes

- css of some components ([5a8e57e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5a8e57ecabc83ca120ac59717afef14987e85ffb))
- export checkbox and radio buttons ([d042c0a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d042c0a420b7a9abecdc2c3041b402cbfc7dfc1a))
- fix backwards compatible of icon by adding old version icon. ([59395f3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/59395f3595da0b8de410d9361f24b8c9498e8bb9))

## [1.6.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.3...v1.6.2) (2021-07-16)

## [1.6.2-beta.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.2...v1.6.2-beta.3) (2021-07-15)

### Bug Fixes

- remove unnecessary logs ([8ea8da7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8ea8da748be20edafc85de5cc800bae65d7d09f6))

## [1.6.2-beta.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.1...v1.6.2-beta.2) (2021-07-15)

### Bug Fixes

- update life cicle hook ([eb2309c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/eb2309ce5e71c0b8408653a600816e9e19c35549))

## [1.6.2-beta.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.0...v1.6.2-beta.1) (2021-07-15)

## [1.6.2-beta.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.5.0...v1.6.2-beta.0) (2021-07-15)

### Features

- add approval process to inspecziune ([d53cb22](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d53cb2206cfedbfa0ef34fc402492d87a3ad0458))
- Add Docs to Modal Confirm component ([e67e1a1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e67e1a12fc78a099f413e65cf484a7660a8519d1))
- Add Modal Confirm component ([b83f27d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b83f27d9a97419ebc709c461d1f6d8660abd6bf3))
- DAZUIC-224 - add radio buttons component ([455249d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/455249d926754b5c7d6911139e83d1bf168feaf7))
- DAZUIC-224 - finalize component, update unit test, add documentation ([d8b3758](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d8b3758654b8001308d99a07824ff72a671aac1d))
- DAZUIC-224 refactor radio buttons to support formgroup ([3e426ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3e426aba9cf947f93eec997fe5627562532d51c9))
- DAZUIC-225 - add checkbox component ([2f1674d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2f1674d857b04f9a2855a8bfeb66e6926061818d))
- DAZUIC-225 - add component and styles ([ca39c35](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ca39c35d90f55710bbc777955a508422406253c7))
- DAZUIC-225 - add documentation ([e99394f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e99394fff783a00d4546f83b4a0fa8f5323867c4))
- DAZUIC-225 - add stories ([4a0c526](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4a0c5264fe0245910621240a623e804b88468b8e))
- DAZUIC-225 - add tests, clean-up ([0a98de1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0a98de1d7c1408b39fdca700d7e87857fdfbfae9))
- DAZUIC-307 - add selectbox with autocomplete component ([21ea6f3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/21ea6f35a8a1f91803afc8606b9292cdb34b08ae))
- DAZUIC-307 - update dropdown component ([7067973](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/706797370fb4dbe7501541560162f76caf44a268))
- DAZUIC-493 - update step item styles, disable active state if not valid ([9751e53](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9751e53fbb062cb8b8d3b0acd91f5b5473006064))
- DAZUIC-493 - update stepper styles ([b5d670a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b5d670a3f4f989bf4215f1060fdb54b5f14d2d09))
- DAZUIC-522 - add logic for filter status chips ([3d2fa47](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d2fa47a847e3268f9fd59a9e79a3cc8400790f4))
- DAZUIC-522 - styling filter chips ([2dac30f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2dac30f2811206ccc936660808e4006b8721f89f))
- DAZUIC-522 - update chips for filter ([1641fef](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1641fefdfd1976ac659bcd1ff2630dc3f1142c98))
- DAZUIC-523 - Quadrel-Filter | Add reset button ([7959520](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7959520e5b477e6ed0dd94345b14aa448bccddd6))
- DAZUIC-523 - Quadrel-Filter | multiple categories ([04f8530](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/04f85306755d7fac977ae654bee18e8824f54a96))
- DAZUIC-524 - add filter type boolean ([a03eefb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a03eefb34976d35b06744fc1fd47e1281bd98843))
- DAZUIC-525 - add singleSelect filter type ([a3f0e9b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a3f0e9bbcaa072549e163f4345214418552293a5))
- DAZUIC-525 - update single select behavior ([1ccc15c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ccc15cc86046e721b4c972419d0472878128d0f))
- DAZUIC-525 - update single select behavior ([159f62b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/159f62bc5f875b0c3df4b1f951a5b57d6d833ce8))
- DAZUIC-560 - create QdSwitchComponent for custom form switch ([c0ef573](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0ef573e9cbb2182d50d157eb50d5bf516494279))
- DAZUIC-603 - add custom tooltip ([c95b313](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c95b31320798ee263c8a4e7df86d63d729b3e388))
- DAZUIC-603 - add custom tooltip ([40f79d7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/40f79d70fde8f295bcc54e4a0be3d012304a9e1a))
- DAZUIC-603 - add custom tooltip ([a716811](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a7168114d10683bb052e4b90f1df807adb243ad2))
- DAZUIC-603 - add custom tooltip ([8e96a72](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e96a72fb1432aa658ee842bfd233e256f4b647c))
- DAZUIC-603 - add custom tooltip ([063b107](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/063b10791e0304b3ef673c012c0c9e0131347453))
- DAZUIC-603 - add custom tooltip ([b888e8b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b888e8b33d00df6c9d282001d2ecffc89f96c893))
- DAZUIC-603 - add custom tooltip ([55bd09f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/55bd09f24149921f499e83fa57cb8806703d8ba0))
- DAZUIC-603 - add snapshot ([941de71](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/941de715edc5cf74a459853cfd9c4f39ea7bd21c))
- DAZUIC-603 - update css for tooltip ([2998318](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/29983180c03dad49d32db561dbb43569439b7525))
- DAZUIC-603 - width calculation of PPH ([3fc8954](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3fc8954b2fb88cd4e3f27896d5da7a31173a3d53))
- DAZUIC-603 - width calculation of PPH ([2968fbb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2968fbbc53d0e73072cbdb4079c8d1bd453df1e9))
- DAZUIC-629 - add checkbox group, add filter ([0813477](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08134774b6ea10f432035cf2bf40e4432d5b6b1f))
- DAZUIC-629 - add checkboxes component ([b5d8fea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b5d8fea6caccaba1f2a1eb588a8bbc5acd0cc303))
- DAZUIC-629 - add tests ([9f2f457](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9f2f4575ed9dce4f678a1226b6e77c87a2ce72de))
- DAZUIC-647 - Add disabled state to control panel ([165c45d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/165c45d7b447b8d23f00ffb012a1b46e09261d50))
- DAZUIC-647 - Add label position to switch component ([445ebbe](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/445ebbe677770c03a41436268c24e19ae0fba788))
- DAZUIC-670 - refactor switch data model to match checkbox ([a91ef34](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a91ef3458131d40f1e8cdbb032e20bf41320cab6))
- DQMS-60 - optional-formgroup ([223b733](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/223b7336cacdd22b3f7d5983dd41d01e9bffd480))
- DQMS-60 - optional-formgroup - typo ([c021a7d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c021a7d56dda8665bc5715ab7f80a56f55a7edb5))
- DQMS-88 - support tab name change after initialized ([3458a1d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3458a1d518af582f0e9b500e7b7dad99eb4690da))
- reduce memory ([02f9fea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02f9fea9a867eee09dbcc547954f5dd840d0a4d2))
- refactor layout renderer to add support to side modal ([3a2d0f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3a2d0f57eafee54154e118a078eeff745d2b2938))
- update i18n ([fa076c0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fa076c0f351429cf01ea901400d4221aca4e79e1))
- Update Scenario for inspecziune ([ce32e72](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ce32e722c3fdd4279d61903ee6b1d6b258c26547))

### Bug Fixes

- DAZUIC-307 - fix errors and warnings in unit tests ([5d185c2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5d185c2ab0af7b7937e71a20be88ca0436f948b7))
- DAZUIC-307 - fix failing tests ([89c996a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/89c996abbca0d6ca1e88923efa107e7527b801e7))
- DAZUIC-307 - fix qd-form module after merge ([e144719](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e1447198fd6c2a60cce21e1d2c3c5bffba6c6dae))
- DAZUIC-524 - remove Hostbinding ([c2db86c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c2db86c8d622614c032fadb4ea737e821fe19c2f))
- DAZUIC-560 - add margin to switch component ([8bcb995](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8bcb9951f8ab4d6093ed03be6ff42bb48360450c))
- DAZUIC-560 - fix disabled label state of switch ([f2ffaeb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f2ffaeb2feb85210fa14ea2bb40d72274d1a4243))
- DAZUIC-642 - export master-layout-service ([1d7e8bb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d7e8bb7ae109c875e518a1d7466f22e8c1c1d2f))
- disable component story without sprint review ([ec32a1d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ec32a1d3b6851944ae5b13c29b027812a26ee8e3))
- DQMS-40 - add disabled status in stepper logic ([1ac4507](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ac45071c2bba95c701ef9cce362a01bec63f156))
- DQMS-77 -background of forms container in control panel ([396214e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/396214ecbdab3c583dea52299809e97c52f20af3))
- DQMS-89 - fix disable submit in PPH ([cecee2b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cecee2b4de7388209fa4cbeafd35b70609eb00dd))
- fix review comment ([23a82b2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/23a82b2bba52670284a6a65ceea09dc8e3a6e45a))
- fix side modal box shadow styling ([d722c93](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d722c93662c0e7eebb4ab3865f64fc3667dc89cd))
- fix side modal popup without size ([75552aa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/75552aadd6ee74ab1079affdf51a637b98de804f))
- fix side modal styling ([c034e97](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c034e972c2c1012820428278daa8b8c930f72501))
- merge conflicts ([2084594](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/208459490469d01ce7844deef35ca91067f20eae))
- merge conflicts ([cb25e6b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cb25e6bac8ee61dabc81c02f9261cdd022c4d0a9))
- panel story uses inputData instead of label ([0ddc46f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ddc46fc82c38d460575eaecf0449721f2eb3905))
- remove top border from side modal ([8dec49a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8dec49a741427b563d828b55fe4ff26ae90223ab))
- resolve merge conflics ([6997b6a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6997b6a4375ffc96a375a630868311dcfdfe1236))
- resolve merge conflicts ([0664ed3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0664ed34317118c7b1e3d117beb14169ccf2abb7))
- resolve merge conflicts ([8e51ee0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e51ee027146717959e8122572e007555a8dc012))
- update notification style ([4c7c29d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4c7c29d1cf57ec013ce2f148f8b98db99c44cb37))

## [1.5.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.4...v1.5.0) (2021-05-17)

### Features

- Add documentation for fullscreen modal ([8d6044d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8d6044de87aa6a8e1dee8048541c53931c968268))
- add scenario for inspectinue project ([158b786](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/158b786a7e8fe5de5d84d77e625d461d733c1066))
- DAZUIC-489 - update button stack styles ([b08dc22](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b08dc22ca834292cc5dccd6f383cbf508728d412))
- DAZUIC-558 - add status indicator component ([087a071](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/087a07121e97b0f0634cb13d3412b381773ffdef))
- DAZUIC-558 - add status indicator in table story ([09459e2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/09459e2f92489e20e1d8c34761b515011eadc6a1))
- DAZUIC-559 - Qaudrel UI | Anzeige Status Header ([88885dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/88885ddf4c088f62689da6ec35fd47826f067e61))
- DAZUIC-591 - Quadrel UI | Page Process Header für Modal FW ([d735ae5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d735ae54450f9ad72cd5d0f0e8a901d12016d6c4))
- DAZUIC-591 - Quadrel UI | Page Process Header für Modal FW ([49e926a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/49e926a38bd7932d61029e71a84adf5fe04791da))
- DAZUIC-595 - QdLayoutPanelProgress in Laufzeit änderbar ([58da7a8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/58da7a8a1a2b5802beddbc79dbb3d4797343c54b))
- fix fullscreen modal style ([ac4d371](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ac4d3719b457e80e529884a277df313177643046))
- layout render style comment fix ([c46e7fd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c46e7fdd5839949a0becd2c528eeee90b4cce15c))
- refactor layout system and fullwidth modal to use same renderer style ([1d0e7e7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d0e7e70e83817ef76a2c905ff431fd8efaa0e8f))
- refactor review comment of stadi scenario ([326d858](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/326d8583b6bffac2559e0fa43081bc1ab6567f04))
- refactor situnaziunform with new container toolbar ([0dcb769](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0dcb769d9949e0319dc406447f2967ab8ebb9c24))

### Bug Fixes

- build error ([783e8c2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/783e8c2529693d95b95079c0595a3ca2a7c0d38e))
- move page process header to use cases ([02a9305](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02a9305cf92b1f8a551dc0778efaa4ced9cb88c3))
- resolve merge conflicts ([8c315f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8c315f763bf84769940d5580591a7759bce67719))
- resolver merge conflicts ([c877434](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c877434313c7521344eb95a58e17db5043086bca))

## [1.4.4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.3...v1.4.4) (2021-04-30)

### Bug Fixes

- add notification service in public api ([f1425d1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1425d1fdb8e7dd141ca7b0ff91e2ac87adb0e25))
- export notification service ([09966ba](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/09966bac9952662b4b3eaa4167cc7bbd4ef1cda0))

## [1.4.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.2...v1.4.3) (2021-04-30)

### Features

- DAZUIC-547 - use new Icon in table inline menu, update qdRow directive ([33d895e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/33d895ec8d9a0937cc370eb4347a5f637e353f70))

## [1.4.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.1...v1.4.2) (2021-04-29)

### Features

- add example scenario for Situaziunforms ([bd6b2df](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bd6b2dffb56b0e49404b5c51bd16d8bc79cc7055))
- add stabi scenarios ([ab2147a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ab2147a90c1dead0a5cd4f2308309bbed0e100c4))
- DAZUIC-546 - add action Area in toolbar ([bf82b7f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf82b7f054139be7847a953ea433390bba3eec57))
- DAZUIC-546 - fix import ([ef0a0ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ef0a0ab6ff4c348d0c82ab4f1f6f9704e76eff32))

## [1.4.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.0...v1.4.1) (2021-04-26)

### Bug Fixes

- change lang tag in html update website language ([2a5fa76](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2a5fa7675697cc8ec1440d47411184df53aa3608))

## [1.4.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0...v1.4.0) (2021-04-26)

### Features

- add components for header type toolbar ([71a0fac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/71a0fac83f448b90779ea683a51fc3431e1612c7))
- adjust toolbar-top height ([7eb3467](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7eb3467430a471edf586765432bf710de6e8757f))
- DAZUIC-520 - add multiselect filter type ([3d7a41e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d7a41e321429d7590f145794f9b444a74b3b852))
- DAZUIC-521, DAZUIC-545 - update container toolbar ([55507b9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/55507b914d982faba72beec78d80d5c233bfb683))
- DAZUIC-528 - add interceptor service, add components ([15399bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/15399bd96296fcd41590507c918f0c6b5748a33a))
- DAZUIC-541 - add modal notitfications ([660049d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/660049d461b5762e5fcf9f668b04ff51a05d295b))
- DAZUIC-573 - Add documentation for Notifications ([1ef301a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ef301a8e1c1ea2e359d8dff53d3f95c79d3e459))
- padding adjustment in container-toolbar ([cd7e6de](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cd7e6de7868ff6bb01bb3a9068b95e6fd367e285))
- remove toolbarType, adjust toolbar styling with flexbox ([624c0b0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/624c0b0a994805cb6ec3a0b650f40a3dbe782900))
- remove unused code, add snapshot tests ([b200152](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b20015252e151608767f1b86c89f5b928ca601ca))

## [1.3.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0-beta.3...v1.3.0) (2021-04-01)

### Features

- Add filter panel logic ([e0946a8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e0946a8fbfb5902f35f30afbb5910271ae0bed0e))
- DAZUIC-408 - add search button to master layout header ([531d01a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/531d01a1faccdea65d8891a794124d031551a97f))
- DAZUIC-408 - new style for search field ([b2833dc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b2833dcf7bede4d493eb33b77eff52dee300061b))
- DAZUIC-408 - update mobile header widget ([30e1c1a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/30e1c1af48a26c76a5b653a70608cc14d8ae4a56))
- DAZUIC-408 - use translate service in header widget automatically ([601450f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/601450f9453b4c985a3d90a89bb38d012707e294))
- restyle filter panel and remove unused input ([65c4f51](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/65c4f5104415885bb4e4a83f2c594479f0153835))

### Bug Fixes

- DQMS-76, DQMS-71, DQMS-20, DAZUIC-136, DQMS-34 ([8829aaf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8829aafe3271d4ab37d8c88fe0e4c7fe59056afa))

## [1.3.0-beta.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0-beta.2...v1.3.0-beta.3) (2021-03-24)

### Features

- add and update stories with component `exception` ([0b3d3db](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0b3d3dbe8431dde2477c7ec65c79330ccef60cb1))
- adjust background-color of container-content-container in panel ([5547ca6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5547ca6e37e571fe20296e672596a6eb70ed335b))
- create component `exception` to replace alert ([af13d67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/af13d673066b331de4c62428e53080a5b948ec76))
- create tests and mocks for component `exception` ([fc12177](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fc121774af4ecf749ac0a16791a3e80386f02231))
- DAZUIC-481 - add data tree, visualization only, 2 levels ([1825c1f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1825c1f78b91bd6bdce821334c22d8165d1cb64e))
- Refactor container content detection to service to enable communication with Grandchild ([513188f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/513188f8c50b2f1f535e82729ae9a33ca5520295))
- update colors ([00c424e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/00c424e01183f9fd34d547f4916f842c7f8d469f))
- update ICS2 story ([e19217a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e19217a1249cf5df06807ff4230f78f1a9bfc8d8))
- update styling ([c9faeea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9faeea0f5303185728d5dfc7e8abe491d85dc44))
- update tests ([f24fb5a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f24fb5aa470455801154cd860999c2b22084701b))

### Bug Fixes

- fix master layout banner when no environment is provided ([7c7cf5b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7c7cf5bdbc27537895b9f2ce3af5f0f6d1ef676f))

## [1.3.0-beta.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.2.4...v1.3.0-beta.2) (2021-03-17)

### Features

- add button stack ([226165c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/226165c0f79ac5789c6c217c732aaf1760ecc595))
- add component ([45ad48b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/45ad48b32921d86ee655a8894faabaf0528d9bd6))
- add defaultTabIndex to be able to show not only first tab by default ([f430bad](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f430bad02caf29acee30f6add02f094e0a966088))
- add directive qdActiveContentTab to render content based on tab in main area ([39fec41](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/39fec41b8c9f03fd32d51e45d9bbe700436f4cea))
- add header navigation ([72167fa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/72167fa2ff83056f4cfe7f765ee5ef6dea060bee))
- add info header to fullscreen modal ([0d18cc1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0d18cc1ba569bacfca93fa44a7f0cce3aa018cf5))
- add left control panel to fullscreen modal container ([bde8231](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bde82312af13efba455360305c6718900747891f))
- add story for forms ([69475f6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/69475f68117fb3a1601792f5d34e367f58b42584))
- add styles ([d7deda2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d7deda2f28d1390a184073d63c0459951715ab14))
- add styles, add unit test, add documentation add navigation to ics2 story ([82fcfe2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/82fcfe257f13ecf532506145c480c7e35cb30158))
- change parameter of directive qdActiveContentTab to object, add documentation ([31fddf2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/31fddf24b1738abd23f2ee5bfc9cb06f2f9fdc29))
- change status change error behavior ([f1b8a94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1b8a94526d2fae7cb128adccbef62f328d6bfcc))
- clean-up ([a937023](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a93702365847bec951c91700a30f19cd42cd9173))
- conditional rendering active tab ([839bd91](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839bd914ed4a8792f6ada5d12d0c4ea6e841578e))
- replace buttons to enable/disable button "Nächstes" with knobs-functionality ([5c200f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5c200f01200de2288dbd03ede9f7620385c14648))
- resolve merge conflicts ([5e2b3be](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5e2b3be63bc9d377c704ba38c359954da3328a6d))
- some updates ([c9dc421](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9dc4214c26b1ab479ecd0865cf619d93c9de1a3))
- tabs without action area ([2b2a738](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2b2a73833591677888aee50588505cba5ad8419f))
- update container mock ([6739317](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6739317516c303e3f327e828a4deacb7e657d94e))
- update ics2 story ([0de45d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0de45d5406f802ae6caa1719cd4e0df80d67baad))

### Bug Fixes

- add defaults, add checks, add docs ([3af2de2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3af2de2ca8432b69c92a66ae33e238a56d4697ab))
- coverage for unit tests ([d18396e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d18396ee18f58adbd2d3feaea548d26f7060577d))
- create workaround for error `ExpressionChangedAfterHasBeenCheckedError` ([785fb43](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/785fb435db1a201dab0666fb5f66d58de34df5d3))
- data model for fullScreen modal ([b2d2b62](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b2d2b6290e879bbdf024ad5f0c70996850179aa3))
- fix alignment of content and header in fullscreen modal by add dynamic padding right. ([d705ce6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d705ce69fa429cb95fb161694439ac56da423d9f))
- fix info modal style in fullscreen modal ([0ccb5f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ccb5f55733c96155cbbdf20f439aaceea393b0f))
- fix style in fullscreen modal panel ([148200b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/148200ba0775b3067ba0082291b33712fc58a435))
- focus state ([57131f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/57131f730619ed09c16399b9b5c83c1fbbe38b8d))
- linting errors ([f954dd9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f954dd99b9b1b140c47c69cdeea067913592b7a3))
- re-format mdx for forms conatiner ([fba4a82](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fba4a82deb6f469867e4c893e619f18a8fb85317))
- remove material form mock ([d2f78bf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2f78bfd322cae4131e9b750e4aa34cdb0a25754))
- update code style ([00548f9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/00548f9cbb473940f908885728e4d41daeb91f7a))

## [1.9.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.0...v1.9.1) (2021-10-22)

### Features

- DAZUIC-703 - update master layout mock ([ae91cb9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ae91cb95465c7416e7350a37a3c637483e594206))

### Bug Fixes

- DAZUIC-702 - clean-up changelog ([92a7be7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/92a7be7cef426bcfbc0ca7f846675ac5228fb9ca))

## [1.9.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.0-beta.0...v1.9.0) (2021-10-19)

### Features

- DAZUIC-589 - clean-up exports ([75d1de8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/75d1de8dbfad5d68efa66942e046ff23c6d13c42))
- DAZUIC-766 - export module for applications ([c18cd31](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c18cd31225a423eb1796586e4540e73eb3e74617))
- DAZUIC-766 - export module for applications ([0f38f47](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0f38f47ca0097815a9b6e16d79a07e48b81bb3c6))
- DAZUIC-766 - update modules after test ([9efdd1a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9efdd1a0173ed34833b57eb3f65796b54eeb3da0))
- DAZUIC-766 - update modules after test ([c23754b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c23754bb8c89392d980859c8c66ddeceb607a11e))

### Bug Fixes

- DAZUIC-688 - add mock module ([973e57f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/973e57f288fb9194c5ac720b972588d396d1dc79))
- DAZUIC-688 - bump version ([bc17d8a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bc17d8a757060c56d87acc35fbd2f446e2fdb926))
- DAZUIC-688 - delete unsused badge ([2dc8128](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2dc8128424dc3e1cd66b8b3b52cdd3dc8d902094))
- DAZUIC-688 - update pupblic api ([056944c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/056944c4bde65c08ee3cddb5713102d871a18f5b))
- DAZUIC-702 - set test-id optinal ([c0f17d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0f17d5f39a893aea7c77f45fe04f8d4f08512eb))

## [1.9.0-beta.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.8.0...v1.9.0-beta.0) (2021-10-11)

### Features

- DAZUIC-702 - add-spectator-for-easy-tests ([d3924ac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d3924acac07477e122f35db7bb9e8f056d52e638))
- DAZUIC-702 - fix icon button alignment in tables ([f3b4cb1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f3b4cb1d6fbd99a82355f43d808c3e7c102ef7d2))

### Bug Fixes

- DAZUIC-688 - add mock module ([a64db67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a64db67310cb8a03f0f2d4914b2fa2dd82dfbe17))
- DAZUIC-688 - update mocks ([53b190a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/53b190a88b18a6c024cc4d9838571e48f6fffc52))
- DAZUIC-702 - fix spectator test ([c59ef94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c59ef941f4fd34a1644ee7b4417103757476cb51))
- DQMS-107 - title autocomplete form ([3cf06ca](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3cf06ca1420f4de8d3bda9291661df872bd69242))

## [1.8.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.3...v1.8.0) (2021-10-07)

### Features

- add changelog ([c77000f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c77000f87ee3ff73811eaeb7d7eafd1510e17eac))
- add changelog ([cea95ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cea95ab538272e371513c75f8ed348202317fe64))
- add versions button ([fe1cb0f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fe1cb0f2aeee5a1b9f9a927ae94077334e136fa5))
- DAZUIC-651 add attribute data-test-id for child component in Page Process Header ([9a6ff38](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9a6ff3871dc25530d9f002fded6172f32da6cd4e))
- DAZUIC-762 add attribute data-test-id for checkbox component ([b410ff1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b410ff1ab54fc244379482b7f5f9906d43406fde))
- DAZUIC-762 add attribute data-test-id for child component in Chip component ([b9db2c9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b9db2c96098368778ca3d0a91104ec2f67b33aaf))
- DAZUIC-762 add attribute data-test-id for child component in Dropdown ([bc34f63](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bc34f63bca403c78bc6d5b9b22ab4a9db5189260))
- DAZUIC-762 add attribute data-test-id for child component in Image component ([372a42c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/372a42c6fd428942145dc0090ab6c5a31b0d0402))
- DAZUIC-762 add attribute data-test-id for child component in radio button ([abffc71](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/abffc71441ea6d02643d981fe40a26cd9f7b5ccb))
- DAZUIC-762 add attribute data-test-id for child component in Status indicator ([f0baed5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f0baed5a4af9d3387040e0cde6b5760caa4dbb65))
- DAZUIC-762 add attribute data-test-id for container component ([3d57210](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d5721068b58e1d1524130e3a389ac50b7a23100))
- DAZUIC-762 add attribute data-test-id for Filter component ([ef7161e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ef7161ed16cfab90e434260c88e7ef46eb36b3e4))
- DAZUIC-762 add attribute data-test-id for Stepper ([7d39d44](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7d39d444ce963964d9fa7bc0943aea153c63aa90))
- DAZUIC-762 add attribute data-test-id for Tab ([216c5ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/216c5ab0f8df83c54d5887bc13c55dd7c8cc2712))
- DAZUIC-762 add example of attribute data-test-id for icon component ([8cbb726](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8cbb72616d02549e893ed28e9101df643b84aef7))
- DAZUIC-762 add example of attribute data-test-id for Layout system ([63f6398](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/63f6398927324066a666bd25364d44093032e0e1))
- DAZUIC-762 add example of attribute data-test-id for list component ([4b38ef5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4b38ef50e19956310f88781e7597f7f646c78539))
- DAZUIC-762 add example of attribute data-test-id for text section ([881c6cf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/881c6cfc2e34c9ff04f0124410c756a20a27dbc9))
- DAZUIC-762 add example of data-test-id for alert component ([c0d52f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0d52f04218efb4ce5de283716dd451baa16ec4e))
- DAZUIC-762 add example of data-test-id for button component ([d74ad29](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d74ad29c0aebb09c8b7fc6b23044ae66ab97d93b))
- DAZUIC-762 add example of data-test-id for data-tree component ([02b7cf9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02b7cf94b6f4219082661b5efc77ff00f68a8e80))
- DAZUIC-762 fix data-test-id ([8a1d266](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8a1d266afddb8527cce5dd0ea058784733646bcf))
- DAZUIC-765 add attribute data-test-id for child component in form input ([839619d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839619d3f7264a9d5059128d33c9fea09b0072fb))
- Display version in welcome page ([91cc029](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/91cc029efeb155944994ccc3ddc93ae5377dbd01))

## [1.7.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.1...v1.7.3) (2021-09-29)

### Features

- DAZUIC-793 - add free text filter ([4ec3733](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4ec3733812006c66b8a4f2fba23fc536fe3038a8))

## [1.7.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.0...v1.7.1) (2021-09-16)

### Features

- DAZUIC-736 - add date type filter ([3208cc5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3208cc5ee9c91e2ff6c32666cf46daab044b8fb1))
- DAZUIC-781 - add dateRange type filter ([033cbb4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/033cbb415d86f17749aa59b5f31ff74ee67120b0))

### Bug Fixes

- some fixes for the realease ([de98731](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/de987311fe3014e078c5a8eab3d958c9798e660d))

## [1.7.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2...v1.7.0) (2021-09-09)

### Features

- DAZUIC-429 - add document for input and textarea ([7631b50](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7631b50f6e1a48d31d505ed780f2dd3397b5b849))
- DAZUIC-429 - Add FormGroup to input component ([bf75029](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf7502913426dcdf64e759d936edf4b88dc9f2e2))
- DAZUIC-542 - Create custom input component ([e373822](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e37382291b4a60c21dec4dfa0a0ff72bb91ac757))
- DAZUIC-542 - refactor icon to use font instead of svg ([d4f3807](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d4f380736424f0436415dda7288e4e4cf42763cf))
- DAZUIC-542 - update component with outdated icon ([ccf43e5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ccf43e5904fd94fe677ed2f056d1bedb818d15dd))
- DAZUIC-542 - update icon font to newest design ([81b13dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/81b13dd5b9afc457695dbb6955b6a23030bcaab8))
- DAZUIC-649 add error state to checkbox ([0189b8b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0189b8b72b7e79bb7fe6e2c98b2a7e1045a20629))
- DAZUIC-649 add error state to radio buttons ([08605b6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08605b667786a867a7cfcba284f753fb0cae8372))
- DAZUIC-649 Fix style of radio button ([42c19c7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/42c19c72bf77ef0b354cdd488b04e44c69501c6a))
- DAZUIC-656 adapt design of filter ([08a224c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08a224c43d59abfe6979351b1da5c7e0541d0858))
- DAZUIC-656 update filter design ([bf3f1cc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf3f1ccad17d6776a57ab7d0c1f990a9620d7f52))
- DAZUIC-656 Update single select filter ([9cb4602](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9cb4602d2f787ea3cfcefe4c478922973bb0b523))
- DAZUIC-674 - Create Custom Textarea component ([3967191](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3967191f1d63f6b8aba74b67d6539d39a5916fc6))
- DAZUIC-676 add type to input component ([05a2f7e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/05a2f7ede7c9690d739701a01008bb9a956fd267))
- DAZUIC-677 fix design detail in input component ([605d9f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/605d9f536e2e6945e3cddbb33e7e8e8180424d8d))
- DAZUIC-677 fix error state to all input component ([4e75f14](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4e75f141ce9c036718f5c5e6f64c0cf9c8111ec7))
- DAZUIC-722 - add error state to dropdown ([173caa0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/173caa07bf5449e71d25e179e0d5e6638dd22cd0))
- DAZUIC-722 fix error state of dropdown ([ab5b6bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ab5b6bdb8f858302af7675b52eaafe79cec2c838))
- DAZUIC-723 fix checkbox icon ([a6daf87](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a6daf87de1bf2aa43f12927c8b56d493df6e3e3f))
- DAZUIC-723 update icon set for checkbox ([99a8a8e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/99a8a8e403b63c645d045aae18adbe4a27ca7b8b))
- DAZUIC-736 Add date filter component ([1177d67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1177d67ded19a18ff81db34adc8cea0bf92bc3fa))
- DAZUIC-737 Add input filter component ([374309f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/374309f4133ff0490a503767beee5ad0319bd5ef))
- DAZUIC-738 - filtering items in Qd-Forms and Qd-Filter ([a4faa30](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a4faa3066f0fcade054dc4d9027696d158a5a7c8))
- DAZUIC-738 - update documentation ([f3010f8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f3010f8d1dedc7d90f976b921e499d76562c321d))
- DAZUIC-740 - design qd filter ([d2a348c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2a348c54f6eb46ca89385536895cd206eb13cd9))
- DAZUIC-741 - optimize filter service, new filter interfaces ([e486837](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e48683788fd9e6efa2444bad6afdec957543e4be))
- DAZUIC-744 - update Tabs, pending tasks ([5444fed](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5444fed921289a7e9ee21562d5c480bf047cb807))
- DAZUIC-776 - finalising filter for use as a beta ([4b7c49a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4b7c49a8e1995e2eb039fd285108e31d82734195))
- DAZUIC-776 - remove comment ([24da726](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/24da726a294828110bf215be2bb8c135bb339e6c))

### Bug Fixes

- css of some components ([5a8e57e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5a8e57ecabc83ca120ac59717afef14987e85ffb))
- export checkbox and radio buttons ([d042c0a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d042c0a420b7a9abecdc2c3041b402cbfc7dfc1a))
- fix backwards compatible of icon by adding old version icon. ([59395f3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/59395f3595da0b8de410d9361f24b8c9498e8bb9))

## [1.6.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.3...v1.6.2) (2021-07-16)

## [1.6.2-beta.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.2...v1.6.2-beta.3) (2021-07-15)

### Bug Fixes

- remove unnecessary logs ([8ea8da7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8ea8da748be20edafc85de5cc800bae65d7d09f6))

## [1.6.2-beta.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.1...v1.6.2-beta.2) (2021-07-15)

### Bug Fixes

- update life cicle hook ([eb2309c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/eb2309ce5e71c0b8408653a600816e9e19c35549))

## [1.6.2-beta.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.0...v1.6.2-beta.1) (2021-07-15)

## [1.6.2-beta.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.5.0...v1.6.2-beta.0) (2021-07-15)

### Features

- add approval process to inspecziune ([d53cb22](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d53cb2206cfedbfa0ef34fc402492d87a3ad0458))
- Add Docs to Modal Confirm component ([e67e1a1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e67e1a12fc78a099f413e65cf484a7660a8519d1))
- Add Modal Confirm component ([b83f27d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b83f27d9a97419ebc709c461d1f6d8660abd6bf3))
- DAZUIC-224 - add radio buttons component ([455249d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/455249d926754b5c7d6911139e83d1bf168feaf7))
- DAZUIC-224 - finalize component, update unit test, add documentation ([d8b3758](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d8b3758654b8001308d99a07824ff72a671aac1d))
- DAZUIC-224 refactor radio buttons to support formgroup ([3e426ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3e426aba9cf947f93eec997fe5627562532d51c9))
- DAZUIC-225 - add checkbox component ([2f1674d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2f1674d857b04f9a2855a8bfeb66e6926061818d))
- DAZUIC-225 - add component and styles ([ca39c35](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ca39c35d90f55710bbc777955a508422406253c7))
- DAZUIC-225 - add documentation ([e99394f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e99394fff783a00d4546f83b4a0fa8f5323867c4))
- DAZUIC-225 - add stories ([4a0c526](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4a0c5264fe0245910621240a623e804b88468b8e))
- DAZUIC-225 - add tests, clean-up ([0a98de1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0a98de1d7c1408b39fdca700d7e87857fdfbfae9))
- DAZUIC-307 - add selectbox with autocomplete component ([21ea6f3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/21ea6f35a8a1f91803afc8606b9292cdb34b08ae))
- DAZUIC-307 - update dropdown component ([7067973](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/706797370fb4dbe7501541560162f76caf44a268))
- DAZUIC-493 - update step item styles, disable active state if not valid ([9751e53](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9751e53fbb062cb8b8d3b0acd91f5b5473006064))
- DAZUIC-493 - update stepper styles ([b5d670a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b5d670a3f4f989bf4215f1060fdb54b5f14d2d09))
- DAZUIC-522 - add logic for filter status chips ([3d2fa47](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d2fa47a847e3268f9fd59a9e79a3cc8400790f4))
- DAZUIC-522 - styling filter chips ([2dac30f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2dac30f2811206ccc936660808e4006b8721f89f))
- DAZUIC-522 - update chips for filter ([1641fef](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1641fefdfd1976ac659bcd1ff2630dc3f1142c98))
- DAZUIC-523 - Quadrel-Filter | Add reset button ([7959520](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7959520e5b477e6ed0dd94345b14aa448bccddd6))
- DAZUIC-523 - Quadrel-Filter | multiple categories ([04f8530](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/04f85306755d7fac977ae654bee18e8824f54a96))
- DAZUIC-524 - add filter type boolean ([a03eefb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a03eefb34976d35b06744fc1fd47e1281bd98843))
- DAZUIC-525 - add singleSelect filter type ([a3f0e9b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a3f0e9bbcaa072549e163f4345214418552293a5))
- DAZUIC-525 - update single select behavior ([1ccc15c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ccc15cc86046e721b4c972419d0472878128d0f))
- DAZUIC-525 - update single select behavior ([159f62b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/159f62bc5f875b0c3df4b1f951a5b57d6d833ce8))
- DAZUIC-560 - create QdSwitchComponent for custom form switch ([c0ef573](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0ef573e9cbb2182d50d157eb50d5bf516494279))
- DAZUIC-603 - add custom tooltip ([c95b313](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c95b31320798ee263c8a4e7df86d63d729b3e388))
- DAZUIC-603 - add custom tooltip ([40f79d7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/40f79d70fde8f295bcc54e4a0be3d012304a9e1a))
- DAZUIC-603 - add custom tooltip ([a716811](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a7168114d10683bb052e4b90f1df807adb243ad2))
- DAZUIC-603 - add custom tooltip ([8e96a72](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e96a72fb1432aa658ee842bfd233e256f4b647c))
- DAZUIC-603 - add custom tooltip ([063b107](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/063b10791e0304b3ef673c012c0c9e0131347453))
- DAZUIC-603 - add custom tooltip ([b888e8b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b888e8b33d00df6c9d282001d2ecffc89f96c893))
- DAZUIC-603 - add custom tooltip ([55bd09f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/55bd09f24149921f499e83fa57cb8806703d8ba0))
- DAZUIC-603 - add snapshot ([941de71](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/941de715edc5cf74a459853cfd9c4f39ea7bd21c))
- DAZUIC-603 - update css for tooltip ([2998318](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/29983180c03dad49d32db561dbb43569439b7525))
- DAZUIC-603 - width calculation of PPH ([3fc8954](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3fc8954b2fb88cd4e3f27896d5da7a31173a3d53))
- DAZUIC-603 - width calculation of PPH ([2968fbb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2968fbbc53d0e73072cbdb4079c8d1bd453df1e9))
- DAZUIC-629 - add checkbox group, add filter ([0813477](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08134774b6ea10f432035cf2bf40e4432d5b6b1f))
- DAZUIC-629 - add checkboxes component ([b5d8fea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b5d8fea6caccaba1f2a1eb588a8bbc5acd0cc303))
- DAZUIC-629 - add tests ([9f2f457](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9f2f4575ed9dce4f678a1226b6e77c87a2ce72de))
- DAZUIC-647 - Add disabled state to control panel ([165c45d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/165c45d7b447b8d23f00ffb012a1b46e09261d50))
- DAZUIC-647 - Add label position to switch component ([445ebbe](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/445ebbe677770c03a41436268c24e19ae0fba788))
- DAZUIC-670 - refactor switch data model to match checkbox ([a91ef34](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a91ef3458131d40f1e8cdbb032e20bf41320cab6))
- DQMS-60 - optional-formgroup ([223b733](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/223b7336cacdd22b3f7d5983dd41d01e9bffd480))
- DQMS-60 - optional-formgroup - typo ([c021a7d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c021a7d56dda8665bc5715ab7f80a56f55a7edb5))
- DQMS-88 - support tab name change after initialized ([3458a1d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3458a1d518af582f0e9b500e7b7dad99eb4690da))
- reduce memory ([02f9fea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02f9fea9a867eee09dbcc547954f5dd840d0a4d2))
- refactor layout renderer to add support to side modal ([3a2d0f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3a2d0f57eafee54154e118a078eeff745d2b2938))
- update i18n ([fa076c0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fa076c0f351429cf01ea901400d4221aca4e79e1))
- Update Scenario for inspecziune ([ce32e72](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ce32e722c3fdd4279d61903ee6b1d6b258c26547))

### Bug Fixes

- DAZUIC-307 - fix errors and warnings in unit tests ([5d185c2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5d185c2ab0af7b7937e71a20be88ca0436f948b7))
- DAZUIC-307 - fix failing tests ([89c996a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/89c996abbca0d6ca1e88923efa107e7527b801e7))
- DAZUIC-307 - fix qd-form module after merge ([e144719](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e1447198fd6c2a60cce21e1d2c3c5bffba6c6dae))
- DAZUIC-524 - remove Hostbinding ([c2db86c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c2db86c8d622614c032fadb4ea737e821fe19c2f))
- DAZUIC-560 - add margin to switch component ([8bcb995](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8bcb9951f8ab4d6093ed03be6ff42bb48360450c))
- DAZUIC-560 - fix disabled label state of switch ([f2ffaeb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f2ffaeb2feb85210fa14ea2bb40d72274d1a4243))
- DAZUIC-642 - export master-layout-service ([1d7e8bb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d7e8bb7ae109c875e518a1d7466f22e8c1c1d2f))
- disable component story without sprint review ([ec32a1d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ec32a1d3b6851944ae5b13c29b027812a26ee8e3))
- DQMS-40 - add disabled status in stepper logic ([1ac4507](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ac45071c2bba95c701ef9cce362a01bec63f156))
- DQMS-77 -background of forms container in control panel ([396214e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/396214ecbdab3c583dea52299809e97c52f20af3))
- DQMS-89 - fix disable submit in PPH ([cecee2b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cecee2b4de7388209fa4cbeafd35b70609eb00dd))
- fix review comment ([23a82b2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/23a82b2bba52670284a6a65ceea09dc8e3a6e45a))
- fix side modal box shadow styling ([d722c93](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d722c93662c0e7eebb4ab3865f64fc3667dc89cd))
- fix side modal popup without size ([75552aa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/75552aadd6ee74ab1079affdf51a637b98de804f))
- fix side modal styling ([c034e97](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c034e972c2c1012820428278daa8b8c930f72501))
- merge conflicts ([2084594](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/208459490469d01ce7844deef35ca91067f20eae))
- merge conflicts ([cb25e6b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cb25e6bac8ee61dabc81c02f9261cdd022c4d0a9))
- panel story uses inputData instead of label ([0ddc46f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ddc46fc82c38d460575eaecf0449721f2eb3905))
- remove top border from side modal ([8dec49a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8dec49a741427b563d828b55fe4ff26ae90223ab))
- resolve merge conflics ([6997b6a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6997b6a4375ffc96a375a630868311dcfdfe1236))
- resolve merge conflicts ([0664ed3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0664ed34317118c7b1e3d117beb14169ccf2abb7))
- resolve merge conflicts ([8e51ee0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e51ee027146717959e8122572e007555a8dc012))
- update notification style ([4c7c29d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4c7c29d1cf57ec013ce2f148f8b98db99c44cb37))

## [1.5.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.4...v1.5.0) (2021-05-17)

### Features

- Add documentation for fullscreen modal ([8d6044d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8d6044de87aa6a8e1dee8048541c53931c968268))
- add scenario for inspectinue project ([158b786](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/158b786a7e8fe5de5d84d77e625d461d733c1066))
- DAZUIC-489 - update button stack styles ([b08dc22](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b08dc22ca834292cc5dccd6f383cbf508728d412))
- DAZUIC-558 - add status indicator component ([087a071](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/087a07121e97b0f0634cb13d3412b381773ffdef))
- DAZUIC-558 - add status indicator in table story ([09459e2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/09459e2f92489e20e1d8c34761b515011eadc6a1))
- DAZUIC-559 - Qaudrel UI | Anzeige Status Header ([88885dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/88885ddf4c088f62689da6ec35fd47826f067e61))
- DAZUIC-591 - Quadrel UI | Page Process Header für Modal FW ([d735ae5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d735ae54450f9ad72cd5d0f0e8a901d12016d6c4))
- DAZUIC-591 - Quadrel UI | Page Process Header für Modal FW ([49e926a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/49e926a38bd7932d61029e71a84adf5fe04791da))
- DAZUIC-595 - QdLayoutPanelProgress in Laufzeit änderbar ([58da7a8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/58da7a8a1a2b5802beddbc79dbb3d4797343c54b))
- fix fullscreen modal style ([ac4d371](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ac4d3719b457e80e529884a277df313177643046))
- layout render style comment fix ([c46e7fd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c46e7fdd5839949a0becd2c528eeee90b4cce15c))
- refactor layout system and fullwidth modal to use same renderer style ([1d0e7e7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d0e7e70e83817ef76a2c905ff431fd8efaa0e8f))
- refactor review comment of stadi scenario ([326d858](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/326d8583b6bffac2559e0fa43081bc1ab6567f04))
- refactor situnaziunform with new container toolbar ([0dcb769](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0dcb769d9949e0319dc406447f2967ab8ebb9c24))

### Bug Fixes

- build error ([783e8c2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/783e8c2529693d95b95079c0595a3ca2a7c0d38e))
- move page process header to use cases ([02a9305](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02a9305cf92b1f8a551dc0778efaa4ced9cb88c3))
- resolve merge conflicts ([8c315f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8c315f763bf84769940d5580591a7759bce67719))
- resolver merge conflicts ([c877434](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c877434313c7521344eb95a58e17db5043086bca))

## [1.4.4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.3...v1.4.4) (2021-04-30)

### Bug Fixes

- add notification service in public api ([f1425d1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1425d1fdb8e7dd141ca7b0ff91e2ac87adb0e25))
- export notification service ([09966ba](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/09966bac9952662b4b3eaa4167cc7bbd4ef1cda0))

## [1.4.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.2...v1.4.3) (2021-04-30)

### Features

- DAZUIC-547 - use new Icon in table inline menu, update qdRow directive ([33d895e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/33d895ec8d9a0937cc370eb4347a5f637e353f70))

## [1.4.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.1...v1.4.2) (2021-04-29)

### Features

- add example scenario for Situaziunforms ([bd6b2df](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bd6b2dffb56b0e49404b5c51bd16d8bc79cc7055))
- add stabi scenarios ([ab2147a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ab2147a90c1dead0a5cd4f2308309bbed0e100c4))
- DAZUIC-546 - add action Area in toolbar ([bf82b7f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf82b7f054139be7847a953ea433390bba3eec57))
- DAZUIC-546 - fix import ([ef0a0ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ef0a0ab6ff4c348d0c82ab4f1f6f9704e76eff32))

## [1.4.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.0...v1.4.1) (2021-04-26)

### Bug Fixes

- change lang tag in html update website language ([2a5fa76](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2a5fa7675697cc8ec1440d47411184df53aa3608))

## [1.4.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0...v1.4.0) (2021-04-26)

### Features

- add components for header type toolbar ([71a0fac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/71a0fac83f448b90779ea683a51fc3431e1612c7))
- adjust toolbar-top height ([7eb3467](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7eb3467430a471edf586765432bf710de6e8757f))
- DAZUIC-520 - add multiselect filter type ([3d7a41e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d7a41e321429d7590f145794f9b444a74b3b852))
- DAZUIC-521, DAZUIC-545 - update container toolbar ([55507b9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/55507b914d982faba72beec78d80d5c233bfb683))
- DAZUIC-528 - add interceptor service, add components ([15399bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/15399bd96296fcd41590507c918f0c6b5748a33a))
- DAZUIC-541 - add modal notitfications ([660049d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/660049d461b5762e5fcf9f668b04ff51a05d295b))
- DAZUIC-573 - Add documentation for Notifications ([1ef301a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ef301a8e1c1ea2e359d8dff53d3f95c79d3e459))
- padding adjustment in container-toolbar ([cd7e6de](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cd7e6de7868ff6bb01bb3a9068b95e6fd367e285))
- remove toolbarType, adjust toolbar styling with flexbox ([624c0b0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/624c0b0a994805cb6ec3a0b650f40a3dbe782900))
- remove unused code, add snapshot tests ([b200152](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b20015252e151608767f1b86c89f5b928ca601ca))

## [1.3.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0-beta.3...v1.3.0) (2021-04-01)

### Features

- Add filter panel logic ([e0946a8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e0946a8fbfb5902f35f30afbb5910271ae0bed0e))
- DAZUIC-408 - add search button to master layout header ([531d01a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/531d01a1faccdea65d8891a794124d031551a97f))
- DAZUIC-408 - new style for search field ([b2833dc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b2833dcf7bede4d493eb33b77eff52dee300061b))
- DAZUIC-408 - update mobile header widget ([30e1c1a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/30e1c1af48a26c76a5b653a70608cc14d8ae4a56))
- DAZUIC-408 - use translate service in header widget automatically ([601450f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/601450f9453b4c985a3d90a89bb38d012707e294))
- restyle filter panel and remove unused input ([65c4f51](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/65c4f5104415885bb4e4a83f2c594479f0153835))

### Bug Fixes

- DQMS-76, DQMS-71, DQMS-20, DAZUIC-136, DQMS-34 ([8829aaf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8829aafe3271d4ab37d8c88fe0e4c7fe59056afa))

## [1.3.0-beta.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0-beta.2...v1.3.0-beta.3) (2021-03-24)

### Features

- add and update stories with component `exception` ([0b3d3db](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0b3d3dbe8431dde2477c7ec65c79330ccef60cb1))
- adjust background-color of container-content-container in panel ([5547ca6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5547ca6e37e571fe20296e672596a6eb70ed335b))
- create component `exception` to replace alert ([af13d67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/af13d673066b331de4c62428e53080a5b948ec76))
- create tests and mocks for component `exception` ([fc12177](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fc121774af4ecf749ac0a16791a3e80386f02231))
- DAZUIC-481 - add data tree, visualization only, 2 levels ([1825c1f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1825c1f78b91bd6bdce821334c22d8165d1cb64e))
- Refactor container content detection to service to enable communication with Grandchild ([513188f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/513188f8c50b2f1f535e82729ae9a33ca5520295))
- update colors ([00c424e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/00c424e01183f9fd34d547f4916f842c7f8d469f))
- update ICS2 story ([e19217a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e19217a1249cf5df06807ff4230f78f1a9bfc8d8))
- update styling ([c9faeea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9faeea0f5303185728d5dfc7e8abe491d85dc44))
- update tests ([f24fb5a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f24fb5aa470455801154cd860999c2b22084701b))

### Bug Fixes

- fix master layout banner when no environment is provided ([7c7cf5b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7c7cf5bdbc27537895b9f2ce3af5f0f6d1ef676f))

## [1.3.0-beta.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.2.4...v1.3.0-beta.2) (2021-03-17)

### Features

- add button stack ([226165c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/226165c0f79ac5789c6c217c732aaf1760ecc595))
- add component ([45ad48b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/45ad48b32921d86ee655a8894faabaf0528d9bd6))
- add defaultTabIndex to be able to show not only first tab by default ([f430bad](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f430bad02caf29acee30f6add02f094e0a966088))
- add directive qdActiveContentTab to render content based on tab in main area ([39fec41](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/39fec41b8c9f03fd32d51e45d9bbe700436f4cea))
- add header navigation ([72167fa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/72167fa2ff83056f4cfe7f765ee5ef6dea060bee))
- add info header to fullscreen modal ([0d18cc1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0d18cc1ba569bacfca93fa44a7f0cce3aa018cf5))
- add left control panel to fullscreen modal container ([bde8231](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bde82312af13efba455360305c6718900747891f))
- add story for forms ([69475f6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/69475f68117fb3a1601792f5d34e367f58b42584))
- add styles ([d7deda2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d7deda2f28d1390a184073d63c0459951715ab14))
- add styles, add unit test, add documentation add navigation to ics2 story ([82fcfe2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/82fcfe257f13ecf532506145c480c7e35cb30158))
- change parameter of directive qdActiveContentTab to object, add documentation ([31fddf2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/31fddf24b1738abd23f2ee5bfc9cb06f2f9fdc29))
- change status change error behavior ([f1b8a94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1b8a94526d2fae7cb128adccbef62f328d6bfcc))
- clean-up ([a937023](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a93702365847bec951c91700a30f19cd42cd9173))
- conditional rendering active tab ([839bd91](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839bd914ed4a8792f6ada5d12d0c4ea6e841578e))
- replace buttons to enable/disable button "Nächstes" with knobs-functionality ([5c200f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5c200f01200de2288dbd03ede9f7620385c14648))
- resolve merge conflicts ([5e2b3be](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5e2b3be63bc9d377c704ba38c359954da3328a6d))
- some updates ([c9dc421](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9dc4214c26b1ab479ecd0865cf619d93c9de1a3))
- tabs without action area ([2b2a738](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2b2a73833591677888aee50588505cba5ad8419f))
- update container mock ([6739317](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6739317516c303e3f327e828a4deacb7e657d94e))
- update ics2 story ([0de45d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0de45d5406f802ae6caa1719cd4e0df80d67baad))

### Bug Fixes

- add defaults, add checks, add docs ([3af2de2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3af2de2ca8432b69c92a66ae33e238a56d4697ab))
- coverage for unit tests ([d18396e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d18396ee18f58adbd2d3feaea548d26f7060577d))
- create workaround for error `ExpressionChangedAfterHasBeenCheckedError` ([785fb43](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/785fb435db1a201dab0666fb5f66d58de34df5d3))
- data model for fullScreen modal ([b2d2b62](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b2d2b6290e879bbdf024ad5f0c70996850179aa3))
- fix alignment of content and header in fullscreen modal by add dynamic padding right. ([d705ce6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d705ce69fa429cb95fb161694439ac56da423d9f))
- fix info modal style in fullscreen modal ([0ccb5f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ccb5f55733c96155cbbdf20f439aaceea393b0f))
- fix style in fullscreen modal panel ([148200b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/148200ba0775b3067ba0082291b33712fc58a435))
- focus state ([57131f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/57131f730619ed09c16399b9b5c83c1fbbe38b8d))
- linting errors ([f954dd9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f954dd99b9b1b140c47c69cdeea067913592b7a3))
- re-format mdx for forms conatiner ([fba4a82](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fba4a82deb6f469867e4c893e619f18a8fb85317))
- remove material form mock ([d2f78bf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2f78bfd322cae4131e9b750e4aa34cdb0a25754))
- update code style ([00548f9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/00548f9cbb473940f908885728e4d41daeb91f7a))

## [1.9.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.9.0-beta.0...v1.9.0) (2021-10-19)

### Features

- DAZUIC-589 - clean-up exports ([75d1de8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/75d1de8dbfad5d68efa66942e046ff23c6d13c42))
- DAZUIC-688 - add mock module ([a64db67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a64db67310cb8a03f0f2d4914b2fa2dd82dfbe17))
- DAZUIC-766 - export module for applications ([0f38f47](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0f38f47ca0097815a9b6e16d79a07e48b81bb3c6))
- DAZUIC-766 - update modules after test ([9efdd1a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9efdd1a0173ed34833b57eb3f65796b54eeb3da0))
- DAZUIC-702 - add-spectator-for-easy-tests ([d3924ac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d3924acac07477e122f35db7bb9e8f056d52e638))
- DAZUIC-702 - fix icon button alignment in tables ([f3b4cb1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f3b4cb1d6fbd99a82355f43d808c3e7c102ef7d2))

### Bug Fixes

- DAZUIC-688 - add mock module ([973e57f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/973e57f288fb9194c5ac720b972588d396d1dc79))
- DAZUIC-688 - bump version ([bc17d8a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bc17d8a757060c56d87acc35fbd2f446e2fdb926))
- DAZUIC-688 - delete unsused badge ([2dc8128](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2dc8128424dc3e1cd66b8b3b52cdd3dc8d902094))
- DAZUIC-688 - update pupblic api ([056944c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/056944c4bde65c08ee3cddb5713102d871a18f5b))
- DAZUIC-702 - set test-id optinal ([c0f17d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0f17d5f39a893aea7c77f45fe04f8d4f08512eb))
- DAZUIC-688 - update mocks ([53b190a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/53b190a88b18a6c024cc4d9838571e48f6fffc52))
- DAZUIC-702 - fix spectator test ([c59ef94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c59ef941f4fd34a1644ee7b4417103757476cb51))
- DQMS-107 - title autocomplete form ([3cf06ca](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3cf06ca1420f4de8d3bda9291661df872bd69242))

## [1.8.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.3...v1.8.0) (2021-10-07)

### Features

- add changelog ([c77000f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c77000f87ee3ff73811eaeb7d7eafd1510e17eac))
- add changelog ([cea95ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cea95ab538272e371513c75f8ed348202317fe64))
- add versions button ([fe1cb0f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fe1cb0f2aeee5a1b9f9a927ae94077334e136fa5))
- DAZUIC-651 add attribute data-test-id for child component in Page Process Header ([9a6ff38](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9a6ff3871dc25530d9f002fded6172f32da6cd4e))
- DAZUIC-762 add attribute data-test-id for checkbox component ([b410ff1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b410ff1ab54fc244379482b7f5f9906d43406fde))
- DAZUIC-762 add attribute data-test-id for child component in Chip component ([b9db2c9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b9db2c96098368778ca3d0a91104ec2f67b33aaf))
- DAZUIC-762 add attribute data-test-id for child component in Dropdown ([bc34f63](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bc34f63bca403c78bc6d5b9b22ab4a9db5189260))
- DAZUIC-762 add attribute data-test-id for child component in Image component ([372a42c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/372a42c6fd428942145dc0090ab6c5a31b0d0402))
- DAZUIC-762 add attribute data-test-id for child component in radio button ([abffc71](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/abffc71441ea6d02643d981fe40a26cd9f7b5ccb))
- DAZUIC-762 add attribute data-test-id for child component in Status indicator ([f0baed5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f0baed5a4af9d3387040e0cde6b5760caa4dbb65))
- DAZUIC-762 add attribute data-test-id for container component ([3d57210](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d5721068b58e1d1524130e3a389ac50b7a23100))
- DAZUIC-762 add attribute data-test-id for Filter component ([ef7161e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ef7161ed16cfab90e434260c88e7ef46eb36b3e4))
- DAZUIC-762 add attribute data-test-id for Stepper ([7d39d44](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7d39d444ce963964d9fa7bc0943aea153c63aa90))
- DAZUIC-762 add attribute data-test-id for Tab ([216c5ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/216c5ab0f8df83c54d5887bc13c55dd7c8cc2712))
- DAZUIC-762 add example of attribute data-test-id for icon component ([8cbb726](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8cbb72616d02549e893ed28e9101df643b84aef7))
- DAZUIC-762 add example of attribute data-test-id for Layout system ([63f6398](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/63f6398927324066a666bd25364d44093032e0e1))
- DAZUIC-762 add example of attribute data-test-id for list component ([4b38ef5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4b38ef50e19956310f88781e7597f7f646c78539))
- DAZUIC-762 add example of attribute data-test-id for text section ([881c6cf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/881c6cfc2e34c9ff04f0124410c756a20a27dbc9))
- DAZUIC-762 add example of data-test-id for alert component ([c0d52f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0d52f04218efb4ce5de283716dd451baa16ec4e))
- DAZUIC-762 add example of data-test-id for button component ([d74ad29](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d74ad29c0aebb09c8b7fc6b23044ae66ab97d93b))
- DAZUIC-762 add example of data-test-id for data-tree component ([02b7cf9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02b7cf94b6f4219082661b5efc77ff00f68a8e80))
- DAZUIC-762 fix data-test-id ([8a1d266](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8a1d266afddb8527cce5dd0ea058784733646bcf))
- DAZUIC-765 add attribute data-test-id for child component in form input ([839619d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839619d3f7264a9d5059128d33c9fea09b0072fb))
- Display version in welcome page ([91cc029](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/91cc029efeb155944994ccc3ddc93ae5377dbd01))

## [1.7.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.1...v1.7.3) (2021-09-29)

### Features

- DAZUIC-793 - add free text filter ([4ec3733](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4ec3733812006c66b8a4f2fba23fc536fe3038a8))

## [1.7.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.7.0...v1.7.1) (2021-09-16)

### Features

- DAZUIC-736 - add date type filter ([3208cc5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3208cc5ee9c91e2ff6c32666cf46daab044b8fb1))
- DAZUIC-781 - add dateRange type filter ([033cbb4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/033cbb415d86f17749aa59b5f31ff74ee67120b0))

### Bug Fixes

- some fixes for the realease ([de98731](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/de987311fe3014e078c5a8eab3d958c9798e660d))

## [1.7.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2...v1.7.0) (2021-09-09)

### Features

- DAZUIC-429 - add document for input and textarea ([7631b50](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7631b50f6e1a48d31d505ed780f2dd3397b5b849))
- DAZUIC-429 - Add FormGroup to input component ([bf75029](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf7502913426dcdf64e759d936edf4b88dc9f2e2))
- DAZUIC-542 - Create custom input component ([e373822](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e37382291b4a60c21dec4dfa0a0ff72bb91ac757))
- DAZUIC-542 - refactor icon to use font instead of svg ([d4f3807](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d4f380736424f0436415dda7288e4e4cf42763cf))
- DAZUIC-542 - update component with outdated icon ([ccf43e5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ccf43e5904fd94fe677ed2f056d1bedb818d15dd))
- DAZUIC-542 - update icon font to newest design ([81b13dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/81b13dd5b9afc457695dbb6955b6a23030bcaab8))
- DAZUIC-649 add error state to checkbox ([0189b8b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0189b8b72b7e79bb7fe6e2c98b2a7e1045a20629))
- DAZUIC-649 add error state to radio buttons ([08605b6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08605b667786a867a7cfcba284f753fb0cae8372))
- DAZUIC-649 Fix style of radio button ([42c19c7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/42c19c72bf77ef0b354cdd488b04e44c69501c6a))
- DAZUIC-656 adapt design of filter ([08a224c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08a224c43d59abfe6979351b1da5c7e0541d0858))
- DAZUIC-656 update filter design ([bf3f1cc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf3f1ccad17d6776a57ab7d0c1f990a9620d7f52))
- DAZUIC-656 Update single select filter ([9cb4602](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9cb4602d2f787ea3cfcefe4c478922973bb0b523))
- DAZUIC-674 - Create Custom Textarea component ([3967191](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3967191f1d63f6b8aba74b67d6539d39a5916fc6))
- DAZUIC-676 add type to input component ([05a2f7e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/05a2f7ede7c9690d739701a01008bb9a956fd267))
- DAZUIC-677 fix design detail in input component ([605d9f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/605d9f536e2e6945e3cddbb33e7e8e8180424d8d))
- DAZUIC-677 fix error state to all input component ([4e75f14](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4e75f141ce9c036718f5c5e6f64c0cf9c8111ec7))
- DAZUIC-722 - add error state to dropdown ([173caa0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/173caa07bf5449e71d25e179e0d5e6638dd22cd0))
- DAZUIC-722 fix error state of dropdown ([ab5b6bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ab5b6bdb8f858302af7675b52eaafe79cec2c838))
- DAZUIC-723 fix checkbox icon ([a6daf87](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a6daf87de1bf2aa43f12927c8b56d493df6e3e3f))
- DAZUIC-723 update icon set for checkbox ([99a8a8e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/99a8a8e403b63c645d045aae18adbe4a27ca7b8b))
- DAZUIC-736 Add date filter component ([1177d67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1177d67ded19a18ff81db34adc8cea0bf92bc3fa))
- DAZUIC-737 Add input filter component ([374309f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/374309f4133ff0490a503767beee5ad0319bd5ef))
- DAZUIC-738 - filtering items in Qd-Forms and Qd-Filter ([a4faa30](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a4faa3066f0fcade054dc4d9027696d158a5a7c8))
- DAZUIC-738 - update documentation ([f3010f8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f3010f8d1dedc7d90f976b921e499d76562c321d))
- DAZUIC-740 - design qd filter ([d2a348c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2a348c54f6eb46ca89385536895cd206eb13cd9))
- DAZUIC-741 - optimize filter service, new filter interfaces ([e486837](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e48683788fd9e6efa2444bad6afdec957543e4be))
- DAZUIC-744 - update Tabs, pending tasks ([5444fed](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5444fed921289a7e9ee21562d5c480bf047cb807))
- DAZUIC-776 - finalising filter for use as a beta ([4b7c49a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4b7c49a8e1995e2eb039fd285108e31d82734195))
- DAZUIC-776 - remove comment ([24da726](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/24da726a294828110bf215be2bb8c135bb339e6c))

### Bug Fixes

- css of some components ([5a8e57e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5a8e57ecabc83ca120ac59717afef14987e85ffb))
- export checkbox and radio buttons ([d042c0a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d042c0a420b7a9abecdc2c3041b402cbfc7dfc1a))
- fix backwards compatible of icon by adding old version icon. ([59395f3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/59395f3595da0b8de410d9361f24b8c9498e8bb9))

## [1.6.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.3...v1.6.2) (2021-07-16)

### Bug Fixes

- remove unnecessary logs ([8ea8da7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8ea8da748be20edafc85de5cc800bae65d7d09f6))

## [1.6.2-beta.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.6.2-beta.1...v1.6.2-beta.2) (2021-07-15)

### Bug Fixes

- update life cicle hook ([eb2309c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/eb2309ce5e71c0b8408653a600816e9e19c35549))

## [1.6.2-beta.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.5.0...v1.6.2-beta.0) (2021-07-15)

### Features

- add approval process to inspecziune ([d53cb22](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d53cb2206cfedbfa0ef34fc402492d87a3ad0458))
- Add Docs to Modal Confirm component ([e67e1a1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e67e1a12fc78a099f413e65cf484a7660a8519d1))
- Add Modal Confirm component ([b83f27d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b83f27d9a97419ebc709c461d1f6d8660abd6bf3))
- DAZUIC-224 - add radio buttons component ([455249d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/455249d926754b5c7d6911139e83d1bf168feaf7))
- DAZUIC-224 - finalize component, update unit test, add documentation ([d8b3758](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d8b3758654b8001308d99a07824ff72a671aac1d))
- DAZUIC-224 refactor radio buttons to support formgroup ([3e426ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3e426aba9cf947f93eec997fe5627562532d51c9))
- DAZUIC-225 - add checkbox component ([2f1674d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2f1674d857b04f9a2855a8bfeb66e6926061818d))
- DAZUIC-225 - add component and styles ([ca39c35](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ca39c35d90f55710bbc777955a508422406253c7))
- DAZUIC-225 - add documentation ([e99394f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e99394fff783a00d4546f83b4a0fa8f5323867c4))
- DAZUIC-225 - add stories ([4a0c526](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4a0c5264fe0245910621240a623e804b88468b8e))
- DAZUIC-225 - add tests, clean-up ([0a98de1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0a98de1d7c1408b39fdca700d7e87857fdfbfae9))
- DAZUIC-307 - add selectbox with autocomplete component ([21ea6f3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/21ea6f35a8a1f91803afc8606b9292cdb34b08ae))
- DAZUIC-307 - update dropdown component ([7067973](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/706797370fb4dbe7501541560162f76caf44a268))
- DAZUIC-493 - update step item styles, disable active state if not valid ([9751e53](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9751e53fbb062cb8b8d3b0acd91f5b5473006064))
- DAZUIC-493 - update stepper styles ([b5d670a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b5d670a3f4f989bf4215f1060fdb54b5f14d2d09))
- DAZUIC-522 - add logic for filter status chips ([3d2fa47](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d2fa47a847e3268f9fd59a9e79a3cc8400790f4))
- DAZUIC-522 - styling filter chips ([2dac30f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2dac30f2811206ccc936660808e4006b8721f89f))
- DAZUIC-522 - update chips for filter ([1641fef](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1641fefdfd1976ac659bcd1ff2630dc3f1142c98))
- DAZUIC-523 - Quadrel-Filter | Add reset button ([7959520](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7959520e5b477e6ed0dd94345b14aa448bccddd6))
- DAZUIC-523 - Quadrel-Filter | multiple categories ([04f8530](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/04f85306755d7fac977ae654bee18e8824f54a96))
- DAZUIC-524 - add filter type boolean ([a03eefb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a03eefb34976d35b06744fc1fd47e1281bd98843))
- DAZUIC-525 - add singleSelect filter type ([a3f0e9b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a3f0e9bbcaa072549e163f4345214418552293a5))
- DAZUIC-525 - update single select behavior ([1ccc15c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ccc15cc86046e721b4c972419d0472878128d0f))
- DAZUIC-525 - update single select behavior ([159f62b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/159f62bc5f875b0c3df4b1f951a5b57d6d833ce8))
- DAZUIC-560 - create QdSwitchComponent for custom form switch ([c0ef573](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c0ef573e9cbb2182d50d157eb50d5bf516494279))
- DAZUIC-603 - add custom tooltip ([c95b313](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c95b31320798ee263c8a4e7df86d63d729b3e388))
- DAZUIC-603 - add custom tooltip ([40f79d7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/40f79d70fde8f295bcc54e4a0be3d012304a9e1a))
- DAZUIC-603 - add custom tooltip ([a716811](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a7168114d10683bb052e4b90f1df807adb243ad2))
- DAZUIC-603 - add custom tooltip ([8e96a72](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e96a72fb1432aa658ee842bfd233e256f4b647c))
- DAZUIC-603 - add custom tooltip ([063b107](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/063b10791e0304b3ef673c012c0c9e0131347453))
- DAZUIC-603 - add custom tooltip ([b888e8b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b888e8b33d00df6c9d282001d2ecffc89f96c893))
- DAZUIC-603 - add custom tooltip ([55bd09f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/55bd09f24149921f499e83fa57cb8806703d8ba0))
- DAZUIC-603 - add snapshot ([941de71](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/941de715edc5cf74a459853cfd9c4f39ea7bd21c))
- DAZUIC-603 - update css for tooltip ([2998318](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/29983180c03dad49d32db561dbb43569439b7525))
- DAZUIC-603 - width calculation of PPH ([3fc8954](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3fc8954b2fb88cd4e3f27896d5da7a31173a3d53))
- DAZUIC-603 - width calculation of PPH ([2968fbb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2968fbbc53d0e73072cbdb4079c8d1bd453df1e9))
- DAZUIC-629 - add checkbox group, add filter ([0813477](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/08134774b6ea10f432035cf2bf40e4432d5b6b1f))
- DAZUIC-629 - add checkboxes component ([b5d8fea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b5d8fea6caccaba1f2a1eb588a8bbc5acd0cc303))
- DAZUIC-629 - add tests ([9f2f457](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9f2f4575ed9dce4f678a1226b6e77c87a2ce72de))
- DAZUIC-647 - Add disabled state to control panel ([165c45d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/165c45d7b447b8d23f00ffb012a1b46e09261d50))
- DAZUIC-647 - Add label position to switch component ([445ebbe](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/445ebbe677770c03a41436268c24e19ae0fba788))
- DAZUIC-670 - refactor switch data model to match checkbox ([a91ef34](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a91ef3458131d40f1e8cdbb032e20bf41320cab6))
- DQMS-60 - optional-formgroup ([223b733](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/223b7336cacdd22b3f7d5983dd41d01e9bffd480))
- DQMS-60 - optional-formgroup - typo ([c021a7d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c021a7d56dda8665bc5715ab7f80a56f55a7edb5))
- DQMS-88 - support tab name change after initialized ([3458a1d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3458a1d518af582f0e9b500e7b7dad99eb4690da))
- reduce memory ([02f9fea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02f9fea9a867eee09dbcc547954f5dd840d0a4d2))
- refactor layout renderer to add support to side modal ([3a2d0f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3a2d0f57eafee54154e118a078eeff745d2b2938))
- update i18n ([fa076c0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fa076c0f351429cf01ea901400d4221aca4e79e1))
- Update Scenario for inspecziune ([ce32e72](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ce32e722c3fdd4279d61903ee6b1d6b258c26547))

### Bug Fixes

- DAZUIC-307 - fix errors and warnings in unit tests ([5d185c2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5d185c2ab0af7b7937e71a20be88ca0436f948b7))
- DAZUIC-307 - fix failing tests ([89c996a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/89c996abbca0d6ca1e88923efa107e7527b801e7))
- DAZUIC-307 - fix qd-form module after merge ([e144719](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e1447198fd6c2a60cce21e1d2c3c5bffba6c6dae))
- DAZUIC-524 - remove Hostbinding ([c2db86c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c2db86c8d622614c032fadb4ea737e821fe19c2f))
- DAZUIC-560 - add margin to switch component ([8bcb995](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8bcb9951f8ab4d6093ed03be6ff42bb48360450c))
- DAZUIC-560 - fix disabled label state of switch ([f2ffaeb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f2ffaeb2feb85210fa14ea2bb40d72274d1a4243))
- DAZUIC-642 - export master-layout-service ([1d7e8bb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d7e8bb7ae109c875e518a1d7466f22e8c1c1d2f))
- disable component story without sprint review ([ec32a1d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ec32a1d3b6851944ae5b13c29b027812a26ee8e3))
- DQMS-40 - add disabled status in stepper logic ([1ac4507](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ac45071c2bba95c701ef9cce362a01bec63f156))
- DQMS-77 -background of forms container in control panel ([396214e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/396214ecbdab3c583dea52299809e97c52f20af3))
- DQMS-89 - fix disable submit in PPH ([cecee2b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cecee2b4de7388209fa4cbeafd35b70609eb00dd))
- fix review comment ([23a82b2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/23a82b2bba52670284a6a65ceea09dc8e3a6e45a))
- fix side modal box shadow styling ([d722c93](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d722c93662c0e7eebb4ab3865f64fc3667dc89cd))
- fix side modal popup without size ([75552aa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/75552aadd6ee74ab1079affdf51a637b98de804f))
- fix side modal styling ([c034e97](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c034e972c2c1012820428278daa8b8c930f72501))
- merge conflicts ([2084594](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/208459490469d01ce7844deef35ca91067f20eae))
- merge conflicts ([cb25e6b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cb25e6bac8ee61dabc81c02f9261cdd022c4d0a9))
- panel story uses inputData instead of label ([0ddc46f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ddc46fc82c38d460575eaecf0449721f2eb3905))
- remove top border from side modal ([8dec49a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8dec49a741427b563d828b55fe4ff26ae90223ab))
- resolve merge conflics ([6997b6a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6997b6a4375ffc96a375a630868311dcfdfe1236))
- resolve merge conflicts ([0664ed3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0664ed34317118c7b1e3d117beb14169ccf2abb7))
- resolve merge conflicts ([8e51ee0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e51ee027146717959e8122572e007555a8dc012))
- update notification style ([4c7c29d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4c7c29d1cf57ec013ce2f148f8b98db99c44cb37))

## [1.5.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.4...v1.5.0) (2021-05-17)

### Features

- Add documentation for fullscreen modal ([8d6044d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8d6044de87aa6a8e1dee8048541c53931c968268))
- add scenario for inspectinue project ([158b786](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/158b786a7e8fe5de5d84d77e625d461d733c1066))
- DAZUIC-489 - update button stack styles ([b08dc22](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b08dc22ca834292cc5dccd6f383cbf508728d412))
- DAZUIC-558 - add status indicator component ([087a071](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/087a07121e97b0f0634cb13d3412b381773ffdef))
- DAZUIC-558 - add status indicator in table story ([09459e2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/09459e2f92489e20e1d8c34761b515011eadc6a1))
- DAZUIC-559 - Qaudrel UI | Anzeige Status Header ([88885dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/88885ddf4c088f62689da6ec35fd47826f067e61))
- DAZUIC-591 - Quadrel UI | Page Process Header für Modal FW ([d735ae5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d735ae54450f9ad72cd5d0f0e8a901d12016d6c4))
- DAZUIC-591 - Quadrel UI | Page Process Header für Modal FW ([49e926a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/49e926a38bd7932d61029e71a84adf5fe04791da))
- DAZUIC-595 - QdLayoutPanelProgress in Laufzeit änderbar ([58da7a8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/58da7a8a1a2b5802beddbc79dbb3d4797343c54b))
- fix fullscreen modal style ([ac4d371](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ac4d3719b457e80e529884a277df313177643046))
- layout render style comment fix ([c46e7fd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c46e7fdd5839949a0becd2c528eeee90b4cce15c))
- refactor layout system and fullwidth modal to use same renderer style ([1d0e7e7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d0e7e70e83817ef76a2c905ff431fd8efaa0e8f))
- refactor review comment of stadi scenario ([326d858](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/326d8583b6bffac2559e0fa43081bc1ab6567f04))
- refactor situnaziunform with new container toolbar ([0dcb769](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0dcb769d9949e0319dc406447f2967ab8ebb9c24))

### Bug Fixes

- build error ([783e8c2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/783e8c2529693d95b95079c0595a3ca2a7c0d38e))
- move page process header to use cases ([02a9305](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/02a9305cf92b1f8a551dc0778efaa4ced9cb88c3))
- resolve merge conflicts ([8c315f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8c315f763bf84769940d5580591a7759bce67719))
- resolver merge conflicts ([c877434](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c877434313c7521344eb95a58e17db5043086bca))

## [1.4.4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.3...v1.4.4) (2021-04-30)

### Bug Fixes

- add notification service in public api ([f1425d1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1425d1fdb8e7dd141ca7b0ff91e2ac87adb0e25))
- export notification service ([09966ba](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/09966bac9952662b4b3eaa4167cc7bbd4ef1cda0))

## [1.4.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.2...v1.4.3) (2021-04-30)

### Features

- DAZUIC-547 - use new Icon in table inline menu, update qdRow directive ([33d895e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/33d895ec8d9a0937cc370eb4347a5f637e353f70))

## [1.4.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.1...v1.4.2) (2021-04-29)

### Features

- add example scenario for Situaziunforms ([bd6b2df](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bd6b2dffb56b0e49404b5c51bd16d8bc79cc7055))
- add stabi scenarios ([ab2147a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ab2147a90c1dead0a5cd4f2308309bbed0e100c4))
- DAZUIC-546 - add action Area in toolbar ([bf82b7f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf82b7f054139be7847a953ea433390bba3eec57))
- DAZUIC-546 - fix import ([ef0a0ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ef0a0ab6ff4c348d0c82ab4f1f6f9704e76eff32))

## [1.4.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.4.0...v1.4.1) (2021-04-26)

### Bug Fixes

- change lang tag in html update website language ([2a5fa76](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2a5fa7675697cc8ec1440d47411184df53aa3608))

## [1.4.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0...v1.4.0) (2021-04-26)

### Features

- add components for header type toolbar ([71a0fac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/71a0fac83f448b90779ea683a51fc3431e1612c7))
- adjust toolbar-top height ([7eb3467](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7eb3467430a471edf586765432bf710de6e8757f))
- DAZUIC-520 - add multiselect filter type ([3d7a41e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3d7a41e321429d7590f145794f9b444a74b3b852))
- DAZUIC-521, DAZUIC-545 - update container toolbar ([55507b9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/55507b914d982faba72beec78d80d5c233bfb683))
- DAZUIC-528 - add interceptor service, add components ([15399bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/15399bd96296fcd41590507c918f0c6b5748a33a))
- DAZUIC-541 - add modal notitfications ([660049d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/660049d461b5762e5fcf9f668b04ff51a05d295b))
- DAZUIC-573 - Add documentation for Notifications ([1ef301a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ef301a8e1c1ea2e359d8dff53d3f95c79d3e459))
- padding adjustment in container-toolbar ([cd7e6de](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cd7e6de7868ff6bb01bb3a9068b95e6fd367e285))
- remove toolbarType, adjust toolbar styling with flexbox ([624c0b0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/624c0b0a994805cb6ec3a0b650f40a3dbe782900))
- remove unused code, add snapshot tests ([b200152](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b20015252e151608767f1b86c89f5b928ca601ca))

## [1.3.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0-beta.3...v1.3.0) (2021-04-01)

### Features

- Add filter panel logic ([e0946a8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e0946a8fbfb5902f35f30afbb5910271ae0bed0e))
- DAZUIC-408 - add search button to master layout header ([531d01a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/531d01a1faccdea65d8891a794124d031551a97f))
- DAZUIC-408 - new style for search field ([b2833dc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b2833dcf7bede4d493eb33b77eff52dee300061b))
- DAZUIC-408 - update mobile header widget ([30e1c1a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/30e1c1af48a26c76a5b653a70608cc14d8ae4a56))
- DAZUIC-408 - use translate service in header widget automatically ([601450f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/601450f9453b4c985a3d90a89bb38d012707e294))
- restyle filter panel and remove unused input ([65c4f51](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/65c4f5104415885bb4e4a83f2c594479f0153835))

### Bug Fixes

- DQMS-76, DQMS-71, DQMS-20, DAZUIC-136, DQMS-34 ([8829aaf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8829aafe3271d4ab37d8c88fe0e4c7fe59056afa))

## [1.3.0-beta.3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.3.0-beta.2...v1.3.0-beta.3) (2021-03-24)

### Features

- add and update stories with component `exception` ([0b3d3db](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0b3d3dbe8431dde2477c7ec65c79330ccef60cb1))
- adjust background-color of container-content-container in panel ([5547ca6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5547ca6e37e571fe20296e672596a6eb70ed335b))
- create component `exception` to replace alert ([af13d67](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/af13d673066b331de4c62428e53080a5b948ec76))
- create tests and mocks for component `exception` ([fc12177](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fc121774af4ecf749ac0a16791a3e80386f02231))
- DAZUIC-481 - add data tree, visualization only, 2 levels ([1825c1f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1825c1f78b91bd6bdce821334c22d8165d1cb64e))
- Refactor container content detection to service to enable communication with Grandchild ([513188f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/513188f8c50b2f1f535e82729ae9a33ca5520295))
- update colors ([00c424e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/00c424e01183f9fd34d547f4916f842c7f8d469f))
- update ICS2 story ([e19217a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e19217a1249cf5df06807ff4230f78f1a9bfc8d8))
- update styling ([c9faeea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9faeea0f5303185728d5dfc7e8abe491d85dc44))
- update tests ([f24fb5a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f24fb5aa470455801154cd860999c2b22084701b))

### Bug Fixes

- fix master layout banner when no environment is provided ([7c7cf5b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7c7cf5bdbc27537895b9f2ce3af5f0f6d1ef676f))

## [1.3.0-beta.2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.2.4...v1.3.0-beta.2) (2021-03-17)

### Features

- add button stack ([226165c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/226165c0f79ac5789c6c217c732aaf1760ecc595))
- add component ([45ad48b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/45ad48b32921d86ee655a8894faabaf0528d9bd6))
- add defaultTabIndex to be able to show not only first tab by default ([f430bad](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f430bad02caf29acee30f6add02f094e0a966088))
- add directive qdActiveContentTab to render content based on tab in main area ([39fec41](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/39fec41b8c9f03fd32d51e45d9bbe700436f4cea))
- add header navigation ([72167fa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/72167fa2ff83056f4cfe7f765ee5ef6dea060bee))
- add info header to fullscreen modal ([0d18cc1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0d18cc1ba569bacfca93fa44a7f0cce3aa018cf5))
- add left control panel to fullscreen modal container ([bde8231](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bde82312af13efba455360305c6718900747891f))
- add story for forms ([69475f6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/69475f68117fb3a1601792f5d34e367f58b42584))
- add styles ([d7deda2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d7deda2f28d1390a184073d63c0459951715ab14))
- add styles, add unit test, add documentation add navigation to ics2 story ([82fcfe2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/82fcfe257f13ecf532506145c480c7e35cb30158))
- change parameter of directive qdActiveContentTab to object, add documentation ([31fddf2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/31fddf24b1738abd23f2ee5bfc9cb06f2f9fdc29))
- change status change error behavior ([f1b8a94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1b8a94526d2fae7cb128adccbef62f328d6bfcc))
- clean-up ([a937023](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a93702365847bec951c91700a30f19cd42cd9173))
- conditional rendering active tab ([839bd91](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839bd914ed4a8792f6ada5d12d0c4ea6e841578e))
- replace buttons to enable/disable button "Nächstes" with knobs-functionality ([5c200f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5c200f01200de2288dbd03ede9f7620385c14648))
- resolve merge conflicts ([5e2b3be](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5e2b3be63bc9d377c704ba38c359954da3328a6d))
- some updates ([c9dc421](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9dc4214c26b1ab479ecd0865cf619d93c9de1a3))
- tabs without action area ([2b2a738](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2b2a73833591677888aee50588505cba5ad8419f))
- update container mock ([6739317](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6739317516c303e3f327e828a4deacb7e657d94e))
- update ics2 story ([0de45d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0de45d5406f802ae6caa1719cd4e0df80d67baad))

### Bug Fixes

- add defaults, add checks, add docs ([3af2de2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3af2de2ca8432b69c92a66ae33e238a56d4697ab))
- coverage for unit tests ([d18396e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d18396ee18f58adbd2d3feaea548d26f7060577d))
- create workaround for error `ExpressionChangedAfterHasBeenCheckedError` ([785fb43](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/785fb435db1a201dab0666fb5f66d58de34df5d3))
- data model for fullScreen modal ([b2d2b62](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b2d2b6290e879bbdf024ad5f0c70996850179aa3))
- fix alignment of content and header in fullscreen modal by add dynamic padding right. ([d705ce6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d705ce69fa429cb95fb161694439ac56da423d9f))
- fix info modal style in fullscreen modal ([0ccb5f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ccb5f55733c96155cbbdf20f439aaceea393b0f))
- fix style in fullscreen modal panel ([148200b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/148200ba0775b3067ba0082291b33712fc58a435))
- focus state ([57131f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/57131f730619ed09c16399b9b5c83c1fbbe38b8d))
- linting errors ([f954dd9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f954dd99b9b1b140c47c69cdeea067913592b7a3))
- re-format mdx for forms conatiner ([fba4a82](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fba4a82deb6f469867e4c893e619f18a8fb85317))
- remove material form mock ([d2f78bf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2f78bfd322cae4131e9b750e4aa34cdb0a25754))
- update code style ([00548f9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/00548f9cbb473940f908885728e4d41daeb91f7a))

## [1.3.0-beta.1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.2.4...v1.3.0-beta.1) (2021-03-17)

### Features

- add button stack ([226165c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/226165c0f79ac5789c6c217c732aaf1760ecc595))
- add component ([45ad48b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/45ad48b32921d86ee655a8894faabaf0528d9bd6))
- add defaultTabIndex to be able to show not only first tab by default ([f430bad](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f430bad02caf29acee30f6add02f094e0a966088))
- add directive qdActiveContentTab to render content based on tab in main area ([39fec41](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/39fec41b8c9f03fd32d51e45d9bbe700436f4cea))
- add header navigation ([72167fa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/72167fa2ff83056f4cfe7f765ee5ef6dea060bee))
- add info header to fullscreen modal ([0d18cc1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0d18cc1ba569bacfca93fa44a7f0cce3aa018cf5))
- add left control panel to fullscreen modal container ([bde8231](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bde82312af13efba455360305c6718900747891f))
- add story for forms ([69475f6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/69475f68117fb3a1601792f5d34e367f58b42584))
- add styles ([d7deda2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d7deda2f28d1390a184073d63c0459951715ab14))
- add styles, add unit test, add documentation add navigation to ics2 story ([82fcfe2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/82fcfe257f13ecf532506145c480c7e35cb30158))
- change parameter of directive qdActiveContentTab to object, add documentation ([31fddf2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/31fddf24b1738abd23f2ee5bfc9cb06f2f9fdc29))
- change status change error behavior ([f1b8a94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1b8a94526d2fae7cb128adccbef62f328d6bfcc))
- clean-up ([a937023](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a93702365847bec951c91700a30f19cd42cd9173))
- conditional rendering active tab ([839bd91](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839bd914ed4a8792f6ada5d12d0c4ea6e841578e))
- replace buttons to enable/disable button "Nächstes" with knobs-functionality ([5c200f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5c200f01200de2288dbd03ede9f7620385c14648))
- resolve merge conflicts ([5e2b3be](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5e2b3be63bc9d377c704ba38c359954da3328a6d))
- some updates ([c9dc421](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9dc4214c26b1ab479ecd0865cf619d93c9de1a3))
- tabs without action area ([2b2a738](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2b2a73833591677888aee50588505cba5ad8419f))
- update container mock ([6739317](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6739317516c303e3f327e828a4deacb7e657d94e))
- update ics2 story ([0de45d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0de45d5406f802ae6caa1719cd4e0df80d67baad))

### Bug Fixes

- add defaults, add checks, add docs ([3af2de2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3af2de2ca8432b69c92a66ae33e238a56d4697ab))
- coverage for unit tests ([d18396e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d18396ee18f58adbd2d3feaea548d26f7060577d))
- create workaround for error `ExpressionChangedAfterHasBeenCheckedError` ([785fb43](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/785fb435db1a201dab0666fb5f66d58de34df5d3))
- data model for fullScreen modal ([b2d2b62](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b2d2b6290e879bbdf024ad5f0c70996850179aa3))
- fix alignment of content and header in fullscreen modal by add dynamic padding right. ([d705ce6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d705ce69fa429cb95fb161694439ac56da423d9f))
- fix info modal style in fullscreen modal ([0ccb5f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ccb5f55733c96155cbbdf20f439aaceea393b0f))
- fix style in fullscreen modal panel ([148200b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/148200ba0775b3067ba0082291b33712fc58a435))
- focus state ([57131f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/57131f730619ed09c16399b9b5c83c1fbbe38b8d))
- linting errors ([f954dd9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f954dd99b9b1b140c47c69cdeea067913592b7a3))
- re-format mdx for forms conatiner ([fba4a82](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fba4a82deb6f469867e4c893e619f18a8fb85317))
- remove material form mock ([d2f78bf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2f78bfd322cae4131e9b750e4aa34cdb0a25754))
- update code style ([00548f9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/00548f9cbb473940f908885728e4d41daeb91f7a))

## [1.3.0-beta.0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/compare/v1.2.4...v1.3.0-beta.0) (2021-03-05)

### Features

- add button stack ([226165c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/226165c0f79ac5789c6c217c732aaf1760ecc595))
- add directive qdActiveContentTab to render content based on tab in main area ([39fec41](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/39fec41b8c9f03fd32d51e45d9bbe700436f4cea))
- add header navigation ([72167fa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/72167fa2ff83056f4cfe7f765ee5ef6dea060bee))
- add info header to fullscreen modal ([0d18cc1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0d18cc1ba569bacfca93fa44a7f0cce3aa018cf5))
- add left control panel to fullscreen modal container ([bde8231](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bde82312af13efba455360305c6718900747891f))
- add styles ([d7deda2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d7deda2f28d1390a184073d63c0459951715ab14))
- add styles, add unit test, add documentation add navigation to ics2 story ([82fcfe2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/82fcfe257f13ecf532506145c480c7e35cb30158))
- change parameter of directive qdActiveContentTab to object, add documentation ([31fddf2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/31fddf24b1738abd23f2ee5bfc9cb06f2f9fdc29))
- change status change error behavior ([f1b8a94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1b8a94526d2fae7cb128adccbef62f328d6bfcc))
- clean-up ([a937023](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a93702365847bec951c91700a30f19cd42cd9173))
- conditional rendering active tab ([839bd91](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/839bd914ed4a8792f6ada5d12d0c4ea6e841578e))
- replace buttons to enable/disable button "Nächstes" with knobs-functionality ([5c200f0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5c200f01200de2288dbd03ede9f7620385c14648))
- resolve merge conflicts ([5e2b3be](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5e2b3be63bc9d377c704ba38c359954da3328a6d))
- some updates ([c9dc421](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c9dc4214c26b1ab479ecd0865cf619d93c9de1a3))
- tabs without action area ([2b2a738](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2b2a73833591677888aee50588505cba5ad8419f))
- update container mock ([6739317](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6739317516c303e3f327e828a4deacb7e657d94e))
- update ics2 story ([0de45d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0de45d5406f802ae6caa1719cd4e0df80d67baad))

### Bug Fixes

- fix info modal style in fullscreen modal ([0ccb5f5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0ccb5f55733c96155cbbdf20f439aaceea393b0f))
- focus state ([57131f7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/57131f730619ed09c16399b9b5c83c1fbbe38b8d))
- linting errors ([f954dd9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f954dd99b9b1b140c47c69cdeea067913592b7a3))

## [1.2.5-beta.0](https://bitbucket.bit.admin.ch///compare/v1.2.4...v1.2.5-beta.0) (2021-02-25)

### Features

- add button stack ([226165c](https://bitbucket.bit.admin.ch///commit/226165c0f79ac5789c6c217c732aaf1760ecc595))
- change status change error behavior ([f1b8a94](https://bitbucket.bit.admin.ch///commit/f1b8a94526d2fae7cb128adccbef62f328d6bfcc))

### Bug Fixes

- focus state ([57131f7](https://bitbucket.bit.admin.ch///commit/57131f730619ed09c16399b9b5c83c1fbbe38b8d))

### 1.2.4 (2021-02-22)

### Features

- activate PPH-Submit-Button depending on stepper ([05fbbc8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/05fbbc8cb15368cc6aefab88a885b10865dd5d79))
- Activate tab based on the current route ([af29909](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/af2990945c6857e8f946a8484e02d7c1dfaca8ca))
- add action area, add button logic, refactoring, add page leave handler ([8a85cbd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8a85cbd1c38ae45293c8aef633e4f4e7e23320c4))
- add alert ([354b271](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/354b2710dd6fa1df6ebdd5412a0b5c361828b33b))
- add animation ([ea7d4ec](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ea7d4ec70a71af1e9a5b329d8e064267293f74ff))
- add app status banner ([5827d80](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5827d80c32da8ff845f4a254bc05e502db454ea2))
- add ArgsTable ([e143957](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e143957d940fc190fce7a6c07f2a5b92c1bdbb5c))
- add border & margin ([f921ce1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f921ce1204af8bf934cd06a01bf70a57051282f9))
- add borders ([c7f2d40](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c7f2d409f510bacec1ac65b5536cb7d700f1746d))
- add breakpoint mapper, add components, add styles ([66a5e80](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/66a5e80f463e3c368e80f60398c2be9295e7be14))
- add buttons ([61556de](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/61556de44f0d10a70372f4be54c0b7c9d2650b78))
- add callback function, update tests ([e67a6d3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e67a6d39deaf8948ac3d55a8647baef616a580e2))
- add caption to image component ([4418423](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4418423a01430cfe44eb7a06300d9e690dd17a50))
- add card title as directive ([c8ec76a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c8ec76a65a1a06f4fec97ee7109db536785a30a0))
- add colors in settings ([7d46d5d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7d46d5da0e679962497526d30ebc4f50b3cb68ae))
- add component ([acd19b4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/acd19b4cb7154673bc8fa1c299c351d66f14c4de))
- add components, add story, add some syling, add modal ([bc8d23c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bc8d23c9df3fd7ef67b8369ace5d207e13c09507))
- add container pairs component for rendering key-value pairs in container grid ([eb0a9eb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/eb0a9eb37d546d1da2cdfc6013a3a7330dfeefc0))
- add content-grid components ([e0fd725](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e0fd725c22cb46f0fcb3bcf32f94e582911be6d5))
- add css ([4a02fcc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4a02fcc87e1537f8a2aee93d3c7718d858d0a0b7))
- add directive ([d1d0d7d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d1d0d7d0042a7e12dadc19ccfb12daa0df7f7a03))
- add directive `editDisabled` to qd-container ([3ba1d60](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3ba1d60924fa6f5d92c57b971271bf2332ecc484))
- add disabled style to table (Control Panel) ([d967053](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d967053ccb2f2b3144f34a27feab63b6cf92bafb))
- add error & warning color ([10cbf1f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/10cbf1fb57cfe7d227a6f4b183d51ad099627117))
- add error state to status pairs ([e8b26b5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e8b26b54cd5231b6a905ae2011173ffcf2bffd43))
- add example ([0f1a352](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0f1a352818155a30fbf9ef69a4741a1c54cbee50))
- Add example for translation DAZUIC-392 ([b941a08](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b941a08f9c790da9c70f0a2c85c7584a45493799))
- add height of sticky action bar ([e42c889](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e42c889f885f74b85f0c43c7df3cf6d8d9cbf2c1))
- add icon buttons in input fields ([c706a63](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c706a63a9ef50785402ad6f7c19b7d9f804e8b0f))
- add icons ([f34c042](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f34c04296a2bb35257e88e7f9224afde3e833448))
- add image component ([3bc1498](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3bc14981793439a1d0555c9c6f1e01cb478e846d))
- add list pairs for containers ([4885691](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4885691a809cdf8c0c7dedfe72def9aff4a7b35e))
- add more icons ([23844b6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/23844b6cce32ed18b89cfbeee23bd49c379e6e1a))
- add navigation property ([4f133a2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4f133a27e6171505b150fe84e2a7c92b86e5b7cf))
- add notes ([90a5749](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/90a57490f675b192a1f4e187162787c542993a93))
- add page title header ([aa4e895](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/aa4e895897dc27cf7c5ccc47451e801489e3b0b4))
- add snapshot ([d58f53b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d58f53bae926b0d2d24c340de343d961308f32af))
- add some checks ([cf00f90](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cf00f90cd9c1b258a30c410937dada3bc69f0372))
- add some mdx files ([a2ccbc3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a2ccbc3f8498e71cb0bc8d01bde4242164a6bea1))
- add some more icons ([9510a0e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9510a0efbc382dfcc725e478bff850dbdae8145c))
- add special container properties ([bfce420](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bfce420dd632f15118552d0179e0fabde62ef42e))
- add special container properties ([99ea522](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/99ea52224207060e6d8d6c47222b2974d3293e38))
- add srory, add styles ([3250923](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/325092318cd83371c6e17cec0d1785f513954f83))
- add styles ([28e58f8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/28e58f8f1f9e5e8f8348bf38b97dca9305ed8be9))
- add submit button in control panel ([f457a06](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f457a063ea7e55b89f41ab79f0503b8d779c1e40))
- add success color ([db56319](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/db5631955e25ae14b643b15dbfe758f5c92d7780))
- add summary modal ([2d64b91](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2d64b9135b3ecae387df63a6d85ff23294b59e15))
- Add table example DAZUIC-392 ([549bdb8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/549bdb8d6ed9c00959437a9c613b07b0836b8432))
- add text section components ([7b77910](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7b7791021feea7c1627b85b79b34c7f887f6addd))
- add title in page process header ([1ae0674](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ae06743b97b4003e23c572fd2554b56d200d2ec))
- add title to container section ([14b494d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/14b494da6ba3342fc5779f0600001d9a14aa3d66))
- add titles in cards ([32a451d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/32a451d85ec901b8af69d0785f47622e27ffb85b))
- add to story ([11ae362](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/11ae3629a47ba62223dd92408b97eff8a94c4e8b))
- Add translation for stepper button DAZUIC-232 ([443d4e1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/443d4e1024ff8aa6810e8de26466ec10ec9013af))
- add trigger function for control panel container status ([fb3f6cc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fb3f6cc09bfba7b9e776943b6c091256d93ddd08))
- add usecases in stories ([b97ce5b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b97ce5b64d2ffcf571bf04d77715f22da5114d33))
- add warning colors ([1a760bf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1a760bf44aa9ecb9ec1fd973b85554ae2b5d31fd))
- add/replace icons ([05aae43](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/05aae43678e89228667408acc6c5105fa18d1b92))
- adjust height of page title by master layout ([77501b3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/77501b3ea0082cbac6a662fe2a3f700055be032c))
- adjust height of page title by master layout ([7c5ea3a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7c5ea3af3702948a3d57e6c6aa9a99b7c6d230b8))
- adjust height of PPH by master layout ([6700f22](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6700f222c6536500ac27c8a014d66a6404a02b08))
- auto expand container when create new ([3b1d97d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3b1d97db02ec7cb71a51d975da861abc5919b51b))
- autodetect forms ([c98cfa3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c98cfa3e1469cbce77acab6aedb1017780125cf5))
- cahnge lifecicle method ([8e791ba](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e791ba522438d4fb96a49548e9248e65a48688b))
- change callback to event pattern ([1956026](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1956026005a29a3c2aac169fc3611af8df5fb2e9))
- change properties ([dd496c1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/dd496c1d96aad407243d98bb4bc7517faba3875e))
- change to warning ([4a4d167](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4a4d1670c719805cb5f9052054674ea3cfc0900d))
- clean-up ([684fac7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/684fac7057cabfdf9edf8c92bed1a45538c5a6ec))
- Control visibility of normal and mobile header-widget inside a custom component DAZUIC-328 ([95f9e95](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/95f9e95c0904b27a8df0bf765ae8ea2115ea74a5))
- Coordinate assignment of html attributes to prevent overwriting the default values DAZUIC-328 ([e8ce7f2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e8ce7f2b41dd6468959105ee6e25fb2f9fd1d6fb))
- Create qd-icon-button component to display buttons with icons only inside ([173bcdd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/173bcddebb4ef24a4075f77cad715aafbec8fd86))
- Create row directive to navigate among table rows ([607669f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/607669fa08fcc0cafb867a6aa5c392aa67a2fa98))
- Create sample page for stepper and auth DAZUIC-392 ([db24834](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/db248341050aac4cef352561c049385f08115498))
- Create story for pams modal ([6e72377](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6e723770990d7151068d9d8bed8e100288b42391))
- Create story for qd-header-widget DAZUIC-328 ([4940560](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4940560649ce6e436dc6fc9d1cada201a0642df5))
- Create tab bar as an router based alternative for qd-tabs ([756ee45](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/756ee4538b3f16e5ad842c995393c1b3b3a82c81))
- Create text and button list item inside tile DAZUIC-278 ([fd28dc9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fd28dc983711b6ada7c3c75cfd84b844ced983b1))
- css ([3844418](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3844418f515f82f3b53e986b4595830d261a8905))
- deactivae mt lists in storybook ([0b18ea1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0b18ea1fb91c1a4690278bec0811191e28417f27))
- disable warning css ([d97ccc4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d97ccc476913074858a49d256b0bd772eb283cd1))
- error in datepicker ([5f29d6e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5f29d6e97dbdc5cdffd4a30e65e9ebd6da0888ec))
- extend stepper showcase ([f4999ac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f4999ac686d50cc4b19aa735e93b012a945ab124))
- fix calender icon ([eceb775](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/eceb775d3811fc93d78a196473ca8e0724f3c346))
- fix more icons ([65e43da](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/65e43dac8487aee055d1f6aea4b19d519fe5bc7a))
- fix more icons ([db442c7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/db442c78ef9fdd6d44b055c4e1626caaf97a7137))
- initial invalidation ([24cd29e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/24cd29eb32414521dd598cf3018b71d5038a4926))
- Move download component and renamed it according to qd naming conventions ([e22e347](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e22e347319a789e65dc9842e9b795bcc56ab850a))
- move page process header to layout system ([c2a2adb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c2a2adb897c90852615f09391ae5792a2cec5082))
- move stories ([850bdbf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/850bdbffddf08020b607a1e9053e6a501903a297))
- move stories, rename stories, update browser check ([c00939b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c00939b6514c452bca0204560dea3d2b6c0f8f4a))
- name as observable ([db08e58](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/db08e58b0e63601113ce1162c08d3bcce0bf87cb))
- px to rem ([4c9250f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4c9250f913416bf1dc789deef0060f4acdd332e2))
- re-organize css ([53f03d5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/53f03d50182fd9442614c807af03e7c8dadbf63c))
- refactor form css, add table margins, add pagination css and margins, add progress bar ([334b494](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/334b49469cacacb772607d2177bf8d9a37ce9351))
- remove focus ([fef9557](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fef95579376065faa987c1454d8864c338f766f6))
- remove import ([ae2bf7d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ae2bf7dbd6aaa669df33bf75393d38663b148399))
- Remove tgz modules DAZUIC-150 ([e01fde6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e01fde65c460e0820cedaee9612f135a550205b3))
- renaming ([0486058](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/04860580acec56ece42cfb9225dc2ba4a094db57))
- reorganize css ([cc024a7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cc024a797536e7193b51cc338e6f61b34616b605))
- set width od page processheader dynamically ([87b68ec](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/87b68ecd52b857acce42785cbe7c92ca2170cfb2))
- shorten lang input field texts ([79a0c3d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/79a0c3dad74d14025ae42c35fde3ae45d98955bb))
- small changes ([66dca57](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/66dca57b502fc68fb14224f3a2151e8510ded925))
- small changes ([7620a2b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7620a2b9426fbd60cc5b5fc1e3267c290883145c))
- small changes ([0208b75](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0208b75a387fcfa46b0f7756d080556ad70b9fa9))
- small changes ([1b1c8b7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1b1c8b7a9ddedc4efe48b7ae1dde7616e254a303))
- some changes ([d24fc2b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d24fc2b9d0603142be196e7494fdb045c3a866a6))
- some changes ([0906be2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0906be2b6cdf49ad24f9f6b89a84e361b5a799b6))
- some changes ([5b19da3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5b19da38f94031ba3d1b4e4fadafd4a1cc0e76f7))
- some small changes ([d2c81e0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d2c81e0505df63a9d5c0f548386db7246f4863e0))
- some small updates ([9ad690c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9ad690cc61c89f3d83a796d1ca0b13aff9197ca3))
- some styling ([c78825c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c78825cd70db67ef0c9a247b5d8f498d6aa80685))
- Table column directive to handle text overflow DAZUIC-241 ([c29412a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c29412aa93cd5efc84a2a836bbc575658f53c132))
- Temporary error component for formGroups (because the default mat-error is not controlled automatically in this case) ([d52a49d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d52a49d92c9c5c7b8ba2b2a0a651a0d8bcf42faa))
- tests ([2eb7941](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2eb79412a874088753ff0889f215818d522f5c3e))
- update ([7fabef5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7fabef53dffe0360d1e5623a094e57781852eda6))
- update ([622325a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/622325aaf15e3dc28d607c54f567283af2b52895))
- update alert ([a1a41d6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a1a41d67a00f628f3706e406464f848822030629))
- update alert ([cce0625](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cce062597a47c8aadd3a26e10ddc5f5e2fb1cd9d))
- update alert ([b9e2a3b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b9e2a3bc5af192f646fab51e6ea300e05813e9d4))
- update calender icon ([d1c1397](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d1c13973016946778b353f2197286b5f4f5a5e7c))
- update configs & use pams endpoint ([e2e4b43](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e2e4b437a7fb0e740a6609e728ba04def56da2a8))
- update container pairs story ([a21b0ea](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a21b0ea4afd76113f9d7771d5d3af08469c64a85))
- update control panel & containers ([6748fed](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6748fed206f819d5b804b74513e1895076c21b2d))
- update control panel & containers, rewrite lists ([5189f12](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5189f12c84a34c5715147021b15477e4f40a9784))
- update control panel icon ([75cecc7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/75cecc70b58c41f7cda07e752e5a3df84137ef66))
- update css ([8d3d247](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8d3d24735c3a4d58ef1eeeb1eeb29822f686eb27))
- update css ([063c56f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/063c56fc5d10407151e253b3e45b79c505c0ec67))
- update Dropdown ([c56d0e7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c56d0e7261ab031448f1408bdea3645006db20c9))
- update enable state of pph button ([b97c6a9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b97c6a91b69b666ec3fe18e0eff053f4a4e9644f))
- update error state ([0f88d11](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0f88d1197864f4da25f4162264ca9a5f77649e91))
- update error state ([b37d258](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b37d258a88177f9996f5c14619ce45bbce96832b))
- update icon ([69e8e94](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/69e8e9425751801a14ec14db64f22b3d642a6985))
- update icon position ([f689d2f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f689d2f35b4114b100b7c83819ad84c6d9da572a))
- update icons ([7fc8d3a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7fc8d3a18f86c0a5313a293a7535910606d91c1f))
- update image story ([0f80cb4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0f80cb4ce2744a724746f0a8c5a7d586cb8292bf))
- update modal colors ([ae87f07](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ae87f0741bcf8cfc65cd3997e7bb3c92ff908d9c))
- update save callbacks ([77399e2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/77399e2339072670dbb5e2641c950d0b03653953))
- update save logic ([567bbba](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/567bbba9b794b7f4c848a7e42f56ae06727db918))
- update snapshot ([d8a4636](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d8a46369d05bc76376f7521b3207713e6056dabd))
- update snapshots ([2dafec6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2dafec6e67ad76ba203ded13c770ae9cfa037e9a))
- update step buttons behavior ([8b85f9e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8b85f9ef2d64841462db53045f204109dc72fd1b))
- update stories ([db67245](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/db67245f80868d58b109efd4a5b7a58797997348))
- update stories für stepper ([24ec68c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/24ec68c97e525694b7780c1444d1682f69eee923))
- update story ([c2ea490](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c2ea490eb9f9738391d274af22ec40b817820ad4))
- update story ([6d3cc07](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6d3cc07b44f2c8a3bafae113d9c1abff302d48e1))
- update story ([bf90303](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bf90303d48256fc2e9574aa745a5fc8dd7b8d786))
- update story ([acaf549](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/acaf549fd9b4e490a92516e7c84e78ac8d1c1516))
- update styles ([687f38a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/687f38a86025557d8b9e648fc097e50f7a11f667))
- update styles ([84c113d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/84c113db7179ddd1357828fc9352957dde3092b8))
- update test ([8e7edc9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8e7edc95a272b5ed5c1c2ed47d130a1ff6928630))
- update test ([6cadf70](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6cadf70c4bb0ae69cb28dcced0451ab4c825e684))
- update test ([6b38e8d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6b38e8d94cfa4763b80fdc676c3eaac26c78254b))
- update test ([deea8ce](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/deea8ce1f7be583cb68bdcf8188e6bbf8567f4d4))
- update tests ([0961761](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/096176184d2e1cdbf6c57949403f086e4fedbc4d))
- update tests ([847e791](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/847e791be49b7091c7065d70212f996eab88df29))
- update text input ([ebc0cdd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/ebc0cdd1f2a85550aa5b462feb40550bac1bec41))
- update validation in stepper ([53e9ab8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/53e9ab82b96a3453ef93bdf2101622bb3dc04bb6))
- update version ([fa531a5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fa531a5d687a670af9c8eff88a0779ec317c38d3))
- update welcome pade ([820d5d8](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/820d5d8f14ff3bf10823bb8f5a92587de8a9a2d5))
- use normalize.css to unify experience between different browsers ([1ab1e32](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1ab1e323ad9e8f405f9ea624155136432e0d3788))
- **icon:** add icon module and component ([e327369](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e32736997cdc849e2abe41692903f56218ffd967))
- **oblique:** adapt master layout to dazit needs ([9a77601](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9a776018823cefde61f00f6b1dd5825332af778b))

### Bug Fixes

- 404 error frutiger ([cfbc435](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cfbc4350172cce36b0dd6c87436a86852201f243))
- add components ([7fa9fef](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7fa9fef61a35e4015224e458d6929b7f4936c389))
- add css ([45b9a69](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/45b9a693cc98d394e4c325accb89c09103d39b9d))
- add disables state for dropdown ([f51ccac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f51ccacb9807dd04418fbad5087ef55fb6354f78))
- Add group identifier to qd-ui package and remove package config properties from example project ([89ea252](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/89ea252be0253a5949681610017965d0012e7052))
- add host listener ([b7d07dc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b7d07dc18edde54e3132a5b86930f20663036e00))
- Add missing import for test ([80e2e6b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/80e2e6b49dcec0ae7b100e015221bbe9e994c496))
- add onDesproy life cicle hook ([dc1b982](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/dc1b982b01042fa00eb6a6839d5beba4e7245d17))
- add provider ([0c0124f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0c0124f0a2305157559c736ec2c6a184a350455c))
- add provider ([aed5b61](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/aed5b61eb2be3ca0c19b2e7d3d5fbb3849dce019))
- add provider ([dab7a17](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/dab7a17b8e2ee58c2a5d98d03280287dd6f6c96f))
- Add wrongly removed condition for uploading files ([f167db7](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f167db74de9e63884d30976ecd06ec144b2b0552))
- Appearance of upload after it broke due to other changes ([8c24b92](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8c24b921c909a400a9e2aa7c5cc6dbc99559b30a))
- Apply style for icons inside table DAZUIC-237 ([93415aa](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/93415aaaa4685a542c568c7541301ba862b9ffb0))
- banner ([7a16bac](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7a16bac8363bda9bbfdd95ef824c096a6147b01f))
- border in panel title ([b5cbb3b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b5cbb3b0a19ed61691d618e1bb62355db93125b5))
- button position date picker ([faebfc5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/faebfc5813be6d3207e040499a3f75d998af1b56))
- Caused error because variable is null DAZUIC-392 ([d061367](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d06136797f14c0c085d349a42521ab2515c5a28c))
- Change version of sass function to improve legacy support ([018be06](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/018be06b3d8fd7586ca30911633e04c4a09af5a3))
- Condition for handling the stepper inside the layout container ([6b7cbc6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/6b7cbc6121309b7c04d996ac177a96108980c04f))
- Copy wrong font face definition ([e0bd0c4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e0bd0c463451ff14806fcee341885ea5139d7338))
- Corrupt checksum of package DAZUIC-392 ([7e7c9d1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7e7c9d1550c4762d21f239ad812c5ea86a010014))
- custom bottons in table ([3939867](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/39398672cc44cb2171b97130b3c2a9a4fb7ca3c7))
- disable broken layout stories ([010aae3](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/010aae34dc82102dc761ffd9d25190e0366d3e28))
- Disabled state is updated on @Input change ([178392b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/178392b2a04123096ef63322a4fe25136b59fa49))
- enable submit - assign to the input ([c2e237e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c2e237e90e67033ead10d832e57a2782c9c04419))
- error messages ([959c284](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/959c28436c2032452a202434ee8381c17cadec0e))
- export APP_ENVIRONMENT configuration of banner ([c83e8ad](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c83e8ad05866fadf9144a9242cdbbce79a2c45c8))
- fix create function in container ([f1eab65](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f1eab65fcf13f9933417d9d54044ae05dd22cb6b))
- fix icons ([679e4e1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/679e4e1d1291dd6c6a69948a09a8527efd900e76))
- fix margin relationship between container column and container list ([e6b3296](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/e6b3296b94c0d2dc648cb47c88a2c365cfcf2878))
- fix master layout footer missing ([2a792ca](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/2a792ca06584156c231782ed795ad8b2de32d855))
- fix tabs without formGroup ([c5a7598](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c5a75987db0792f9c1b3d0e71c3da8f8b7857dda))
- height of container header ([bb16026](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bb16026772625a29c6115b1899dac7f737403135))
- icon button color ([5619870](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/56198703668d8991d03693f84ed6ad03da131ba8))
- Import fontawesome libs as zip archive due to pipeline failure DAZUIC-150 ([1fe9653](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1fe96539d6701a11c2307f26ad4f5c9257d16bf9))
- import material component scss to fix style error ([29a6ffb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/29a6ffb8367a5fdc2447ad4315432d2cd911f0b0))
- Import of global styles DAZUIC-150 ([817a8f9](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/817a8f94bc00b103dc0cb1677dd9cd1f1e41836c))
- imports ([391d17a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/391d17a0d9d76882b85037bedfd658c1aea1954c))
- Karma config removed because jest is used DAZUIC-150 ([d40a6ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d40a6ab89607f8b8cc21b66ac8d5e6f40d5536cb))
- limit letter count in header ([4de8f9c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4de8f9cdce7dd719c92e085f5f38de7f87f13c4a))
- Make import relative to prevent error ([dd5024b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/dd5024b0d1b29eb35707b170e88c009be933d1e6))
- Make qd-icon inside mat-icon-button clickable ([b4d137a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b4d137ab86675451de861cda542629c9c770754e))
- margins full width conatainer ([a1e6e01](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a1e6e01662bd4e190491d75dc6dfa020ae8dbe0f))
- Match of active tab link ([0dd3ec1](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0dd3ec17532dc7b7ff618442a6668735e327d980))
- material forms ([f9cf71b](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f9cf71bac29a6d9b577f29a4caec0a29e70a4eae))
- modals in scenarios ([355224d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/355224d79ebc1341f7e338185f91abd66210bfc5))
- name as observable ([3265c1d](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3265c1d1575a667e0ad76989b6b84ef7fb6b20d0))
- override frutiger ([d1cf5bd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d1cf5bdbb8a0dbe003541a7a94cbbb6193d833db))
- panel width ([948650e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/948650e68104b4f143242887da74335cb825aa70))
- Pass environment to qd-ui by using forRoot method ([8fa3bdd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8fa3bddb4da4df998a7a36b99f71251767aef61b))
- qd button color ([32e4cd4](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/32e4cd4513682bd2edcc3cb6796b610d537b00e3))
- re-activate pph use cases ([282f13e](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/282f13e1895ff4b7ab166f0c7df1600094e8c608))
- Recognition of active route route ([99de056](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/99de056755a57a65d0e512cd920e079ebd4b2a93))
- reduce min-width ([9a832dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9a832ddd9983e6029c0a80c73d03570d55f6ea45))
- remove console.log ([95ec4ed](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/95ec4ed4447df859c8661103a6e7598a53f06309))
- remove css-width ([bb9e6db](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/bb9e6db296053ed4f53279a4bbc36fdfbcec2c0f))
- Remove double forRoot declaration in route module ([a713fe2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a713fe2af75fec3da91d0afaf0a93dec33bd1fc1))
- Remove double forRoot declaration in route module ([0a34a17](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/0a34a17faecaf543eefbf67d013a923312ad12b4))
- Remove duplicate instantiating of TranslateModule ([fbd3330](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fbd3330b35d36edd5992c300994ed7af79d6d988))
- Remove duplicate keys in environment.prod.ts ([fe44458](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fe44458b246c6088b14f41e5ddfb33adbd3733c3))
- remove fonts ([c250d39](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c250d39adfc1bdbedc9ccd7eabde54b0c5e2eae8))
- Remove NoopAnimationsModule from QdMaterialModule because it caused an "imported twice"-error when using lazy-loaded modules ([3c571c2](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3c571c2e2cacf83f4c0f228dac67ae5f0cf137a6))
- Remove not working structure ([fccd2ab](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fccd2ab7323a3d8967b954ec56819a5d1f2d4f6b))
- Remove overflow restriction to prevent hiding the language selection of the header-widget ([4b36e2a](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/4b36e2ab71d7012f1b868d4975fe214e4bbe4ba1))
- remove padding bottom of container ([40e78d0](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/40e78d0c0290b9cf3b638008607d2f5e97feb4eb))
- remove temp functins ([03eb844](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/03eb844e11ba0bf66a1a317770d9ee2ea1ec4b48))
- resolve merge conflicts ([a127f56](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/a127f561bcc19eb6c43ce5a1b825e705d84679cd))
- Return correct type for auth helper function ([fc2a07f](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/fc2a07fdf0e5f2f6ccb50fa6bc513d0f99dfd80f))
- selector content grid row ([c6b9b0c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/c6b9b0c9613b88a6e8be796daa7d02d50915b533))
- small update ([46d992c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/46d992cca175010f398cee1a17c402b4363908c5))
- stepper - save on step item ([b7aa1dd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b7aa1dd435b020fa12dfec701eafb4d24b60cafc))
- style in container section subheader ([b64e169](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/b64e1695dbec362853baea5dfab3e8f3e7d67e81))
- styling issues due to oblique ([3fe0505](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/3fe0505a025801009771d31c393a71a9bf5f2901))
- table container css ([422858c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/422858c3e84b48b6989480e0eeb79fb036afe2a5))
- translation step button ([cc9a6fb](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/cc9a6fbc8141af3e91ee6ae51e19900ad24d0127))
- truncated text ([9a5cec6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9a5cec64abb02ff44291fb458e1d86652ffef592))
- Ts lint problems ([9c8fed5](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/9c8fed5b0ec7243898df46e4373df3114186293d))
- Ts lint problems ([d63af52](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/d63af521ea30ef964fd20365ee78d69713e9c993))
- Typo ([16ddb7c](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/16ddb7c61ddab17fa09321498d97160e68f52e42))
- update components ([f439d98](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f439d98ac82061d45fe1da72f0a54920ebc518ec))
- update conditions ([7d70ebc](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/7d70ebc3cb7d2ef1ec33df5e7fc213a1b00e6cfe))
- update marginin table ([084f480](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/084f48039ae6f428d122aeee0c57ca85db917e3b))
- update snapshots ([1d664a6](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d664a615e8feda9a42c1cae38d19486e6e05dbb))
- update version ([f62d562](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/f62d562eb947270c1cefea8d69436e701392bb30))
- update version ([8273dbf](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/8273dbfbcb370f74c1b0e1cdffa6483630bce8eb))
- use 100% height of html ([1d19d86](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/1d19d867f54b50753178dfb60799466b47bb50cd))
- use new list element ([5ca6c82](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/5ca6c82ff030b3bbb36b1aa511bedb9aea7f7efc))
- vertical gap in vertical pairs ([95f02fd](http://bitbucket.bit.admin.ch/ezqd/qd-ui/commit/95f02fdcef7643b3ad4e1b02d14e0ba4f53119a9))

### 1.2.3 (2021-02-12)

### Features

- name as observable ([db08e58](https://bitbucket.bit.admin.ch///commit/db08e58b0e63601113ce1162c08d3bcce0bf87cb))
- **icon:** add icon module and component ([e327369](https://bitbucket.bit.admin.ch///commit/e32736997cdc849e2abe41692903f56218ffd967))
- activate PPH-Submit-Button depending on stepper ([05fbbc8](https://bitbucket.bit.admin.ch///commit/05fbbc8cb15368cc6aefab88a885b10865dd5d79))
- Activate tab based on the current route ([af29909](https://bitbucket.bit.admin.ch///commit/af2990945c6857e8f946a8484e02d7c1dfaca8ca))
- add action area, add button logic, refactoring, add page leave handler ([8a85cbd](https://bitbucket.bit.admin.ch///commit/8a85cbd1c38ae45293c8aef633e4f4e7e23320c4))
- add alert ([354b271](https://bitbucket.bit.admin.ch///commit/354b2710dd6fa1df6ebdd5412a0b5c361828b33b))
- add animation ([ea7d4ec](https://bitbucket.bit.admin.ch///commit/ea7d4ec70a71af1e9a5b329d8e064267293f74ff))
- add app status banner ([5827d80](https://bitbucket.bit.admin.ch///commit/5827d80c32da8ff845f4a254bc05e502db454ea2))
- add ArgsTable ([e143957](https://bitbucket.bit.admin.ch///commit/e143957d940fc190fce7a6c07f2a5b92c1bdbb5c))
- add border & margin ([f921ce1](https://bitbucket.bit.admin.ch///commit/f921ce1204af8bf934cd06a01bf70a57051282f9))
- add borders ([c7f2d40](https://bitbucket.bit.admin.ch///commit/c7f2d409f510bacec1ac65b5536cb7d700f1746d))
- add breakpoint mapper, add components, add styles ([66a5e80](https://bitbucket.bit.admin.ch///commit/66a5e80f463e3c368e80f60398c2be9295e7be14))
- add buttons ([61556de](https://bitbucket.bit.admin.ch///commit/61556de44f0d10a70372f4be54c0b7c9d2650b78))
- add callback function, update tests ([e67a6d3](https://bitbucket.bit.admin.ch///commit/e67a6d39deaf8948ac3d55a8647baef616a580e2))
- add card title as directive ([c8ec76a](https://bitbucket.bit.admin.ch///commit/c8ec76a65a1a06f4fec97ee7109db536785a30a0))
- add colors in settings ([7d46d5d](https://bitbucket.bit.admin.ch///commit/7d46d5da0e679962497526d30ebc4f50b3cb68ae))
- add component ([acd19b4](https://bitbucket.bit.admin.ch///commit/acd19b4cb7154673bc8fa1c299c351d66f14c4de))
- add components, add story, add some syling, add modal ([bc8d23c](https://bitbucket.bit.admin.ch///commit/bc8d23c9df3fd7ef67b8369ace5d207e13c09507))
- add css ([4a02fcc](https://bitbucket.bit.admin.ch///commit/4a02fcc87e1537f8a2aee93d3c7718d858d0a0b7))
- add directive ([d1d0d7d](https://bitbucket.bit.admin.ch///commit/d1d0d7d0042a7e12dadc19ccfb12daa0df7f7a03))
- add error & warning color ([10cbf1f](https://bitbucket.bit.admin.ch///commit/10cbf1fb57cfe7d227a6f4b183d51ad099627117))
- add example ([0f1a352](https://bitbucket.bit.admin.ch///commit/0f1a352818155a30fbf9ef69a4741a1c54cbee50))
- Add example for translation DAZUIC-392 ([b941a08](https://bitbucket.bit.admin.ch///commit/b941a08f9c790da9c70f0a2c85c7584a45493799))
- add height of sticky action bar ([e42c889](https://bitbucket.bit.admin.ch///commit/e42c889f885f74b85f0c43c7df3cf6d8d9cbf2c1))
- add icon buttons in input fields ([c706a63](https://bitbucket.bit.admin.ch///commit/c706a63a9ef50785402ad6f7c19b7d9f804e8b0f))
- add icons ([f34c042](https://bitbucket.bit.admin.ch///commit/f34c04296a2bb35257e88e7f9224afde3e833448))
- add image component ([3bc1498](https://bitbucket.bit.admin.ch///commit/3bc14981793439a1d0555c9c6f1e01cb478e846d))
- add list pairs for containers ([4885691](https://bitbucket.bit.admin.ch///commit/4885691a809cdf8c0c7dedfe72def9aff4a7b35e))
- add more icons ([23844b6](https://bitbucket.bit.admin.ch///commit/23844b6cce32ed18b89cfbeee23bd49c379e6e1a))
- add navigation property ([4f133a2](https://bitbucket.bit.admin.ch///commit/4f133a27e6171505b150fe84e2a7c92b86e5b7cf))
- add notes ([90a5749](https://bitbucket.bit.admin.ch///commit/90a57490f675b192a1f4e187162787c542993a93))
- add page title header ([aa4e895](https://bitbucket.bit.admin.ch///commit/aa4e895897dc27cf7c5ccc47451e801489e3b0b4))
- add snapshot ([d58f53b](https://bitbucket.bit.admin.ch///commit/d58f53bae926b0d2d24c340de343d961308f32af))
- add some checks ([cf00f90](https://bitbucket.bit.admin.ch///commit/cf00f90cd9c1b258a30c410937dada3bc69f0372))
- add some mdx files ([a2ccbc3](https://bitbucket.bit.admin.ch///commit/a2ccbc3f8498e71cb0bc8d01bde4242164a6bea1))
- add some more icons ([9510a0e](https://bitbucket.bit.admin.ch///commit/9510a0efbc382dfcc725e478bff850dbdae8145c))
- add special container properties ([99ea522](https://bitbucket.bit.admin.ch///commit/99ea52224207060e6d8d6c47222b2974d3293e38))
- add special container properties ([bfce420](https://bitbucket.bit.admin.ch///commit/bfce420dd632f15118552d0179e0fabde62ef42e))
- add srory, add styles ([3250923](https://bitbucket.bit.admin.ch///commit/325092318cd83371c6e17cec0d1785f513954f83))
- add styles ([28e58f8](https://bitbucket.bit.admin.ch///commit/28e58f8f1f9e5e8f8348bf38b97dca9305ed8be9))
- add submit button in control panel ([f457a06](https://bitbucket.bit.admin.ch///commit/f457a063ea7e55b89f41ab79f0503b8d779c1e40))
- add success color ([db56319](https://bitbucket.bit.admin.ch///commit/db5631955e25ae14b643b15dbfe758f5c92d7780))
- add summary modal ([2d64b91](https://bitbucket.bit.admin.ch///commit/2d64b9135b3ecae387df63a6d85ff23294b59e15))
- Add table example DAZUIC-392 ([549bdb8](https://bitbucket.bit.admin.ch///commit/549bdb8d6ed9c00959437a9c613b07b0836b8432))
- add text section components ([7b77910](https://bitbucket.bit.admin.ch///commit/7b7791021feea7c1627b85b79b34c7f887f6addd))
- add title in page process header ([1ae0674](https://bitbucket.bit.admin.ch///commit/1ae06743b97b4003e23c572fd2554b56d200d2ec))
- add title to container section ([14b494d](https://bitbucket.bit.admin.ch///commit/14b494da6ba3342fc5779f0600001d9a14aa3d66))
- add titles in cards ([32a451d](https://bitbucket.bit.admin.ch///commit/32a451d85ec901b8af69d0785f47622e27ffb85b))
- add to story ([11ae362](https://bitbucket.bit.admin.ch///commit/11ae3629a47ba62223dd92408b97eff8a94c4e8b))
- Add translation for stepper button DAZUIC-232 ([443d4e1](https://bitbucket.bit.admin.ch///commit/443d4e1024ff8aa6810e8de26466ec10ec9013af))
- add usecases in stories ([b97ce5b](https://bitbucket.bit.admin.ch///commit/b97ce5b64d2ffcf571bf04d77715f22da5114d33))
- add warning colors ([1a760bf](https://bitbucket.bit.admin.ch///commit/1a760bf44aa9ecb9ec1fd973b85554ae2b5d31fd))
- add/replace icons ([05aae43](https://bitbucket.bit.admin.ch///commit/05aae43678e89228667408acc6c5105fa18d1b92))
- adjust height of page title by master layout ([7c5ea3a](https://bitbucket.bit.admin.ch///commit/7c5ea3af3702948a3d57e6c6aa9a99b7c6d230b8))
- adjust height of page title by master layout ([77501b3](https://bitbucket.bit.admin.ch///commit/77501b3ea0082cbac6a662fe2a3f700055be032c))
- adjust height of PPH by master layout ([6700f22](https://bitbucket.bit.admin.ch///commit/6700f222c6536500ac27c8a014d66a6404a02b08))
- auto expand container when create new ([3b1d97d](https://bitbucket.bit.admin.ch///commit/3b1d97db02ec7cb71a51d975da861abc5919b51b))
- autodetect forms ([c98cfa3](https://bitbucket.bit.admin.ch///commit/c98cfa3e1469cbce77acab6aedb1017780125cf5))
- change callback to event pattern ([1956026](https://bitbucket.bit.admin.ch///commit/1956026005a29a3c2aac169fc3611af8df5fb2e9))
- change properties ([dd496c1](https://bitbucket.bit.admin.ch///commit/dd496c1d96aad407243d98bb4bc7517faba3875e))
- change to warning ([4a4d167](https://bitbucket.bit.admin.ch///commit/4a4d1670c719805cb5f9052054674ea3cfc0900d))
- clean-up ([684fac7](https://bitbucket.bit.admin.ch///commit/684fac7057cabfdf9edf8c92bed1a45538c5a6ec))
- Control visibility of normal and mobile header-widget inside a custom component DAZUIC-328 ([95f9e95](https://bitbucket.bit.admin.ch///commit/95f9e95c0904b27a8df0bf765ae8ea2115ea74a5))
- Coordinate assignment of html attributes to prevent overwriting the default values DAZUIC-328 ([e8ce7f2](https://bitbucket.bit.admin.ch///commit/e8ce7f2b41dd6468959105ee6e25fb2f9fd1d6fb))
- Create qd-icon-button component to display buttons with icons only inside ([173bcdd](https://bitbucket.bit.admin.ch///commit/173bcddebb4ef24a4075f77cad715aafbec8fd86))
- Create row directive to navigate among table rows ([607669f](https://bitbucket.bit.admin.ch///commit/607669fa08fcc0cafb867a6aa5c392aa67a2fa98))
- Create sample page for stepper and auth DAZUIC-392 ([db24834](https://bitbucket.bit.admin.ch///commit/db248341050aac4cef352561c049385f08115498))
- Create story for pams modal ([6e72377](https://bitbucket.bit.admin.ch///commit/6e723770990d7151068d9d8bed8e100288b42391))
- Create story for qd-header-widget DAZUIC-328 ([4940560](https://bitbucket.bit.admin.ch///commit/4940560649ce6e436dc6fc9d1cada201a0642df5))
- Create tab bar as an router based alternative for qd-tabs ([756ee45](https://bitbucket.bit.admin.ch///commit/756ee4538b3f16e5ad842c995393c1b3b3a82c81))
- Create text and button list item inside tile DAZUIC-278 ([fd28dc9](https://bitbucket.bit.admin.ch///commit/fd28dc983711b6ada7c3c75cfd84b844ced983b1))
- css ([3844418](https://bitbucket.bit.admin.ch///commit/3844418f515f82f3b53e986b4595830d261a8905))
- deactivae mt lists in storybook ([0b18ea1](https://bitbucket.bit.admin.ch///commit/0b18ea1fb91c1a4690278bec0811191e28417f27))
- disable warning css ([d97ccc4](https://bitbucket.bit.admin.ch///commit/d97ccc476913074858a49d256b0bd772eb283cd1))
- error in datepicker ([5f29d6e](https://bitbucket.bit.admin.ch///commit/5f29d6e97dbdc5cdffd4a30e65e9ebd6da0888ec))
- extend stepper showcase ([f4999ac](https://bitbucket.bit.admin.ch///commit/f4999ac686d50cc4b19aa735e93b012a945ab124))
- fix calender icon ([eceb775](https://bitbucket.bit.admin.ch///commit/eceb775d3811fc93d78a196473ca8e0724f3c346))
- fix more icons ([db442c7](https://bitbucket.bit.admin.ch///commit/db442c78ef9fdd6d44b055c4e1626caaf97a7137))
- fix more icons ([65e43da](https://bitbucket.bit.admin.ch///commit/65e43dac8487aee055d1f6aea4b19d519fe5bc7a))
- initial invalidation ([24cd29e](https://bitbucket.bit.admin.ch///commit/24cd29eb32414521dd598cf3018b71d5038a4926))
- Move download component and renamed it according to qd naming conventions ([e22e347](https://bitbucket.bit.admin.ch///commit/e22e347319a789e65dc9842e9b795bcc56ab850a))
- move page process header to layout system ([c2a2adb](https://bitbucket.bit.admin.ch///commit/c2a2adb897c90852615f09391ae5792a2cec5082))
- move stories ([850bdbf](https://bitbucket.bit.admin.ch///commit/850bdbffddf08020b607a1e9053e6a501903a297))
- move stories, rename stories, update browser check ([c00939b](https://bitbucket.bit.admin.ch///commit/c00939b6514c452bca0204560dea3d2b6c0f8f4a))
- px to rem ([4c9250f](https://bitbucket.bit.admin.ch///commit/4c9250f913416bf1dc789deef0060f4acdd332e2))
- re-organize css ([53f03d5](https://bitbucket.bit.admin.ch///commit/53f03d50182fd9442614c807af03e7c8dadbf63c))
- refactor form css, add table margins, add pagination css and margins, add progress bar ([334b494](https://bitbucket.bit.admin.ch///commit/334b49469cacacb772607d2177bf8d9a37ce9351))
- remove focus ([fef9557](https://bitbucket.bit.admin.ch///commit/fef95579376065faa987c1454d8864c338f766f6))
- remove import ([ae2bf7d](https://bitbucket.bit.admin.ch///commit/ae2bf7dbd6aaa669df33bf75393d38663b148399))
- Remove tgz modules DAZUIC-150 ([e01fde6](https://bitbucket.bit.admin.ch///commit/e01fde65c460e0820cedaee9612f135a550205b3))
- renaming ([0486058](https://bitbucket.bit.admin.ch///commit/04860580acec56ece42cfb9225dc2ba4a094db57))
- reorganize css ([cc024a7](https://bitbucket.bit.admin.ch///commit/cc024a797536e7193b51cc338e6f61b34616b605))
- set width od page processheader dynamically ([87b68ec](https://bitbucket.bit.admin.ch///commit/87b68ecd52b857acce42785cbe7c92ca2170cfb2))
- shorten lang input field texts ([79a0c3d](https://bitbucket.bit.admin.ch///commit/79a0c3dad74d14025ae42c35fde3ae45d98955bb))
- small changes ([0208b75](https://bitbucket.bit.admin.ch///commit/0208b75a387fcfa46b0f7756d080556ad70b9fa9))
- small changes ([7620a2b](https://bitbucket.bit.admin.ch///commit/7620a2b9426fbd60cc5b5fc1e3267c290883145c))
- small changes ([1b1c8b7](https://bitbucket.bit.admin.ch///commit/1b1c8b7a9ddedc4efe48b7ae1dde7616e254a303))
- small changes ([66dca57](https://bitbucket.bit.admin.ch///commit/66dca57b502fc68fb14224f3a2151e8510ded925))
- some changes ([5b19da3](https://bitbucket.bit.admin.ch///commit/5b19da38f94031ba3d1b4e4fadafd4a1cc0e76f7))
- some changes ([0906be2](https://bitbucket.bit.admin.ch///commit/0906be2b6cdf49ad24f9f6b89a84e361b5a799b6))
- some changes ([d24fc2b](https://bitbucket.bit.admin.ch///commit/d24fc2b9d0603142be196e7494fdb045c3a866a6))
- some small changes ([d2c81e0](https://bitbucket.bit.admin.ch///commit/d2c81e0505df63a9d5c0f548386db7246f4863e0))
- some small updates ([9ad690c](https://bitbucket.bit.admin.ch///commit/9ad690cc61c89f3d83a796d1ca0b13aff9197ca3))
- some styling ([c78825c](https://bitbucket.bit.admin.ch///commit/c78825cd70db67ef0c9a247b5d8f498d6aa80685))
- Table column directive to handle text overflow DAZUIC-241 ([c29412a](https://bitbucket.bit.admin.ch///commit/c29412aa93cd5efc84a2a836bbc575658f53c132))
- Temporary error component for formGroups (because the default mat-error is not controlled automatically in this case) ([d52a49d](https://bitbucket.bit.admin.ch///commit/d52a49d92c9c5c7b8ba2b2a0a651a0d8bcf42faa))
- tests ([2eb7941](https://bitbucket.bit.admin.ch///commit/2eb79412a874088753ff0889f215818d522f5c3e))
- update ([7fabef5](https://bitbucket.bit.admin.ch///commit/7fabef53dffe0360d1e5623a094e57781852eda6))
- update ([622325a](https://bitbucket.bit.admin.ch///commit/622325aaf15e3dc28d607c54f567283af2b52895))
- update alert ([b9e2a3b](https://bitbucket.bit.admin.ch///commit/b9e2a3bc5af192f646fab51e6ea300e05813e9d4))
- update alert ([cce0625](https://bitbucket.bit.admin.ch///commit/cce062597a47c8aadd3a26e10ddc5f5e2fb1cd9d))
- update alert ([a1a41d6](https://bitbucket.bit.admin.ch///commit/a1a41d67a00f628f3706e406464f848822030629))
- update calender icon ([d1c1397](https://bitbucket.bit.admin.ch///commit/d1c13973016946778b353f2197286b5f4f5a5e7c))
- update configs & use pams endpoint ([e2e4b43](https://bitbucket.bit.admin.ch///commit/e2e4b437a7fb0e740a6609e728ba04def56da2a8))
- update control panel & containers ([6748fed](https://bitbucket.bit.admin.ch///commit/6748fed206f819d5b804b74513e1895076c21b2d))
- update control panel & containers, rewrite lists ([5189f12](https://bitbucket.bit.admin.ch///commit/5189f12c84a34c5715147021b15477e4f40a9784))
- update control panel icon ([75cecc7](https://bitbucket.bit.admin.ch///commit/75cecc70b58c41f7cda07e752e5a3df84137ef66))
- update css ([063c56f](https://bitbucket.bit.admin.ch///commit/063c56fc5d10407151e253b3e45b79c505c0ec67))
- update css ([8d3d247](https://bitbucket.bit.admin.ch///commit/8d3d24735c3a4d58ef1eeeb1eeb29822f686eb27))
- update Dropdown ([c56d0e7](https://bitbucket.bit.admin.ch///commit/c56d0e7261ab031448f1408bdea3645006db20c9))
- update enable state of pph button ([b97c6a9](https://bitbucket.bit.admin.ch///commit/b97c6a91b69b666ec3fe18e0eff053f4a4e9644f))
- update error state ([b37d258](https://bitbucket.bit.admin.ch///commit/b37d258a88177f9996f5c14619ce45bbce96832b))
- update error state ([0f88d11](https://bitbucket.bit.admin.ch///commit/0f88d1197864f4da25f4162264ca9a5f77649e91))
- update icon ([69e8e94](https://bitbucket.bit.admin.ch///commit/69e8e9425751801a14ec14db64f22b3d642a6985))
- update icon position ([f689d2f](https://bitbucket.bit.admin.ch///commit/f689d2f35b4114b100b7c83819ad84c6d9da572a))
- update icons ([7fc8d3a](https://bitbucket.bit.admin.ch///commit/7fc8d3a18f86c0a5313a293a7535910606d91c1f))
- update image story ([0f80cb4](https://bitbucket.bit.admin.ch///commit/0f80cb4ce2744a724746f0a8c5a7d586cb8292bf))
- update modal colors ([ae87f07](https://bitbucket.bit.admin.ch///commit/ae87f0741bcf8cfc65cd3997e7bb3c92ff908d9c))
- update save callbacks ([77399e2](https://bitbucket.bit.admin.ch///commit/77399e2339072670dbb5e2641c950d0b03653953))
- update save logic ([567bbba](https://bitbucket.bit.admin.ch///commit/567bbba9b794b7f4c848a7e42f56ae06727db918))
- update snapshot ([d8a4636](https://bitbucket.bit.admin.ch///commit/d8a46369d05bc76376f7521b3207713e6056dabd))
- update snapshots ([2dafec6](https://bitbucket.bit.admin.ch///commit/2dafec6e67ad76ba203ded13c770ae9cfa037e9a))
- update step buttons behavior ([8b85f9e](https://bitbucket.bit.admin.ch///commit/8b85f9ef2d64841462db53045f204109dc72fd1b))
- update stories ([db67245](https://bitbucket.bit.admin.ch///commit/db67245f80868d58b109efd4a5b7a58797997348))
- update stories für stepper ([24ec68c](https://bitbucket.bit.admin.ch///commit/24ec68c97e525694b7780c1444d1682f69eee923))
- update story ([acaf549](https://bitbucket.bit.admin.ch///commit/acaf549fd9b4e490a92516e7c84e78ac8d1c1516))
- update story ([bf90303](https://bitbucket.bit.admin.ch///commit/bf90303d48256fc2e9574aa745a5fc8dd7b8d786))
- update story ([6d3cc07](https://bitbucket.bit.admin.ch///commit/6d3cc07b44f2c8a3bafae113d9c1abff302d48e1))
- update story ([c2ea490](https://bitbucket.bit.admin.ch///commit/c2ea490eb9f9738391d274af22ec40b817820ad4))
- update styles ([84c113d](https://bitbucket.bit.admin.ch///commit/84c113db7179ddd1357828fc9352957dde3092b8))
- update styles ([687f38a](https://bitbucket.bit.admin.ch///commit/687f38a86025557d8b9e648fc097e50f7a11f667))
- update test ([6b38e8d](https://bitbucket.bit.admin.ch///commit/6b38e8d94cfa4763b80fdc676c3eaac26c78254b))
- update test ([8e7edc9](https://bitbucket.bit.admin.ch///commit/8e7edc95a272b5ed5c1c2ed47d130a1ff6928630))
- update test ([6cadf70](https://bitbucket.bit.admin.ch///commit/6cadf70c4bb0ae69cb28dcced0451ab4c825e684))
- update test ([deea8ce](https://bitbucket.bit.admin.ch///commit/deea8ce1f7be583cb68bdcf8188e6bbf8567f4d4))
- **oblique:** adapt master layout to dazit needs ([9a77601](https://bitbucket.bit.admin.ch///commit/9a776018823cefde61f00f6b1dd5825332af778b))
- update tests ([0961761](https://bitbucket.bit.admin.ch///commit/096176184d2e1cdbf6c57949403f086e4fedbc4d))
- update tests ([847e791](https://bitbucket.bit.admin.ch///commit/847e791be49b7091c7065d70212f996eab88df29))
- update text input ([ebc0cdd](https://bitbucket.bit.admin.ch///commit/ebc0cdd1f2a85550aa5b462feb40550bac1bec41))
- update validation in stepper ([53e9ab8](https://bitbucket.bit.admin.ch///commit/53e9ab82b96a3453ef93bdf2101622bb3dc04bb6))
- update version ([fa531a5](https://bitbucket.bit.admin.ch///commit/fa531a5d687a670af9c8eff88a0779ec317c38d3))
- update welcome pade ([820d5d8](https://bitbucket.bit.admin.ch///commit/820d5d8f14ff3bf10823bb8f5a92587de8a9a2d5))
- use normalize.css to unify experience between different browsers ([1ab1e32](https://bitbucket.bit.admin.ch///commit/1ab1e323ad9e8f405f9ea624155136432e0d3788))

### Bug Fixes

- 404 error frutiger ([cfbc435](https://bitbucket.bit.admin.ch///commit/cfbc4350172cce36b0dd6c87436a86852201f243))
- add components ([7fa9fef](https://bitbucket.bit.admin.ch///commit/7fa9fef61a35e4015224e458d6929b7f4936c389))
- add css ([45b9a69](https://bitbucket.bit.admin.ch///commit/45b9a693cc98d394e4c325accb89c09103d39b9d))
- add disables state for dropdown ([f51ccac](https://bitbucket.bit.admin.ch///commit/f51ccacb9807dd04418fbad5087ef55fb6354f78))
- Add group identifier to qd-ui package and remove package config properties from example project ([89ea252](https://bitbucket.bit.admin.ch///commit/89ea252be0253a5949681610017965d0012e7052))
- add host listener ([b7d07dc](https://bitbucket.bit.admin.ch///commit/b7d07dc18edde54e3132a5b86930f20663036e00))
- Add missing import for test ([80e2e6b](https://bitbucket.bit.admin.ch///commit/80e2e6b49dcec0ae7b100e015221bbe9e994c496))
- add onDesproy life cicle hook ([dc1b982](https://bitbucket.bit.admin.ch///commit/dc1b982b01042fa00eb6a6839d5beba4e7245d17))
- add provider ([0c0124f](https://bitbucket.bit.admin.ch///commit/0c0124f0a2305157559c736ec2c6a184a350455c))
- add provider ([aed5b61](https://bitbucket.bit.admin.ch///commit/aed5b61eb2be3ca0c19b2e7d3d5fbb3849dce019))
- add provider ([dab7a17](https://bitbucket.bit.admin.ch///commit/dab7a17b8e2ee58c2a5d98d03280287dd6f6c96f))
- Add wrongly removed condition for uploading files ([f167db7](https://bitbucket.bit.admin.ch///commit/f167db74de9e63884d30976ecd06ec144b2b0552))
- Appearance of upload after it broke due to other changes ([8c24b92](https://bitbucket.bit.admin.ch///commit/8c24b921c909a400a9e2aa7c5cc6dbc99559b30a))
- Apply style for icons inside table DAZUIC-237 ([93415aa](https://bitbucket.bit.admin.ch///commit/93415aaaa4685a542c568c7541301ba862b9ffb0))
- banner ([7a16bac](https://bitbucket.bit.admin.ch///commit/7a16bac8363bda9bbfdd95ef824c096a6147b01f))
- border in panel title ([b5cbb3b](https://bitbucket.bit.admin.ch///commit/b5cbb3b0a19ed61691d618e1bb62355db93125b5))
- button position date picker ([faebfc5](https://bitbucket.bit.admin.ch///commit/faebfc5813be6d3207e040499a3f75d998af1b56))
- Caused error because variable is null DAZUIC-392 ([d061367](https://bitbucket.bit.admin.ch///commit/d06136797f14c0c085d349a42521ab2515c5a28c))
- Change version of sass function to improve legacy support ([018be06](https://bitbucket.bit.admin.ch///commit/018be06b3d8fd7586ca30911633e04c4a09af5a3))
- Condition for handling the stepper inside the layout container ([6b7cbc6](https://bitbucket.bit.admin.ch///commit/6b7cbc6121309b7c04d996ac177a96108980c04f))
- Copy wrong font face definition ([e0bd0c4](https://bitbucket.bit.admin.ch///commit/e0bd0c463451ff14806fcee341885ea5139d7338))
- Corrupt checksum of package DAZUIC-392 ([7e7c9d1](https://bitbucket.bit.admin.ch///commit/7e7c9d1550c4762d21f239ad812c5ea86a010014))
- custom bottons in table ([3939867](https://bitbucket.bit.admin.ch///commit/39398672cc44cb2171b97130b3c2a9a4fb7ca3c7))
- disable broken layout stories ([010aae3](https://bitbucket.bit.admin.ch///commit/010aae34dc82102dc761ffd9d25190e0366d3e28))
- Disabled state is updated on @Input change ([178392b](https://bitbucket.bit.admin.ch///commit/178392b2a04123096ef63322a4fe25136b59fa49))
- enable submit - assign to the input ([c2e237e](https://bitbucket.bit.admin.ch///commit/c2e237e90e67033ead10d832e57a2782c9c04419))
- error messages ([959c284](https://bitbucket.bit.admin.ch///commit/959c28436c2032452a202434ee8381c17cadec0e))
- export APP_ENVIRONMENT configuration of banner ([c83e8ad](https://bitbucket.bit.admin.ch///commit/c83e8ad05866fadf9144a9242cdbbce79a2c45c8))
- fix create function in container ([f1eab65](https://bitbucket.bit.admin.ch///commit/f1eab65fcf13f9933417d9d54044ae05dd22cb6b))
- fix icons ([679e4e1](https://bitbucket.bit.admin.ch///commit/679e4e1d1291dd6c6a69948a09a8527efd900e76))
- fix tabs without formGroup ([c5a7598](https://bitbucket.bit.admin.ch///commit/c5a75987db0792f9c1b3d0e71c3da8f8b7857dda))
- height of container header ([bb16026](https://bitbucket.bit.admin.ch///commit/bb16026772625a29c6115b1899dac7f737403135))
- icon button color ([5619870](https://bitbucket.bit.admin.ch///commit/56198703668d8991d03693f84ed6ad03da131ba8))
- Import fontawesome libs as zip archive due to pipeline failure DAZUIC-150 ([1fe9653](https://bitbucket.bit.admin.ch///commit/1fe96539d6701a11c2307f26ad4f5c9257d16bf9))
- import material component scss to fix style error ([29a6ffb](https://bitbucket.bit.admin.ch///commit/29a6ffb8367a5fdc2447ad4315432d2cd911f0b0))
- Import of global styles DAZUIC-150 ([817a8f9](https://bitbucket.bit.admin.ch///commit/817a8f94bc00b103dc0cb1677dd9cd1f1e41836c))
- imports ([391d17a](https://bitbucket.bit.admin.ch///commit/391d17a0d9d76882b85037bedfd658c1aea1954c))
- Karma config removed because jest is used DAZUIC-150 ([d40a6ab](https://bitbucket.bit.admin.ch///commit/d40a6ab89607f8b8cc21b66ac8d5e6f40d5536cb))
- limit letter count in header ([4de8f9c](https://bitbucket.bit.admin.ch///commit/4de8f9cdce7dd719c92e085f5f38de7f87f13c4a))
- Make import relative to prevent error ([dd5024b](https://bitbucket.bit.admin.ch///commit/dd5024b0d1b29eb35707b170e88c009be933d1e6))
- Make qd-icon inside mat-icon-button clickable ([b4d137a](https://bitbucket.bit.admin.ch///commit/b4d137ab86675451de861cda542629c9c770754e))
- margins full width conatainer ([a1e6e01](https://bitbucket.bit.admin.ch///commit/a1e6e01662bd4e190491d75dc6dfa020ae8dbe0f))
- Match of active tab link ([0dd3ec1](https://bitbucket.bit.admin.ch///commit/0dd3ec17532dc7b7ff618442a6668735e327d980))
- material forms ([f9cf71b](https://bitbucket.bit.admin.ch///commit/f9cf71bac29a6d9b577f29a4caec0a29e70a4eae))
- modals in scenarios ([355224d](https://bitbucket.bit.admin.ch///commit/355224d79ebc1341f7e338185f91abd66210bfc5))
- name as observable ([3265c1d](https://bitbucket.bit.admin.ch///commit/3265c1d1575a667e0ad76989b6b84ef7fb6b20d0))
- override frutiger ([d1cf5bd](https://bitbucket.bit.admin.ch///commit/d1cf5bdbb8a0dbe003541a7a94cbbb6193d833db))
- panel width ([948650e](https://bitbucket.bit.admin.ch///commit/948650e68104b4f143242887da74335cb825aa70))
- Pass environment to qd-ui by using forRoot method ([8fa3bdd](https://bitbucket.bit.admin.ch///commit/8fa3bddb4da4df998a7a36b99f71251767aef61b))
- qd button color ([32e4cd4](https://bitbucket.bit.admin.ch///commit/32e4cd4513682bd2edcc3cb6796b610d537b00e3))
- re-activate pph use cases ([282f13e](https://bitbucket.bit.admin.ch///commit/282f13e1895ff4b7ab166f0c7df1600094e8c608))
- Recognition of active route route ([99de056](https://bitbucket.bit.admin.ch///commit/99de056755a57a65d0e512cd920e079ebd4b2a93))
- reduce min-width ([9a832dd](https://bitbucket.bit.admin.ch///commit/9a832ddd9983e6029c0a80c73d03570d55f6ea45))
- remove console.log ([95ec4ed](https://bitbucket.bit.admin.ch///commit/95ec4ed4447df859c8661103a6e7598a53f06309))
- remove css-width ([bb9e6db](https://bitbucket.bit.admin.ch///commit/bb9e6db296053ed4f53279a4bbc36fdfbcec2c0f))
- Remove double forRoot declaration in route module ([0a34a17](https://bitbucket.bit.admin.ch///commit/0a34a17faecaf543eefbf67d013a923312ad12b4))
- Remove double forRoot declaration in route module ([a713fe2](https://bitbucket.bit.admin.ch///commit/a713fe2af75fec3da91d0afaf0a93dec33bd1fc1))
- Remove duplicate instantiating of TranslateModule ([fbd3330](https://bitbucket.bit.admin.ch///commit/fbd3330b35d36edd5992c300994ed7af79d6d988))
- Remove duplicate keys in environment.prod.ts ([fe44458](https://bitbucket.bit.admin.ch///commit/fe44458b246c6088b14f41e5ddfb33adbd3733c3))
- remove fonts ([c250d39](https://bitbucket.bit.admin.ch///commit/c250d39adfc1bdbedc9ccd7eabde54b0c5e2eae8))
- Remove NoopAnimationsModule from QdMaterialModule because it caused an "imported twice"-error when using lazy-loaded modules ([3c571c2](https://bitbucket.bit.admin.ch///commit/3c571c2e2cacf83f4c0f228dac67ae5f0cf137a6))
- Remove not working structure ([fccd2ab](https://bitbucket.bit.admin.ch///commit/fccd2ab7323a3d8967b954ec56819a5d1f2d4f6b))
- Remove overflow restriction to prevent hiding the language selection of the header-widget ([4b36e2a](https://bitbucket.bit.admin.ch///commit/4b36e2ab71d7012f1b868d4975fe214e4bbe4ba1))
- remove padding bottom of container ([40e78d0](https://bitbucket.bit.admin.ch///commit/40e78d0c0290b9cf3b638008607d2f5e97feb4eb))
- remove temp functins ([03eb844](https://bitbucket.bit.admin.ch///commit/03eb844e11ba0bf66a1a317770d9ee2ea1ec4b48))
- resolve merge conflicts ([a127f56](https://bitbucket.bit.admin.ch///commit/a127f561bcc19eb6c43ce5a1b825e705d84679cd))
- Return correct type for auth helper function ([fc2a07f](https://bitbucket.bit.admin.ch///commit/fc2a07fdf0e5f2f6ccb50fa6bc513d0f99dfd80f))
- small update ([46d992c](https://bitbucket.bit.admin.ch///commit/46d992cca175010f398cee1a17c402b4363908c5))
- stepper - save on step item ([b7aa1dd](https://bitbucket.bit.admin.ch///commit/b7aa1dd435b020fa12dfec701eafb4d24b60cafc))
- style in container section subheader ([b64e169](https://bitbucket.bit.admin.ch///commit/b64e1695dbec362853baea5dfab3e8f3e7d67e81))
- styling issues due to oblique ([3fe0505](https://bitbucket.bit.admin.ch///commit/3fe0505a025801009771d31c393a71a9bf5f2901))
- table container css ([422858c](https://bitbucket.bit.admin.ch///commit/422858c3e84b48b6989480e0eeb79fb036afe2a5))
- translation step button ([cc9a6fb](https://bitbucket.bit.admin.ch///commit/cc9a6fbc8141af3e91ee6ae51e19900ad24d0127))
- truncated text ([9a5cec6](https://bitbucket.bit.admin.ch///commit/9a5cec64abb02ff44291fb458e1d86652ffef592))
- Ts lint problems ([9c8fed5](https://bitbucket.bit.admin.ch///commit/9c8fed5b0ec7243898df46e4373df3114186293d))
- Ts lint problems ([d63af52](https://bitbucket.bit.admin.ch///commit/d63af521ea30ef964fd20365ee78d69713e9c993))
- Typo ([16ddb7c](https://bitbucket.bit.admin.ch///commit/16ddb7c61ddab17fa09321498d97160e68f52e42))
- update components ([f439d98](https://bitbucket.bit.admin.ch///commit/f439d98ac82061d45fe1da72f0a54920ebc518ec))
- update conditions ([7d70ebc](https://bitbucket.bit.admin.ch///commit/7d70ebc3cb7d2ef1ec33df5e7fc213a1b00e6cfe))
- update marginin table ([084f480](https://bitbucket.bit.admin.ch///commit/084f48039ae6f428d122aeee0c57ca85db917e3b))
- update snapshots ([1d664a6](https://bitbucket.bit.admin.ch///commit/1d664a615e8feda9a42c1cae38d19486e6e05dbb))
- update version ([f62d562](https://bitbucket.bit.admin.ch///commit/f62d562eb947270c1cefea8d69436e701392bb30))
- update version ([8273dbf](https://bitbucket.bit.admin.ch///commit/8273dbfbcb370f74c1b0e1cdffa6483630bce8eb))
- use 100% height of html ([1d19d86](https://bitbucket.bit.admin.ch///commit/1d19d867f54b50753178dfb60799466b47bb50cd))
- use new list element ([5ca6c82](https://bitbucket.bit.admin.ch///commit/5ca6c82ff030b3bbb36b1aa511bedb9aea7f7efc))
- vertical gap in vertical pairs ([95f02fd](https://bitbucket.bit.admin.ch///commit/95f02fdcef7643b3ad4e1b02d14e0ba4f53119a9))
