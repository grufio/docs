const fs = require('fs');
const os = require('os');
const cp = require('child_process');
const isWindows = os.platform() === 'win32';
let output;
try {
  output = require('@nx/workspace').output;
} catch (e) {
  console.warn(
    'Angular CLI could not be decorated to enable computation caching. Please ensure @nx/workspace is installed.'
  );
  process.exit(0);
}

function symlinkNgCLItoNxCLI() {
  try {
    const ngPath = './node_modules/.bin/ng';
    const nxPath = './node_modules/.bin/nx';
    if (isWindows) {
      ['', '.cmd', '.ps1'].forEach(ext => {
        if (fs.existsSync(nxPath + ext)) fs.writeFileSync(ngPath + ext, fs.readFileSync(nxPath + ext));
      });
    } else {
      cp.execSync(`ln -sf ./nx ${ngPath}`);
    }
  } catch (e) {
    output.error({ title: 'Unable to create a symlink from the Angular CLI to the Nx CLI:' + e.message });
    throw e;
  }
}

try {
  symlinkNgCLItoNxCLI();
  require('nx/src/adapter/decorate-cli').decorateCli();
  output.log({ title: 'Angular CLI has been decorated to enable computation caching.' });
} catch (e) {
  output.error({ title: 'Decoration of the Angular CLI did not complete successfully' });
}
